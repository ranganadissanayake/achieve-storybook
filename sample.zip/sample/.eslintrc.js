export default {
  root: true,
  extends: ["custom", "plugin:storybook/recommended"],
  settings: {
    next: {
      rootDir: ["apps/*/"],
    },
  },
};
