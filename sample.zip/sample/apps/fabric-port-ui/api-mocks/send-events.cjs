module.exports = {
  url: "/api/v1/globalfabric/monitors/event-notifications",
  method: "post",
  status: 200,
  mock: {},
};
