module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/customer-premises-orders",
  method: "patch",
  mock: {
    result: {
      externalId: "0nYH4G3k-KiKv-aBYK-NflD-1Z4oDz6Im5DP",
      productOrderItem: [
        {
          id: "0nYH4G3k-KiKv-aBYK-NflD-1Z4oDz6Im5DP",
          action: "modify",
        },
      ],
      state: "acknowledged",
      type: "ProductOrder",
      serviceId: "Sinprefix-YY-90000-00001",
      requestId: "BTC1234567",
    },
  },
};
