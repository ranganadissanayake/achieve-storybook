module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/customer-premises-quotes/*",
  method: "get",
  status: 200,
  mock: {
    quoteId: "0Q03L000000R8kzSAC",
    quoteStatus: "approved",
    actualCompletion: "",
    validFrom: "The date & time the quote is valid from",
    validTo: "The date & time the quote is valid to",
    pricing: {
      primaryPortPrice: {
        oneTimePrice: 0,
        recurringMonthlyPrice: 1477,
      },
      primaryConnectivityPrice: {
        oneTimePrice: 105,
        recurringMonthlyPrice: 105,
      },
      secondaryPortPrice: {
        oneTimePrice: 0,
        recurringMonthlyPrice: 1477,
      },
      secondaryConnectivityPrice: {
        oneTimePrice: 105,
        recurringMonthlyPrice: 105,
      },
    },
    totalPrice: {
      oneTimePrice: 210,
      recurringMonthlyPrice: 3164,
    },
    currencyFormat: "GBP",
    portTerm: 365,
    primaryPort: { siteId: "1510772" },
    secondaryPort: { siteId: "" },
  },
};
