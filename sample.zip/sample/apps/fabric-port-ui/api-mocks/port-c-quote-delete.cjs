module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/customer-premises-quotes/*",
  method: "delete",
  status: 204,
  mock: {},
};
