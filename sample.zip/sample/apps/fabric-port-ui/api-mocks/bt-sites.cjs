module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/sites",
  method: "post",
  mock: [
    {
      siteId: "ST1096474",
      siteType: {
        btPop: false,
        dataCentre: true,
      },
      facilityProvider: "Equinix",
      siteStatus: "up",
      facilityName: "Equinix LA1 - 600 W 7th St, Los Angeles, CA 90017, USA",
      metroName: "Berlin",
      metroCode: "BE",
      facilityAddress: {
        siteAddressLine1: "600",
        siteAddressLine2: "West 7th Street",
        city: "Los Angeles",
        countyOrState: "California",
        postcode: "90017",
        country: "United States",
        latitude: 34.0472718,
        longitude: -118.2571581,
      },
      products: {
        customerPorts: {
          portOnly: [1000, 10000, 25000, 100000],
          dataCentreConnection: [
            4000, 8000, 2500, 1000, 5000, 9000, 9800, 10000, 2000, 6000, 7000,
            3000, 9500,
          ],
        },
        networkServices: {
          ipVPN: true,
          internet: true,
          eLine: true,
          ipRegionCode: "US-2",
        },
      },
    },
    {
      siteId: "AUMELA005",
      siteType: {
        btPop: true,
        dataCentre: false,
      },
      siteStatus: "down",
      facilityProvider: "NextDC",
      facilityName: "Melbourne NextDC M1 Lorimer Street 826",
      metroName: "Perth",
      metroCode: "PE",
      facilityAddress: {
        siteAddressLine1: "826",
        siteAddressLine2: "LORIMER STREET",
        city: "MELBOURNE",
        countyOrState: "VICTORIA",
        postcode: "3207",
        country: "Australia",
        latitude: -37.8226323,
        longitude: 144.9321032,
      },
      products: {
        customerPorts: {
          portOnly: [1000, 10000, 25000, 100000],
          dataCentreConnection: null,
        },
        networkServices: {
          ipVPN: true,
          internet: true,
          eLine: true,
          ipRegionCode: "AU-01",
        },
      },
    },
  ],
};
