module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-internet-connections/search",
  method: "post",
  mock: {
    results: [
      {
        name: "Internet-Test19",
        description: "This is a nice port",
        isResilient: false,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000AskexQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00001",
          portId: "02i3GA10001ljL8QAI",
          VLANID: 2032,
          mtu: 1499,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "100.9.8.29",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AskBJQAZ",
              LANConfig: [
                {
                  LANId: "02i3L00000AskBOQAZ",
                },
              ],
              BTWANAddress: "100.9.8.28",
              CustomerWANAddress: "100.9.8.29",
              isDHCP: true,
            },
          },
          staticBandwidthConfig: {
            staticBandwidth: 50,
            isStaticBandwidthThreshold: false,
          },
        },
      },
      {
        name: "Internet-Test23",
        description: "",
        isResilient: false,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000AsmyLQAR",
          serviceId: "Sinprefix-SPEC-IN-90000-00002",
          portId: "02i3GA10001ljL8QAI",
          VLANID: 2030,
          mtu: 1459,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "burstable",
          isBFD: false,
          IPVersion: "ipv6",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv6Config: {
                bgpPeerAddress: "1fab:dad:1111:2222::db08:c2b9",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: true,
          IPAddressConfiguration: {
            ipv6Config: {
              WANId: "02i3L00000AsmsaQAB",
              LANConfig: [
                {
                  LANId: "02i3L00000AsmsfQAB",
                },
              ],
              BTWANAddress: "1fab:dad:1111:2222::db08:c2b8",
              CustomerWANAddress: "1fab:dad:1111:2222::db08:c2b9",
            },
          },
          isPredictiveMonitoring: true,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 1,
            burstableMaxBandwidth: 2,
            isBurstableBandwidthThreshold: false,
          },
        },
      },
      {
        name: "Internet-Test25",
        description: "",
        isResilient: false,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000Asn4vQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00003",
          portId: "02i3GA00009ljL8QAI",
          VLANID: 2029,
          mtu: 1460,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "burstable",
          isBFD: false,
          IPVersion: "dual",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-and-on-net",
              ipv4Config: {
                bgpPeerAddress: "100.9.8.33",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
              ipv6Config: {
                bgpPeerAddress: "1fab:dad:1111:2222::f7c8:ff1e",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: true,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000Asn3mQAB",
              LANConfig: [
                {
                  LANId: "02i3L00000Asn4SQAR",
                },
              ],
              BTWANAddress: "100.9.8.32",
              CustomerWANAddress: "100.9.8.33",
              isDHCP: true,
            },
            ipv6Config: {
              WANId: "02i3L00000Asn3UQAR",
              LANConfig: [
                {
                  LANId: "02i3L00000AsmsfQAB",
                },
              ],
              BTWANAddress: "1fab:dad:1111:2222::f7c8:ff1d",
              CustomerWANAddress: "1fab:dad:1111:2222::f7c8:ff1e",
            },
          },
          isPredictiveMonitoring: true,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 100,
            burstableMaxBandwidth: 200,
            isBurstableBandwidthThreshold: false,
          },
        },
      },
      {
        name: "Dev Testing Jan22",
        description: "",
        isResilient: false,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000AsjQ9QAJ",
          serviceId: "Sinprefix-SPEC-IN-90000-00004",
          portId: "02i3L00000Amw8aQAB",
          VLANID: 2030,
          mtu: 1489,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "100.9.8.117",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: false,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AsjPfQAJ",
              LANConfig: [],
              BTWANAddress: "100.9.8.116",
              CustomerWANAddress: "100.9.8.117",
              isDHCP: false,
            },
          },
          staticBandwidthConfig: {
            staticBandwidth: 50,
            isStaticBandwidthThreshold: false,
          },
        },
      },
      {
        name: "DualStack-Test02-02-02-24",
        description: "",
        isResilient: false,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000AspVSQAZ",
          serviceId: "Sinprefix-SPEC-IN-90000-00005",
          portId: "02i3L00000AspUvQAJ",
          VLANID: 2032,
          mtu: 1452,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: false,
          IPVersion: "dual",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "60.0.0.58",
                ebgpMultihop: "2",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
              ipv6Config: {
                bgpPeerAddress: "2a00:2000:2000:8::",
                ebgpMultihop: "2",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AspUrQAJ",
              LANConfig: [
                {
                  LANId: "02i3L00000AspUhQAJ",
                },
              ],
              BTWANAddress: "60.0.0.57",
              CustomerWANAddress: "60.0.0.58",
              isDHCP: false,
            },
            ipv6Config: {
              WANId: "02i3L00000AspVGQAZ",
              LANConfig: [
                {
                  LANId: "02i3L00000AspV1QAJ",
                },
              ],
              BTWANAddress: "2a00:2000:2000:8::1",
              CustomerWANAddress: "2a00:2000:2000:8::2",
            },
          },
          staticBandwidthConfig: {
            staticBandwidth: 75,
            isStaticBandwidthThreshold: false,
          },
        },
      },
      {
        name: "DualStack-Test06-07-02-24",
        description: "",
        isResilient: false,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000AsqvGQAR",
          serviceId: "Sinprefix-SPEC-IN-90000-00006",
          portId: "02i3L00000AsqtbQAB",
          VLANID: 2044,
          mtu: 1449,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: false,
          IPVersion: "dual",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "60.0.0.14",
                ebgpMultihop: "2",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
              ipv6Config: {
                bgpPeerAddress: "2a00:2000:2001:1::",
                ebgpMultihop: "2",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AsquMQAR",
              LANConfig: [
                {
                  LANId: "02i3L00000AsqtwQAB",
                },
              ],
              BTWANAddress: "60.0.0.13",
              CustomerWANAddress: "60.0.0.14",
              isDHCP: false,
            },
            ipv6Config: {
              WANId: "02i3L00000AsqufQAB",
              LANConfig: [
                {
                  LANId: "02i3L00000AsquaQAB",
                },
              ],
              BTWANAddress: "2a00:2000:2001:1::1",
              CustomerWANAddress: "2a00:2000:2001:1::2",
            },
          },
          staticBandwidthConfig: {
            staticBandwidth: 50,
            isStaticBandwidthThreshold: false,
          },
        },
      },
      {
        name: "IPV4RealNaas-Test01-12-02-24",
        description: "",
        isResilient: true,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000AssI4QAJ",
          serviceId: "Sinprefix-SPEC-IN-90000-00007",
          portId: "02i3GA10001ljL8QAI",
          VLANID: 2047,
          mtu: 1495,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "burstable",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "60.0.0.22",
                ebgpMultihop: "2",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AsrlEQAR",
              LANConfig: [],
              BTWANAddress: "60.0.0.21",
              CustomerWANAddress: "60.0.0.22",
              isDHCP: false,
            },
          },
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 100,
            burstableMaxBandwidth: 200,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00000AsmcpQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00008",
          portId: "02i3GA10001ljL8QAI",
          VLANID: 2030,
          mtu: 1491,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "100.9.8.26",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: true,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AslOjQAJ",
              LANConfig: [
                {
                  LANId: "02i3L00000AskBOQAZ",
                },
              ],
              BTWANAddress: "100.9.8.25",
              CustomerWANAddress: "100.9.8.26",
              isDHCP: true,
            },
          },
          isPredictiveMonitoring: true,
          staticBandwidthConfig: {
            staticBandwidth: 20,
            isStaticBandwidthThreshold: true,
            staticMinBandwidthThreshold: 10,
            staticMaxBandwidthThreshold: 90,
          },
        },
      },
      {
        name: "DualStack-Test07-05-02-24",
        description: "",
        isResilient: true,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000AsqGDQAZ",
          serviceId: "Sinprefix-SPEC-IN-90000-00009",
          portId: "02i3GA10001ljL8QAI",
          VLANID: 2033,
          mtu: 1493,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: false,
          IPVersion: "dual",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "60.0.0.66",
                ebgpMultihop: "2",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
              ipv6Config: {
                bgpPeerAddress: "2a00:2000:2000:9::",
                ebgpMultihop: "2",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AsqCLQAZ",
              LANConfig: [
                {
                  LANId: "02i3L00000AsqCGQAZ",
                },
              ],
              BTWANAddress: "60.0.0.65",
              CustomerWANAddress: "60.0.0.66",
              isDHCP: false,
            },
            ipv6Config: {
              WANId: "02i3L00000AsqCfQAJ",
              LANConfig: [
                {
                  LANId: "02i3L00000AsqCQQAZ",
                },
              ],
              BTWANAddress: "2a00:2000:2000:9::1",
              CustomerWANAddress: "2a00:2000:2000:9::2",
            },
          },
          staticBandwidthConfig: {
            staticBandwidth: 75,
            isStaticBandwidthThreshold: false,
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00000AsmcpQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00010",
          portId: "02i3GA10001ljL8QAI",
          VLANID: 2030,
          mtu: 1498,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "100.9.8.26",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: true,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AslOjQAJ",
              LANConfig: [
                {
                  LANId: "02i3L00000AskBOQAZ",
                },
              ],
              BTWANAddress: "100.9.8.25",
              CustomerWANAddress: "100.9.8.26",
              isDHCP: true,
            },
          },
          isPredictiveMonitoring: true,
          staticBandwidthConfig: {
            staticBandwidth: 20,
            isStaticBandwidthThreshold: true,
            staticMinBandwidthThreshold: 10,
            staticMaxBandwidthThreshold: 90,
          },
        },
      },
      {
        name: "Test01-Krishna-12-03-24",
        description: "",
        isResilient: true,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000AssI4QAJ",
          serviceId: "Sinprefix-SPEC-IN-90000-00011",
          portId: "02i3GA10004ljL8QAI",
          VLANID: 2047,
          mtu: 1499,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "burstable",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "60.0.0.22",
                ebgpMultihop: "2",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AsrlEQAR",
              LANConfig: [],
              BTWANAddress: "60.0.0.21",
              CustomerWANAddress: "60.0.0.22",
              isDHCP: false,
            },
          },
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 100,
            burstableMaxBandwidth: 200,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00000AsmcpQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00012",
          portId: "02i3GA10004ljL8QAI",
          VLANID: 2030,
          mtu: 1499,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "100.9.8.26",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: true,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AslOjQAJ",
              LANConfig: [
                {
                  LANId: "02i3L00000AskBOQAZ",
                },
              ],
              BTWANAddress: "100.9.8.25",
              CustomerWANAddress: "100.9.8.26",
              isDHCP: true,
            },
          },
          isPredictiveMonitoring: true,
          staticBandwidthConfig: {
            staticBandwidth: 20,
            isStaticBandwidthThreshold: true,
            staticMinBandwidthThreshold: 10,
            staticMaxBandwidthThreshold: 90,
          },
        },
      },
      {
        name: "Test02-Krishna-12-03-24",
        description: "",
        isResilient: true,
        billingAccountId: "SBE202306061740",
        primaryConnection: {
          connectionId: "02i3L00000AssI4QAJ",
          serviceId: "Sinprefix-SPEC-IN-90000-00013",
          portId: "02i3GA10005ljL8QAI",
          VLANID: 2047,
          mtu: 1475,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "burstable",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "60.0.0.22",
                ebgpMultihop: "2",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AsrlEQAR",
              LANConfig: [],
              BTWANAddress: "60.0.0.21",
              CustomerWANAddress: "60.0.0.22",
              isDHCP: false,
            },
          },
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 100,
            burstableMaxBandwidth: 200,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00000AsmcpQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00014",
          portId: "02i3GA10005ljL8QAI",
          VLANID: 2030,
          mtu: 1478,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "100.9.8.26",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: true,
                enableAdvanceBGP: "",
              },
            },
          },
          isTelemetryStreamingEnabled: true,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AslOjQAJ",
              LANConfig: [
                {
                  LANId: "02i3L00000AskBOQAZ",
                },
              ],
              BTWANAddress: "100.9.8.25",
              CustomerWANAddress: "100.9.8.26",
              isDHCP: true,
            },
          },
          isPredictiveMonitoring: true,
          staticBandwidthConfig: {
            staticBandwidth: 20,
            isStaticBandwidthThreshold: true,
            staticMinBandwidthThreshold: 10,
            staticMaxBandwidthThreshold: 90,
          },
        },
      },
      {
        name: "Vaji-18Mar24-burst-ip4-bgp",
        description: "Test connection created on 18-Mar-2024",
        isResilient: false,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00001AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00015",
          portId: "02i3L00003At0LAQAZ",
          VLANID: 2030,
          mtu: 1492,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "burstable",
          isBFD: false,
          IPVersion: "ipv4",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "100.9.8.125",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: false,
                enableAdvanceBGP: false,
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQETQA5",
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
              ],
              BTWANAddress: "100.9.8.125",
              CustomerWANAddress: "100.9.8.126",
              isDHCP: true,
            },
          },
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 11111,
            burstableMaxBandwidth: 22222,
            isBurstableBandwidthThreshold: false,
          },
        },
      },
      {
        name: "Vaji-18Mar24-static-ip6-bgp",
        description: "Test connection created on 18-Mar-2024",
        isResilient: false,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00002AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00016",
          portId: "02i3L00003At0LAQAZ",
          VLANID: 2032,
          mtu: 1499,
          encapsulation: "dot1q",
          isEnabled: true,
          bandwidthType: "static",
          isBFD: true,
          IPVersion: "ipv6",
          routingType: "bgp",
          routingConfig: {
            bgpConfig: {
              ASNType: "private",
              bgpPeerASN: "65530",
              btRoutesAdvertised: "default-only",
              ipv4Config: {
                bgpPeerAddress: "A::B001",
                ebgpMultihop: "",
                gracefulRestart: false,
                isMD5Authentication: false,
                enableAdvanceBGP: false,
              },
            },
          },
          isTelemetryStreamingEnabled: false,
          isPredictiveMonitoring: true,
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000AThlWQAT",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
              BTWANAddress: "A::B001",
              CustomerWANAddress: "A::B002",
              isDHCP: false,
            },
          },
          staticBandwidthConfig: {
            staticBandwidth: 10,
            isStaticBandwidthThreshold: true,
            staticMinBandwidthThreshold: 10,
            staticMaxBandwidthThreshold: 90,
          },
        },
      },
      {
        name: "Vaji-18Mar-static-ip4&6-static",
        description: "Static routing test connection.",
        isResilient: true,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00003AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00017",
          portId: "02i3L00003At0LAQAZ",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 200,
          mtu: 1491,
          bandwidthType: "static",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: true,
          staticBandwidthConfig: {
            staticBandwidth: 123,
            isStaticBandwidthThreshold: true,
            staticMinBandwidthThreshold: 10,
            staticMaxBandwidthThreshold: 90,
          },
          isBFD: true,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQETQA5",
              BTWANAddress: "100.9.8.125",
              CustomerWANAddress: "100.9.8.126",
              isDHCP: false,
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
                {
                  LANId: "0013453F000k6GAD",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThlWQAT",
              BTWANAddress: "A::B002",
              CustomerWANAddress: "A::B003",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.10",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.11",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
                  prefixLength: 127,
                  priority: 1,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
                  prefixLength: 127,
                  priority: 2,
                },
              ],
            },
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00004AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00019",
          portId: "02i3L00003At0LAQAZ",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 2002,
          bandwidthType: "static",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: true,
          staticBandwidthConfig: {
            staticBandwidth: 321,
            isStaticBandwidthThreshold: true,
            staticMinBandwidthThreshold: 15,
            staticMaxBandwidthThreshold: 95,
          },
          isBFD: false,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQFgQAP",
              BTWANAddress: "100.9.8.48",
              CustomerWANAddress: "100.9.8.49",
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThkzQAD",
              BTWANAddress: "1fab:dad:1111:2222::0d90:a65e",
              CustomerWANAddress: "1fab:dad:1111:2222::0d90:a65f",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.12",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.13",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ac",
                  prefixLength: 127,
                  priority: 2,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ad",
                  prefixLength: 127,
                  priority: 1,
                },
              ],
            },
          },
        },
      },
      {
        name: "Vaji-18Mar-burs-ip4&6-static",
        description: "Static routing test connection.",
        isResilient: true,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00005AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00020",
          portId: "02i3L00001At0LAQAZ",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 200,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: false,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 30,
            burstableMaxBandwidth: 1020,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
          isBFD: true,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQETQA5",
              BTWANAddress: "100.9.8.125",
              CustomerWANAddress: "100.9.8.126",
              isDHCP: false,
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
                {
                  LANId: "0013453F000k6GAD",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThlWQAT",
              BTWANAddress: "A::B002",
              CustomerWANAddress: "A::B003",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.10",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.11",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
                  prefixLength: 127,
                  priority: 1,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
                  prefixLength: 127,
                  priority: 2,
                },
              ],
            },
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00006AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00021",
          portId: "02i3L00002At0LAQAZ",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 2002,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: true,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 555,
            burstableMaxBandwidth: 999,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 1,
            burstableMinCommitMaxThreshold: 99,
            burstableMaxBandwidthMinThreshold: 1,
            burstableMaxBandwidthMaxThreshold: 99,
          },
          isBFD: false,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQFgQAP",
              BTWANAddress: "100.9.8.48",
              CustomerWANAddress: "100.9.8.49",
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThkzQAD",
              BTWANAddress: "1fab:dad:1111:2222::0d90:a65e",
              CustomerWANAddress: "1fab:dad:1111:2222::0d90:a65f",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.12",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.13",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ac",
                  prefixLength: 127,
                  priority: 2,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ad",
                  prefixLength: 127,
                  priority: 1,
                },
              ],
            },
          },
        },
      },
      {
        name: "Datacenter Connection - Same Pop",
        description: "Static routing test connection.",
        isResilient: true,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00005AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00022",
          portId: "7B1D90C8B23C46F9B47D9F3DA1D50E10",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 200,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: false,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 30,
            burstableMaxBandwidth: 1020,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
          isBFD: true,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQETQA5",
              BTWANAddress: "100.9.8.125",
              CustomerWANAddress: "100.9.8.126",
              isDHCP: false,
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
                {
                  LANId: "0013453F000k6GAD",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThlWQAT",
              BTWANAddress: "A::B002",
              CustomerWANAddress: "A::B003",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.10",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.11",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
                  prefixLength: 127,
                  priority: 1,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
                  prefixLength: 127,
                  priority: 2,
                },
              ],
            },
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00006AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00023",
          portId: "BB1BECB7CDF64BB4A1850D9C523EADBE",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 2002,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: true,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 555,
            burstableMaxBandwidth: 999,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 1,
            burstableMinCommitMaxThreshold: 99,
            burstableMaxBandwidthMinThreshold: 1,
            burstableMaxBandwidthMaxThreshold: 99,
          },
          isBFD: false,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQFgQAP",
              BTWANAddress: "100.9.8.48",
              CustomerWANAddress: "100.9.8.49",
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThkzQAD",
              BTWANAddress: "1fab:dad:1111:2222::0d90:a65e",
              CustomerWANAddress: "1fab:dad:1111:2222::0d90:a65f",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.12",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.13",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ac",
                  prefixLength: 127,
                  priority: 2,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ad",
                  prefixLength: 127,
                  priority: 1,
                },
              ],
            },
          },
        },
      },
      {
        name: "Datacenter Connection - Dual Pop",
        description: "Static routing test connection.",
        isResilient: true,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00005AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00024",
          portId: "E651D4234C1C48AD8FF5538D654C235D",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 200,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: false,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 30,
            burstableMaxBandwidth: 1020,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
          isBFD: true,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQETQA5",
              BTWANAddress: "100.9.8.125",
              CustomerWANAddress: "100.9.8.126",
              isDHCP: false,
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
                {
                  LANId: "0013453F000k6GAD",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThlWQAT",
              BTWANAddress: "A::B002",
              CustomerWANAddress: "A::B003",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.10",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.11",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
                  prefixLength: 127,
                  priority: 1,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
                  prefixLength: 127,
                  priority: 2,
                },
              ],
            },
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00006AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00025",
          portId: "3038E5A157B244938E67FBE8B39C0C38",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 2002,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: true,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 555,
            burstableMaxBandwidth: 999,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 1,
            burstableMinCommitMaxThreshold: 99,
            burstableMaxBandwidthMinThreshold: 1,
            burstableMaxBandwidthMaxThreshold: 99,
          },
          isBFD: false,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQFgQAP",
              BTWANAddress: "100.9.8.48",
              CustomerWANAddress: "100.9.8.49",
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThkzQAD",
              BTWANAddress: "1fab:dad:1111:2222::0d90:a65e",
              CustomerWANAddress: "1fab:dad:1111:2222::0d90:a65f",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.12",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.13",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ac",
                  prefixLength: 127,
                  priority: 2,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ad",
                  prefixLength: 127,
                  priority: 1,
                },
              ],
            },
          },
        },
      },
      {
        name: "Datacenter Connection - Split Site",
        description: "Static routing test connection.",
        isResilient: true,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00005AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00026",
          portId: "D4F2F5811417450591EA39E86070BBD9",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 200,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: false,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 30,
            burstableMaxBandwidth: 1020,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
          isBFD: true,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQETQA5",
              BTWANAddress: "100.9.8.125",
              CustomerWANAddress: "100.9.8.126",
              isDHCP: false,
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
                {
                  LANId: "0013453F000k6GAD",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThlWQAT",
              BTWANAddress: "A::B002",
              CustomerWANAddress: "A::B003",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.10",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.11",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
                  prefixLength: 127,
                  priority: 1,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
                  prefixLength: 127,
                  priority: 2,
                },
              ],
            },
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00006AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00027",
          portId: "7DBDF4EB53A449CAB8BDC6B9E944C069",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 2002,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: true,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 555,
            burstableMaxBandwidth: 999,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 1,
            burstableMinCommitMaxThreshold: 99,
            burstableMaxBandwidthMinThreshold: 1,
            burstableMaxBandwidthMaxThreshold: 99,
          },
          isBFD: false,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQFgQAP",
              BTWANAddress: "100.9.8.48",
              CustomerWANAddress: "100.9.8.49",
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThkzQAD",
              BTWANAddress: "1fab:dad:1111:2222::0d90:a65e",
              CustomerWANAddress: "1fab:dad:1111:2222::0d90:a65f",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.12",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.13",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ac",
                  prefixLength: 127,
                  priority: 2,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ad",
                  prefixLength: 127,
                  priority: 1,
                },
              ],
            },
          },
        },
      },
      {
        name: "Customer Premise - Same Pop",
        description: "Static routing test connection.",
        isResilient: true,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00005AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00028",
          portId: "72919148371B4CB794B0F37C2F510BDC",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 200,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: false,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 30,
            burstableMaxBandwidth: 1020,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
          isBFD: true,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQETQA5",
              BTWANAddress: "100.9.8.125",
              CustomerWANAddress: "100.9.8.126",
              isDHCP: false,
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
                {
                  LANId: "0013453F000k6GAD",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThlWQAT",
              BTWANAddress: "A::B002",
              CustomerWANAddress: "A::B003",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.10",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.11",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
                  prefixLength: 127,
                  priority: 1,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
                  prefixLength: 127,
                  priority: 2,
                },
              ],
            },
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00006AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00029",
          portId: "0B31E2A652364F938ED3CC44F6EA12F0",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 2002,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: true,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 555,
            burstableMaxBandwidth: 999,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 1,
            burstableMinCommitMaxThreshold: 99,
            burstableMaxBandwidthMinThreshold: 1,
            burstableMaxBandwidthMaxThreshold: 99,
          },
          isBFD: false,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQFgQAP",
              BTWANAddress: "100.9.8.48",
              CustomerWANAddress: "100.9.8.49",
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThkzQAD",
              BTWANAddress: "1fab:dad:1111:2222::0d90:a65e",
              CustomerWANAddress: "1fab:dad:1111:2222::0d90:a65f",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.12",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.13",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ac",
                  prefixLength: 127,
                  priority: 2,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ad",
                  prefixLength: 127,
                  priority: 1,
                },
              ],
            },
          },
        },
      },
      {
        name: "Customer Premise - Dual Pop",
        description: "Static routing test connection.",
        isResilient: true,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00005AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00030",
          portId: "299F131A33D340FC9A5D8D95E780B50E",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 200,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: false,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 30,
            burstableMaxBandwidth: 1020,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
          isBFD: true,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQETQA5",
              BTWANAddress: "100.9.8.125",
              CustomerWANAddress: "100.9.8.126",
              isDHCP: false,
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
                {
                  LANId: "0013453F000k6GAD",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThlWQAT",
              BTWANAddress: "A::B002",
              CustomerWANAddress: "A::B003",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.10",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.11",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
                  prefixLength: 127,
                  priority: 1,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
                  prefixLength: 127,
                  priority: 2,
                },
              ],
            },
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00006AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00031",
          portId: "50A6750DA8224EF386508B0187C3A797",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 2002,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: true,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 555,
            burstableMaxBandwidth: 999,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 1,
            burstableMinCommitMaxThreshold: 99,
            burstableMaxBandwidthMinThreshold: 1,
            burstableMaxBandwidthMaxThreshold: 99,
          },
          isBFD: false,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQFgQAP",
              BTWANAddress: "100.9.8.48",
              CustomerWANAddress: "100.9.8.49",
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThkzQAD",
              BTWANAddress: "1fab:dad:1111:2222::0d90:a65e",
              CustomerWANAddress: "1fab:dad:1111:2222::0d90:a65f",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.12",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.13",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ac",
                  prefixLength: 127,
                  priority: 2,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ad",
                  prefixLength: 127,
                  priority: 1,
                },
              ],
            },
          },
        },
      },
      {
        name: "Customer Premise - Split Site",
        description: "Static routing test connection.",
        isResilient: true,
        billingAccountId: "0013L00000YobLzQAJ",
        primaryConnection: {
          connectionId: "02i3L00005AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00032",
          portId: "28781947DFC4498B98A7766EC6B718F3",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 200,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: false,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 30,
            burstableMaxBandwidth: 1020,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 30,
            burstableMinCommitMaxThreshold: 60,
            burstableMaxBandwidthMinThreshold: 30,
            burstableMaxBandwidthMaxThreshold: 60,
          },
          isBFD: true,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQETQA5",
              BTWANAddress: "100.9.8.125",
              CustomerWANAddress: "100.9.8.126",
              isDHCP: false,
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
                {
                  LANId: "0013453F000k6GAD",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThlWQAT",
              BTWANAddress: "A::B002",
              CustomerWANAddress: "A::B003",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.10",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.11",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
                  prefixLength: 127,
                  priority: 1,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
                  prefixLength: 127,
                  priority: 2,
                },
              ],
            },
          },
        },
        secondaryConnection: {
          connectionId: "02i3L00006AskqwQAB",
          serviceId: "Sinprefix-SPEC-IN-90000-00033",
          portId: "5B6FED2B436B4D86BFC2628FCD2DE3ED",
          isEnabled: true,
          encapsulation: "dot1q",
          VLANID: 2002,
          bandwidthType: "burstable",
          isTelemetryStreamingEnabled: true,
          isPredictiveMonitoring: true,
          burstableBandwidthConfig: {
            burstableMinCommitBandwidth: 555,
            burstableMaxBandwidth: 999,
            isBurstableBandwidthThreshold: true,
            burstableMinCommitMinThreshold: 1,
            burstableMinCommitMaxThreshold: 99,
            burstableMaxBandwidthMinThreshold: 1,
            burstableMaxBandwidthMaxThreshold: 99,
          },
          isBFD: false,
          IPVersion: "dual-stack",
          IPAddressConfiguration: {
            ipv4Config: {
              WANId: "02i3L00000ATQFgQAP",
              BTWANAddress: "100.9.8.48",
              CustomerWANAddress: "100.9.8.49",
              LANConfig: [
                {
                  LANId: "02i3L00000AThQBQA1",
                },
              ],
            },
            ipv6Config: {
              WANId: "02i3L00000AThkzQAD",
              BTWANAddress: "1fab:dad:1111:2222::0d90:a65e",
              CustomerWANAddress: "1fab:dad:1111:2222::0d90:a65f",
              LANConfig: [
                {
                  LANId: "02i3L00000ATTcwQAH",
                },
              ],
            },
          },
          routingType: "static",
          routingConfig: {
            staticConfig: {
              ipv4Config: [
                {
                  prefix: "192.168.0.12",
                  prefixLength: 27,
                  priority: 1,
                },
                {
                  prefix: "192.168.0.13",
                  prefixLength: 29,
                  priority: 2,
                },
              ],
              ipv6Config: [
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ac",
                  prefixLength: 127,
                  priority: 2,
                },
                {
                  prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ad",
                  prefixLength: 127,
                  priority: 1,
                },
              ],
            },
          },
        },
      },
    ],
    pagination: {
      offset: 0,
      limit: 25,
      total: 26,
    },
  },
};
