module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/customer-premises",
  method: "patch",
  status: 200,
  mock: {
    data: {
      siteId: "ABCDEF123456",
      siteName: "NEWCABC123",
      siteDescription: "ABC.com North East Voice Infrastructure PoP updated",
      siteType: "customerPremises",
      address: {
        accuracyLevel: "2",
        premiseName: "BT Hadrian",
        streetNumber: "2",
        streetName: "Melbourne Street",
        cityOrTown: "Newcastle upon Type",
        locality: null,
        countyOrState: "Tyne and Wear",
        countryISOCode: "GB",
        postOrZipCode: "NE1 2JQ",
      },
      geoCode: {
        latitude: 54.9730349,
        longitude: -1.6021391,
      },
      subLocations: [
        {
          subLocationId: "ABCDEF123456:1",
          name: "6th floor Server Room",
          level: "6th",
          unit: "6.1",
          comments: "",
        },
        {
          subLocationId: "ABCDEF123456:2",
          name: "2nd Floor Vindolanda Room",
          level: "2nd",
          unit: "vindolanda",
          comments: "",
        },
      ],
    },
    message: {},
  },
};
