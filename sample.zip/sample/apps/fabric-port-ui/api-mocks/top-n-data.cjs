module.exports = {
  url: "/api/v1/globalfabric/monitors/utilization-reports",
  method: "post",
  mock: {
    resourceType: "customerPorts",
    topN: {
      resultLimit: 5,
      telemetryData: "inboundUtilisation",
      unit: "percent",
      sortOrder: "descending",
    },
    result: [
      {
        resourceId: "2c3a9f32-bbe7-4857-b4b8-cba940b7459c",
        rank: 1,
        value: 95.01,
        resourceName: "p1",
      },
      {
        resourceId: "68b95d61-ed86-4421-a8b4-54e9b718bd62",
        rank: 2,
        value: 92.48,
        resourceName: "p2",
      },
      {
        resourceId: "dc9d2a73-4fb3-49e5-886c-e7d8e60d7256",
        rank: 3,
        value: 92.11,
        resourceName: "p3",
      },
      {
        resourceId: "4a679293-e07c-4a88-b3b9-96e6b3333fca",
        rank: 4,
        value: 91.85,
        resourceName: "p4",
      },
      {
        resourceId: "0260581a-7149-4e89-9f3e-eb5755b98f03",
        rank: 5,
        value: 85.23,
        resourceName: "p5",
      },
    ],
  },
};
