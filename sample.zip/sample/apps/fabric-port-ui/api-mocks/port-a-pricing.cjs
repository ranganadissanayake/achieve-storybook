module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/port-only-prices",
  method: "post",
  mock: {
    primaryPortPrice: {
      oneTimePrice: 0,
      recurringMonthlyPrice: 1477,
      currencyFormat: "GBP",
      BTPoPSiteId: "086-11001",
    },
    secondaryPortPrice: {
      oneTimePrice: 0,
      recurringMonthlyPrice: 1477,
      currencyFormat: "GBP",
      diverserBTPoPSiteId: "086-11001",
    },
  },
};