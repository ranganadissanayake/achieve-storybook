module.exports = {
  url: "/api/v1/globalfabric-ip-addresses/contacts",
  method: "post",
  mock: {
    title: "Miss",
    firstName: "Teri",
    lastName: "Dactyl",
    email: "teri.dactyl@abc.com",
    telephoneNumber: "+01234567657",
    mobileNumber: "+09876543210",
    address: {
      line1: "1 roadrunner avenue",
      line2: "looney world",
      city: "acme city",
      state: "acme state",
      postCode: "AC1 ME1",
      countryISOCode: "US",
    },
    contactId: "003Vd00000CMOWDIA5",
  },
};
