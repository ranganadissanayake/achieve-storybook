module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/customer-premises-quotes",
  method: "post",
  mock: {
    result: {
      requestId: "0lu7OKLT-tBr5-Q43v-dSqL-fbe2EUjUw4yv",
      productOrderItem: [
        {
          action: "add",
        },
      ],
      state: "acknowledged",
    },
  },
};
