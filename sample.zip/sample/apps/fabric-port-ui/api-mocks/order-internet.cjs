module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-internet-connections/orders",
  method: "post",
  mock: {
    result: {
      externalId: "123",
      productOrderItem: [{ id: "123", action: "add" }],
      state: "acknowledged",
      serviceId: "Sinprefix-IO-90000-00001",
    },
  },
};
