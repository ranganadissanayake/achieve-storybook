module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/customer-premises/site-contacts/*",
  method: "get",
  mock: {
    contactId: "12345",
    title: "Mr.",
    familyName: "Joe",
    givenName: "Bloggs",
    email: "joe.bloggs@abc.com",
    telephone: {
      number: "+44123456789",
      extension: "1234",
    },
    mobileNumber: "+44123456789",
    siteIds: [
      {
        siteId: "1234",
        role: "Site Primary Contact",
      },
    ],
  },
};
