module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-ip-addresses/orders",
  method: "post",
  mock: {
    result: {
      externalId: "SsjPl4ZU-y1ID-uW1t-OYrv-SiuvS3MoWips",
      productOrderItem: [
        {
          id: "SsjPl4ZU-y1ID-uW1t-OYrv-SiuvS3MoWips",
          action: "add",
        },
      ],
      state: "acknowledged",
      serviceId: "Sinprefix-SPEC-IP-90000-00001",
    },
  },
};
