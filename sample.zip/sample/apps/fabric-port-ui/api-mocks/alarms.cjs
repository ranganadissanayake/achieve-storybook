module.exports = {
  url: "/api/v1/globalfabric/monitors/alarms",
  method: "post",
  mock: {
    results: [
      {
        alarmId: "Alert11257500",
        serviceType: "customerPort",
        serviceId: "GFCPO-24-96898-62350",
        action: "Update",
        severity: "Major",
        state: "Open",
        timestamp: {
          active: "2024-07-29T17:57:27.000Z",
          modified: "2024-07-29T17:57:45.000Z",
        },
        relatedEvents: {
          eventCount: 1,
          flapCount: 0,
        },
        body: {
          type: "customerPort_Errors",
          name: "High Inbound Port Errors",
          message:
            "Inbound errors on Customer Port <name> <portId> has exceeded 1%",
          data: {
            state: "Open",
            portId: "GFCPO-24-96898-62350",
            portName: "",
          },
        },
        viewedStatus: false,
      },
      {
        alarmId: "Alert11247263",
        serviceType: "customerPort",
        serviceId: "GFCPP-24-92492-69763",
        action: "Update",
        severity: "Major",
        state: "Open",
        timestamp: {
          active: "2024-07-29T05:57:28.000Z",
          modified: "2024-07-29T05:57:49.000Z",
        },
        relatedEvents: {
          eventCount: 1,
          flapCount: 0,
        },
        body: {
          type: "customerPort_Errors",
          name: "",
          message: "",
          data: {
            state: "Open",
            portId: "GFCPP-24-92492-69763",
            portName: "",
          },
        },
        viewedStatus: false,
      },
    ],
    pagination: {
      limit: 10,
      offset: 0,
      total: 8,
    },
  },
};
