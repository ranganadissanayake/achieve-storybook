module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/data-center-prices",
  method: "post",
  mock: {
    primaryPortPrice: {
      oneTimePrice: 600,
      recurringMonthlyPrice: 500,
    },
    primaryConnectivityPrice: {
      oneTimePrice: 429.12,
      recurringMonthlyPrice: 150.21,
      minTermMonths: 12,
    },
    secondaryPortPrice: {
      oneTimePrice: 16000,
      recurringMonthlyPrice: 14000,
    },
    secondaryConnectivityPrice: {
      oneTimePrice: 858.24,
      recurringMonthlyPrice: 300.42,
      minTermMonths: 12,
    },
    totalPrice: {
      oneTimePrice: 17887.36,
      recurringMonthlyPrice: 14950.63,
    },
    currencyFormat: "GBP",
    accessTermOffered: 12,
    portTerm: 0,
  },
};
