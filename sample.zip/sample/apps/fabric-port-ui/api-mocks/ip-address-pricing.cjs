module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-ip-addresses/prices",
  method: "post",
  mock: {
    oneTimePrice: 100,
    recurringMonthlyPrice: 500,
    currencyFormat: "GBP",
  },
};
