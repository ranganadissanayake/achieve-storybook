module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-internet-connections/orders",
  method: "patch",
  mock: {
    result: {
      externalId: "123",
      productOrderItem: [{ id: "123", action: "add" }],
      state: "acknowledged",
      serviceId: "Sinprefix-SPEC-IU-90000-00001",
    },
  },
};
