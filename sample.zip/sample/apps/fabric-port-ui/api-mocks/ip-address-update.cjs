module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-ip-addresses/orders",
  method: "patch",
  mock: {
    result: {
      externalId: "RK2JBcJU-EywV-kkpQ-xj6V-Lvk6QQxb7hIX",
      productOrderItem: [
        {
          id: "RK2JBcJU-EywV-kkpQ-xj6V-Lvk6QQxb7hIX",
          action: "modify",
        },
      ],
      state: "acknowledged",
      serviceId: "Sinprefix-SPEC-IP-90000-00001",
    },
  },
};
