module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/port-only-orders",
  method: "post",
  mock: {
    result: {
      externalId: "0nYH4G3k-KiKv-aBYK-NflD-1Z4oDz6Im5DP",
      productOrderItem: [
        {
          id: "0nYH4G3k-KiKv-aBYK-NflD-1Z4oDz6Im5DP",
          action: "add",
        },
      ],
      state: "acknowledged",
      serviceId: "Sinprefix-YY-90000-00001",
    },
  },
};
