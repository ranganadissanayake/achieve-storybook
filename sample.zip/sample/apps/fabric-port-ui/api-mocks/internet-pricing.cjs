module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-internet-connections/prices",
  method: "post",
  mock: {
    bandwidthType: "static",
    oneTimePrice: 0,
    recurringMonthlyPrice: 168,
    currencyFormat: "GBP",
    countryISOCode: "GB"
  }
};