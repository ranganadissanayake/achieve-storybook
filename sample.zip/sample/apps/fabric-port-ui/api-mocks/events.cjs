module.exports = {
  url: "/api/v1/globalfabric/monitors/events",
  method: "post",
  mock: {
    results: [
      {
        eventId: "d6cbee74-825b-4953-9fab-a39e3c2dc647",
        timestamp: "2023-04-14T09:04:00",
        serviceType: "customerPort",
        serviceId: "f3436b42-c60b-4e32-9bff-8281424c6fa6",
        action: "update",
        severity: "information",
        viewedStatus: false,
        body: {
          type: "customerPort_Change",
          name: "Customer Port Configuration Change Initiated",
          message:
            "Customer Port Primary Data Centre f3436b42-c60b-4e32-9bff-8281424c6fa6 configuration of isEnabled with a value of false initiated by grahamp",
          data: {
            portName: "Primary Data Centre",
            portId: "f3436b42-c60b-4e32-9bff-8281424c6fa6",
            state: "inProgress",
            username: "grahamp",
            thresholdValue: "10",
            indicativeDeliveryDate: "2023-04-14T09:04:15",
            customerCommittedDate: "2023-04-14T09:04:15",
            parameter: " isEnabled ",
            parameterValue: "false",
          },
        },
      },
      {
        eventId: "d6cbee74-825b-4953-9fab-a39e3c2dc647",
        timestamp: "2023-04-14T09:04:00",
        serviceType: "customerPort",
        serviceId: "f3436b42-c60b-4e32-9bff-8281424c6fa6",
        action: "update",
        severity: "information",
        viewedStatus: true,
        body: {
          type: "customerPort_Change",
          name: "Customer Port Configuration Change Initiated",
          message:
            "Customer Port Primary Data Centre f3436b42-c60b-4e32-9bff-8281424c6fa6 configuration of isEnabled with a value of false initiated by grahamp",
          data: {
            portName: "Primary Data Centre",
            portId: "f3436b42-c60b-4e32-9bff-8281424c6fa6",
            state: "disabled",
            username: "grahamp",
            thresholdValue: "10",
            indicativeDeliveryDate: "2023-04-14T09:04:15",
            customerCommittedDate: "2023-04-14T09:04:15",
            parameter: " isEnabled ",
            parameterValue: "false",
          },
        },
      },
    ],
    pagination: {
      limit: 10,
      offset: 0,
      total: 8,
    },
  },
};
