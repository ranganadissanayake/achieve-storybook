module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-billing-accounts",
  method: "get",
  status: 200,
  mock: {
    customerID: "29055",
    customerName: "CSA-29055",
    billingAccounts: [
      {
        id: "0013L00000WLYrAQAX",
        name: "BAC-0013L00000WLYrAQAX",
        currency: "USD",
        default: true,
      },
      {
        id: "0015L00000WLYrAQAY",
        name: "EAC-0015L00000WLYrAQAY",
        currency: "GBP",
        default: false,
      },
      {
        id: "0014L00000WLYrAQAZ",
        name: "DAC-0014L00000WLYrAQAZ",
        currency: "LKR",
        default: false,
      },
      {
        id: "b100",
        name: "Hindustan Unilever Ltd Account",
        currency: "INR",
        default: false,
        customerPurchaseOrder: [
          {
            purchaseOrderNumber: "112414",
            purchaseOrderName: "PO1",
            purchaseOrderType: "mrc",
          },
        ],
      },
      {
        id: "b400",
        name: "Unilever UK Account",
        currency: "GBP",
        default: false,
        customerPurchaseOrder: [
          {
            purchaseOrderNumber: "112414",
            purchaseOrderName: "PO1",
            purchaseOrderType: "mrc",
          },
          {
            purchaseOrderNumber: "112417",
            purchaseOrderName: "PO2",
            purchaseOrderType: "nrc",
          },
        ],
      },
    ],
  },
};
