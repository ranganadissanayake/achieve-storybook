module.exports = {
    url: "/api/v1/globalfabric/cloudfabric-customer-ports/cessation-charges",
    method: "get",
    status: 200,
    mock: {
        portId: "12323",
        ceaseDate: "02/06/2024",
        serviceActivationDate: "02/06/2023",
        serviceId: "Sinprefix-PO-90000-00002",
        minTermMonths: 18,
        remainingTermMonths: 2,
        noticePeriodMonths: 2,
        ceasePrice: {
            status: "firm",
            oneTimePrice: 340,
            currencyFormat: "GBP"
        }
    }
};
