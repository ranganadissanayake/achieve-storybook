module.exports = {
    url: "/api/v1/globalfabric/cloudfabric-locations/customer-premises/site-contacts/*",
    method: "patch",
    status: 200,
    mock: {
        "contactId": "123abc",
        "title": "Mr.",
        "familyName": "Joe",
        "givenName": "Bloggs",
        "email": "joe.bloggs@abc.com",
        "telephone": {
           "number": "+44123456789",
           "extension": "1234"
        },
        "mobileNumber": "+44123456789"
     },
  };
  