module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-ip-addresses",
  method: "delete",
  status: 200,
  mock: {
    id: "971112a0-bda7-11ed-8c27-29dc5ccad45f",
    message: "Request processed successfully",
    state: "acknowledged",
  },
};
