module.exports = {
    url: "/api/v1/globalfabric/cloudfabric-ip-addresses",
    method: "get",
    mock: {
        addressId: "02i3L00000AsvExQAJ",
        description: "",
        IPAddress: {
            prefixLength: "127",
            ipRegionCode: "US-01",
            prefix: "2a00:2000:2000::/127"
        },
        customerContacts: {
            techNicHdlBT: "",
            registeredRIRBT: "",
            adminNicHdl: "PG123-RIPE",
            registeredRIR: "RIPE_NCC",
            rirAnonymise: "false",
            techNicHdl: "PG345-RIPE",
            adminNicHdlBT: "",
            adminContact: {
                name: "",
                premiseName: "BT Hadrian",
                streetNumber: "2",
                streetName: "Melbourne Street",
                cityOrTown: "Newcastle upon Type",
                locality: "",
                postOrZipCode: "NE1 2JQ",
                countyOrState: "Tyne and Wear",
                countryISOCode: "US",
                email: "",
                telephone: ""
            },
            techContact: {
                name: "",
                premiseName: "BT Hadrian",
                streetNumber: "2",
                streetName: "Melbourne Street",
                cityOrTown: "Newcastle upon Type",
                locality: "",
                email: "",
                telephone: "",
                postOrZipCode: "NE1 2JQ",
                countyOrState: "Tyne and Wear",
                countryISOCode: "US"
            }
        },
        IPOwner: "PA",
        IPVersion: "ipv6",
        name: "SubnetIP_Test225",
        addressType: "WAN",
        countryISOCode: "US",
        associatedNetworkServices: [
            
        ]
    }
}