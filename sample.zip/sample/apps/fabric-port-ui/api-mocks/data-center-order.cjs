module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/data-center-orders",
  method: "post",
  mock: {
    result: {
      externalId: "01078939003",
      productOrderItem: [
        {
          id: "971112a0-bda7-11ed-8c27-29dc5ccad45f",
          action: "add",
        },
      ],
      state: "acknowledged",
      serviceId: "Sinprefix-YY-90000-00002",
    },
  },
};
