module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/geographical-locations",
  mock: [
    {
      countryISOCode: "ARG",
      countryDisplayName: "Argentina",
      metro: [{ metroCode: "BAI", metroDisplayName: "Buenos Aires" }],
    },
    {
      countryISOCode: "AU",
      countryDisplayName: "Australia",
      metro: [
        { metroCode: "PER", metroDisplayName: "Perth" },
        { metroCode: "SYD", metroDisplayName: "Sydney" },
        { metroCode: "MEL", metroDisplayName: "Melbourne" },
      ],
    },
    {
      countryISOCode: "AT",
      countryDisplayName: "Austria",
      metro: [{ metroCode: "VIE", metroDisplayName: "Vienna" }],
    },
    {
      countryISOCode: "BE",
      countryDisplayName: "Belgium",
      metro: [{ metroCode: "BRU", metroDisplayName: "Brussels" }],
    },
    {
      countryISOCode: "BR",
      countryDisplayName: "Brazil",
      metro: [
        { metroCode: "RIO", metroDisplayName: "Rio de Janeiro" },
        { metroCode: "SPA", metroDisplayName: "Sao Paulo" },
      ],
    },
    {
      countryISOCode: "CA",
      countryDisplayName: "Canada",
      metro: [
        { metroCode: "MON", metroDisplayName: "Montreal" },
        { metroCode: "TOR", metroDisplayName: "Toronto" },
        { metroCode: "VAN", metroDisplayName: "Vancouver" },
      ],
    },
    {
      countryISOCode: "CN",
      countryDisplayName: "China",
      metro: [
        { metroCode: "SHA", metroDisplayName: "Shanghai" },
        { metroCode: "BEI", metroDisplayName: "Beijing" },
      ],
    },
    {
      countryISOCode: "CO",
      countryDisplayName: "Columbia",
      metro: [{ metroCode: "SHA", metroDisplayName: "Bogota" }],
    },
    {
      countryISOCode: "CZ",
      countryDisplayName: "Czech Republic",
      metro: [{ metroCode: "PRG", metroDisplayName: "Prague" }],
    },
    {
      countryISOCode: "DK",
      countryDisplayName: "Denmark",
      metro: [{ metroCode: "COP", metroDisplayName: "Copenhagen" }],
    },
    {
      countryISOCode: "FI",
      countryDisplayName: "Finland",
      metro: [{ metroCode: "HEL", metroDisplayName: "Espoo/Helsinki" }],
    },
    {
      countryISOCode: "FR",
      countryDisplayName: "France",
      metro: [
        { metroCode: "PAR", metroDisplayName: "Paris" },
        { metroCode: "MAR", metroDisplayName: "Marseille" },
        { metroCode: "LYO", metroDisplayName: "Lyon" },
      ],
    },
    {
      countryISOCode: "DE",
      countryDisplayName: "Germany",
      metro: [
        { metroCode: "BER", metroDisplayName: "Berlin" },
        { metroCode: "FRA", metroDisplayName: "Frankfurt" },
        { metroCode: "MUN", metroDisplayName: "Munich" },
      ],
    },
    {
      countryISOCode: "GR",
      countryDisplayName: "Greece",
      metro: [{ metroCode: "ATH", metroDisplayName: "Athens" }],
    },
    {
      countryISOCode: "HK",
      countryDisplayName: "Hong Kong",
      metro: [{ metroCode: "HKG", metroDisplayName: "Hong Kong" }],
    },
    {
      countryISOCode: "HU",
      countryDisplayName: "Hungary",
      metro: [{ metroCode: "BUD", metroDisplayName: "Budapest" }],
    },
    {
      countryISOCode: "IN",
      countryDisplayName: "India",
      metro: [
        { metroCode: "MUM", metroDisplayName: "Mumbai" },
        { metroCode: "NDE", metroDisplayName: "New Delhi" },
        { metroCode: "CHE", metroDisplayName: "Chennai" },
      ],
    },
    {
      countryISOCode: "ID",
      countryDisplayName: "Indonesia",
      metro: [{ metroCode: "JAK", metroDisplayName: "Jakarta" }],
    },
    {
      countryISOCode: "IE",
      countryDisplayName: "Ireland",
      metro: [{ metroCode: "DUB", metroDisplayName: "Dublin" }],
    },
    {
      countryISOCode: "IT",
      countryDisplayName: "Italy",
      metro: [{ metroCode: "MIL", metroDisplayName: "Milan" }],
    },
    {
      countryISOCode: "JP",
      countryDisplayName: "Japan",
      metro: [
        { metroCode: "TOK", metroDisplayName: "Tokyo" },
        { metroCode: "OSA", metroDisplayName: "Osaka" },
      ],
    },
    {
      countryISOCode: "KR",
      countryDisplayName: "Korea",
      metro: [{ metroCode: "SEO", metroDisplayName: "Seoul" }],
    },
    {
      countryISOCode: "LU",
      countryDisplayName: "Luxembourg",
      metro: [{ metroCode: "LUX", metroDisplayName: "Luxembourg" }],
    },
    {
      countryISOCode: "MA",
      countryDisplayName: "Malaysia",
      metro: [
        { metroCode: "KUL", metroDisplayName: "Kuala Lumpur" },
        { metroCode: "CYB", metroDisplayName: "Cyberjaya" },
      ],
    },
    {
      countryISOCode: "MX",
      countryDisplayName: "Mexico",
      metro: [
        { metroCode: "MEX", metroDisplayName: "Mexico City" },
        { metroCode: "QUE", metroDisplayName: "Queretaro" },
      ],
    },
    {
      countryISOCode: "NL",
      countryDisplayName: "Netherlands",
      metro: [{ metroCode: "AMS", metroDisplayName: "Amsterdam" }],
    },
    {
      countryISOCode: "NZ",
      countryDisplayName: "New Zealand",
      metro: [{ metroCode: "AUC", metroDisplayName: "Auckland" }],
    },
    {
      countryISOCode: "NO",
      countryDisplayName: "Norway",
      metro: [{ metroCode: "OSL", metroDisplayName: "Oslo" }],
    },
    {
      countryISOCode: "PH",
      countryDisplayName: "Phillippines",
      metro: [{ metroCode: "MAN", metroDisplayName: "Manila" }],
    },
    {
      countryISOCode: "PL",
      countryDisplayName: "Poland",
      metro: [{ metroCode: "WAR", metroDisplayName: "Warsaw" }],
    },
    {
      countryISOCode: "PT",
      countryDisplayName: "Portugal",
      metro: [{ metroCode: "LIS", metroDisplayName: "Lisbon" }],
    },
    {
      countryISOCode: "RO",
      countryDisplayName: "Romania",
      metro: [{ metroCode: "BUC", metroDisplayName: "Bucharest" }],
    },
    {
      countryISOCode: "RU",
      countryDisplayName: "Russia",
      metro: [{ metroCode: "MOS", metroDisplayName: "Moscow" }],
    },
    {
      countryISOCode: "SG",
      countryDisplayName: "Singapore",
      metro: [{ metroCode: "SGP", metroDisplayName: "Singapore" }],
    },
    {
      countryISOCode: "ZA",
      countryDisplayName: "South Africa",
      metro: [{ metroCode: "JOH", metroDisplayName: "Johannesburg" }],
    },
    {
      countryISOCode: "ES",
      countryDisplayName: "Spain",
      metro: [
        { metroCode: "BAR", metroDisplayName: "Barcelona" },
        { metroCode: "MAD", metroDisplayName: "Madrid" },
      ],
    },
    {
      countryISOCode: "SE",
      countryDisplayName: "Sweden",
      metro: [{ metroCode: "STO", metroDisplayName: "Stockholm" }],
    },
    {
      countryISOCode: "CH",
      countryDisplayName: "Switzerland",
      metro: [{ metroCode: "ZUR", metroDisplayName: "Zurich" }],
    },
    {
      countryISOCode: "TW",
      countryDisplayName: "Taiwan",
      metro: [{ metroCode: "TAI", metroDisplayName: "Taipei" }],
    },
    {
      countryISOCode: "TH",
      countryDisplayName: "Thailand",
      metro: [{ metroCode: "BAN", metroDisplayName: "Bangkok" }],
    },
    {
      countryISOCode: "TUR",
      countryDisplayName: "Turkey",
      metro: [{ metroCode: "ITB", metroDisplayName: "Istanbul" }],
    },
    {
      countryISOCode: "AE",
      countryDisplayName: "UAE",
      metro: [{ metroCode: "DUB", metroDisplayName: "Dubai" }],
    },
    {
      countryISOCode: "GB",
      countryDisplayName: "United Kingdom",
      metro: [{ metroCode: "LON", metroDisplayName: "London" }],
    },
    {
      countryISOCode: "US",
      countryDisplayName: "United States",
      metro: [
        { metroCode: "SVY", metroDisplayName: "Silicon Valley" },
        { metroCode: "DAL", metroDisplayName: "Dallas" },
        { metroCode: "CHI", metroDisplayName: "Chicago" },
        { metroCode: "LOS", metroDisplayName: "Los Angeles" },
        { metroCode: "MIA", metroDisplayName: "Miami" },
        { metroCode: "ASH", metroDisplayName: "Ashburn" },
        { metroCode: "ATL", metroDisplayName: "Atlanta" },
        { metroCode: "NYK", metroDisplayName: "New York" },
      ],
    },
  ],
};
