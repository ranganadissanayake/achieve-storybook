module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/customer-sites/*",
  method: "delete",
  mock: {
    message: "Site deleted successfully with siteId '123'",
    code: "M001",
  },
};
