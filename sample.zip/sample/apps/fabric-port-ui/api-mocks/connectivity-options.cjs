module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/connectivity-options",
  method: "post",
  mock: {
    results: [
      {
        accessDiversity: "AD1",
        connectivitySolutionId:
          "1481289-GBLONA009-25180-111111:1481289-GBLONA009-25180-111111",
        primaryConnectivity: {
          btPopSiteId: "GBLONA009",
          connectivityModel: "Dedicated",
          connectivityProductName:
            "Equinix DC on net - P2P - Equinix provided cross connect",
          serviceDemarcation: "customerRackPatchPanel",
          connectivitySLAs: {
            availability: 99.99,
            serviceDeskHours: "00:00-24:00 Mon-Sun excl holidays included",
            p1FixHours: "4 Hours",
            p2FixHours: "24 Hours",
            p3FixHours: "48 Hours",
          },
          circuits: [
            {
              connectivityProductId: "1481289-GBLONA009-25180-111111",
              circuitTechnology: "Ethernet",
              circuitProtection: "Protected",
              circuitSpeed: 10000,
              supportedPortSpeed: ["10000"],
              selectededPortSpeed: 10000,
              interfacePresentation: [
                {
                  mediaType: "Fibre",
                  interfaceStandard: "1000Base-EX",
                  interfaceConnector: "LC (SFP)",
                },
                {
                  mediaType: "multiModeFiber",
                  interfaceStandard: "1000BASE-SX",
                  interfaceConnector: "LC",
                },
                {
                  mediaType: "copper",
                  interfaceStandard: "1000BASE-T",
                  interfaceConnector: "RJ-45",
                },
              ],
              mtu: 9100,
              l2cpSupport: "transparent",
              lagPortSupport: true,
              contention: "1:1",
              minTermMonths: [12, 24, 36, 48, 60],
              indicativeLeadTime: 3,
              indicativePrice: {
                oneTimePrice: 116.21,
                recurringMonthlyPrice: 25.48,
                currencyFormat: "GBP",
                priceStatus: "Firm",
              },
            },
          ],
        },
        secondaryConnectivity: {
          btPopSiteId: "GBLONA009",
          connectivityModel: "Dedicated",
          connectivityProductName:
            "Equinix DC on net - P2P - Equinix provided cross connect",
          serviceDemarcation: "customerRackPatchPanel",
          connectivitySLAs: {
            availability: 99.99,
            serviceDeskHours: "00:00-24:00 Mon-Sun excl holidays included",
            p1FixHours: "4 Hours",
            p2FixHours: "24 Hours",
            p3FixHours: "48 Hours",
          },
          circuits: [
            {
              connectivityProductId: "1481289-GBLONA009-25180-111111",
              circuitTechnology: "Ethernet",
              circuitProtection: "Protected",
              circuitSpeed: 10000,
              supportedPortSpeed: ["10000"],
              selectededPortSpeed: 10000,
              interfacePresentation: [
                {
                  mediaType: "Fibre",
                  interfaceStandard: "1000Base-EX",
                  interfaceConnector: "LC (SFP)",
                },
                {
                  mediaType: "multiModeFiber",
                  interfaceStandard: "1000BASE-SX",
                  interfaceConnector: "LC",
                },
                {
                  mediaType: "copper",
                  interfaceStandard: "1000BASE-T",
                  interfaceConnector: "RJ-45",
                },
              ],
              mtu: 9100,
              l2cpSupport: "transparent",
              lagPortSupport: true,
              contention: "1:1",
              minTermMonths: [12, 24, 36, 48, 60],
              indicativeLeadTime: 3,
              indicativePrice: {
                oneTimePrice: 116.21,
                recurringMonthlyPrice: 25.48,
                currencyFormat: "GBP",
                priceStatus: "Firm",
              },
            },
          ],
        },
      },
    ],
    pagination: {
      limit: 10,
      offset: 0,
      total: 6,
    },
  },
};
