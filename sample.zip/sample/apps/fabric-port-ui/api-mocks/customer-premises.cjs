module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/customer-premises",
  method: "post",
  mock: {
    data: {
      siteId: "1510652",
      siteName: "Freistaat Bayern",
      siteDescription: null,
      siteType: "customerPremise",
      address: {
        accuracy: "1",
        premiseName: "SALDENBURG",
        streetNumber: "Saldenburg",
        streetName: "SALDENBURG",
        cityOrTown: "SALDENBURG",
        locality: null,
        countyOrState: "Saldenburg",
        countryISOCode: "DE",
        postOrZipCode: "94163"
      },
      geoCode: {
        latitude: 48.7736375,
        longitude: 13.3558458
      },
      subLocations: [

      ]
    },
    message: {

    }
  }
  
};
