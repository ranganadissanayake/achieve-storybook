module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/port-only-ports",
  method: "delete",
  status: 200,
  mock: {
    result: {
      externalId: "01078939003",
      productOrderItem: [
        {
          id: "971112a0-bda7-11ed-8c27-29dc5ccad45f",
          action: "delete",
        },
      ],
      state: "acknowledged",
    },
  },
};
