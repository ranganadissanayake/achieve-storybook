module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/customer-premises-orders",
  method: "post",
  mock: {
    result: {
      requestId: "m9qZLUB3-1zsq-fftX-zOHc-Qj5e1nbD0eV9",
      productOrderItem: [
        {
          serviceId: "GFCPS-24-98585-84447",
          action: "add",
        },
      ],
      state: "acknowledged",
    },
  },
};
