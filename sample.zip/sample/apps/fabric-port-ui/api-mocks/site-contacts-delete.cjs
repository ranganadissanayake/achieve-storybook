module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/customer-premises/site-contacts/*",
  method: "delete",
  status: 204,
  mock: {},
};
