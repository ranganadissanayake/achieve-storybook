module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/customer-premises/1510652/sub-locations",
  method: "post",
  mock: {
    subLocationId: "1234",
    name: "6th level Server unit",
    level: "6th",
    unit: "6.1",
    comments: "",
  },
};
