module.exports = {
  url: "/api/v1/globalfabric/monitors/network-allocation-reports",
  method: "post",
  mock: {
    resourceType: "customerPorts",
    topN: {
      resultLimit: 5,
      telemetryData: "allocatedBandwidth",
      unit: "percent",
      sortOrder: "descending",
    },
    result: [
      {
        resourceId: "2c3a9f32-bbe7-4857-b4b8-cba940b7459c",
        resourceName: "Port-SPEC-24-00000-45035",
        rank: 1,
        value: 100,
        breakdown: [
          {
            resourceId: "f95488fd-e21f-410a-a967-4177653269ca",
            resourceName: "CL1-1",
            resourceType: "internetConnection",
            value: 100,
          },
        ],
      },
      {
        resourceId: "68b95d61-ed86-4421-a8b4-54e9b718bd62",
        resourceName: "Port-SPEC-24-00000-32166",
        rank: 2,
        value: 95,
        breakdown: [
          {
            resourceId: "8e43c59f-5325-4681-b0f7-6e81869e40c8",
            resourceName: "CL1-2",
            resourceType: "ipVPNConnection",
            value: 30,
          },
          {
            resourceId: "4b6e78d1-148c-4490-acab-75cd1dc39141",
            resourceName: "CL2-2",
            resourceType: "internetConnection",
            value: 30,
          },
          {
            resourceId: "4f065162-a22e-43ad-b03d-da1da84abc1d",
            resourceName: "CL3-2",
            resourceType: "ipVPNConnection",
            value: 35,
          },
        ],
      },
      {
        resourceId: "dc9d2a73-4fb3-49e5-886c-e7d8e60d7256",
        resourceName: "Port-SPEC-24-00000-22860",
        rank: 3,
        value: 85,
        breakdown: [
          {
            resourceId: "3021f84f-47c6-4f1f-8b55-9a93c98da334",
            resourceName: "CL1-3",
            resourceType: "ipVPNConnection",
            value: 55,
          },
          {
            resourceId: "b4cf4f96-3dba-401f-aeec-f6dc50050c09",
            resourceName: "CL2-3",
            resourceType: "ipVPNConnection",
            value: 30,
          },
        ],
      },
      {
        resourceId: "4a679293-e07c-4a88-b3b9-96e6b3333fca",
        resourceName: "Port-SPEC-24-00000-28638",
        rank: 4,
        value: 82,
        breakdown: [
          {
            resourceId: "3970a992-016f-4910-b002-d881117496ad",
            resourceName: "CL1-4",
            resourceType: "ipVPNConnection",
            value: 55,
          },
          {
            resourceId: "a41550cc-93cd-4d42-b616-166631dd737c",
            resourceName: "CL2-4",
            resourceType: "ipVPNConnection",
            value: 27,
          },
        ],
      },
      {
        resourceId: "0260581a-7149-4e89-9f3e-eb5755b98f03",
        resourceName: "LAGSer-SPEC-24-00000-28186",
        rank: 5,
        value: 78,
        breakdown: [
          {
            resourceId: "996b94e4-d60e-4e71-a989-90d624200e9e",
            resourceName: "CL1-5",
            resourceType: "ipVPNConnection",
            value: 24,
          },
          {
            resourceId: "ad53fe20-c199-4958-9e7c-5732fd216a36",
            resourceName: "CL2-5",
            resourceType: "internetConnection",
            value: 54,
          },
        ],
      },
    ],
  },
};
