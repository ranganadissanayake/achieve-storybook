module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-internet-connections",
  method: "get",
  status: 200,
  mock: {
    name: "Static Routing Example",
    description: "Static routing resilient ipv4 with 100Mbps static bandwidth, resilient ipv4 with 100Mbps static bandwidth, resilient ipv4 with 100Mbps static bandwidth, resilient ipv4 with 100Mbps static bandwidth., Static routing resilient ipv4 with 100Mbps static bandwidth., Static routing resilient ipv4 with 100Mbps static bandwidth., Static routing resilient ipv4 with 100Mbps static bandwidth.",
    isResilient: true,
    billingAccountId: "0013L00000FG982",
    primaryConnection: {
      connectionId: "0013L345601k0We3",
      serviceId: "Sinprefix-SPEC-ID-90000-00001",
      portId: "0013L0001k0QAD",
      isEnabled: true,
      encapsulation: "dot1q",
      VLANID: 200,
      bandwidthType: "static",
      isTelemetryStreamingEnabled: true,
      isPredictiveMonitoring: true,
      staticBandwidthConfig: {
        staticBandwidth: 100,
        isStaticBandwidthThreshold: true,
        staticMinBandwidthThreshold: 10,
        staticMaxBandwidthThreshold: 90
      },
      isBFD: true,
      IPVersion: "dual-stack",
      IPAddressConfiguration: {
        ipv4Config: {
          WANId: "0013L34540k6HER",
          BTWANAddress: "",
          CustomerWANAddress: "",
          LANConfig: [
            {
              LANId: "0013453F000k6GAD"
            },
            {
              LANId: "0013453F000k6GAD"
            }
          ]
        },
        ipv6Config: {
          WANId: "0013L3454RE6HER",
          BTWANAddress: "",
          CustomerWANAddress: "",
          LANConfig: [
            {
              LANId: "001345TES000k6GAD"
            },
            {
              LANId: "0013453RES00k6GAD"
            }
          ]
        }
      },
      routingType: "static",
      routingConfig: {
        staticConfig: {
          ipv4Config: [
            {
              prefix: "192.168.0.10",
              prefixLength: 27,
              priority: 10
            },
            {
              prefix: "192.168.0.11",
              prefixLength: 29,
              priority: 12
            }
          ],
          ipv6Config: [
            {
              prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
              prefixLength: 127,
              priority: 10
            },
            {
              prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
              prefixLength: 127,
              priority: 12
            }
          ]
        }
      }
    },
    secondaryConnection: {
      connectionId: "0013L345601kDW3",
      serviceId: "Sinprefix-SPEC-90000-00002",
      portId: "0013L345601k0QAD",
      isEnabled: true,
      encapsulation: "dot1q",
      VLANID: 2002,
      bandwidthType: "static",
      isTelemetryStreamingEnabled: true,
      isPredictiveMonitoring: true,
      staticBandwidthConfig: {
        staticBandwidth: 100,
        isStaticBandwidthThreshold: true,
        staticMinBandwidthThreshold: 10,
        staticMaxBandwidthThreshold: 90
      },
      isBFD: false,
      IPVersion: "dual-stack",
      IPAddressConfiguration: {
        ipv4Config: {
          WANId: "0013L34540k6HER",
          BTWANAddress: "",
          CustomerWANAddress: "",
          LANConfig: [
            {
              LANId: "0013453F000k6GAD"
            },
            {
              LANId: "0013453F000k6GAD"
            }
          ]
        },
        ipv6Config: {
          WANId: "0013L3454RE6HER",
          BTWANAddress: "",
          CustomerWANAddress: "",
          LANConfig: [
            {
              LANId: "001345TES000k6GAD"
            },
            {
              LANId: "0013453RES00k6GAD"
            }
          ]
        }
      },
      routingType: "static",
      routingConfig: {
        staticConfig: {
          ipv4Config: [
            {
              prefix: "192.168.0.10",
              prefixLength: 27,
              priority: 10
            },
            {
              prefix: "192.168.0.11",
              prefixLength: 29,
              priority: 12
            }
          ],
          ipv6Config: [
            {
              prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2aa",
              prefixLength: 127,
              priority: 10
            },
            {
              prefix: "2001:1d5a:ab31:2b21:aa73:143c:cc22:f2ab",
              prefixLength: 127,
              priority: 12
            }
          ]
        }
      }
    }
  }
};
