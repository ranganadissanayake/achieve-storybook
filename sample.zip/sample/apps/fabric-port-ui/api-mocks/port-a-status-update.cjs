module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/port-only-orders",
  method: "patch",
  mock: {
    result: {
      externalId: "8F5q6prx-xdKV-1Kt8-Aoyy-DnjeQpeWAGKj",
      productOrderItem: [
        {
          id: "8F5q6prx-xdKV-1Kt8-Aoyy-DnjeQpeWAGKj",
          action: "add",
        },
      ],
      state: "acknowledged",
      type: "ProductOrder",
      serviceId: "Sinprefix-YY-90000-00001",
      requestId: "BTC1234567",
    },
  },
};
