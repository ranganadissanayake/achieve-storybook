module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/customer-premises/site-contacts",
  method: "post",
  mock: {
      siteId: "ABCDEF123456",
      id: "12345",
      title: "Mr.",
      familyName: "Joe",
      givenName: "Bloggs",
      email: "joe.bloggs@abc.com",
      telephone: {
          number: "+44123456789",
          extension: "1234"
      },
      mobileNumber: "+44123456789",
      role: "Site Primary Contact",
      status: "active"
  }
};
