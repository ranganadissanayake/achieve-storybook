module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-customer-ports/customer-premises-quotes/0Q03L000000QXa5SAG",
  method: "patch",
  mock: [
    {
      result: {
        quoteItem: [
          {
            id: "0Q03L000000QXa5SAG",
            action: "progressFirm",
          },
        ],
        state: "acknowledged",
      },
    },
  ],
};
