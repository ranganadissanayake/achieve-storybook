module.exports = {
  url: "/api/gf/bt-global/v2/user-profiles",
  method: "get",
  mock: {
    status: "OK",
    data: {
      basicDetails: {
        uuid: "fceb953e-f2fc-103b-ae9a-c422379a3a01",
        safid: null,
        loginName: "dogakir102@camplvad.com",
        title: "Mr.",
        firstName: "Stefan",
        lastName: "Smith",
        email: "dogakir102@camplvad.com",
        requestorEmail: "dogakir102@camplvad.com",
        language: "English",
        userType: "NON_EIN",
        userLevel: "Company User",
        status: "Active",
        additionalAttributes: [
          {
            key: "Last update date",
            value: "2024-02-19 14:58:11.0",
          },
        ],
      },
      organisations: [
        {
          orgID: 750646,
          orgType: "company",
          orgName: "Starc Enterprises - SLE 23",
          parentID: 749092,
          attributes: [
            {
              key: "BOR_ID",
              value: "G6743278443",
            },
            {
              key: "CHEnabled",
              value: "true",
            },
          ],
        },
        {
          orgID: 750690,
          orgType: "company",
          orgName: "BUPA GLOBAL ACC",
          parentID: 749092,
          attributes: [
            {
              key: "BOR_ID",
              value: "949118",
            },
            {
              key: "CHEnabled",
              value: "true",
            },
          ],
        },
        {
          orgID: 750692,
          orgType: "customer",
          orgName: "T1 DR ICG",
          parentID: 750690,
          attributes: [
            {
              key: "CUS_ID",
              value: "290921",
            },
          ],
        },
        {
          orgID: 750693,
          orgType: "customer",
          orgName: "BUPA LTD",
          parentID: 750690,
          attributes: [
            {
              key: "CUS_ID",
              value: "2586058",
            },
          ],
        },
        {
          orgID: 750694,
          orgType: "customer",
          orgName: "BUPA",
          parentID: 750690,
          attributes: [
            {
              key: "CUS_ID",
              value: "2586058",
            },
          ],
        },
      ],
      orgApplications: [
        {
          orgID: 750690,
          applications: [],
        },
        {
          orgID: 750646,
          applications: [
            {
              applicationID: 7819,
              applicationName: "SNOW (Rainbow) Incidents",
              additionalAttributes: [
                {
                  key: "Launch URL",
                  value:
                    "https://test.service.global.bt.com/support?id=csm_my_lists&table=sn_customerservice_case&view=csp&target_page_id=csm_ticket&filter=initiated_as_request=false&sel=my_issues",
                },
              ],
              roles: [],
            },
          ],
        },
      ],
      requestedDate: "26-Sep-22 14:00:16",
      sourceSystem: "Snow(Rainbow)",
    },
  },
};
