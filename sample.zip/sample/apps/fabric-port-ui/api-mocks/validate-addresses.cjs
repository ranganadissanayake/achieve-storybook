const { mock } = require("./customer-premises.cjs");

module.exports = {
  url: "/api/v1/globalfabric/cloudfabric-locations/validate-addresses",
  method: "post",
  mock: [
    {
      formattedAddress: "Melbourne St, Newcastle upon Tyne NE1 2JQ, UK",
      accuracyLevel: "2",
      country: { value: "UNITED KINGDOM" },
      premiseName: { value: null },
      streetNumber: { value: null },
      streetName: { value: "MELBOURNE STREET" },
      postOrZipCode: { value: "NE1 2JQ" },
      cityOrtown: { value: "NEWCASTLE UPON TYNE" },
      countyOrState: { value: "ENGLAND" },
      countryISOCode: { value: "GB" },
      geoCode: { latitude: 54.9728479, longitude: -1.602012 },
    },
  ],
};
