module.exports = {
  extends: ["custom"],
};
