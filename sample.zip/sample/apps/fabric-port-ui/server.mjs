import bodyParser from "body-parser";
import { parse } from "dotenv";
import { readFileSync } from "fs";
import glob from "glob";
import { createRequire } from "module";
import { fileURLToPath } from "url";

export default (app) => {
  const env = parse(readFileSync("./environments/.env", "utf-8"));

  app.use(bodyParser.json({ limit: "1mb" }));
  app.use(bodyParser.urlencoded({ extended: true }));
  // for pretty print debugging
  app.set("json spaces", 2);

  if (env.REACT_APP_USE_API_MOCKS === "1") {
    const include = createRequire(fileURLToPath(import.meta.url));

    const files = glob.sync("./api-mocks/**/*.cjs");
    files.forEach((file) => {
      const { url, method = "get", status = 200, mock } = include(file);

      if (typeof mock === "object") {
        app[String(method)](url, (_, res) => {
          res.status(status).send(mock);
        });
      } else {
        app[String(method)](url, mock);
      }
    });
    console.log(">>>Mock used");
  }
};
