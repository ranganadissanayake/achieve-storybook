export default {
  setupFilesAfterEnv: ["<rootDir>/settings/jestSetup.js"],
  testResultsProcessor: "jest-sonar-reporter",
  testEnvironment: "jsdom",
  transformIgnorePatterns: ["../../node_modules/*"],
  moduleNameMapper: {
    "^uuid$": "uuid",
    ".(css|less|scss)$": "identity-obj-proxy",
    "\\.(jpg|ico|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$":
      "<rootDir>/settings/fileMock.js",
    "\\.(css|less)$": "<rootDir>/settings/fileMock.js",
    "^ip-bigint$": "<rootDir>/settings/fileMock.js",
  },
};
