import React from "react";
import "./SeletonLoader.scss";
import images from "../../shared/assets/index";
import GFHeading from "../GFHeading";

interface SkeletonProps {
    className?: string;
    layout?: "block" | "blockRow" | "table" | "barChart" | "rowViewWide" | "rowViewWithArrow" | "mapView";
    numberOfBars?: string[];
    numberOfBlocks?: any[]
    numberOfRows?: number;
    listOfColumns?: any[];

}


const SeletonLoader = ({
    className,
    layout = "block",
    numberOfBars = ['width-80', 'width-50', 'width-40', 'width-30', 'width-20'],
    listOfColumns = [
        {
            title: 'Incident',
            border: 'xy',
            blocks: ['width-90', 'width-30'],
            width:'width-25'
        },
        {
            title: 'Priority',
            border: 'y',
            blocks: ['width-80'],
            width:'width-10'
        },
        {
            title: 'Service',
            border: 'y',
            blocks: ['width-80'],
            width:'width-15'
        },
        {
            title: 'Progress',
            border: 'y',
            blocks: ['width-80'],
            width:'width-15'
        },
        {
            title: 'Date',
            border: 'y',
            blocks: ['width-80'],
            width:'width-15'
        },
        {
            title: 'Status',
            border: 'y',
            blocks: ['width-80'],
            width:'width-10'
        },
        {
            title: 'Generated',
            border: 'y',
            blocks: ['width-80'],
            width:'width-10'
        }],
    numberOfRows = 5,
    numberOfBlocks = [
        {
            letfColWidth: "width-0",
            hasBorder: false
        },
        {
            letfColWidth: "width-5",
            hasBorder: true
        },
        {
            letfColWidth: "width-5",
            hasBorder: true
        },
        {
            letfColWidth: "width-5",
            hasBorder: true
        }
    ]
}: SkeletonProps) => {
    return (
        <div className="seleton-Loader" data-testid="skeleton-loader">
            <div className={`card-skeleton pos-r ${className}`}>
                {layout === "barChart" && (
                    <div className="skel-mask-container skel-mask-barChart skel-animate">
                        {numberOfBars.map((bar, index) => (
                            <div key={index} className={`skel-mask bgcolor-lynx-white chart-row-mask b-radius-6 ${bar}`}></div>
                        ))}
                    </div>
                )}
                {layout === "rowViewWide" && (
                    <div className="skel-mask-container skel-mask-row-skel-1 gap-12 d-flex flex-d-col ">
                        {[...Array(numberOfRows)].map((_, i) => (
                            <div key={i} className={`skel-animate skel-mask b-radius-12 d-flex gap-16 flex-d-row pl-16 pr-32 pt-16 pb-16`}>
                                <div className="left-col-block b-radius-6 bgcolor-lynx-white"></div>
                                <div className="right-row-block d-flex width-100 gap-8 flex-d-col">
                                    <div className="row-line d-block bgcolor-lynx-white width-100 height-12 b-radius-6"></div>
                                    <div className="row-line d-block bgcolor-lynx-white width-100 height-24 b-radius-6"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {layout === "rowViewWithArrow" && (
                    <div className="skel-mask-container skel-mask-row-with-arrow d-flex flex-d-col pl-16 pr-16 pb-16">
                        {[...Array(numberOfRows)].map((_, i) => (
                            <div key={i} className={`skel-animate skel-mask d-flex gap-16 flex-d-row pl-16 pt-12 pb-12 pos-r`}>
                                <div className="left-col-block b-radius-6 bgcolor-lynx-white"></div>
                                <div className="right-row-block d-flex width-100 gap-8 flex-d-col">
                                    <div className="row-line d-block bgcolor-lynx-white width-20 height-16 b-radius-6"></div>
                                    <div className="row-line d-block bgcolor-lynx-white width-70 height-34 b-radius-6"></div>
                                </div>
                                <span className="row-arrow"></span>
                            </div>
                        ))}
                    </div>
                )}
                {layout === "mapView" && (
                    <div className="skelton-map skel-mask-container d-flex pt-16 skel-animate">
                        <img src={images.mapMask} alt="map skelton" />
                    </div>
                )}
                {layout === "block" && (
                    <div className="skelton-block skel-mask-container d-flex pt-24 pb-24 pl-20 pr-20">
                        <div className="row-block skel-animate d-flex flex-d-row gap-16 width-100">
                            <div className="lft-col-prt bgcolor-lynx-white b-radius-6"></div>
                            <div className="rgt-col-prt d-flex width-100 gap-6 flex-d-col">
                                <div className="row-skelton-line height-20 width-30 bgcolor-lynx-white b-radius-6"></div>
                                <div className="row-skelton-line height-14 width-80 bgcolor-lynx-white b-radius-6"></div>
                            </div>
                        </div>
                    </div>
                )}
                {layout === "blockRow" && (
                    <div className="skelton-block skel-mask-container gap-16 d-flex">
                        {numberOfBlocks.map((block, index) => (
                            <div key={index} className={`skel-animate row-block d-flex flex-d-row width-100 b-radius-6 pt-10 pb-10 ${block.hasBorder && 'skel-border'} ${block.letfColWidth !== 'width-0' && 'gap-16 pr-10 pl-10'}`}>
                                <div className={`lft-col-prt bgcolor-lynx-white b-radius-6 ${block.letfColWidth}`}></div>
                                <div className="rgt-col-prt d-flex width-100 gap-6 flex-d-col">
                                    <div className="row-skelton-line height-14 width-40 bgcolor-lynx-white b-radius-6"></div>
                                    <div className="row-skelton-line height-10 width-80 bgcolor-lynx-white b-radius-6"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
                {layout === "table" && (
                    <div className="skelton-table skel-mask-container d-flex pt-8 pb-8">
                        {listOfColumns.map((col, index) => (
                            <div key={index} className={`skelton-col ${col.width}`}>
                                <div className={`col-head pt-8 pb-8 pl-8 pr-24 bgcolor-lynx-white ${col.border === 'xy' && 'cell-border'} ${col.border === 'y' && 'cell-border-y'}`}>
                                    <GFHeading size="S6" weight="regular" text={col.title} />
                                </div>
                                {[...Array(numberOfRows)].map((_, i) => (
                                    <div key={i} className={`skel-animate d-flex flex-d-col col-cell pt-8 pb-8 pl-8 pr-24 ${col.blocks.length > 1 && 'gap-4'} ${col.border === 'xy' && 'cell-border'} ${col.border === 'y' && 'cell-border-y'}`}>
                                        {col.blocks.map((block: any, index: React.Key | null | undefined) => (
                                            <div key={index} className={`cell-skel-line bgcolor-lynx-white b-radius-6 ${block} height-14`}></div>
                                        ))}
                                    </div>
                                ))}
                            </div>
                        ))}
                    </div>

                )}
            </div>
        </div>
    )
}

export default SeletonLoader;