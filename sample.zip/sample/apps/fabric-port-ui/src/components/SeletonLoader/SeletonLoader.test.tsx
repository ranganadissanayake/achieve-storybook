import React from "react";
import { render, screen } from "@testing-library/react";
import SeletonLoader from ".";

describe("SeletonLoader Component", () => {
  it("should render without crashing", () => {
    render(<SeletonLoader />);
    expect(screen.getByTestId("skeleton-loader")).toBeInTheDocument();
  });

});
