import React from "react";
import { render, screen } from "@testing-library/react";
import GFLoader from "./index";

describe("GFLoader", () => {
  it("should render GFLoader'", () => {
    render(<GFLoader />);
    expect(screen.getByText("Loading...")).toBeInTheDocument();
  });
});
