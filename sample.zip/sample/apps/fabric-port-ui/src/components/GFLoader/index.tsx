import GFHeading from "../../components/GFHeading";
import React from "react";
import "./GFLoader.scss";
import spinner from "../../shared/assets/gifs/loading-spinner-80.gif";

const GFLoader: React.FC = () => {
  return (
    <div className="gf-loader">
      <img src={spinner} alt="Loading..." className="loading-spinner" />
      <GFHeading
        size="S1"
        weight="regular"
        color="dark-jungle-green"
        className="loader-heading"
        text="Loading..."
      />
      <GFHeading
        size="S4"
        weight="regular"
        color="the-end"
        className="loader-p"
        text="Please do not refresh the page"
      />
    </div>
  );
};

export default GFLoader;
