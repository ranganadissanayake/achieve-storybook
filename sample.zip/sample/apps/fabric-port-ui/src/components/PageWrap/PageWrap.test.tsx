import React from "react";
import { render } from "@testing-library/react";
import PageWrap from "./index";

describe("PageWrap Component", () => {
  it("renders the component with default props", () => {
    const { queryByText } = render(<PageWrap />);

    expect(queryByText("Breadcrumb")).toBeNull();
    expect(queryByText("Progress Stepper")).toBeNull();
  });
});
