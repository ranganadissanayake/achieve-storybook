import React from "react";

import {
  Breadcrumb,
  Crumb,
  Icon,
  ProgressStepper,
} from "@btdigital/nayan-component-library";
import TopPanel from "../../components/TopPanel";

import "./PageWrap.scss";

export interface PageWrapProps {
  currentStep?: number;
  steps?: string[];
  className?: string;
  handleBreadcrumbRouting?: () => Crumb[];
  children?: React.ReactNode;
  onClick?: VoidFunction;
  testId?: string;
  hasProgressBar?: boolean;
}

const PageWrap: React.FC<PageWrapProps> = ({
  currentStep = 1,
  steps = [],
  className = "",
  handleBreadcrumbRouting,
  children,
  onClick,
  testId,
  hasProgressBar = true,
}) => {
  const hasBreadcrumb = !!handleBreadcrumbRouting;
  return (
    <div
      className={`fp-container ${className}`}
      onClick={onClick}
      data-testid={testId}
    >
      {hasBreadcrumb && (
        <TopPanel>
          <Breadcrumb
            crumbs={handleBreadcrumbRouting()}
            separator={<Icon title="chevron_right" size="sm" />}
          />
          {hasProgressBar && (
            <ProgressStepper
              steps={steps}
              currentStep={currentStep}
              type="stepper"
              className="progress_stepper"
            />
          )}
        </TopPanel>
      )}
      <div className={`main-content-children ${hasBreadcrumb && ""}`}>
        {children}
      </div>
    </div>
  );
};

export default PageWrap;
