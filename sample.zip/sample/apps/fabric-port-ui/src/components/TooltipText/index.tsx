import React from "react";

import { Label, Icon } from "@btdigital/nayan-component-library";

import Tooltip from "../TooltipV2";

export interface TooltipTextProps {
  labelText: string;
  tooltipContent: string;
  htmlFor?: string;
}

const TooltipText: React.FC<TooltipTextProps> = ({
  labelText,
  tooltipContent,
  htmlFor,
}) => {
  return (
    <div className="group_fields">
      <div className="tooltip_text">
        <Label text={labelText} htmlFor={htmlFor} />
        <Tooltip content={tooltipContent} placement="bottom">
          <Icon title="info_alt" size="sm" className="tooltip_icon" />
        </Tooltip>
      </div>
    </div>
  );
};

export default TooltipText;
