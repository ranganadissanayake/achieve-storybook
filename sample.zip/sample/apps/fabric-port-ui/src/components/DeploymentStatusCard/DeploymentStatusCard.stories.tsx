import type { Meta, StoryObj } from '@storybook/react';
import DeploymentStatusCard from '.';
import images from "../../shared/assets"


const meta: Meta<typeof DeploymentStatusCard> = {
    title: 'FabricPortWebApp/DeploymentStatusCard',
    component: DeploymentStatusCard,
    parameters: {
        layout: 'centered',
    },
    tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof DeploymentStatusCard>;

export const Default: Story = {
    args: {
        title: "We're working on your request :)",
        description:
            [
                "We will be in touch as soon as deployment is completed.",
                "You can now leave this page",
            ],
        statusImageURL: images.cloudPort,
        imageWidth: "80px",
        imageHeight: "80px",
    },
};