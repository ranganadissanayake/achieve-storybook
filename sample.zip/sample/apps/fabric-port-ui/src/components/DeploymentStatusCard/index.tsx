import { Button, Label } from "@btdigital/nayan-component-library";
import React from "react";
import "./DeploymentStatusCard.scss";

export interface DeploymentStatusPanelProps {
  statusImageURL?: string;
  imageHeight?: string;
  imageWidth?: string;
  title: string;
  description: string[];
  leftButtonTitle?: string;
  leftButtonClassName?: string;
  leftButtonClick?: () => void;
  leftButtonDisabled?: boolean;
  rightButtonTitle?: string;
  rightButtonClassName?: string;
  rightButtonClick?: () => void;
  rightButtonDisabled?: boolean;
  containerClassName?: string;
}

const DeploymentStatusCard = ({
  statusImageURL,
  imageHeight,
  imageWidth,
  title,
  description,
  leftButtonTitle,
  leftButtonClassName,
  leftButtonClick,
  rightButtonTitle,
  rightButtonClassName,
  rightButtonClick,
  containerClassName,
  leftButtonDisabled,
  rightButtonDisabled
}: DeploymentStatusPanelProps) => {
  return (
    <div
      className={`status-container ${containerClassName} txt-center`}
      data-testid="status-failed-container"
    >
      {statusImageURL && (
        <img
          src={statusImageURL}
          alt="DeploymentAwaited"
          style={{ width: imageWidth, height: imageHeight }}
        />
      )}
      <Label
        text={title}
        labelTextStyles="header-label"
        containerStyles="header-label-container"
      />
      <div className="description-label-container">
        {description.map((desc: string, i) => (
          <Label
            text={desc}
            key={"desc" + i}
            labelTextStyles="description-label"
          />
        ))}
      </div>
      <div className="button-container">
        {leftButtonTitle && (
          <Button
            disabled={leftButtonDisabled}
            label={leftButtonTitle}
            variant="outline"
            size="medium"
            onPress={leftButtonClick}
            className={leftButtonClassName}
          />
        )}
        {rightButtonTitle && (
          <Button
            disabled={rightButtonDisabled}
            label={rightButtonTitle}
            variant="gradient"
            size="medium"
            onPress={rightButtonClick}
            className={rightButtonClassName}
          />
        )}
      </div>
    </div>
  );
};

export default DeploymentStatusCard;
