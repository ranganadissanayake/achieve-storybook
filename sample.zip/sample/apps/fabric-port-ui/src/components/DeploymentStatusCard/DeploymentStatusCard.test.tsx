import { render, screen } from "@testing-library/react";
import DeploymentStatusCard, { DeploymentStatusPanelProps } from "./index";
import React from "react";

describe("DeploymentStatusCard", () => {
  const props: DeploymentStatusPanelProps = {
    statusImageURL: "",
    title: "Sample title",
    description: ["description text 1"],
  };

  it("should render", () => {
    render(<DeploymentStatusCard {...props} />);
    expect(screen.getByTestId("status-failed-container")).toBeInTheDocument();
  });
});
