import { Icon } from '@btdigital/nayan-component-library';
import React from 'react';
import deleted from "../../shared/assets/images/svg/deleted.svg";
import deploying from "../../shared/assets/images/svg/deploying.svg";
import disabled from "../../shared/assets/images/svg/disabled.svg";


export type StatusIconProps = {
    status: string
}

const StatusIcon = ({ status }: StatusIconProps) => {
    switch (status.toLowerCase()) {
        case "deploying":
            return <img style={{ width: "20px", height: "20px" }} src={deploying} />;
        case "disconnected":
            return <Icon title="cross" inverse color="#DA020F" />;
        case "unknown":
            return <Icon title="alert" inverse color="#DA020F" />;
        case "disabled":
            return (
                <img
                    style={{ width: "20px", height: "20px" }}
                    className="disable-icon"
                    src={disabled}
                />
            );
        case "deleting":
            return <img style={{ width: "24px", height: "24px" }} src={deleted} />;
        default:
            return <Icon size="md" title="tick_variant" inverse color="#088003" />;
    }
};

export default StatusIcon;