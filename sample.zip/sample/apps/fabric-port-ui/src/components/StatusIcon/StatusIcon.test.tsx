import React from 'react'
import { render, screen } from "@testing-library/react";
import StatusIcon from '.';

describe("StatusIcon", () => {
    it('should render live', () => {
        render(<StatusIcon status="live" />);
        expect(screen.getByTestId("icon")).toBeInTheDocument();
    })
    it('should render acknowledged', () => {
        render(<StatusIcon status="acknowledged" />);
        expect(screen.getByTestId("icon")).toBeInTheDocument();
    })
    it('should render deploying', () => {
        render(<StatusIcon status="deploying" />);
        expect(screen.getByRole('img')).toBeInTheDocument();
    })
    it('should render disconnected', () => {
        render(<StatusIcon status="disconnected" />);
        expect(screen.getByTestId("icon")).toBeInTheDocument();
    })
    it('should render unknown', () => {
        render(<StatusIcon status="unknown" />);
        expect(screen.getByTestId("icon")).toBeInTheDocument();
    })
    it('should render deleting', () => {
        render(<StatusIcon status="deleting" />);
        expect(screen.getByRole('img')).toBeInTheDocument();
    })
    it('should render default for empty value', () => {
        render(<StatusIcon status="" />);
        expect(screen.getByTestId("icon")).toBeInTheDocument();
    })
    it('should render disabled', () => {
        render(<StatusIcon status="disabled" />);
        expect(screen.getByRole('img')).toBeInTheDocument();
    })
});