import React from "react";
import { Heading } from "@arc-ui/components/dist/Heading";
import { Columns } from "@arc-ui/components/dist/Columns";
import { Section } from "@arc-ui/components/dist/Section";
import { VerticalSpace } from "@arc-ui/components/dist/VerticalSpace";
import GFHeading from "../../GFHeading";

export interface TypographyProps {}
const Typography: React.FC<TypographyProps> = () => {
  return (
    <Section>
      <VerticalSpace size="20" />
      <Columns>
        <Columns.Col spanL={12}>
          <Heading size="m">
            Type fundamentals <br /> <br />
          </Heading>
        </Columns.Col>
      </Columns>

      <Columns>
        <Columns.Col spanL={4}>
          <GFHeading
            size="S3"
            text="700 Font weight"
            weight="bold"
            color="brand"
          />

          <GFHeading size="S1" text="S1 (36px)" weight="bold" />
          <GFHeading size="S2" text="S2 (28px)" weight="bold" />
          <GFHeading size="S3" text="S3 (24px)" weight="bold" />
          <GFHeading size="S4" text="S4 (20px)" weight="bold" />
          <GFHeading size="S5" text="S5 (16px)" weight="bold" />
          <GFHeading size="S6" text="S6 (14px)" weight="bold" />
          <GFHeading size="S7" text="S7 (12px)" weight="bold" />
          <GFHeading size="S8" text="S8 (11px)" weight="bold" />
        </Columns.Col>

        <Columns.Col spanL={4}>
          <GFHeading
            size="S3"
            text="500 Font weight"
            weight="regular"
            color="brand"
          />
          <GFHeading size="S1" text="S1 (36px)" weight="regular" />
          <GFHeading size="S2" text="S2 (28px)" weight="regular" />
          <GFHeading size="S3" text="S3 (24px)" weight="regular" />
          <GFHeading size="S4" text="S4 (20px)" weight="regular" />
          <GFHeading size="S5" text="S5 (16px)" weight="regular" />
          <GFHeading size="S6" text="S6 (14px)" weight="regular" />
          <GFHeading size="S7" text="S7 (12px)" weight="regular" />
          <GFHeading size="S8" text="S8 (11px)" weight="regular" />
        </Columns.Col>

        <Columns.Col spanL={4}>
          <GFHeading
            size="S3"
            text="400 Font weight"
            weight="light"
            color="brand"
          />
          <GFHeading size="S1" text="S1 (36px)" weight="light" />
          <GFHeading size="S2" text="S2 (28px)" weight="light" />
          <GFHeading size="S3" text="S3 (24px)" weight="light" />
          <GFHeading size="S4" text="S4 (20px)" weight="light" />
          <GFHeading size="S5" text="S5 (16px)" weight="light" />
          <GFHeading size="S6" text="S6 (14px)" weight="light" />
          <GFHeading size="S7" text="S7 (12px)" weight="light" />
          <GFHeading size="S8" text="S8 (11px)" weight="light" />
        </Columns.Col>
      </Columns>
    </Section>
  );
};

export default Typography;
