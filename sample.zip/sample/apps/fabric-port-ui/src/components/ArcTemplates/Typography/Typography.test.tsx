import React from "react";
import { render, screen } from "@testing-library/react";
import Typography from "./index";

describe("Typography", () => {
  it("should render Typography component", () => {
    render(<Typography />);
    expect(screen.getByText("Type fundamentals")).toBeInTheDocument();
  });
});
