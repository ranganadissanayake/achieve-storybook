import React from "react";
import { Heading } from "@arc-ui/components/dist/Heading";
import { Columns } from "@arc-ui/components/dist/Columns";
import { Section } from "@arc-ui/components/dist/Section";
import { VerticalSpace } from "@arc-ui/components/dist/VerticalSpace";
import { Image } from "@arc-ui/components/dist/Image";
import { Text } from "@arc-ui/components/dist/Text";
import { Elevation } from "@arc-ui/components/dist/Elevation";
import { Button } from "@arc-ui/components/dist/Button";
import { Surface } from "@arc-ui/components/dist/Surface";
import { Align } from "@arc-ui/components/dist/Align";
import { Card } from "@arc-ui/components/dist/Card";

export interface ArcTempleteProps {}
const ArcComponents: React.FC<ArcTempleteProps> = () => {
  return (
    <>
      <Section>
        <Columns>
          <Columns.Col spanM={12}>
            <Image src="https://res.cloudinary.com/measured/image/upload/f_auto,q_auto,w_1932/v1616502511/BT/20784_tywqio.jpg" />
          </Columns.Col>
          <Columns.Col align="center" spanM={12}>
            <Heading color="auto" level="2" size="l">
              Sample Header (L)
            </Heading>
            <VerticalSpace size="16" />
            <Text>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
              reprehenderit in
            </Text>
            <VerticalSpace size="16" />
            <Heading color="auto" level="2" size="s">
              Sample Header (S)
            </Heading>
            <VerticalSpace size="16" />
            <Text>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
              reprehenderit in
            </Text>
            <VerticalSpace size="16" />
            <Elevation>
              <Button label="Button" />
            </Elevation>
          </Columns.Col>
        </Columns>
        <VerticalSpace size="32" />
      </Section>
      <Section>
        <Columns>
          <Columns.Col spanL={4} spanM={6}>
            <Card
              actionLabel="Button"
              href="#"
              imageAlt="BT Tower"
              imageLoading="lazy"
              imageSrc="https://res.cloudinary.com/measured/image/upload/f_auto,q_auto,w_1368/v1616502502/BT/20780_vx13vc.jpg"
              title="Card Title"
            >
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ante
              mi, dapibus at est non, mollis mattis elit. Phasellus vehicula
              elit lacus, in posuere orci rhoncus sit.
            </Card>
          </Columns.Col>
          <Columns.Col spanL={4} spanM={6}>
            <Card actionLabel="Button" href="#" title="Card Title">
              <Card.Block grow>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                ante mi, dapibus at est non, mollis mattis elit. Phasellus
                vehicula elit lacus, in posuere orci rhoncus sit.
              </Card.Block>
            </Card>
          </Columns.Col>
          <Columns.Col spanL={4} spanM={6}>
            <Card
              actionLabel="Button"
              fill="outlined"
              href="#"
              title="Card Title"
            >
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ante
              mi, dapibus at est non, mollis mattis elit. Phasellus vehicula
              elit lacus, in posuere orci rhoncus sit.
            </Card>
          </Columns.Col>
        </Columns>
      </Section>
      <VerticalSpace size="32" />
      <Surface background="light">
        <Section>
          <VerticalSpace size="96" />
          <Columns>
            <Columns.Col spanM={5}>
              <Align vertical="center">
                <Heading level="2" size="l">
                  All our insights and events{" "}
                  <Heading.Proposition>in one place</Heading.Proposition>
                </Heading>
                <VerticalSpace size="16" />
                <Text>
                  We’ve created a new place for all our content. From top tech
                  articles to new events coming your way, from case studies to
                  digital transformation – we’ve got it all in one place.
                </Text>
                <VerticalSpace size="24" />
                <Elevation>
                  <Button label="See Insights & Events" />
                </Elevation>
              </Align>
            </Columns.Col>
            <Columns.Col spanM={1} />
            <Columns.Col spanM={6}>
              {" "}
              <Image src="https://res.cloudinary.com/measured/image/upload/f_auto,q_auto,w_1932/v1616502511/BT/20784_tywqio.jpg" />
            </Columns.Col>
          </Columns>
          <VerticalSpace size="96" />
        </Section>
      </Surface>
    </>
  );
};

export default ArcComponents;
