import React from "react";
import { render, screen } from "@testing-library/react";
import ArcTemplete from "./index";

describe("ArcTemplete", () => {
  it("should render ArcTemplete component", () => {
    render(<ArcTemplete />);
    expect(screen.getByText("Sample Header (L)")).toBeInTheDocument();
  });
});
