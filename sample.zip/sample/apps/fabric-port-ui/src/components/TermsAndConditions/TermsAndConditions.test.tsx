import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import TermsAndConditions, { TermsAndConditionsProps } from '.';

describe('TermsAndConditions', () => {
  const props: TermsAndConditionsProps = {
    className:'false',
    isErrorPrompt:false,
    isCheckboxChecked: false,
    onCheckboxChange: () => {}, 
  };

  it('should render the modal with the provided content', async () => {
    render(<TermsAndConditions {...props} />);
    
    setTimeout(() => {
      expect(screen.getByText('Terms and Conditions')).toBeInTheDocument();
      expect(screen.getByText('To place this order with BT please check the summary details of your Order.')).toBeInTheDocument();
      expect(screen.getByText('I acknowledge that by adding, deleting or amending Services as set out in this Order')).toBeInTheDocument();
    }, 100);
  });
  
  it('should open the modal when rendered', () => {
    render(<TermsAndConditions {...props} />);
    
    setTimeout(() => {
      expect(screen.getByTestId('modal-overlay')).toHaveClass('modal-open');
    }, 100);
  });

  it('should close the modal when clicked outside (if applicable)', () => {
    const onCloseMock = jest.fn();
    render(<TermsAndConditions {...props} onClose={onCloseMock} />);
    
    setTimeout(() => {
      const modalOverlay = screen.getByTestId('modal-overlay');
      fireEvent.click(modalOverlay);
      
      expect(onCloseMock).toHaveBeenCalledTimes(1);
    }, 100);
  });

  it('should call openTCModal and set isModalOpen to true when button is clicked', () => {
    const { getByTestId } = render(<TermsAndConditions {...props} />);
    setTimeout(()=>{const openModalButton = getByTestId('open-modal-button');

    fireEvent.click(openModalButton);
    expect(document.body.classList.contains('modal-open')).toBe(true);},10);
  });

  it('should call closeTCModal and set isModalOpen to false when button is clicked', () => {
    const { getByTestId } = render(<TermsAndConditions {...props} />);
    setTimeout(() => { const closeModalButton = getByTestId('close-button');

    fireEvent.click(closeModalButton);

    expect(screen.getByTestId('modal-overlay')).not.toHaveClass('modal-open');},10);
  });

  it('should call handleCheckboxClick when the checkbox is clicked', () => {
    const handleCheckboxClickMock = jest.fn();
    render(<TermsAndConditions {...props} onCheckboxChange={handleCheckboxClickMock} />);
    const checkbox = screen.getByTestId('checkbox');

    fireEvent.click(checkbox);

    expect(handleCheckboxClickMock).toHaveBeenCalledTimes(1);
  });

  it('should set isModalOpen to false when closeTCModal is called', () => {
    setTimeout(()=>{
    const { getByTestId } = render(<TermsAndConditions {...props} />);
    const openModalButton = getByTestId('open-modal-button');

    fireEvent.click(openModalButton);

    expect(document.body.classList.contains('modal-open')).toBe(true);

    const closeTCModalButton = getByTestId('close-button');
    fireEvent.click(closeTCModalButton);

    expect(document.body.classList.contains('modal-open')).toBe(false);},10);
  });
});
