import React, { useState } from "react";
import "./TermsAndConditions.scss";
import GFHeading from "../GFHeading";
import GFModal from "../GFModal";
import images from "../../shared/assets";

export interface TermsAndConditionsProps {
    className?: string;
    isErrorPrompt: boolean;
    isCheckboxChecked: boolean;
    onCheckboxChange: (isChecked: boolean) => void;
    onClose?: () => void;
}

const TermsAndConditions: React.FC<TermsAndConditionsProps> = ({ isCheckboxChecked, isErrorPrompt = false, onCheckboxChange, className }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const openTCModal = () => {
        setIsModalOpen(true);
    }

    const closeTCModal = () => {
        setIsModalOpen(false);
    }
    const handleCheckboxClick = () => {
        onCheckboxChange(!isCheckboxChecked);
    };

    return (
        <>
            <div className={`gf-label-check ${className}`}>
                <div className="gf-checkbox d-flex">
                    <input type="checkbox" name="gfCheckbox" id="gfCheckboxTC" data-testid="checkbox" className="c-pointer" checked={isCheckboxChecked}
                        onChange={handleCheckboxClick} />
                    <label htmlFor="gfCheckboxTC" className="pl-16 c-pointer"></label><GFHeading className="d-inline-block" size="S6" text="I agree to the" weight="regular" /><GFHeading  onClick={(openTCModal)} data-testid="open-modal-button" className="d-inline-block pl-4 c-pointer" size="S6" color="indigo" text="Terms and Conditions." weight="regular" />
                </div>
                {(!isCheckboxChecked && isErrorPrompt) && <div className="error-prompt d-flex mt-8">
                    <img
                        data-testid="critical-img"
                        src={images.critical}
                        className="error_critical_icon mr-4"
                    /><GFHeading size="S7" color="red-knuckles" text="Please agree to all terms and conditions before continuing." weight="light" />
                </div>}
            </div>
            <GFModal isOpen={isModalOpen} onClose={closeTCModal}>
                <GFModal.Head><GFHeading size="S4" text="Terms and Conditions" weight="regular" className="tc-heading-gfmodal"/></GFModal.Head>
                <GFModal.Body className='pt-16'>
                    <>
                        <GFHeading size="S6" text="To place this order with BT please check the summary details of your Order. If any details are incorrect, please select the back button and make corrections. Once you are happy that the details on this order are correct then please read and action the steps below:" weight="light" />
                        <ol>
                            <li><GFHeading size="S6" weight="light"><>The master agreement you previously entered with BT for Global Fabric will apply to this Order. Any services set out in this Order are subject to the latest Global Fabric Schedule which can be found here <a href='https://www.globalservices.bt.com/en/terms-and-conditions/serviceschedules' target='_blank'>https://www.globalservices.bt.com/en/terms-and-conditions/serviceschedules</a></></GFHeading></li>
                            <li><GFHeading size="S6" text="I acknowledge that by adding, deleting or amending Services as set out in this Order I am amending my existing Agreement between [Customer entity name] and [BT entity name]." weight="light" /></li>
                            <li><GFHeading size="S6" text="I have reviewed the Schedule that applies to this Order as set out in the link above and accept it." weight="light" /></li>
                            <li><GFHeading size="S6" text="I agree I am authorised to place this Order on behalf of [Customer entity name]." weight="light" /></li>
                            <li><GFHeading size="S6" text="I accept that the Order confirmation email I receive will not contain a summary of the contractual terms." weight="light" /></li>
                            <li><GFHeading size="S6" text="This Order will only be deemed accepted, and your Agreement amended, once you have received a confirmation email from BT. The email will contain the link to the website where the Global Fabric Schedule is stored and downloadable. " weight="light" /></li>
                        </ol>
                    </>
                </GFModal.Body>
            </GFModal>
        </>
    )
}

export default TermsAndConditions;