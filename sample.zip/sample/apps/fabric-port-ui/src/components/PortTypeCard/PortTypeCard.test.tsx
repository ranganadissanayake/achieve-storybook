import React from "react";
import { render, screen } from "@testing-library/react";
import PortTypeCard, { PortTypeCardProps } from "./index";

describe("PortTypeCard", () => {
  it("should render", () => {
    const cardProps: PortTypeCardProps = {
      mainImage: "",
      actionButton: <button>Sample Action</button>,
      mainTitle: "Card title",
      description: "card description",
      subtitle: "card sub title",
      subItems: ["item1"],
    };
    render(<PortTypeCard {...cardProps} />);
    expect(screen.getByTestId("port-type-card")).toBeInTheDocument();
    expect(screen.getByTestId("port-type-card-title")?.textContent).toContain(
      cardProps.mainImage || "",
    );
    expect(
      screen.getByTestId("port-type-card-description")?.textContent,
    ).toContain(cardProps.description || "");
    expect(
      screen.getByTestId("port-type-card-sub-title")?.textContent,
    ).toContain(cardProps.subtitle || "");
    expect(screen.getByTestId("action-area")).toBeInTheDocument();
  });

  it("should render without action buttons", () => {
    const cardProps: PortTypeCardProps = {
      mainImage: "",
      actionButton: null,
      mainTitle: "Card title",
      description: "card description",
      subtitle: "card sub title",
      subItems: ["item1"],
    };
    render(<PortTypeCard {...cardProps} />);
    expect(screen.getByTestId("port-type-card")).toBeInTheDocument();
    expect(screen.getByTestId("port-type-card-title")?.textContent).toContain(
      cardProps.mainImage || "",
    );
    expect(
      screen.getByTestId("port-type-card-description")?.textContent,
    ).toContain(cardProps.description || "");
    expect(
      screen.getByTestId("port-type-card-sub-title")?.textContent,
    ).toContain(cardProps.subtitle || "");
    expect(screen.queryByTestId("action-area")).not.toBeInTheDocument();
  });

  it("should render without sub items", () => {
    const cardProps: PortTypeCardProps = {
      mainImage: "",
      actionButton: <button>Sample Action</button>,
      mainTitle: "Card title",
      description: "card description",
      subtitle: "card sub title",
      subItems: [],
    };
    render(<PortTypeCard {...cardProps} />);
    expect(screen.getByTestId("port-type-card")).toBeInTheDocument();
    expect(screen.getByTestId("port-type-card-title")?.textContent).toContain(
      cardProps.mainImage || "",
    );
    expect(
      screen.getByTestId("port-type-card-description")?.textContent,
    ).toContain(cardProps.description || "");
    expect(
      screen.getByTestId("port-type-card-sub-title")?.textContent,
    ).toContain(cardProps.subtitle || "");
    expect(screen.queryByTestId("port-type-sub-items")).not.toBeInTheDocument();
  });

  it("should render without sub title", () => {
    const cardProps: PortTypeCardProps = {
      mainImage: "",
      actionButton: <button>Sample Action</button>,
      mainTitle: "Card title",
      description: "card description",
      subtitle: "card sub title",
      subItems: [],
    };
    render(<PortTypeCard {...cardProps} />);
    expect(screen.getByTestId("port-type-card")).toBeInTheDocument();
    expect(screen.getByTestId("port-type-card-title")?.textContent).toContain(
      cardProps.mainImage || "",
    );
    expect(
      screen.getByTestId("port-type-card-description")?.textContent,
    ).toContain(cardProps.description || "");
    expect(
      screen.getByTestId("port-type-card-sub-title")?.textContent,
    ).toContain(cardProps.subtitle || "");
  });

  it("should render without image", () => {
    const cardProps: PortTypeCardProps = {
      mainImage: undefined,
      actionButton: <button>Sample Action</button>,
      mainTitle: "Card title",
      description: "card description",
      subtitle: "card sub title",
      subItems: [],
    };
    render(<PortTypeCard {...cardProps} />);
    expect(screen.getByTestId("port-type-card")).toBeInTheDocument();
  });
});
