import { Divider, Icon, Label } from "@btdigital/nayan-component-library";
import React, { ReactNode } from "react";
import "./PortTypeCard.scss";

type ImageDirectionType = "top" | "right";

export interface PortTypeCardProps {
  /**
   * Set main tile image
   */
  mainImage?: string;
  /**
   * Set main tile title
   */
  mainTitle?: string;
  /**
   * Set tile content
   */
  description?: string;
  /**
   * Set sub title
   */
  subtitle?: string;
  /**
   * Set sub items as a string array
   */
  subItems?: string[];
  /**
   * Set react element
   */
  actionButton?: ReactNode;
  /**
   * Set image direction
   */
  imageDirection?: ImageDirectionType;
  /**
   * Set the width of the component
   */
  fullWidth?: "default" | "full-width";
  /**
   * Set sub item icon
   */
  subItemIcon?: ReactNode;
  /**
   * Set show hide divider
   */
  hideDivider?: boolean;
  /**
   * Set custom style
   */
  customStyle?: string;
}

const PortTypeCard: React.FC<PortTypeCardProps> = ({
  mainImage,
  mainTitle,
  description,
  subtitle,
  subItems,
  subItemIcon,
  actionButton,
  hideDivider,
  customStyle,
  imageDirection = "top",
  fullWidth = "default",
}: PortTypeCardProps) => {
  const cardContent = (
    <>
      <div
        className={`port-selection-card-content-wrapper ${
          imageDirection === "right" &&
          "port-selection-card-content-wrapper-width"
        } ${customStyle ? customStyle : ""}`}
        data-testid="port-type-card"
      >
        <div className="content-header" data-testid="port-type-card-main-image">
          {mainImage && imageDirection === "top" && imageDirection === "top" ? (
            <div className="content-img-wrapper">
              <img
                src={mainImage}
                className="content-img"
                data-testid="main-img"
                alt={mainTitle}
              />
            </div>
          ) : null}
          <div
            className={`content-title ${
              imageDirection === "right" && "content-title-left-align"
            }`}
            data-testid="port-type-card-title"
          >
            {mainTitle}
          </div>
        </div>
        <div
          className="content-description"
          data-testid="port-type-card-description"
        >
          {description}
        </div>
        <div className="content-divider">
          {!hideDivider ? <Divider></Divider> : ""}
        </div>
        <div className="sub-content">
          {subtitle && (
            <div className="sub-title" data-testid="port-type-card-sub-title">
              {subtitle}:
            </div>
          )}
          {Array.isArray(subItems) && subItems.length ? (
            <>
              <ul className="sub-items" data-testid="port-type-sub-items">
                {subItems.map((d, i) => (
                  <li key={i}>
                    <div className="sub-item">
                      <div className="sub-item-icon">
                        {subItemIcon ? (
                          subItemIcon
                        ) : (
                          <Icon
                            size="md"
                            title="tick_variant"
                            color="#5514B4"
                          />
                        )}
                      </div>
                      <Label text={d} labelTextStyles="sub-item-label" />
                    </div>
                  </li>
                ))}
              </ul>
            </>
          ) : null}
        </div>
        {actionButton ? (
          <div className="action-btn" data-testid="action-area">
            {actionButton}
          </div>
        ) : null}
      </div>
      {mainImage && imageDirection === "right" ? (
        <div className="content-img-wrapper-2">
          <img src={mainImage} className="content-img-2" alt={mainTitle} />
        </div>
      ) : null}
    </>
  );
  return (
    <div className={`port-type-card ${fullWidth}`}>
      <div
        className={`port-type-card-content ${
          imageDirection === "right" && "port-type-card-content-direction"
        }`}
      >
        {cardContent}
      </div>
    </div>
  );
};

export default PortTypeCard;
