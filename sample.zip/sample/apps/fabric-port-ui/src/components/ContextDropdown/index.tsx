import React from "react";
import "./ContextDropDown.scss";
import { Button, IconName } from "@btdigital/nayan-component-library";

export type DropItem = {
  id?: string;
  icon: IconName | string;
  label: string;
  onClick?: () => void;
  enableOriginal?: boolean;
  iconInverted?: boolean;
};

type ContextDropDownProps = {
  dropItems: DropItem[];
};

const ContextDropDown = ({ dropItems }: ContextDropDownProps) => {
  return (
    <div className="context-dropdown">
      {dropItems.map((item, index) => (
        <div
          id={item.id}
          key={`${item.label}-${index}`}
          className={"context-dropdown--item"}
        >
          <Button
            iconBefore
            label={item.label}
            variant="link"
            iconTitle={item.icon as IconName}
            isFontHeadline={false}
            className="context-dropdown--item__button"
            onPress={() => {
              item.onClick && item.onClick();
            }}
            enableOriginalIcon={item.enableOriginal ?? false}
            iconInverted={item.iconInverted}
            labelPosition="left"
          />
        </div>
      ))}
    </div>
  );
};

export default ContextDropDown;
