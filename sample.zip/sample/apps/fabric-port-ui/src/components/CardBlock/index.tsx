import React, { ReactNode } from 'react';
import "./CardBlock.scss";

interface CardBlockProps {
  className?: string;
  children: ReactNode;
}

interface CardBlockComponent extends React.FC<CardBlockProps> {
  Head: React.FC<CardBlockHeadProps>;
  Body: React.FC<CardBlockBodyProps>;
}

const CardBlock: CardBlockComponent = ({ className, children }) => {
  return (
    <div className={`cardBlock ${className || ''}`} data-testid="cardBlock">
      {children}
    </div>
  );
};

interface CardBlockHeadProps {
  className?: string;
  children: ReactNode;
  enableHeaderBorder?:boolean;
}

const CardBlockHead: React.FC<CardBlockHeadProps> = ({ className, enableHeaderBorder, children }) => {
  return (
    <div className={`cardBlockHead ${className || ''}`} data-testid="cardBlockHead">
      {children}
      {enableHeaderBorder && (<div className='head-btm-border mt-8' data-testid="head-border"></div>)}
    </div>
  );
};

interface CardBlockBodyProps {
  className?: string;
  children: ReactNode;
}

const CardBlockBody: React.FC<CardBlockBodyProps> = ({ className, children }) => {
  return (
    <div className={`cardBlockBody ${className || ''}`} data-testid="cardBlockBody">
      {children}
    </div>
  );
};

CardBlock.Head = CardBlockHead;
CardBlock.Body = CardBlockBody;

export default CardBlock;
