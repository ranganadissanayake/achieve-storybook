import React from 'react';
import { render } from '@testing-library/react';
import CardBlock from '.'; // Import your CardBlock component

describe('CardBlock Component', () => {
  it('renders CardBlock component correctly', () => {
    const { getByTestId } = render(<CardBlock children={undefined} />);
    const cardBlock = getByTestId('cardBlock');
    expect(cardBlock).toBeInTheDocument();
  });

  it('renders CardBlockHead component correctly', () => {
    const { getByTestId } = render(<CardBlock.Head  children={undefined} />);
    const cardBlockHead = getByTestId('cardBlockHead');
    expect(cardBlockHead).toBeInTheDocument();
  });

  it('renders CardBlockBody component correctly', () => {
    const { getByTestId } = render(<CardBlock.Body  children={undefined} />);
    const cardBlockBody = getByTestId('cardBlockBody');
    expect(cardBlockBody).toBeInTheDocument();
  });

  it('passes className prop to CardBlock component', () => {
    const { getByTestId } = render(<CardBlock className="custom-class"  children={undefined} />);
    const cardBlock = getByTestId('cardBlock');
    expect(cardBlock).toHaveClass('custom-class');
  });

  it('passes className prop to CardBlockHead component', () => {
    const { getByTestId } = render(<CardBlock.Head className="custom-class"  children={undefined} />);
    const cardBlockHead = getByTestId('cardBlockHead');
    expect(cardBlockHead).toHaveClass('custom-class');
  });

  it('passes className prop to CardBlockBody component', () => {
    const { getByTestId } = render(<CardBlock.Body className="custom-class"  children={undefined} />);
    const cardBlockBody = getByTestId('cardBlockBody');
    expect(cardBlockBody).toHaveClass('custom-class');
  });

  it('renders header border when enableHeaderBorder is true', () => {
    const { getByTestId } = render(<CardBlock.Head enableHeaderBorder  children={undefined} />);
    const headBorder = getByTestId('head-border');
    expect(headBorder).toBeInTheDocument();
  });

  it('does not render header border when enableHeaderBorder is false', () => {
    const { queryByTestId } = render(<CardBlock.Head enableHeaderBorder={false}  children={undefined} />);
    const headBorder = queryByTestId('head-border');
    expect(headBorder).toBeNull();
  });
});
