import React from "react";
import "./SeverityAlert.scss";
import { Card } from "@btdigital/nayan-component-library";
import GFHeading from "../../components/GFHeading";

export interface SeverityAlertProps {
  title: string;
  type?: "warning" | "critical" | "informational" | "major";
  amount: number;
  onclick?: () => void;
}
const SeverityAlert: React.FC<SeverityAlertProps> = ({
  title,
  type = "informational",
  amount,
  onclick,
}) => {
  return (
    <>
      <section className="severity-alert-wrapper" onClick={onclick}>
        <Card>
          <section className="content-wrapper">
            <section className={`left-indicator ${type}`}></section>
            <section className="content-area">
              <GFHeading
                size="S8"
                weight="regular"
                className="title"
                text={title}
              />
              <div className="amount" onClick={onclick}>
                <GFHeading size="S5" text={`${amount}`} weight="regular" />
              </div>
            </section>
          </section>
        </Card>
      </section>
    </>
  );
};

export default SeverityAlert;
