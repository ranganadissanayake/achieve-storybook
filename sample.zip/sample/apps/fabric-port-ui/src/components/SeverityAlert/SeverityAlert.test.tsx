import React from "react";
import { render, screen } from "@testing-library/react";
import SeverityAlert from "./index";
import { BrowserRouter } from "react-router-dom";

describe("SeverityAlert Component", () => {
  it("renders the component with main heading and sub heading", () => {
    render(
      <BrowserRouter>
        <SeverityAlert
          amount={12}
          title="Test"
          type="critical"
          onclick={jest.fn()}
        />
      </BrowserRouter>,
    );
    expect(screen.getByText("12")).toBeInTheDocument();
    expect(screen.getByText("Test")).toBeInTheDocument();
  });
  it("Renders with a default type", () => {
    const { container } = render(
      <SeverityAlert amount={12} title="Test" onclick={jest.fn()} />,
    );
    expect(container.getElementsByClassName("informational").length).toBeGreaterThan(0);
  });
});
