

import React from 'react';
import { priorityLevels } from "../../shared/constants";
import Tooltip from "../TooltipV2";
import GFHeading from "./../GFHeading";

type PriorityLabelProps = {
    priority: "P1" | "P2" | "P3" | "P4";
};

const PriorityLabel = ({ priority }: PriorityLabelProps) => {
    return (
        <div className="priority_row">
            <img
                src={priorityLevels[priority].icon}
            />
            <Tooltip
                placement='top'
                content={priorityLevels[priority].tooltip}
            >
                <GFHeading
                    size="S6"
                    text={priority}
                    weight="light"
                />
            </Tooltip>
        </div>
    );
};

export default PriorityLabel;
