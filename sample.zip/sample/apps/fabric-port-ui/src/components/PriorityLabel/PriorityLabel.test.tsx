import React from 'react'
import PriorityLabel from ".";
import { render } from '@testing-library/react';

describe("PriorityLabel", () => {
    it("should render", () => {
        render(<PriorityLabel priority="P1"/>);
    });
});