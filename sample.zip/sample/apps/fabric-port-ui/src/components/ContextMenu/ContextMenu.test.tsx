import React from "react";
import { render, fireEvent, waitFor } from "@testing-library/react";
import ContextMenu from "./index";

describe("ContextMenu", () => {
  it("renders without crashing", () => {
    const { getByTestId } = render(
      <ContextMenu
        className="test-class"
        onMouseEnter={() => {}}
        onMouseLeave={() => {}}
        threeDotsStatus={false}
        onClickViewDetails={() => {}}
        onClickEdit={() => {}}
        onClickState={() => {}}
        isDisabledRow={false}
        onClickDelete={() => {}}
        dotsToggleAction={() => {}}
        isSubrow={false}
      />
    );

    expect(getByTestId("three-dots")).toBeInTheDocument();
  });

  it("toggles three dots visibility on mouse enter/leave", async () => {
    const { getByTestId } = render(
      <ContextMenu
        className="test-class"
        onMouseEnter={() => {}}
        onMouseLeave={() => {}}
        threeDotsStatus={false}
        onClickViewDetails={() => {}}
        onClickEdit={() => {}}
        onClickState={() => {}}
        isDisabledRow={false}
        onClickDelete={() => {}}
        dotsToggleAction={() => {}}
        isSubrow={false}
      />
    );

    const dotsContainer = getByTestId("three-dots");
    fireEvent.mouseEnter(dotsContainer);

    fireEvent.mouseLeave(dotsContainer);

    await waitFor(() => {
      expect(dotsContainer).not.toHaveClass("show");
    });
  });

  it("calls dotsToggleAction on dots click", () => {
    const dotsToggleActionMock = jest.fn();
    const { getByTestId } = render(
      <ContextMenu
        className="test-class"
        onMouseEnter={() => {}}
        onMouseLeave={() => {}}
        threeDotsStatus={false}
        onClickViewDetails={() => {}}
        onClickEdit={() => {}}
        onClickState={() => {}}
        isDisabledRow={false}
        onClickDelete={() => {}}
        dotsToggleAction={dotsToggleActionMock}
        isSubrow={false}
      />
    );

    const dotsContainer = getByTestId("three-dot-container");
    fireEvent.click(dotsContainer);
    expect(dotsToggleActionMock).toHaveBeenCalledTimes(1);
  });

  it("renders child context wrapper if isSubrow is true", () => {
    const { container } = render(
      <ContextMenu
        className="test-class"
        onMouseEnter={() => {}}
        onMouseLeave={() => {}}
        threeDotsStatus={false}
        onClickViewDetails={() => {}}
        onClickEdit={() => {}}
        onClickState={() => {}}
        isDisabledRow={false}
        onClickDelete={() => {}}
        dotsToggleAction={() => {}}
        isSubrow={true}
      />
    );

    const childContextWrapper = container.querySelector(
      ".child-context-wrapper"
    );
    expect(childContextWrapper).toBeInTheDocument();
  });
});

it("renders child context wrapper if isSubrow is false", () => {
  const { container } = render(
    <ContextMenu
      className="test-class"
      onMouseEnter={() => {}}
      onMouseLeave={() => {}}
      threeDotsStatus={false}
      onClickViewDetails={() => {}}
      onClickEdit={() => {}}
      onClickState={() => {}}
      isDisabledRow={false}
      onClickDelete={() => {}}
      dotsToggleAction={() => {}}
      isSubrow={false}
    />
  );

  const childContextWrapper = container.querySelector(".child-context-wrapper");
  expect(childContextWrapper).not.toBeInTheDocument();
});

