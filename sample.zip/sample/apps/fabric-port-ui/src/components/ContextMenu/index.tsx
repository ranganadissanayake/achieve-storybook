/* eslint-disable @next/next/no-img-element */ //keeps throwing warnong to use next/image component
import React, { FC } from "react";

import dots from "../../shared/assets/images/svg/dots-vertical.svg";

import ContextDropDown, { DropItem } from "../../components/ContextDropdown";

export interface ContextMenuProps {
  className: string;
  onMouseEnter: (event: React.MouseEvent) => void;
  onMouseLeave: (event: React.MouseEvent) => void;
  threeDotsStatus: boolean;
  dotsToggleAction?: (event: React.MouseEvent) => void;
  onClickViewDetails?: VoidFunction;
  onClickEdit?: VoidFunction;
  onClickState?: VoidFunction;
  isDisabledRow?: boolean;
  onClickDelete?: VoidFunction;
  isSubrow?: boolean;
  dropItems?: DropItem[];
  triggerAt?: 'click'| 'mouseEnter';
}

const ContextMenu: FC<ContextMenuProps> = ({
  className,
  onMouseEnter,
  onMouseLeave,
  threeDotsStatus,
  onClickViewDetails,
  onClickEdit,
  onClickState,
  isDisabledRow,
  onClickDelete,
  dotsToggleAction,
  isSubrow,
  dropItems,
  triggerAt = "click"
}: ContextMenuProps) => {

  const handleToogleActionClick = (e:React.MouseEvent) => {
    if(dotsToggleAction && triggerAt==="click") {
      dotsToggleAction(e)
    }
  }

  const handleToogleActionMove = (e:React.MouseEvent) => {
    if(dotsToggleAction && triggerAt==="mouseEnter") {
      dotsToggleAction(e)
    }
  }

  return (
    <div
      className={`dots-container ${className}`}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      data-testid="three-dots"
    >
      <>
        <div
          className={`dots ${threeDotsStatus ? "show" : ""}`}
          onClick={handleToogleActionClick}
          onMouseOver={handleToogleActionMove}
          data-testid="three-dot-container"
        >
          <img
            className="three-dots"
            style={{ width: "20px", height: "20px" }}
            src={dots}
            alt="three-dots"
          />
        </div>

        <div
          className={`context ${isSubrow ? "child-context-wrapper" : ""}`}
          id="dots-actions"
        >
          <ContextDropDown
            dropItems={
              dropItems && dropItems?.length > 0
                ? (dropItems as DropItem[])
                : isSubrow
                ? [
                    {
                      label: isDisabledRow ? "Enable" : "Disable",
                      onClick: () => onClickState && onClickState(),
                      icon: isDisabledRow ? "tick_variant" : "stop",
                    },
                    {
                      id: "delete",
                      label: "Delete",
                      onClick: () => onClickDelete && onClickDelete(),
                      icon: "bin",
                    },
                  ]
                : [
                    {
                      label: "View",
                      onClick: () => onClickViewDetails && onClickViewDetails(),
                      icon: "view",
                    },
                    {
                      label: "Edit",
                      onClick: () => onClickEdit && onClickEdit(),
                      icon: "signature",
                    },
                    {
                      label: isDisabledRow ? "Enable" : "Disable",
                      onClick: () => onClickState && onClickState(),
                      icon: isDisabledRow ? "tick_variant" : "stop",
                    },
                    {
                      id: "delete",
                      label: "Delete",
                      onClick: () => onClickDelete && onClickDelete(),
                      icon: "bin",
                    },
                  ]
            }
          />
        </div>
      </>
    </div>
  );
};

export default ContextMenu;
