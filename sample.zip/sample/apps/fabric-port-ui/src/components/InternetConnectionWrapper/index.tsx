import React from "react";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { useSelector } from "react-redux";

import {
  Badge,
  Card,
  Button,
  Label,
  Modal,
  Crumb,
} from "@btdigital/nayan-component-library";

import InternetConnectionHeader from "./InternetConnectionHeader";
import {
  selectCurrentStep,
  selectInternetEditItem,
  selectPortData,
} from "../../redux/internetSlice";

import images from "../../shared/assets";

import "./index.scss";
import PageWrap from "../../components/PageWrap";

export interface InternetConnectionWrapperProps
  extends React.PropsWithChildren {
  selectedPort?: boolean;
  portsPreview?: boolean;
  hideHeader?: boolean;
  selectedPorts?: any[];
  currentStep?: number;
  handleBack?: () => void;
  handleNext?: () => void;
  diverseSecondaryResielienceType?: string;
  diverseSecondaryPortName?: string;
  isSelectedDiversePrimaryPort?: boolean;
  isSelectedDiverseSecondaryPort?: boolean;
  diversePortSubRows?: any;
  dataLength?: number;
  checkNextJourney?: boolean;
}

const InternetConnectionWrapper: React.FC<InternetConnectionWrapperProps> = ({
  selectedPort,
  selectedPorts,
  portsPreview,
  hideHeader,
  children,
  currentStep,
  handleBack,
  handleNext,
  isSelectedDiversePrimaryPort,
  isSelectedDiverseSecondaryPort,
  diversePortSubRows,
  dataLength,
  checkNextJourney,
}) => {
  const navigate = useNavigate();
  const [searchParams, _] = useSearchParams();
  const _selectCurrentStep = useSelector(selectCurrentStep);
  const _portData = useSelector(selectPortData);
  const editInternetItem = useSelector(selectInternetEditItem);
  const isEdit = searchParams.get("status") === "edit";

  const selectedRowSubRow = diversePortSubRows?.length
    ? diversePortSubRows
    : _portData[0]?.diversePortSubRows;

  const [showAlert, setShowAlert] = React.useState(false);
  const [_currentStep, setCurrentStep] = React.useState(_selectCurrentStep);
  const { pathname } = useLocation();

  const [_showModal, setShowModal] = React.useState(false);
  const [_destination, setDestination] = React.useState<string>("");

  const defaultCrumbs: Crumb[] = [
    {
      name: "Network Services",
      onClick: () => {
        setShowModal(true);
        setDestination("/network-services");
      },
    },
    {
      name: "Create Internet Connection",
    },
  ];

  const editCrumbs: Crumb[] = [
    {
      name: "Network Services",
      onClick: () => {
        setShowModal(true);
        setDestination("/network-services");
      },
    },
    {
      name: "Internet Inventory",
      onClick: () => {
        setShowModal(true);
        setDestination("/internet-connection");
      },
    },
    {
      name: "Edit",
    },
  ];

  const handleBreadcrumbRouting = (): Crumb[] => {
    const breadcrumbItems = isEdit ? editCrumbs : defaultCrumbs;

    const updatedBreadcrumb: Crumb[] = [];

    breadcrumbItems.forEach((crumb) => {
      if (!updatedBreadcrumb.some((item) => item.name === crumb.name)) {
        updatedBreadcrumb.push(crumb);
      }
    });

    return updatedBreadcrumb;
  };

  React.useEffect(() => {
    if (isEdit && currentStep) {
      setCurrentStep(currentStep);
    }
  }, [isEdit, currentStep]);

  const _onModalOk = () => {
    setShowModal(false);
    navigate(_destination);
  };

  return (
    <section className="internet-wrapper">
      <PageWrap
        className="internet-wrapper-header m-0 p-0"
        steps={["Select Ports", "Configuration", "Summary"]}
        currentStep={_currentStep}
        handleBreadcrumbRouting={handleBreadcrumbRouting}
      />
      <div
        className="internet-wrapper--content p-0 pos-r"
        data-testid="internet-wrapper"
      >
        <div className="fp-container">
          {hideHeader ? null : (
            <div className="fp-row">
              <div className="col-16">
                <InternetConnectionHeader
                  title={isEdit ? editInternetItem?.internetName : undefined}
                />
              </div>
            </div>
          )}
          {portsPreview && (
            <div className="fp-row preview-section">
              {selectedPort ? (
                selectedPorts &&
                selectedPorts.map(
                  (port) =>
                    port && (
                      <>
                        {(port.resilience === "Standard" ||
                          port.resilience === "Non diverse") && (
                          <div
                            className="col-16 md:col-4 port-card"
                            data-testid="non_diverse_title"
                          >
                            <Card>
                              <div>
                                <Badge
                                  style="default-light"
                                  text="Non Diverse"
                                />
                                <div className="text">{port.portName}</div>
                                <Label
                                  helper={`${
                                    port.portLocation ?? port.country
                                  }`}
                                  helperTextStyles="port_location"
                                />
                              </div>
                            </Card>
                          </div>
                        )}

                        {port.isDiverse && (
                          <>
                            {selectedRowSubRow?.length > 0 &&
                            (isSelectedDiversePrimaryPort ||
                              isSelectedDiverseSecondaryPort) ? (
                              <div
                                className={`port-card col-16 md:col-${
                                  isSelectedDiversePrimaryPort &&
                                  isSelectedDiverseSecondaryPort
                                    ? "8"
                                    : "4"
                                } mb-16`}
                                data-testid="diverse_title"
                              >
                                <Card>
                                  <>
                                    {isSelectedDiversePrimaryPort ||
                                    (_portData[0].isPrimarySelected &&
                                      selectedRowSubRow.length) ? (
                                      <div
                                        className={
                                          isSelectedDiverseSecondaryPort
                                            ? "card-wrap"
                                            : ""
                                        }
                                      >
                                        <div className="card-left">
                                          <Badge
                                            style="default-light"
                                            text="Diverse - Primary"
                                          />
                                          <div className="text">
                                            {selectedRowSubRow[0].portName
                                              ? selectedRowSubRow[0].portName
                                              : ""}
                                          </div>
                                          <Label
                                            helper={
                                              selectedRowSubRow[0].location
                                                ? selectedRowSubRow[0].location
                                                : ""
                                            }
                                            helperTextStyles="port_location"
                                          />
                                        </div>
                                      </div>
                                    ) : (
                                      ""
                                    )}

                                    {isSelectedDiverseSecondaryPort ||
                                    (_portData[0].isSecondarySelected &&
                                      selectedRowSubRow.length) ? (
                                      <div
                                        className={
                                          isSelectedDiversePrimaryPort
                                            ? "card-wrap"
                                            : ""
                                        }
                                      >
                                        <div className="card-right">
                                          <Badge
                                            style="default-light"
                                            text="Diverse - Secondary"
                                          />
                                          <div className="text">
                                            {selectedRowSubRow[1].portName
                                              ? selectedRowSubRow[1].portName
                                              : ""}
                                          </div>
                                          <Label
                                            helper={
                                              selectedRowSubRow[1].location
                                                ? selectedRowSubRow[1].location
                                                : ""
                                            }
                                            helperTextStyles="port_location"
                                          />
                                        </div>
                                      </div>
                                    ) : (
                                      ""
                                    )}
                                  </>
                                </Card>
                              </div>
                            ) : (
                              <div className="col-16 md:col-8 port-card">
                                <Card>
                                  <div className="no-port">
                                    <img
                                      src={images.connector}
                                      alt=""
                                      srcSet=""
                                    />
                                    <Label
                                      size="sm"
                                      text="No Port Selected"
                                      helper="Start an Internet connection with an existing port below."
                                    />
                                  </div>
                                </Card>
                              </div>
                            )}
                          </>
                        )}
                      </>
                    ),
                )
              ) : (
                <div className="col-16 md:col-8 port-card">
                  <Card>
                    <div className="no-port">
                      <img src={images.connector} alt="" srcSet="" />
                      <Label
                        size="sm"
                        text="No Port Selected"
                        helper="Start an Internet connection with an existing port below."
                      />
                    </div>
                  </Card>
                </div>
              )}
            </div>
          )}
        </div>
        {children}
        <div className="fp-container">
          <div className="fp-row">
            <div className="actions actions__bottom col-16">
              {handleBack && pathname !== "/internet-connection/summary" && (
                <Button
                  label="Back"
                  variant="link"
                  dataTestId="back_btn"
                  onPress={handleBack}
                />
              )}
              {handleNext && (
                <Button
                  className="btn-continue"
                  disabled={!dataLength && checkNextJourney}
                  label="Continue"
                  variant="gradient"
                  dataTestId="continue_btn"
                  onPress={() => {
                    selectedPort ? handleNext() : setShowAlert(true);
                  }}
                />
              )}
            </div>
          </div>
        </div>
      </div>
      {showAlert && (
        <Modal
          topIcon="cloud_desktop"
          topIconStyle="critical"
          size="md"
          title="You haven’t selected a live port"
          complementaryMessage="You cannot continue without selecting a live port"
          contentAlign="center"
          hideButtons={true}
          onCancel={() => setShowAlert(false)}
          closeModal={!showAlert}
        />
      )}

      <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        topIconSize="md"
        title="Leave without saving changes"
        complementaryMessage="Are you sure you want to leave this page? Your setup information will be lost."
        contentAlign="center"
        actionText="Leave"
        onOk={_onModalOk}
        closeModal={!_showModal}
        onCancel={() => setShowModal(false)}
      />
    </section>
  );
};

export default InternetConnectionWrapper;
