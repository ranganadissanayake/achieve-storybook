import { Label } from "@btdigital/nayan-component-library";
import React from "react";
import images from "../../../shared/assets";
import "./InternetConnectionHeader.scss";

export interface InternetConnectionHeaderProps {
  title?: string;
}

const InternetConnectionHeader: React.FC<InternetConnectionHeaderProps> = ({
  title = "Create an Internet connection from an existing Port",
}) => {
  return (
    <div className="header-wrapper" data-testid="header-wrapper">
      <div className="header-image">
        <img src={images.attachPort} alt="" srcSet="" />
      </div>
      <div className="header-content">
        <Label text={title} />
        <div className="header-content--caption">
          <p>
            Visit <span>BT Global Fabric knowledge centre</span> for more
            information on Internet connection.
          </p>
        </div>
      </div>
    </div>
  );
};

export default InternetConnectionHeader;
