import React from 'react';
import { render } from '@testing-library/react';
import InternetConnectionHeader from './index';

describe('InternetConnectionHeader', () => {
  it('renders with a default title', () => {
    const { getByTestId, getByText } = render(<InternetConnectionHeader />);
    const headerWrapper = getByTestId('header-wrapper');
    const defaultTitle = 'Create an Internet connection from an existing Port';

    expect(headerWrapper).toBeInTheDocument();
    expect(getByText(defaultTitle)).toBeInTheDocument();
  });

});
