import { fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import { useSelector } from "react-redux";
import { BrowserRouter } from "react-router-dom";
import "regenerator-runtime";
import InternetConnectionWrapper from "./index";
import { diverseItem } from "../../shared/constants/portInventory";

jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
}));

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useSearchParams: () => [new URLSearchParams({ status: "edit" })],
}));

describe("InternetConnectionWrapper", () => {
  const selectCurrentStepMock = useSelector as jest.Mock;

  beforeEach(() => {
    selectCurrentStepMock.mockClear();
  });

  afterAll(() => jest.clearAllMocks());

  it("renders without errors", () => {
    selectCurrentStepMock.mockReturnValue(1);
    render(
      <BrowserRouter>
        <InternetConnectionWrapper />
      </BrowserRouter>
    );
    fireEvent.click(screen.getByText("Network Services"));
    expect(
      screen.getByText("Leave without saving changes")
    ).toBeInTheDocument();
    fireEvent.click(screen.getByText("Leave"));

    fireEvent.click(screen.getByText("Internet Inventory"));
    expect(
      screen.getByText("Leave without saving changes")
    ).toBeInTheDocument();
    fireEvent.click(screen.getByText("Cancel"));
  });

  it("renders without errors; handle continue", () => {
    selectCurrentStepMock.mockReturnValue(1);
    const nextSpy = jest.fn();
    render(
      <BrowserRouter>
        <InternetConnectionWrapper dataLength={1} handleNext={() => nextSpy} />
      </BrowserRouter>
    );
    fireEvent.click(screen.getByText("Continue"));
    expect(
      screen.getByText("You cannot continue without selecting a live port")
    ).toBeInTheDocument();
  });

  it("renders port items without errors", () => {
    selectCurrentStepMock.mockReturnValue(2);
    render(
      <BrowserRouter>
        <InternetConnectionWrapper
          selectedPort={true}
          portsPreview={true}
          selectedPorts={[diverseItem]}
          isSelectedDiversePrimaryPort={true}
          isSelectedDiverseSecondaryPort={true}
          diversePortSubRows={[diverseItem, diverseItem]}
        />
      </BrowserRouter>
    );
    expect(screen.getByText("Internet Inventory")).toBeInTheDocument();
  });

  it("renders port items without children selected", () => {
    selectCurrentStepMock.mockReturnValue(2);
    render(
      <BrowserRouter>
        <InternetConnectionWrapper
          selectedPort={true}
          portsPreview={true}
          selectedPorts={[diverseItem]}
          isSelectedDiversePrimaryPort={false}
          isSelectedDiverseSecondaryPort={false}
        />
      </BrowserRouter>
    );
    expect(screen.getByText("No Port Selected")).toBeInTheDocument();
  });
});
