import React, { PropsWithChildren, useEffect, useState, FC } from "react";
import useAppContext from "../../shared/hooks/useAppContext";

type ComponentControllerProps = PropsWithChildren & {
  flag: string;
};

export const ComponentController: FC<ComponentControllerProps> = ({
  children,
  flag,
}) => {
  const { featureFlags } = useAppContext();
  const [isVisible, setIsVisible] = useState<boolean | null>(null);

  useEffect(() => {
    setIsVisible(!featureFlags.component.includes(flag));
  }, [featureFlags.component, flag]);

  return <>{isVisible && children}</>;
};
