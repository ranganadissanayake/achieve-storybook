import React from "react";

import "./AlertTile.scss";
import GFHeading from "../GFHeading";
import SeletonLoader from "../SeletonLoader";
import CardBlock from "../CardBlock";

export interface AlertTileProps {
  iconName: string;
  mainHeading: string;
  subHeading: string;
  loading?: boolean;
}

const AlertTile: React.FC<AlertTileProps> = ({
  iconName,
  mainHeading,
  subHeading,
  loading = false
}) => {
  return (
    <>
      <CardBlock className="custom-card">
        <CardBlock.Body className="cardBlock-body">

          {loading ? ( <SeletonLoader />) : 
          (<section className="alert-tile-wrapper d-flex al-itm-ctr pl-20 pr-20 pb-20 pt-20">
            <section className="alert-tile-icon d-flex al-itm-ctr">
              <img src={iconName} alt={iconName + "-image"} />
            </section>
            <ul className="main-content-wrapper">
              <GFHeading size="S3" text={mainHeading} weight="regular" />
              <GFHeading
                size="S6"
                weight="light"
                className="sub-heading"
                text={subHeading}
              />
            </ul>
          </section> )}
        </CardBlock.Body>
      </CardBlock>
    </>
  );
};

export default AlertTile;
