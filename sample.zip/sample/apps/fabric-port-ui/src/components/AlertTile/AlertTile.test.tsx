import React from "react";
import { render, screen } from "@testing-library/react";
import AlertTile from "./index";

describe("AlertTile Component", () => {
  it("renders the component with main heading and sub heading", () => {
    render(
      <AlertTile iconName="test" mainHeading="32" subHeading="Network port" />,
    );
    setTimeout(()=>{
    expect(screen.getByText("Network port")).toBeInTheDocument();
    expect(screen.getByAltText("test-image")).toBeInTheDocument();},5001);
  });
});
