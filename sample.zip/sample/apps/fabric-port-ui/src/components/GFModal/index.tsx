import React, { ReactNode, useEffect, useState } from 'react';
import "./GFModal.scss";

export interface GFModalProps {
  isOpen: boolean;
  className?: string;
  children: ReactNode;
  testid?: string;
  onClose: () => void;
}
interface GFModalComponent extends React.FC<GFModalProps> {
  Head: React.FC<GFModalHeadProps>;
  Body: React.FC<GFModalBodyProps>;
}

const GFModal: GFModalComponent = ({ isOpen, className, children, onClose, testid = 'gfmodal' }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const closeModal = () => {
    onClose();
  };

  useEffect(() => {
    setIsModalOpen(isOpen)
  }, [isOpen]);

  useEffect(() => {
    if (isModalOpen) {
      document.body.classList.add('modal-open');
    } else {
      document.body.classList.remove('modal-open');
    }

    return () => {
      document.body.classList.remove('modal-open');
    };
  }, [isModalOpen]);

  if (!isModalOpen) {
    return null;
  }

  return (
    <>
      <span className="gfModal_overlay" data-testid="modal-overlay"  onClick={closeModal}></span>
      <div className={`gfModal pt-24 pb-32 pl-40 pr-4 ${className || ''}  ${isModalOpen ? 'open' : ''}`} data-testid={testid}>
        <span className="gfModal_close-btn" data-testid="close-button" onClick={closeModal}></span>
        {children}
      </div>
    </>
  );
};

interface GFModalHeadProps {
  className?: string;
  children: ReactNode;
}

const GFModalHead: React.FC<GFModalHeadProps> = ({ className, children }) => {
  return (
    <div className={`gfModal_head ${className || ''}`} data-testid="gfModalHead">
      {children}
    </div>
  );
};

interface GFModalBodyProps {
  className?: string;
  children: ReactNode;
}

const GFModalBody: React.FC<GFModalBodyProps> = ({ className, children }) => {
  return (
    <div className={`gfModal_body pr-32 ${className || ''}`} data-testid="gfModalBody">
      {children}
    </div>
  );
};

GFModal.Head = GFModalHead;
GFModal.Body = GFModalBody;

export default GFModal;
