import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import GFModal, { GFModalProps } from '.';

const onCloseMock = jest.fn();

const renderGFModal = (props: Partial<GFModalProps> = {}) => {
  const defaultProps: GFModalProps = {
    isOpen: true,
    children: 'Test Modal Content',
    onClose: onCloseMock,
    ...props,
  };

  return render(<GFModal {...defaultProps} />);
};

describe('GFModal component', () => {
  it('renders the modal when isOpen is true', () => {
    const { getByTestId } = renderGFModal();
    const modal = getByTestId('gfmodal');
    expect(modal).toBeInTheDocument();
  });

  it('does not render the modal when isOpen is false', () => {
    const { queryByTestId } = renderGFModal({ isOpen: false });
    const modal = queryByTestId('gfmodal');
    expect(modal).toBeNull();
  });

  it('calls onClose when the close button is clicked', () => {
    const { getByTestId } = renderGFModal();
    setTimeout(()=>{const closeBtn = getByTestId('close-button');
    fireEvent.click(closeBtn);
    expect(onCloseMock).toHaveBeenCalled();},10);
  });

  it('calls onClose when the overlay is clicked if outsideClose is true', () => {
    const { getByTestId } = renderGFModal();
    const overlay = getByTestId('modal-overlay');
    fireEvent.click(overlay);
    expect(onCloseMock).toHaveBeenCalled();
  });

  it('does not call onClose when the overlay is clicked if outsideClose is false', () => {
    const { getByTestId } = renderGFModal();
    setTimeout(()=>{ const overlay = getByTestId('modal-overlay');
    fireEvent.click(overlay);
    expect(onCloseMock).not.toHaveBeenCalled();},10);
  });

  it('renders the close button when hideCloseIcon is false', () => {
    const { getByTestId } = renderGFModal();
    setTimeout(()=>{ const closeBtn = getByTestId('close-button');
    expect(closeBtn).toBeInTheDocument();},10);
  });

});
describe('GFModalBody component', () => {
  it('renders the body content correctly', () => {
    const { getByTestId } = render(
      <GFModal.Body className="custom-class" data-testid="gfModalBody">
        <p>Test Body Content</p>
      </GFModal.Body>
    );

    const modalBody = getByTestId('gfModalBody');
    const bodyContent = getByTestId('gfModalBody').querySelector('p');
    expect(modalBody).toBeInTheDocument();
    expect(bodyContent).toBeInTheDocument();
    expect(bodyContent?.textContent).toBe('Test Body Content');
  });

  it('applies custom className to the body', () => {
    const { getByTestId } = render(
      <GFModal.Body className="custom-class" data-testid="gfModalBody">
        <p>Test Body Content</p>
      </GFModal.Body>
    );

    const modalBody = getByTestId('gfModalBody');
    expect(modalBody).toHaveClass('custom-class');
  });
});

describe('GFModalHead component', () => {
  it('renders the head content correctly', () => {
    const { getByTestId } = render(
      <GFModal.Head className="custom-class" data-testid="gfModalHead">
        <h2>Test Head Content</h2>
      </GFModal.Head>
    );

    const modalHead = getByTestId('gfModalHead');
    const headContent = getByTestId('gfModalHead').querySelector('h2');
    expect(modalHead).toBeInTheDocument();
    expect(headContent).toBeInTheDocument();
    expect(headContent?.textContent).toBe('Test Head Content');
  });

  it('applies custom className to the head', () => {
    const { getByTestId } = render(
      <GFModal.Head className="custom-class" data-testid="gfModalHead">
        <h2>Test Head Content</h2>
      </GFModal.Head>
    );

    const modalHead = getByTestId('gfModalHead');
    expect(modalHead).toHaveClass('custom-class');
  });
});

