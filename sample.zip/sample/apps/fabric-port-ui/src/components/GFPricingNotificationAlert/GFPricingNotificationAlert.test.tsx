import React from 'react';
import { render } from '@testing-library/react';
import GFPricingNotificationAlert from './index';

describe('GFPricingNotificationAlert', () => {
  it('renders with default state', () => {
    const { getByTestId } = render(<GFPricingNotificationAlert state='default'/>);
    const alertElement = getByTestId('pricing-notification-alert');
    expect(alertElement).toBeInTheDocument();
    expect(alertElement).toHaveClass('pricing-notification-alert default');
  });

  it('renders with error state', () => {
    const { getByTestId } = render(<GFPricingNotificationAlert state="error" />);
    const alertElement = getByTestId('pricing-notification-alert');
    expect(alertElement).toBeInTheDocument();
    expect(alertElement).toHaveClass('error');
  });

  it('renders with custom style', () => {
    const customStyle = { color: 'red' };
    const { getByTestId } = render(<GFPricingNotificationAlert style={customStyle} />);
    const alertElement = getByTestId('pricing-notification-alert');
    expect(alertElement).toBeInTheDocument();
    expect(alertElement).toHaveStyle(customStyle);
  });

  it('renders children', () => {
    const { getByTestId, getByText } = render(
      <GFPricingNotificationAlert>
        <span>Test Children</span>
      </GFPricingNotificationAlert>
    );
    const alertElement = getByTestId('pricing-notification-alert');
    expect(alertElement).toBeInTheDocument();
    expect(getByText('Test Children')).toBeInTheDocument();
  });
});