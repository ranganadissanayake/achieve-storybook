import React from 'react'
import './index.scss'
type GFPricingNotificationAlert = {
    children?: JSX.Element, // A JSX element, add className="pricing-notification-alert-bold" to emboldedn the text
    state?: 'default' | 'error' | 'placeholder',
    className?: string,
    style?: React.CSSProperties,
}
const GFPricingNotificationAlert = ({children,state,className,style}:GFPricingNotificationAlert) => {
    return (
        <div 
        className={`pricing-notification-alert ${state} ${className}`}
        style={style}
        data-testid='pricing-notification-alert'
        >
            {children}
        </div>
    )
}

export default GFPricingNotificationAlert