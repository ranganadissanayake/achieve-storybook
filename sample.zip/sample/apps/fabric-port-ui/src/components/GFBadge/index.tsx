import React from "react";
import "./index.scss";
import GFHeading from "./../../components/GFHeading";
import { Icon } from "@btdigital/nayan-component-library";

export interface GFBadgeProps {
  text: string;
  style?: string;
  iconTitle?: boolean;
  onClick?: () => void;
}

const GFBadge: React.FC<GFBadgeProps> = ({
  text,
  style = "acknowledged",
  iconTitle = false,
  onClick,
}) => {
  return (
    <GFHeading
      className={`gfBadge ${style.toLowerCase().replace(" ", "-")}`}
      weight={"regular"}
      text={text}
      size={"S6"}
      children={
        iconTitle ? <Icon title="tick_alt_2px" className="displayIcon" /> : ""
      }
      onClick={onClick}
    />
  );
};

export default GFBadge;
