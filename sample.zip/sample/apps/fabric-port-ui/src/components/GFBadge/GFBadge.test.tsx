import React from "react";
import { render, screen } from "@testing-library/react";
import GFBadge from "./index";

describe("GFBadge", () => {
  test("should render acknowledged style", () => {
    render(<GFBadge style="acknowledged" text="Acknowledged" />);
    expect(screen.getByText("Acknowledged")).toBeInTheDocument();
  });
  test("should render budgetary style", () => {
    render(<GFBadge style="budgetary" text="Budgetary" />);
    expect(screen.getByText("Budgetary")).toBeInTheDocument();
  });
  test("should render complete style", () => {
    render(<GFBadge style="complete" text="Complete" />);
    expect(screen.getByText("Complete")).toBeInTheDocument();
  });
  test("should render expired style", () => {
    render(<GFBadge style="expired" text="Expired" />);
    expect(screen.getByText("Expired")).toBeInTheDocument();
  });
  test("should render agree style", () => {
    render(<GFBadge style="agree" text="agree" />);
    expect(screen.getByText("agree")).toBeInTheDocument();
  });
  test("should render accept style", () => {
    render(<GFBadge style="accept" text="agree" />);
    expect(screen.getByText("agree")).toBeInTheDocument();
  });
  test("should render accepted style", () => {
    render(<GFBadge style="accepted" text="agree"  iconTitle={true} />);
    expect(screen.getByText("agree")).toBeInTheDocument();
  });
});
