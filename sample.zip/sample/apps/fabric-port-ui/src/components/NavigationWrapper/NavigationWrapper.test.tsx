import React from "react";
import {
  render,
  fireEvent,
  screen,
  waitFor,
  renderHook,
  act,
} from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import NavigationWrapper from "./index";
import { ApiProvider, useApi } from "../../shared/helpers";
import { mockResponses } from "../../../msw/mock-responses";
import { MOCK_ALARMS_LIST } from "../../shared/constants/alarms";

jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
  useDispatch: jest.fn().mockReturnValue(jest.fn()),
}));
jest.mock("../../shared/helpers/api", () => ({
  ApiProvider: ({ children }) => <div>{children}</div>,
  useApi: jest.fn(),
}));
jest.mock("@btdigital/nayan-component-library", () => ({
  ...jest.requireActual("@btdigital/nayan-component-library"),
  Map: () => <div data-testid="map-component" />,
}));
jest.mock("react-inlinesvg");

const mockAlarmsResponse = {
  results: MOCK_ALARMS_LIST,
  pagination: {
    limit: 10,
    offset: 0,
    total: 8,
  },
};

describe("NavigationWrapper", () => {
  const mockUseSelector = useSelector as jest.Mock;
  const mockUseDispatch = useDispatch as jest.Mock;
  beforeEach(() => {
    mockUseSelector.mockClear();
    mockUseDispatch.mockClear();
    (useApi as jest.Mock).mockReturnValue({
      getBillingAccounts: jest
        .fn()
        .mockResolvedValue(mockResponses.billingAccount.response),
      getGeoLocations: jest
        .fn()
        .mockResolvedValue(mockResponses.geographicalLocations.response),
        getAlarms: jest
        .fn()
        .mockResolvedValue(mockAlarmsResponse),
      getUserProfile: jest
        .fn()
        .mockResolvedValue(mockResponses.userProfile.response),
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders without error", () => {
    mockUseSelector.mockReturnValue(0);

    render(
      <BrowserRouter>
        <NavigationWrapper />
      </BrowserRouter>
    );

    expect(screen.getByTestId("navigation-wrapper")).toHaveClass(
      "app-container"
    );
  });

  test("navigates to the correct route when a side navigation item is clicked", async () => {
    mockUseSelector.mockReturnValue(0);
    mockUseDispatch.mockReturnValue(jest.fn());

    render(
      <BrowserRouter>
        <NavigationWrapper />
      </BrowserRouter>
    );

    const sideNavItem = screen
      .getByText("Notifications")
      .closest("a") as HTMLAnchorElement;

    fireEvent.click(sideNavItem);

    await waitFor(() => {
      expect(sideNavItem).toHaveClass("link");
    });
  });

  test("displays the Unsaved Changes modal when attempting to leave the page with unsaved changes", () => {
    mockUseSelector.mockReturnValue(1);
    const mockDispatch = jest.fn();
    mockUseDispatch.mockReturnValue(mockDispatch);

    render(
      <BrowserRouter>
        <NavigationWrapper />
      </BrowserRouter>
    );

    const leaveButton = screen.getByText("Leave");
    fireEvent.click(leaveButton);

    const unsavedChangesModal = screen.getByText(
      "Leave without saving changes"
    );
    expect(unsavedChangesModal).toBeInTheDocument();
  });
  test('should switch between "All" and "Unread" tabs when clicked', () => {
    const { result } = renderHook(() => React.useState(false));
    const [, setisNotificationAlert] = result.current;

    // Render component
    act(() => {
      setisNotificationAlert(true);
      render(
        <ApiProvider>
          <BrowserRouter>
            <NavigationWrapper />
          </BrowserRouter>
        </ApiProvider>
      );
    });

    // Assert
    expect(result.current[0]).toBe(true);
  });

  test("trigger _onClickSwitchAccount and check", async () => {
    const { getByText, getByTestId, getAllByText } = render(
      <BrowserRouter>
        <NavigationWrapper />
      </BrowserRouter>
    );
    const profileAvatar = getByTestId("avatar");
    fireEvent.click(profileAvatar);
    expect(getByText("Switch Account")).toBeTruthy();
    fireEvent.click(getByText("Switch Account"));
    await waitFor(() => {
      expect(getAllByText("Switch Account")[0]).toBeTruthy();
    });
  });

  test("bell icon click", () => {
    mockUseSelector.mockReturnValue(0);

    render(
      <BrowserRouter>
        <NavigationWrapper />
      </BrowserRouter>
    );

    expect(screen.getAllByTestId("icon")[0]).toBeInTheDocument();
    fireEvent.click(screen.getAllByTestId("icon")[0]);
    expect(screen.getByText("View all")).toBeInTheDocument();
    expect(screen.getByText("My Locations")).toBeInTheDocument();
    fireEvent.click(screen.getByText("My Locations"));
  });
});
