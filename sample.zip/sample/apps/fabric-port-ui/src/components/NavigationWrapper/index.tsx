/* eslint-disable security/detect-object-injection */
import React, { useRef, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { motion } from "framer-motion";

import {
  Header,
  Modal,
  Radio,
  useToast,
} from "@btdigital/nayan-component-library";

import {
  headerItems,
  navItems,
  JOURNEY_ROUTES,
  RouteEnum,
  UNSAVED_POPUP_TITLE,
  UNSAVED_POPUP_MESAGE,
  BT_NOTIFICATIONS,
  accountDetails,
  SELECTED_ACCOUNT,
} from "../../shared/constants";
import { selectCountState } from "../../redux/basketSlice";
import images from "../../shared/assets";
import { resetPortOnly } from "../../redux/portOnlySlice";
import { resetInternetSlice } from "../../redux/internetSlice";
import Notifications from "../../containers/Notifications";
import SideNav from "../../components/NavigationBarV2";
import { useApi } from "../../shared/helpers";
import {
  updateNotificationsList,
  resetNotificationsSlice,
} from "../../redux/notificationsSlice";
import {
  selectBillingAccounts,
  updateSelectedBillingAccount,
} from "../../redux/billingAccountsSlice";
import { IGeoLocation } from "../../shared/models";
import { setGeoLocation } from "../../redux/geoLocationSlice";
import { buildNotification } from "../../shared/constants/toastBuilder";
import { errorToastOptions } from "../../shared/constants/errorToast";
import useLocalStorage from "../../shared/hooks/useLocalStorage";
import useAppContext from "../../shared/hooks/useAppContext";
import { EventsEntity } from "../../shared/mappers/classes/entity/events.entity";
import { eventsRequestDTO } from "../../shared/mappers/services/events.service";
import { IGetAlarmResponse } from "../../shared/constants/alarms";
import { removeNullEmptyPropsEvents } from "../../shared/utils";

import "./NavigationWrapper.scss";

/**
 * The properties required for the Navigation Wrapper Component
 * @author Joel Chi <joel.abongwa@distributed.com>
 */
export interface NavigationWrapperProps {
  /**
   * Difines the content for the component the wrapper is wrapped around
   */
  children?: React.ReactNode;
}

/**
 * Renders the Port Type A Wrapper Component
 * @param {React.PropsWithChildren<NavigationWrapperProps>} props NavigationWrapperProps properties
 * @returns
 */
const NavigationWrapper: React.FC<NavigationWrapperProps> = ({ children }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const toast = useToast();
  const api = useApi();

  const [notificationStorage, setNotificationStorage] = useLocalStorage(
    BT_NOTIFICATIONS,
    [],
  );

  const [collapse, setCollapse] = React.useState(true);

  const _cartCount = useSelector(selectCountState);
  const billingAccounts = useSelector(selectBillingAccounts);

  const [_showModal, setShowModal] = React.useState(false);
  const [selectedAccount, setSelectedAccount] = React.useState<string>(
    sessionStorage.getItem(SELECTED_ACCOUNT) ?? "BT Global",
  );
  const [switchAccount, setSwitchAccount] = React.useState(false);
  const [_selectedRoute, setSelectedRoute] = React.useState("");
  const [_isAlertPopover, setisAlertPopover] = React.useState(false);
  const [isNotificationAlert, setisNotificationAlert] = React.useState(false);

  const location = useLocation();
  const { featureFlags } = useAppContext();

  const [notifications, setNotifications]: any = React.useState([]);

  const actionCardRef = useRef<HTMLDivElement | null>(null);

  const notificationList = React.useCallback(() => {
    if (localStorage.getItem(BT_NOTIFICATIONS)) {
      setNotifications(
        JSON.parse(localStorage.getItem(BT_NOTIFICATIONS) ?? ""),
      );
    }
    console.log(notifications);
  }, [localStorage.getItem(BT_NOTIFICATIONS), location.pathname]);

  const navigateBasket = () => {
    navigate("/basket");
  };

  const onClickSideNavItem = (route?: string) => {
    dispatch(resetPortOnly());
    if (billingAccounts.length > 0) {
      dispatch(
        updateSelectedBillingAccount({
          billingAccountId:
            billingAccounts.find((acc) => acc.default)?.id ?? "",
          currencyFormat:
            billingAccounts.find((acc) => acc.default)?.currency ?? "",
          billingAccountName:
            billingAccounts.find((acc) => acc.default)?.name ?? "",
          customerPurchaseOrders:
            billingAccounts.find((acc) => acc.default)?.customerPurchaseOrder ??
            undefined,
        }),
      );
    }
  };

  const updatedRoutes = navItems.main
    ?.filter((route) => !featureFlags.navigationItems.includes(route.title))
    .map((item) => {
      item.onClick = () => onClickSideNavItem(item.route);
      item.isActive =
        location.pathname === item.route && location.pathname !== "/";
      return item;
    });

  const _onModalOk = () => {
    setShowModal(false);
    dispatch(resetPortOnly());
    dispatch(resetInternetSlice());
    navigate(_selectedRoute);
  };

  const showAlertPopup = () => {
    setisNotificationAlert(false);
    setisAlertPopover(!_isAlertPopover);
    notificationList();
  };

  const handleCollapse = () => {
    setCollapse(!collapse);
  };

  (function getCurrentRoute() {
    const currentPathname =
      window.location.pathname.split("globalfabric")[1] || "/";

    for (const routeKey in RouteEnum) {
      const route = RouteEnum[routeKey];
      if (route.childRoutes.includes(currentPathname)) {
        localStorage.setItem("currentRoute", route.parentRoute);
        return route.parentRoute;
      }
    }

    localStorage.removeItem("currentRoute");
    return null;
  })();

  const _onClickHeaderItem = (route: string) => {
    if (JOURNEY_ROUTES.includes(location.pathname)) {
      setShowModal(true);
      setSelectedRoute(route);
    } else {
      navigate(route);
    }
  };

  const RadioAccountMap = () => {
    return (
      <div className="switch-scroll">
        <Radio
          key="radioGroupDetails"
          inputname="radioGroupDetails"
          name={`${selectedAccount} (Default)`}
          id={"BT Global"}
          isCheckedDefault={true}
        />
        <hr />
        {accountDetails.map((detail) => (
          <Radio
            inputname="radioGroupDetails"
            name={detail.name}
            id={detail.name}
            isCheckedDefault={false}
            key={detail.name}
            onSelect={() => {
              setSelectedAccount(detail.name);
            }}
          />
        ))}
      </div>
    );
  };

  const _onClickSwitchAccount = () => {
    setSwitchAccount(true);
  };

  const _onClickSwitchAccountOk = () => {
    setSwitchAccount(false);
    sessionStorage.setItem(SELECTED_ACCOUNT, JSON.stringify(selectedAccount));
    const accountSwitchNotification = buildNotification(
      {
        title: "Profile change successful",
        description: (
          <div className="toast-body">
            <p>
              <span>You have changed to </span>
              <b>{selectedAccount}</b>
              <span> profile</span>
              <br />
            </p>
          </div>
        ),
        type: "success",
      },
      "Port",
    );

    toast.addToast(accountSwitchNotification.view(), {
      ...errorToastOptions,
      deleteSideEffect: () => {
        accountSwitchNotification.save({
          notificationStorage,
          setNotificationStorage,
        });
      },
    });
  };

  //  Kindly not remove this code; Will remove once newly implemented feature tested properly

  // const getNotifications = (
  //   offset: number,
  //   limit: number,
  //   sort: string | number,
  //   event_occured_time?: string,
  //   event_type?: string
  // ) => {
  //   api
  //     .updateNotifications(
  //       notificationRequestParamsDTO({
  //         offset,
  //         limit,
  //         sort,
  //         event_occured_time,
  //         event_type,
  //       })
  //     )
  //     .then((response: NotificationResponseDTO) => {
  //       const mappedRespDTO = notificationResponseDTO(response);
  //       dispatch(resetNotificationsSlice());
  //       dispatch(updateNotificationsList(mappedRespDTO));
  //       setisNotificationAlert(true);
  //       setNotifications(mappedRespDTO);
  //     })
  //     .catch((error) => {
  //       console.error("An error occurred:", error);
  //     });
  // };

  const getAlarmsList = () => {
    const reqPayload = new EventsEntity();
    reqPayload.sortedBy = "timestamp";
    reqPayload.sortOrder = "descending";
    api
      .getAlarms(
        removeNullEmptyPropsEvents(eventsRequestDTO(reqPayload)),
        0,
        20,
      )
      .then((response: IGetAlarmResponse) => {
        setNotifications(response?.results);
        dispatch(resetNotificationsSlice());
        dispatch(updateNotificationsList(response?.results));
        setisNotificationAlert(true);
        setNotifications(response?.results);
      });
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (
      actionCardRef.current &&
      !actionCardRef.current.contains(event.target as Node)
    ) {
      setisAlertPopover(false);
    }
  };

  useEffect(() => {
    setisAlertPopover(false);
  }, [location.pathname]);

  useEffect(() => {
    getAlarmsList();
    const intervalId = setInterval(() => {
      getAlarmsList();
    }, 30000);
    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    api
      .getGeoLocations()
      .then((data: IGeoLocation[]) => {
        dispatch(setGeoLocation(data));
      })
      .catch((Error) => {
        console.error(Error);
      });
  }, [dispatch, api]);

  React.useEffect(() => {
    if (_isAlertPopover) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [_isAlertPopover]);

  return (
    <>
      <div className="app-container" data-testid="navigation-wrapper">
        <div className="header-nav-wrapper">
          <Header
            mainItem={{ label: "Global Fabric" }}
            items={headerItems}
            cta="Create"
            ctasDropItems={[
              {
                label: "Create a new port",
                icon: "create_ports",
                onClick: () => _onClickHeaderItem("/create-new-port"),
              },
              {
                label: "Add a Network Service",
                icon: "create_network",
                onClick: () => _onClickHeaderItem("/network-services"),
              },
              {
                label: "Create new location",
                icon: "my_location",
                onClick: () => _onClickHeaderItem("/#"),
              },
            ]}
            user={images.user}
            showBasket={false}
            cartCount={_cartCount}
            cartUrl={navigateBasket}
            showAlertPopup={showAlertPopup}
            showNotificationAlert={isNotificationAlert}
            ctaProfileDropItems={[
              {
                label: "Profile",
                icon: "profile",
                onClick: () => _onClickHeaderItem("/profile"),
              },
              {
                label: "Manage user",
                icon: "profile_user",
              },
              {
                label: "Switch Account",
                icon: "profile_switch",
                onClick: () => _onClickSwitchAccount(),
              },
              // Note: Restricting page from the Jan release until such time that the Preference page UI and API updates have been made.
              // {
              //   label: "Notification preferences",
              //   icon: "profile_notifications",
              //   onClick: () => navigate("/notifications/alert-settings"),
              // },
              {
                label: "Log Out",
                icon: "profile_logout",
                //TODO logout feature is not working due to event notification API failure. uncomment the below line once the API success  
                // onClick: async () => {
                //   await api.updateEvents({
                //     eventOccuredTime: new Date(),
                //     message: "User successfully logged out",
                //     severity: "Information",
                //     correlationId: "467c-937d-9afe827e85ee",
                //   });
                //   _onClickHeaderItem("/logout");
                // },
                onClick: () => _onClickHeaderItem("/logout")
              },
            ]}
          />

          <div
            id={`${_isAlertPopover ? "mySidenav" : "mySideClose"}`}
            className="sidenav"
            ref={actionCardRef}
          >
            {_isAlertPopover && (
              <Notifications showAlertPopup={showAlertPopup} />
            )}
          </div>
        </div>
        <div className="main-wrapper-type-a">
          <nav className="side-navigation">
            <SideNav
              navItems={{ ...navItems, main: updatedRoutes }}
              toggleCollapseCb={handleCollapse}
            />
          </nav>
          <motion.main
            className={`main-content `}
            animate={{
              marginLeft: collapse ? "280px" : "68px",
              transition: {
                duration: 0.5,
                damping: 10,
              },
            }}
          >
            {children}
          </motion.main>
        </div>
      </div>
      <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        topIconSize="md"
        title={UNSAVED_POPUP_TITLE}
        complementaryMessage={UNSAVED_POPUP_MESAGE}
        contentAlign="center"
        actionText="Leave"
        onOk={_onModalOk}
        closeModal={!_showModal}
        onCancel={() => setShowModal(false)}
        outsideClose={true}
      />
      {switchAccount && (
        <Modal
          className="switch-account"
          title={<span>Switch Account</span>}
          message={RadioAccountMap()}
          contentAlign="left"
          actionText={"Switch Account"}
          buttonsSize="medium"
          onOk={_onClickSwitchAccountOk}
          closeModal={!switchAccount}
          onCancel={() => setSwitchAccount(false)}
          outsideClose={false}
        />
      )}
    </>
  );
};

export default NavigationWrapper;
