import React from "react";
import { render, screen } from "@testing-library/react";
import AlertsList from ".";
import { alertContentList } from "../../shared/constants";

describe("AlertsList Component", () => {
  it("renders the component with main heading and sub heading", () => {
    render(<AlertsList alertsList={alertContentList} loading={false} />);
    setTimeout(() => {
      expect(screen.getByText("0")).toBeInTheDocument();
      expect(screen.getByText("Total ports")).toBeInTheDocument();
      expect(screen.getByText("0")).toBeInTheDocument();
      expect(screen.getByText("Network services")).toBeInTheDocument();
    }, 10);
  });
});
