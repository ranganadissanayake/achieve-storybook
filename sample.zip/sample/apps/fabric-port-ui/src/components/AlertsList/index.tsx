import React from "react";
import AlertTile, { AlertTileProps } from "../AlertTile";

interface AlertsListProps {
  alertsList: AlertTileProps[];
  loading?: boolean;
}

const AlertsList: React.FC<AlertsListProps> = ({ alertsList, loading }) => {
  return (
    <>
      <div className="alerts-list-wrapper fp-row">
        {alertsList.map((alert, id) => (
          <div className="col-8" key={id}>
            <AlertTile
              key={id}
              iconName={alert.iconName}
              mainHeading={alert.mainHeading}
              subHeading={alert.subHeading}
              loading={loading}
            ></AlertTile>
          </div>
        ))}
      </div>
    </>
  );
};

export default AlertsList;
