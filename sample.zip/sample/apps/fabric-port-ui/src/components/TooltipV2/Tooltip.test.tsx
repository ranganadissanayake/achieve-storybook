import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";

import Tooltip from "./index";

describe("ToolTip", () => {
  test("renders the Tooltip component", () => {
    render(
      <Tooltip content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );

    expect(screen.getByText("Tooltip example")).toBeInTheDocument();
  });
  test("Click text to show tooltip", async () => {
    render(
      <Tooltip content="Default Tooltip" trigger="click">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByText("Default Tooltip")).toBeInTheDocument();
  });
  
  test("Mouse Over to show tooltip", async () => {
    render(
      <Tooltip content="Default Tooltip" trigger="mouseover">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.mouseOver(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByText("Default Tooltip")).toBeInTheDocument();
  });

  test("Mouse over the text to show callout", async () => {
    render(
      <Tooltip
        content={{
          title: "Callout Tooltip",
          caption:
            "Enabling oversubscription will allow exceeding port speed for any one or sum of network services.",
          action: {
            actionText: "action",
            action: () => {
              console.log("here");
            },
          },
          secondaryAction: {
            actionText: "action stuff",
            action: () => {
              console.log("here");
            },
          },
        }}
        variant="callout"
      >
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByText("Callout Tooltip")).toBeInTheDocument();
  });

  test("Mouse over the text to show tooltip top", async () => {
    render(
      <Tooltip placement="top" content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByTestId("tooltip-content")).toHaveClass(
      "tip-placement-top"
    );
  });
  test("Mouse over the text to show tooltip top right", async () => {
    render(
      <Tooltip placement="top-right" content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByTestId("tooltip-content")).toHaveClass(
      "tip-placement-top-right"
    );
  });

  test("Mouse over the text to show tooltip top left", async () => {
    render(
      <Tooltip placement="top-left" content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByTestId("tooltip-content")).toHaveClass(
      "tip-placement-top-left"
    );
  });

  test("Mouse over the text to show tooltip left", async () => {
    render(
      <Tooltip placement="left" content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByTestId("tooltip-content")).toHaveClass(
      "tip-placement-left"
    );
  });
  test("Mouse over the text to show tooltip right", async () => {
    render(
      <Tooltip placement="right" content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByTestId("tooltip-content")).toHaveClass(
      "tip-placement-right"
    );
  });
  test("Mouse over the text to show tooltip bottom", async () => {
    render(
      <Tooltip placement="bottom" content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByTestId("tooltip-content")).toHaveClass(
      "tip-placement-bottom"
    );
  });

  test("Mouse over the text to show tooltip bottom-right", async () => {
    render(
      <Tooltip placement="bottom-right" content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByTestId("tooltip-content")).toHaveClass(
      "tip-placement-bottom-right"
    );
  });
  test("Mouse over the text to show tooltip bottom-left", async () => {
    render(
      <Tooltip placement="bottom-left" content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByTestId("tooltip-content")).toHaveClass(
      "tip-placement-bottom-left"
    );
  });

  test("On mouse leave tooltip text should hide", async () => {
    render(
      <Tooltip placement="bottom" content="Default Tooltip">
        <span>Tooltip example</span>
      </Tooltip>
    );
    fireEvent.click(screen.getByText("Tooltip example"));
    fireEvent.click(screen.getByText("Tooltip example"));
    expect(screen.queryByTestId("tooltip-content")).toBeNull();
  });

  test("Mouse over the text to hide callout on custom variant", async () => {
    render(
      <Tooltip
        content={{
          title: "Callout Tooltip",
          caption: "This is a callout tooltip.",
        }}
        variant="callout"
      >
        <span>Tooltip example</span>
      </Tooltip>
    );
  
    fireEvent.click(screen.getByText("Tooltip example"));
    await waitFor(() => screen.getByTestId("tooltip-content"));
  
    fireEvent.mouseLeave(screen.getByText("Tooltip example"));
    expect(screen.queryByTestId("tooltip-content")).toBeInTheDocument();
  });
  
  test("Mouse over the text to show custom tooltip", async () => {
    render(
      <Tooltip
        content={{
          title: "Custom Tooltip",
          helperTitle: "Helper Title",
          caption: "Custom Tooltip Content",
          action: {
            actionText: "Action",
            action: () => {
              console.log("here");
            },
          },
        }}
        variant="custom"
      >
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByText("Custom Tooltip")).toBeInTheDocument();
    expect(screen.getByText("Helper Title")).toBeInTheDocument();
    expect(screen.getByText("Custom Tooltip Content")).toBeInTheDocument();
  });

  test("Mouse over the text to show graph tooltip", async () => {
    render(
      <Tooltip
        content={{
          title: "Graph Tooltip",
          caption: "Graph Tooltip Content",
          legendColor: "blue", 
          graphUnits: "units",
        }}
        variant="graph"
      >
        <span>Tooltip example</span>
      </Tooltip>
    );

    fireEvent.click(screen.getByText("Tooltip example"));

    await waitFor(() => screen.getByTestId("tooltip-content"));
    expect(screen.getByText("Graph Tooltip")).toBeInTheDocument();
    expect(screen.getByText("Graph Tooltip Content")).toBeInTheDocument();
    
  });
});
