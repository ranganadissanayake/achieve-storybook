import React, { useState, useRef, useEffect } from "react";
import "./Tooltip.scss";
import GFHeading from "../../components/GFHeading";
import { Align } from "@arc-ui/components/dist/Align";
import { Button } from "@btdigital/nayan-component-library";
import { Image } from "@arc-ui/components/dist/Image";
import noPortNew from "../../shared/assets/images/Equinix.png";

export interface CalloutItem {
  title?: string;
  helperTitle?: string;
  caption: string;
  legendColor?: string;
  graphUnits?: string;
  action?: { actionText: string; action: VoidFunction };
  secondaryAction?: { actionText: string; action: VoidFunction };
}
export interface TooltipProps {
  children: React.ReactElement;
  content: string | CalloutItem;
  placement?:
    | "default"
    | "top"
    | "top-right"
    | "top-left"
    | "right"
    | "bottom"
    | "bottom-left"
    | "bottom-right"
    | "left";
  delay?: number;
  variant?: "default" | "callout" | "custom" | "graph";
  showCallout?: boolean;
  closeCallout?: VoidFunction;
  trigger?: "mouseover" | "click" 
}

const Tooltip: React.FC<TooltipProps> = ({
  content,
  children,
  delay,
  placement = "default",
  variant = "default",
  showCallout,
  closeCallout,
  trigger= "mouseover" || "click"
}) => {
  let timeout:NodeJS.Timeout;
  const isCallout = variant === "callout";
  const [active, setActive] = useState(false);
  const tooltipRef = useRef<HTMLDivElement | null>(null); 

  const showTip = () => {
    if(trigger === "mouseover") {
      timeout = setTimeout(() => {
          setActive(true);
      }, delay || 500);
    }
  };

  const handleMouseLeave = () => {
    if(trigger === "mouseover") {
      hideTip()
    }
  };

  const  hideTip = () => {
    if (isCallout) return;
    clearInterval(timeout);
    setActive(false);
  };

  const handleClickOutside = (event:MouseEvent) => {
    if (tooltipRef.current && !tooltipRef.current.contains(event.target as Node)) {
      setActive(false);
    }
  }; 

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  React.useEffect(() => {
    if (variant === "default") {
      hideTip();
    }
  }, [variant]);

  const handleVariants = () => {
    const text = typeof content === "object" ? content.caption : content;

    switch (variant) {
      case "default":
        return <GFHeading weight="light" text={text} size="S7" />;
      case "callout":
        return (
          <div className="callout-container">
            <div className="title-section">
              <GFHeading
                weight="regular"
                text={(content as CalloutItem).title}
                size="S5"
              />
              <Button
                iconBefore={false}
                iconTitle={"cross_alt_2px"}
                enableOriginalIcon
                variant="link"
                size="small"
                onPress={closeCallout && closeCallout}
              />
            </div>

            <p className="callout-caption">{text}</p>
            <div className="action-row">
              {(content as CalloutItem).secondaryAction && (
                <Align horizontal="left">
                  <Button
                    label={(content as CalloutItem).secondaryAction?.actionText}
                    onPress={(content as CalloutItem).secondaryAction?.action}
                    size="small"
                    variant="outline"
                  />
                </Align>
              )}
              {(content as CalloutItem).action && (
                <Align horizontal="left">
                  <Button
                    iconCustomStyle="action-button"
                    label={(content as CalloutItem).action?.actionText}
                    onPress={(content as CalloutItem).action?.action}
                    variant="gradient"
                    size="small"
                  />
                </Align>
              )}
            </div>
          </div>
        );
      case "custom":
        return (
          <div className="callout-container">
            <div className="custom-content">
              <div className="image-section">
                <Image src={noPortNew} />
              </div>
              <div className="body-section">
                <div className="title-section">
                  <p className="callout-caption">
                    {(content as CalloutItem).helperTitle}
                  </p>
                  <GFHeading
                    weight="regular"
                    text={(content as CalloutItem).title}
                    size="S5"
                  />
                </div>

                <p className="callout-caption">{text}</p>
              </div>
            </div>
            {(content as CalloutItem).action && (
              <Align horizontal="left">
                <Button
                  label={(content as CalloutItem).action?.actionText}
                  onPress={(content as CalloutItem).action?.action}
                  size="small"
                  variant="link"
                  iconTitle="next_arrow_alt"
                  iconSize="sm"
                  enableOriginalIcon={true}
                />
              </Align>
            )}
          </div>
        );
      case "graph":
        return (
          <div className="callout-container">
            <div className="graph-content">
              <div
                className="color-section"
                style={{
                  backgroundColor: (content as CalloutItem).legendColor,
                }}
              />
              <div className="body-section">
                <div className="graph-title-section">
                  <GFHeading
                    weight="regular"
                    text={(content as CalloutItem).title}
                    size="S5"
                  />
                  <p className="callout-caption">
                    {(content as CalloutItem).graphUnits}
                  </p>
                </div>

                <p className="callout-caption">{text}</p>
              </div>
            </div>
          </div>
        );
      default:
        return <GFHeading weight="light" text={text} size="S6" />;
    }
  };

  const handleToggleActive = () => {
    setActive(!active);
  };

  return (
    <div
      ref={tooltipRef}
      className="tooltip-container"
      onClick={handleToggleActive} 
      onMouseEnter={showTip} 
      onMouseLeave={handleMouseLeave}
    >
      {children}
      {(active || showCallout) && content && (
        <div
          data-testid="tooltip-content"
          className={`tooltip-item tip-placement-${placement}`}
        >
          {handleVariants()}
        </div>
      )}
    </div>
  );
};

export default Tooltip;
