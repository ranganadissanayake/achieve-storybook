import React from "react";
import type { Meta, StoryObj } from "@storybook/react";

import "./Tooltip.scss";
import Tooltip from "./index";

const meta: Meta<typeof Tooltip> = {
  title: "FabricPortWebApp/Tooltip",
  component: Tooltip,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
};

export default meta;

type Story = StoryObj<typeof Tooltip>;

export const Default: Story = {
  args: {
    content: "Cloud Port Inventory",
    children: (
      <p className="sub-title">
        Visit <span>BT Global Fabric knowledge centre</span> for more
        information on ports connection.
      </p>
    ) as React.ReactElement,
  },
};
