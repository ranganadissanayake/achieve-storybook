import React from "react";
import { render, screen } from "@testing-library/react";
import GFHeading from "./index";

describe("ArcHeader", () => {
  it("should render ArcHeader size 1", () => {
    render(<GFHeading size="S1" weight="regular" text="S1" />);
    expect(screen.getByText("S1")).toBeInTheDocument();
  });

  it("should render ArcHeader size 8", () => {
    render(<GFHeading size="S8" weight="regular" text="S8" />);
    expect(screen.getByText("S8")).toBeInTheDocument();
  });

  it("should map size S2 to 'l'", () => {
    render(<GFHeading size="S2" weight="regular" text="S2" />);
    expect(screen.getByText("S2")).toBeInTheDocument();
  });

  it("should map size S3 to 'm'", () => {
    render(<GFHeading size="S3" weight="regular" text="S3" />);
    expect(screen.getByText("S3")).toBeInTheDocument();
  });

  it("should map size S4 to 's'", () => {
    render(<GFHeading size="S4" weight="regular" text="S4" />);
    expect(screen.getByText("S4")).toBeInTheDocument();
  });

  it("should map size S5 to 'xs'", () => {
    render(<GFHeading size="S5" weight="regular" text="S5" />);
    expect(screen.getByText("S5")).toBeInTheDocument();
  });

  it("should map size S6 to 'xxs'", () => {
    render(<GFHeading size="S6" weight="regular" text="S6" />);
    expect(screen.getByText("S6")).toBeInTheDocument();
  });

  it("should map size S7 to 'xxxs'", () => {
    render(<GFHeading size="S7" weight="regular" text="S7" />);
    expect(screen.getByText("S7")).toBeInTheDocument();
  });

});
