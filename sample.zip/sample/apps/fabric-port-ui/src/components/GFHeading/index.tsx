import React from "react";
import { Heading } from "@arc-ui/components/dist/Heading";

export interface GFHeadingProps {
  weight: "light" | "regular" | "bold";
  size: string;
  text?: string;
  children?: React.ReactElement | string;
  align?: "center" | "left" | "right";
  casing?: "auto" | "none";
  level?: "1" | "2" | "3" | "4" | "5";
  id?: string;
  key?: string;
  color?: "auto" | "brand" | string;
  className?: string;
  testid?:string;
  onClick?: () => void;
}
const GFHeading: React.FC<GFHeadingProps> = ({
  weight,
  className,
  size,
  text,
  children,
  align,
  casing,
  level,
  id,
  key,
  color,
  testid,
  onClick
}) => {
  const getLevels = (level: string) => {
    switch (level) {
      case "S1":
        return "xl";
      case "S2":
        return "l";
      case "S3":
        return "m";
      case "S4":
        return "s";
      case "S5":
        return "xs";
      case "S6":
        return "xxs";
      case "S7":
        return "xxxs";
      case "S8":
        return "xxxs";
      default:
        return "m";
    }
  };

  const _onClick = () => {
    onClick?.();
  };

  return (
    <>
      <Heading
        size={size && size !== "S8" ? getLevels(size) : "xxxs"}
        align={align}
        level={level}
        casing={casing}
        id={id}
        key={key}
        color={color === "auto" || color === "brand" ? color : undefined}
      >
        <span className={` color-${color} ${className} ${weight} ${size === "S8" ? "xxxxs" : ""}`} data-testid={testid} onClick={_onClick}>
          {text}
          {children}
        </span>       
      </Heading>
    </>
  );
};

export default GFHeading;
