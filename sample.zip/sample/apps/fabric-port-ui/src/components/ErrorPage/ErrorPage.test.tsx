import React from "react";
import { render, screen } from "@testing-library/react";
import ErrorPage from "./index";
import { BrowserRouter, useRouteError } from "react-router-dom";
import { Provider } from "react-redux";
import store from "../../redux/store";
import { ApiProvider, useApi } from "../../shared/helpers"; // Import the ApiProvider
import { MOCK_ALARMS_LIST } from "../../shared/constants/alarms";
import { mockResponses } from "../../../msw/mock-responses";

const mockAlarmsResponse = {
  results: MOCK_ALARMS_LIST,
  pagination: {
    limit: 10,
    offset: 0,
    total: 8,
  },
};

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useRouteError: jest.fn(),
}));
jest.mock("react-inlinesvg");

jest.mock("../../shared/helpers/api", () => ({
  ...jest.requireActual("../../shared/helpers/api"),
  useApi: jest.fn(),
}));

describe("ErrorPage component", () => {
  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getAlarms: jest.fn().mockResolvedValue(mockAlarmsResponse),
      getGeoLocations: jest
      .fn()
      .mockResolvedValue(mockResponses.geographicalLocations.response),
    });
  });

  test("renders error message correctly", () => {
    const error = {
      statusText: "Not Found",
      message: "Page not found",
    };

    // Mock the useRouteError function
    (useRouteError as jest.Mock).mockReturnValue(error);

    const { getByText } = render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider> {/* Add ApiProvider */}
            <ErrorPage />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );

    const errorMessage = getByText(`${error.statusText || error.message}`);
    expect(errorMessage).toBeInTheDocument();
  });

  test("renders NavigationWrapper when isRoot is true", () => {
    const error = {
      statusText: "Not Found",
      message: "Page not found",
    };

    (useRouteError as jest.Mock).mockReturnValue(error);

    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider> {/* Add ApiProvider */}
            <ErrorPage isRoot={true} />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );

    const navigationWrapper = screen.getByTestId(
      "error-page-navigation-wrapper"
    );
    expect(navigationWrapper).toBeInTheDocument();
  });

  test("does not render NavigationWrapper when isRoot is false", () => {
    const error = {
      statusText: "Not Found",
      message: "Page not found",
    };

    (useRouteError as jest.Mock).mockReturnValue(error);

    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider>
            <ErrorPage isRoot={false} />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );
    const navigationWrapper = screen.queryByTestId(
      "error-page-navigation-wrapper"
    );
    expect(navigationWrapper).toBeNull();
  });
});
