import React from "react";
import { useRouteError } from "react-router-dom";
import NavigationWrapper from "../NavigationWrapper";

export interface ErrorPageProps {
  isRoot?: boolean;
}

const ErrorPage: React.FC<ErrorPageProps> = ({ isRoot }) => {
  const error = useRouteError() as any;

  const ErrorDispay = () => (
    <div id="error-page" style={{ marginLeft: "50px" }} >
      <h1>Oops!</h1>
      <p>Sorry, an unexpected error has occurred.</p>
      <p>
        <i>{error.statusText || error.message}</i>
      </p>
    </div>
  );

  if (isRoot)
    return (
      <NavigationWrapper>
        <div data-testid="error-page-navigation-wrapper">
          <ErrorDispay />
        </div>
      </NavigationWrapper>
    );
  return <ErrorDispay />;
};

export default ErrorPage;
