import React from "react";
import "./TitleBar.scss";
import { Label } from "@btdigital/nayan-component-library";

type TitleBarProps = {
  imageUrl?: string;
  title: string;
  subTitle?: string;
  subTitleContent?: React.ReactNode;
  wrapperClassName?: string;
  imageClassName?: string;
  titleTextClassName?: string;
  titleContainerClassName?: string;
  subTitleTextClassName?: string;
  subTitleContainerClassName?: string;
};

const TitleBar = ({
  imageUrl,
  title,
  subTitle,
  subTitleContent,
  wrapperClassName = "",
  imageClassName = "",
  titleTextClassName = "heading-text",
  subTitleTextClassName = "sub-heading-text",
  titleContainerClassName = "",
  subTitleContainerClassName = "sub-heading-container",
}: TitleBarProps) => {
  return (
    <div
      className={`titlebar-container ${wrapperClassName}`}
      data-testid="titlebar"
    >
      <div className="titlebar__image">
        {imageUrl && (
          <img
            src={imageUrl}
            className={imageClassName}
            data-testid="main-img"
            alt={title}
          />
        )}
      </div>
      <div className="titlebar__title">
        <Label
          size="lg"
          text={title}
          labelTextStyles={titleTextClassName}
          containerStyles={titleContainerClassName}
        />
        {subTitle && (
          <Label
            text={subTitle}
            labelTextStyles={subTitleTextClassName}
            containerStyles={subTitleContainerClassName}
          />
        )}
        {subTitleContent}
      </div>
    </div>
  );
};

export default TitleBar;
