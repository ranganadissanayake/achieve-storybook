import React from "react";
import { render, screen } from "@testing-library/react";
import TitleBar from "./index";

describe("TitleBar", () => {
  test("should render the TitleBar component", () => {
    render(<TitleBar imageUrl="" subTitle="" title="" />);
    expect(screen.getByTestId("titlebar")).toBeInTheDocument();
  });
});
