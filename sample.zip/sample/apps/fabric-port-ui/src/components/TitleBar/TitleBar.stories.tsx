import type { Meta, StoryObj } from "@storybook/react";
import React from "react";
import TitleBar from ".";

const meta: Meta<typeof TitleBar> = {
  title: "FabricPortWebApp/TitleBar",
  component: TitleBar,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj<typeof TitleBar>;

export const Default: Story = {
  args: {
    title: "Cloud Port Inventory",
    subTitleContent: (
      <p className="sub-title">
        Visit <span>BT Global Fabric knowledge centre</span> for more
        information on ports connection.
      </p>
    ) as React.ReactNode,
  },
};
