import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import { Textarea } from "@btdigital/nayan-component-library";

export interface ConnectedTextareaProps {
  name: string;
  label: string;
  placeholder?: string;
  rows?: number;
  labelSize?: "lg" | "sm";
  containerStyles?: string;
  labelTextStyles?: string;
  disabled?: boolean;
  onChangeSideEffects?: (text: string) => void;
}

const ConnectedTextarea: React.FC<ConnectedTextareaProps> = ({
  name,
  label,
  placeholder,
  rows = 5,
  labelSize = "sm",
  containerStyles,
  labelTextStyles,
  disabled,
  onChangeSideEffects,
}) => {
  const { control } = useFormContext();

  return (
    <Controller
      name={name as string}
      control={control}
      render={({
        field: { value, onChange },
        fieldState: { isTouched, isDirty, error },
      }) => {
        const showError = isDirty && !!error?.message;
        return (
          <Textarea
            id={name}
            value={value ? value.replace("  ", " ") : ""}
            label={label}
            placeholder={placeholder}
            name={name}
            onChange={(text) => {
              const newText = text.trim() === "" ? "" : text;
              onChange(newText);
              if (onChangeSideEffects) {
                onChangeSideEffects(newText);
              }
            }}
            showErrorIcon={false}
            state={showError ? "error" : "default"}
            disabled={disabled}
            errorMessageSize="sm"
            errorMessage={error?.message}
            rows={rows}
            labelSize={labelSize}
            containerStyles={containerStyles}
            labelTextStyles={labelTextStyles}
          />
        );
      }}
    />
  );
};

export default ConnectedTextarea;
