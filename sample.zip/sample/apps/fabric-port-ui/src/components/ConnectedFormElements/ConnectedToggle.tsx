import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import { Toggle } from "@btdigital/nayan-component-library";

export interface ConnectedToggleProps {
  name: string;
  label?: string;
  onChangeSideEffects?: (value: boolean) => void;
}

const ConnectedToggle: React.FC<ConnectedToggleProps> = ({
  name,
  label,
  onChangeSideEffects,
}) => {
  const { control } = useFormContext();

  return (
    <Controller
      name={name as string}
      control={control}
      render={({ field: { value, onChange } }) => {
        return (
          <Toggle
            checked={value}
            size="md"
            label={label}
            onChange={(value) => {
              onChange(value);
              onChangeSideEffects && onChangeSideEffects(value);
            }}
          />
        );
      }}
    />
  );
};

export default ConnectedToggle;
