import React from "react";
import { Controller, FieldError, useFormContext } from "react-hook-form";
import { DropdownInput, Option } from "@btdigital/nayan-component-library";

export interface ConnectedDropdownInputProps {
  name: string;
  label?: string;
  options: Option[];
  placeholder?: string;
  helper?: string;
  type?: string;
  allowSearch?: boolean;
  onlySelectedValue?: boolean;
  hideErrors?: boolean;
  state?: "default" | "disabled" | "error" | 'loading';
  labelSize?: "lg" | "sm" | "xs";
  searchInput?: boolean;
  labelTextStyles?: string;
  containerStyles?: string;
  className?: string;
  onChangeSideEffects?: (text: string) => void;
  onErrors?: (error?: FieldError) => void;
  keepErrorSpace?: boolean;
  showFlag?: boolean;
  assetMap?: {},
  assetCategory?: "flags" | "providers";
  assetSrc?: string,
  onClick?: ()=>void,
}

const ConnectedDropdownInput: React.FC<ConnectedDropdownInputProps> = ({
  name,
  label,
  placeholder,
  options,
  allowSearch,
  helper,
  type,
  onlySelectedValue,
  hideErrors,
  state,
  searchInput,
  labelTextStyles,
  containerStyles,
  labelSize = "sm",
  className,
  onChangeSideEffects,
  onErrors,
  keepErrorSpace,
  showFlag,
  assetMap,
  assetCategory,
  assetSrc,
  onClick
}) => {
  const { control } = useFormContext();

  return (
    <Controller
      name={name as string}
      control={control}
      render={({
        field: { value, onChange, onBlur },
        fieldState: { isDirty, error },
      }) => {
        const showError = !!error?.message;

        isDirty && onErrors && onErrors(error);
        return (
          <DropdownInput
            id={name}
            value={value}
            label={label}
            placeholder={placeholder}
            allowSearch={allowSearch}
            name={name}
            helper={helper}
            type={type}
            onSelect={(text) => {
              onChange(text);
              onChangeSideEffects && onChangeSideEffects(text);
            }}
            onlySelectedValue={onlySelectedValue}
            showErrorIcon={false}
            state={
              !hideErrors && showError ? "error" : state ? state : "default"
            }
            errorMessageSize="sm"
            errorMessage={error?.message}
            searchInput={searchInput}
            options={options}
            labelSize={labelSize}
            labelTextStyles={labelTextStyles}
            containerStyles={containerStyles}
            className={className}
            keepErrorSpace={keepErrorSpace}
            showAsset={showFlag}
            assetMap={assetMap}
            assetCategory={assetCategory}
            assertSrc={assetSrc}
            onClick={onClick}
          />
        );
      }}
    />
  );
};

export default ConnectedDropdownInput;
