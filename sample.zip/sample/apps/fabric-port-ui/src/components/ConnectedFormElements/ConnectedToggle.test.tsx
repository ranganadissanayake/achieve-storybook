import React from "react";
import { render } from "@testing-library/react";
import { useForm, FormProvider } from "react-hook-form";
import ConnectedToggle from "./ConnectedToggle";

describe("ConnectedToggle", () => {
  test("renders the component with correct props", () => {
    const onChangeSideEffects = jest.fn();

    const Wrapper = () => {
      const methods = useForm();
      return (
        <FormProvider {...methods}>
          <ConnectedToggle
            name="connectedToggle"
            label="Connected"
            onChangeSideEffects={onChangeSideEffects}
          />
        </FormProvider>
      );
    };

    render(<Wrapper />);
  });
});
