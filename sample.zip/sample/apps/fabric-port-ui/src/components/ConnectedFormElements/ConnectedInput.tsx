import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import { Input, IconName } from "@btdigital/nayan-component-library";

export interface ConnectedInputProps {
  name: string;
  label?: string;
  placeholder?: string;
  helper?: string;
  type?: "text" | "number" | "integer";
  labelSize?: "lg" | "sm" | "xs";
  state?: "default" | "error" | "success" | "disabled";
  containerStyles?: string;
  className?: string;
  customError?: string;
  primaryBadgeBefore?: boolean;
  primaryBadgeIconShowOriginal?: boolean;
  primaryBadgeText?: string;
  primaryBadgeTextStyle?: string;
  primaryBadgeIcon?: IconName;
  primaryBadgeIconColor?: string;
  primaryBadgeCustomStyle?: string;
  labelTextStyles?: string;
  onChangeSideEffects?: (text: string) => void;
  testId?: string;
  onFocus?: () => void;
  onBlur?: () => void;
}

const ConnectedInput: React.FC<ConnectedInputProps> = ({
  name,
  label,
  helper,
  type = "text",
  placeholder,
  labelSize,
  state = "default",
  containerStyles,
  className,
  customError,
  primaryBadgeBefore,
  primaryBadgeIconShowOriginal,
  primaryBadgeText,
  primaryBadgeTextStyle,
  primaryBadgeIcon,
  primaryBadgeIconColor,
  primaryBadgeCustomStyle,
  labelTextStyles,
  onChangeSideEffects,
  testId = "input",
  onFocus,
  onBlur
}) => {
  const { control } = useFormContext();

  return (
    <Controller
      name={name as string}
      control={control}
      render={({
        field: { value, onChange },
        fieldState: { isDirty, error },
      }) => {
        const showError = !!customError || !!error?.message;

        return (
          <Input
            data-testid={testId}
            id={name}
            value={type === "text" && value ? value.replace("  ", " ") : value}
            label={label}
            type={type}
            placeholder={placeholder}
            helper={helper}
            name={name}
            onChange={(text) => {
              onChange(text);
              onChangeSideEffects && onChangeSideEffects(text);
            }}
            showErrorIcon={false}
            state={
              state !== "default" ? state : showError ? "error" : "default"
            }
            errorMessageSize="sm"
            errorMessage={customError ? customError : error?.message}
            containerStyles={containerStyles}
            className={className}
            labelSize={labelSize}
            labelTextStyles={labelTextStyles}
            primaryBadgeBefore={primaryBadgeBefore}
            primaryBadgeIconShowOriginal={primaryBadgeIconShowOriginal}
            primaryBadgeIcon={primaryBadgeIcon}
            primaryBadgeIconColor={primaryBadgeIconColor}
            primaryBadgeCustomStyle={primaryBadgeCustomStyle}
            primaryBadgeText={primaryBadgeText}
            primaryBadgeTextStyle={primaryBadgeTextStyle}
            onFocus={() => onFocus && onFocus()}
            onBlur={() => onBlur && onBlur()}
          />
        );
      }}
    />
  );
};

export default ConnectedInput;
