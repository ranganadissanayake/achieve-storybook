import React from "react";
import images from "../../shared/assets";

const TextLoader = () => {
  return (
    <img
    data-testid="text-loader"
      src={images.loader}
      alt="Loading"
      srcSet=""
      width="32"
      height="32"
      className="loader"
    />
  );
};

export default TextLoader;
