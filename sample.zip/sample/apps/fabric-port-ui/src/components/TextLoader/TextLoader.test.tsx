import React from "react";
import TextLoader from "./";
import { render } from "@testing-library/react";

describe("TextLoader Component", () => {
  it("renders the component with default props", () => {
    const { getByTestId } = render(<TextLoader />);
    expect(getByTestId("text-loader")).toBeInTheDocument();
  });
});
