import type { Meta, StoryObj } from '@storybook/react';
import ButtonsTab from '.';


const meta: Meta<typeof ButtonsTab> = {
  title: 'FabricPortWebApp/ButtonsTab',
  component: ButtonsTab,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof ButtonsTab>;

export const Default: Story = {
  args: {
    buttonTextList: ["button1", "button2"]
  },
};