import { fireEvent, render } from "@testing-library/react";
import ButtonsTab from ".";
import React from 'react'

describe("ButtonsTab", () => {
    it("renders without errors", () => {
        const changeEvent = jest.fn();
        const { getByTestId } = render(
            <ButtonsTab
                buttonTextList={["Map", "Table"]}
                activeIndex={0}
                onChangeButton={changeEvent} />
        );
        expect(getByTestId("buttons-tab")).toBeInTheDocument();
        expect(getByTestId("btn-0")).toBeInTheDocument();
        expect(getByTestId("btn-1")).toBeInTheDocument();
    });

    it("should call onchange button event", () => {
        const changeEvent = jest.fn();
        const { getByTestId, getByText } = render(
            <ButtonsTab
                buttonTextList={["Map", "Table"]}
                activeIndex={0}
                onChangeButton={changeEvent} />
        );

        fireEvent.click(getByText('Map'));
        expect(changeEvent).toBeCalledWith("Map", 0);

        fireEvent.click(getByText('Table'));
        expect(changeEvent).toBeCalledWith("Table", 1);

        expect(getByTestId("buttons-tab")).toBeInTheDocument();
    });
});

