import React from 'react';
import './ButtonsTab.scss';

export type ButtonsTabProps = {
    buttonTextList: string[];
    onChangeButton: (label: string, index?: number) => void;
    activeIndex: number
}

const ButtonsTab: React.FC<ButtonsTabProps> = ({
    buttonTextList,
    onChangeButton,
    activeIndex = 0
}) => {
    const [activeButtonIndex, setActiveButtonIndex] = React.useState(activeIndex);
    const onChangeButtonsTab = (index: number) => {
        setActiveButtonIndex(index);
        onChangeButton(buttonTextList[index], index);
    }
    return (
        <div className="buttons-tab" data-testid="buttons-tab">
            <div className="buttons-tab--container">
                {
                    buttonTextList.map(
                        (buttonText: string, index) => (
                            <div
                                key={buttonText}
                                className={`buttons-tab--button ${activeButtonIndex === index ? 'active' : ''}`}
                                onClick={() => onChangeButtonsTab(index)}
                                data-testid={`btn-${index}`}
                            >
                                <span>{buttonText}</span>
                            </div>
                        )
                    )
                }
            </div>
        </div>
    )
}

export default ButtonsTab
