import React from "react";
import "./TotalAlerts.scss";
import CardBlock from "../CardBlock";
import GFHeading from "../../components/GFHeading";
import SeverityAlert, {
  SeverityAlertProps,
} from "../../components/SeverityAlert";
import { useNavigate } from "react-router-dom";
import { getNameWithCapitalFirstLetter } from "../../shared/helpers";
import SeletonLoader from "../../components/SeletonLoader";
import { useSelector } from "react-redux";
import { selectNotifications } from "../../redux/notificationsSlice";
export interface TotalAlertsProps {
  alertsDataList?: SeverityAlertProps[];
  loading?: boolean;
}

const TotalAlerts: React.FC<TotalAlertsProps> = ({loading}) => {
  const navigate = useNavigate();
  const _onClickSeverity = (
    type: "warning" | "critical" | "informational" | "major" | undefined,
  ) => {
    if (type)
      navigate(
        `/notifications?filterBy=${getNameWithCapitalFirstLetter(type)}`,
      );
  };
  const notificationsData = useSelector(selectNotifications);
  const severityAlertContentList: SeverityAlertProps[] = [
    { title: "Critical", type: "critical", amount: notificationsData.countOfCriticalNotifications  },
    { title: "Warning", type: "warning", amount: notificationsData.countOfWarningNotifications },
    { title: "Informational", type: "informational", amount: notificationsData.countOfInformationNotifications },
  ];

  return (
    <>
      <CardBlock className="custom-card">
        <CardBlock.Body className="cardBlock-body pt-16 pb-16 pl-20 pr-20">
          {loading ? (<SeletonLoader layout={"blockRow"} />) :
            (<section className="total-alerts-wrapper">
              <section className="main-content-wrapper fp-row">
                <section className="sub-content-left col-16 sm:col-16 md:col-4 lg:col-4">
                  <GFHeading
                    size="S6"
                    weight="light"
                    className="title"
                    text="Total alerts"
                  />
                  <GFHeading size="S4" text={`${notificationsData.totalCount}`} weight="regular" />
                </section>
                {severityAlertContentList.map((data, id) => (
                  <section className="sub-content-right col-4" key={id}>
                    <SeverityAlert
                      amount={data.amount}
                      title={data.title}
                      type={data.type}
                      onclick={() => _onClickSeverity(data.type)}
                    />
                  </section>
                ))}
              </section>
            </section>
            )}
        </CardBlock.Body>
      </CardBlock>
    </>
  );
};

export default TotalAlerts;
