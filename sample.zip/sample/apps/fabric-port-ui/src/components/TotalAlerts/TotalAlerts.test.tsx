import React from "react";
import { render, screen } from "@testing-library/react";
import { Provider } from "react-redux"; // Import the Provider from react-redux
import TotalAlerts from "./index";
import { severityAlertContentList } from "../../shared/constants";
import { BrowserRouter } from "react-router-dom";
import store from "../../redux/store"; // Import your Redux store
import { act } from "react-dom/test-utils"; // Import act to handle asynchronous rendering

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"), // Preserve the actual implementation
  useNavigate: jest.fn(),
}));

describe("TotalAlerts Component", () => {
  it("renders the component with data", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <TotalAlerts alertsDataList={severityAlertContentList} />
        </Provider>
      );
    });

  setTimeout(() => {  
    expect(screen.getByText("Critical")).toBeInTheDocument();

    act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <TotalAlerts alertsDataList={severityAlertContentList} />
          </BrowserRouter>
        </Provider>
      );
    });

    expect(screen.getByText("Critical")).toBeInTheDocument();
    expect(screen.getByText("Warning")).toBeInTheDocument();
    expect(screen.getByText("Informational")).toBeInTheDocument();
  }, 10);
  });
});
