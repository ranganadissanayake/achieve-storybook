import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import configureMockStore from "redux-mock-store";

import BillingAccount from "./index";
import { ApiProvider } from "../../shared/helpers";

const mockStore = configureMockStore();
const billingAccounts = {
  billingAccountDetails: {
    customerID: "29055",
    customerName: "CSA-29055",
    billingAccounts: [
      {
        id: "0013L00000WLYrAQAX",
        name: "BAC-0013L00000WLYrAQAX",
        currency: "GBP",
        default: true,
      },
      {
        id: "0014L00000WLYrAQAY",
        name: "DAC-0014L00000WLYrAQAY",
        currency: "GBP",
        default: false,
      },
      {
        id : "b100",
        name : "Hindustan Unilever Ltd Account",
        currency : "INR",
        default : false,
        customerPurchaseOrder : [
          {
            purchaseOrderNumber: "112414",
            purchaseOrderName: "PO1",
            purchaseOrderType: "mrc"
          }
        ]
      },
      {
        id : "b400",
        name : "Unilever UK Account",
        currency : "GBP",
        default : false,
        customerPurchaseOrder : [
          {
            purchaseOrderNumber: "112414",
            purchaseOrderName: "PO1",
            purchaseOrderType: "mrc"
          },
          {
            purchaseOrderNumber: "112417",
            purchaseOrderName: "PO2",
            purchaseOrderType: "nrc"
          }
        ]
      }
    ],
  },
};

describe("Billing account component", () => {
  const onSelectBilling = jest.fn();
  const store = mockStore({ billingAccounts: { ...billingAccounts }});

  const selectedBillingAccount = {
    id: "0013L00000WLYrAQAX",
    name: "BAC-0013L00000WLYrAQAX",
    currency: "USD",
    default: true,
  };

  it("renders billing account component details correctly", () => {
    render(
      <Provider store={store}>
        <Router>
          <ApiProvider>
            <BillingAccount onSelectBilling={onSelectBilling} />
          </ApiProvider>
        </Router>
      </Provider>,
    );
    expect(screen.getByTestId("billing-account")).toBeInTheDocument();
  });

  it("calls onSelectBilling function", () => {
    render(
      <Provider store={store}>
        <Router>
          <ApiProvider>
            <BillingAccount
              onSelectBilling={onSelectBilling}
              selectedBillingAccount={selectedBillingAccount}
            />
          </ApiProvider>
        </Router>
      </Provider>
    );
    expect(onSelectBilling).toHaveBeenCalled();
    expect(onSelectBilling).toHaveBeenCalledWith("0013L00000WLYrAQAX");
  });

  it("displays the billing account dropdown with no value", async () => {
    render(
      <Provider store={store}>
        <Router>
          <ApiProvider>
            <BillingAccount selectedBillingAccount={undefined} />
          </ApiProvider>
        </Router>
      </Provider>,
    );
    const [billingDropdown] = await screen.getAllByPlaceholderText("Select");
    expect(billingDropdown).toBeInTheDocument();
    expect(billingDropdown).toHaveValue("");
  });

  it("displays the billing account dropdown with default value", async () => {
    render(
      <Provider store={store}>
        <Router>
          <ApiProvider>
            <BillingAccount selectedBillingAccount={selectedBillingAccount} />
          </ApiProvider>
        </Router>
      </Provider>,
    );
    const [billingDropdown] = await screen.getAllByPlaceholderText("Select");
    expect(billingDropdown).toBeInTheDocument();
    expect(billingDropdown).toHaveValue("0013L00000WLYrAQAX");
  });


  it("displays the billing account dropdown values when clicked on", async () => {
    render(
      <Provider store={store}>
        <Router>
          <ApiProvider>
            <BillingAccount
              selectedBillingAccount={selectedBillingAccount}
              billingAccounts={
                billingAccounts.billingAccountDetails.billingAccounts
              }
            />
          </ApiProvider>
        </Router>
      </Provider>
    );

    const [billingDropdown] = await screen.getAllByPlaceholderText("Select");
    fireEvent.click(billingDropdown);
    const dropOptions = screen.getAllByTestId("dropdown-option");
    expect(dropOptions).toHaveLength(4);
  });

  it("displays purchase order select dropdown if purchase orders available", async () => {
    render(
      <Provider store={store}>
        <Router>
          <ApiProvider>
            <BillingAccount
              selectedBillingAccount={billingAccounts.billingAccountDetails.billingAccounts[3]}
              billingAccounts={
                billingAccounts.billingAccountDetails.billingAccounts
              }
            />
          </ApiProvider>
        </Router>
      </Provider>
    );

    expect(screen.getByTestId("purchase-order-select")).toBeInTheDocument();
    expect(screen.getByText("Select Purchase Order")).toBeInTheDocument();
  });
});
