import React from "react";
import { useDispatch } from "react-redux";

import {
  Card,
  Label,
  DropdownInput,
  Icon,
} from "@btdigital/nayan-component-library";

import Tooltip from "../../components/TooltipV2";
import { updateSelectedPurchaseOrder } from "../../redux/billingAccountsSlice";
import { BillingAccount as BillingAccountDTO } from "../../shared/mappers/classes/dto/billingAccount.dto";

import "./BillingAccount.scss";

interface BillingAccountProps {
  onSelectBilling?: (selectedItem: string) => void;
  billingAccounts?: BillingAccountDTO[];
  selectedBillingAccount?: BillingAccountDTO;
  spaceTop?: "5" | "10" | "15" | "20";
  spaceBottom?: "5" | "10" | "15" | "20";
}

const BillingAccount: React.FC<BillingAccountProps> = ({
  onSelectBilling,
  billingAccounts,
  selectedBillingAccount,
  spaceTop = 0,
  spaceBottom = 0,
}) => {
  const dispatch = useDispatch();

  const _onSelectBillingAccount = React.useCallback(
    (val: string) => {
      if (val && onSelectBilling) {
        onSelectBilling(val);
      }
    }, [onSelectBilling]
  );

  React.useEffect(()=> {
    dispatch(updateSelectedPurchaseOrder({ purchaseOrderNumber: "", purchaseOrderName: "", purchaseOrderType: "" }));
  },[selectedBillingAccount])

  return (
    <div
      className="billing-account"
      data-testid="billing-account"
      style={{ paddingTop: `${spaceTop}px`, paddingBottom: `${spaceBottom}px` }}
    >
      <Card>
        <div className="fp-row ">
          <div className="col-8 xl:col-8 sm:col-8 md:col-8 sm:mb-8 title-row">
            <div className="billing-select-dropdown">
            <Label
              containerStyles="billing-label"
              text="Select Billing Account"
              size="sm"
            />
            <Tooltip
              content="A billing account is your primary method of payment within this app. It's directly linked to a specific legal entity."
              placement="bottom"
            >
              <Icon title="info_alt" size="md" className="tooltip_icon" />
            </Tooltip>
            </div>
          </div>
          <div className="col-8 xl:col-8 sm:col-8 md:col-8 sm:mb-8">
            <DropdownInput
              name="accounts"
              placeholder="Select"
              onSelect={_onSelectBillingAccount}
              onlySelectedValue= {false}
              state={billingAccounts && billingAccounts.length > 0 ? "default" : "disabled"}
              options={
                billingAccounts &&
                [...billingAccounts]
                  .sort((a, b) => (a.name < b.name ? -1 : 1))
                  .map(({ id, name }) => {
                    return {
                      id,
                      value: `${name}`,
                    };
                  })
              }
              showErrorIcon={false}
              value={selectedBillingAccount ? `${selectedBillingAccount.id}` : ""}
            />
          </div>
        </div>

        {!(billingAccounts && billingAccounts.length > 0) && (
          <div
            className="fp-row no_billing_message"
            data-testid="no_billing_message"
          >
            <div>
              <Icon title="info_alt" size="md" className="tooltip_icon" />
            </div>
            <div>
              Sorry, it seems that there are currently no billing accounts
              associated with this location. For further assistance, please
              raise a ticket through{" "}
              <a
                href={process.env.REACT_APP_HELP_SUPPORT_LINK}
                target="_blank"
                rel="noreferrer"
              >
                Help and Support
              </a>
            </div>
          </div>
        )}

        {selectedBillingAccount && selectedBillingAccount?.customerPurchaseOrder && selectedBillingAccount.customerPurchaseOrder.length > 0 &&
        <div className="fp-row purchase-order-select" data-testid="purchase-order-select">
          <div className="col-8 xl:col-8 sm:col-8 md:col-8 sm:mb-8 title-row">
            <div className="billing-select-dropdown">
            <Label
              containerStyles="purchase-order-label"
              text="Select Purchase Order"
              size="sm"
            />
            <Tooltip
              content=" Purchase Orders for the selected billing account"
              placement="bottom"
            >
              <Icon title="info_alt" size="md" className="tooltip_icon" />
            </Tooltip>
            </div>
          </div>
          <div className="col-8 xl:col-8 sm:col-8 md:col-8 sm:mb-8">
            <DropdownInput
              name="accounts"
              placeholder="Select Purchase Order"
              onSelect={(val) => {
                if(val) {
                  const selectedPurchaseOrderObject = selectedBillingAccount.customerPurchaseOrder && selectedBillingAccount.customerPurchaseOrder.find(
                    (po) => po.purchaseOrderNumber === val
                  );
                  if (selectedPurchaseOrderObject) {
                    dispatch(
                      updateSelectedPurchaseOrder(selectedPurchaseOrderObject)
                    );
                  }
                }
              }}
              options={selectedBillingAccount.customerPurchaseOrder.map(po => {
                return {
                  id: po.purchaseOrderNumber,
                  value: `${po.purchaseOrderName}`
                }
              })}
              showErrorIcon={false}
            />
          </div>
        </div>
}
      </Card>
    </div>
  );
};

export default BillingAccount;
