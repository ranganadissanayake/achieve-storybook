import React, { FC } from "react";
import { MemberPortId } from "../../shared/mappers/classes/entity/port.entity";
import { Badge, Label } from "@btdigital/nayan-component-library";
import { kebabCase } from "lodash";

type MemberPortDetailsProps = {
  memberPortIds: MemberPortId[];
}

const MemberPortDetails: FC<MemberPortDetailsProps> = ({ memberPortIds }) => {
  return (
    <div className="port-details-wrapper mt-12">
      <div className="header-control">
        <Label text="Member port ID" labelTextStyles="grid-header"/>
        <Label text="Status" labelTextStyles="grid-header" containerStyles="mr-2"/>
      </div>
      {
        memberPortIds.map((memberPort, i) => (
          <div className={`form-control ${i === 0 ? 'mt-8' : 'mt-4'}`} key={memberPort.memberPortId}>
            <Label text={memberPort.memberPortId} labelTextStyles="normal-text" />
            <Badge text={memberPort.status} customStyle={kebabCase(memberPort.status)}/>
          </div>
        ))
      }
    </div>
  )
}

export default MemberPortDetails
