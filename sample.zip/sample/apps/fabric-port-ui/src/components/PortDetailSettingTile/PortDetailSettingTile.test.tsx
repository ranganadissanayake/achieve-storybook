import { render, screen } from "@testing-library/react";
import React from 'react';
import PortDetailSettingTile from ".";

const mockData = {
    telemetryStreamingEnabled: "Disabled",
    lowThreshold: "10%",
    highThreshold: "80%",
    predictiveBandwidth: "Disabled",
    enableOverSubscription: "Disabled",
    vLanEncapsulation: "unspecified",
    lag: "Enabled",
    lagPortCount: "1",
    lagPortSpeed: "200 Gbps",
    memberPortIds: [{
        memberPortId: "G4i3L000008KoVdPKS",
        status: "Port Up"
    }, {
        memberPortId: "G4i3L00rrrr0008KoVdPKS",
        status: "Port Up"
    }, {
        memberPortId: "G4i3L000008KoVdPKS",
        status: "Port Up"
    }]
}

describe("PortDetailSettingTile component", () => {
    test("renders the Paginator component", async () => {
        render(<PortDetailSettingTile settings={mockData} />);
        expect(screen.getByText("Port Settings")).toBeInTheDocument();
    })
});