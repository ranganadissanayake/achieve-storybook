import React from "react";
import { render } from "@testing-library/react";
import MemberPortDetails from "./MemberPortDetails";

describe("MemberPortDetails", () => {
  const memberPortIds = [
    { memberPortId: "port1", status: "Active" },
    { memberPortId: "port2", status: "Inactive" },
  ];

  it("renders the correct number of member ports", () => {
    render(
      <MemberPortDetails memberPortIds={memberPortIds} />
    );
  });
  
});
