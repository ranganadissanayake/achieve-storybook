import { Badge, Divider, Icon, Label } from "@btdigital/nayan-component-library";
import React, { FC, useState } from "react";
import { PortDetailSettingEntity } from "../../shared/mappers/classes/entity/port.entity";
import MemberPortDetails from "./MemberPortDetails";
import "./PortDetailSettingTile.scss";
import { lowerCase } from "lodash";
import GFHeading from "../../components/GFHeading";

export type PortDetailSettingTileProps = {
    settings: PortDetailSettingEntity;
}

const PortDetailSettingTile: FC<PortDetailSettingTileProps> = ({ settings }) => {
    const [expanded, setExpanded] = useState(false);
    return (
        <div className="port-details-setting-tile">
            <div className="header">
                <GFHeading size="S5" text="Port Settings" weight="regular" />
            </div>
            <Divider className="divider" />
            <div className="form-control pt-8">
                <Label text="Telemetry streaming" />
                <Badge
                    text={settings.telemetryStreamingEnabled}
                    customStyle={lowerCase(settings.telemetryStreamingEnabled)} />
            </div>
            <div className="form-control mt-4">
                <Label text="Low utilisation threshold" labelTextStyles="normal-text" />
                <Label text={settings.lowThreshold} />
            </div>
            <div className="form-control mt-4">
                <Label text="High utilisation threshold" labelTextStyles="normal-text" />
                <Label text={settings.highThreshold} />
            </div>
            <div className="form-control mt-8">
                <Label text="Predictive bandwidth optimisation" />
                <Badge
                    text={settings.predictiveBandwidth}
                    customStyle={lowerCase(settings.predictiveBandwidth)} />
            </div>
            <div className="form-control mt-8">
                <Label text="Enable oversubscription" />
                <Badge
                    text={settings.enableOverSubscription}
                    customStyle={lowerCase(settings.enableOverSubscription)} />
            </div>
            <div className="form-control mt-8">
                <Label text="Link Aggregation Group (LAG)" />
                <Badge
                    text={settings.lag}
                    customStyle={lowerCase(settings.lag)} />
            </div>
            <div className="form-control mt-4">
                <Label text="LAG port count" labelTextStyles="normal-text" />
                <Label text={settings.lagPortCount} />
            </div>
            <div className="form-control mt-4">
                <Label text="LAG port speed" labelTextStyles="normal-text" />
                <Label text={settings.lagPortSpeed} />
            </div>

            <div className="expander mt-64">
                <Label text="LAG port details" labelTextStyles="accordion" />
                <Icon
                    onClick={() => setExpanded(!expanded)}
                    title={expanded ? "chevron_up" : "chevron_down"}
                    size="sm"
                    className="icon-alignment"
                />
            </div>
            {expanded && settings.memberPortIds && (
                <MemberPortDetails memberPortIds={settings.memberPortIds} />
            )}
        </div>
    )
}

export default PortDetailSettingTile;
