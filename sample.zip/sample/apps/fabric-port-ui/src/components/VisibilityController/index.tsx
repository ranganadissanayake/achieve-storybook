import React, { PropsWithChildren, useEffect, useState, FC } from "react";
import { useLocation } from "react-router-dom";

type VisibilityControllerProps = PropsWithChildren & {
  notAllowedRoute?: string[];
};

export const VisibilityController: FC<VisibilityControllerProps> = ({
  children,
  notAllowedRoute,
}) => {
  const location = useLocation();
  const [isVisible, setIsVisible] = useState<boolean | null>(true);

  const notEmtpy = (arr: any) => arr?.some((el) => el === null);
  const allowed = (arr: any) => {
    const res = notEmtpy(
      arr?.map((path: any) => location.pathname.match(path))
    );

    if (!res) return null;
    return true;
  };

  useEffect(() => {
    if (notAllowedRoute && notAllowedRoute.length > 0) {
      setIsVisible(allowed(notAllowedRoute));
    }
  }, [location, window.location]);

  return <>{isVisible && children}</>;
};
