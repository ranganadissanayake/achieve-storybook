import { Icon } from "@btdigital/nayan-component-library";
import React, { useCallback } from "react";
import "./ExportTableDataButton.scss";
import { CSVLink } from "react-csv";

export interface ExportTableDataButtonProps {
    rawData: any[];
    headers?: any[];
    customClassName?: string;
    exportFileName?: string;
    mapperFunction?: (rawData: any) => any;
}

const ExportTableDataButton = ({
    customClassName,
    rawData,
    headers,
    exportFileName = "inventory-data",
    mapperFunction
}: ExportTableDataButtonProps) => {
    const [mappedData, setMappedData] = React.useState<any[]>([]);

    const getformattedData = useCallback(() => {
        mapperFunction
            ? setMappedData(rawData.flatMap((data) => mapperFunction(data).exportItems))
            : setMappedData(rawData);
    }, [rawData]);

    return (
        <div
            className={`export-data-container ${customClassName}`}
            data-testid="exportTableDataButton"
        >
            <CSVLink
                headers={headers}
                filename={exportFileName}
                data={mappedData}
                onClick={() => getformattedData()}
                target="_blank"
            >
                <Icon title="export_data_button" showOriginal />
            </CSVLink>

        </div>
    );
};

export default ExportTableDataButton;
