import { fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import ExportTableDataButton from ".";

const mockRawData = [{
    firstName: "first name",
    lastName: "last name"
}];

const mockMappingFunc = (data) => {
    return {
        exportItems: [{
            fullName: data.firstName + ' ' + data.lastName
        }]
    }
}


describe("ExportTableDataButton", () => {
    test("should render", () => {
        render(<ExportTableDataButton
            rawData={mockRawData}
            mapperFunction={mockMappingFunc}
            exportFileName="mock-file-name"
        />);
        expect(screen.getByTestId("exportTableDataButton")).toBeInTheDocument();
    });

    test("should able to click on export icon", () => {
        render(<ExportTableDataButton
            rawData={mockRawData}
            mapperFunction={mockMappingFunc}
            exportFileName="mock-file-name"
            customClassName="custom-class"
        />);
        expect(screen.getByTestId("exportTableDataButton")).toBeInTheDocument();
        const hrefLink = screen.getByRole<HTMLAnchorElement>('link');
        fireEvent.click(hrefLink);
        expect(hrefLink.href).toContain("data:text/csv;charset=utf-8");
        expect(hrefLink.href).toContain("fullName");
        expect(hrefLink.href).toContain(`${mockRawData[0].firstName} ${mockRawData[0].lastName}`);
    });

});