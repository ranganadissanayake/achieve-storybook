import React from "react";

import "./TopPanel.scss";

/**
 * The properties required for the TopPanel Component
 * @author Joel Chi <joel.abongwa@distributed.com>
 */
export interface TopPanelProps {
  /**
   * Difines the children of the TopPanel component
   */
  children?: React.ReactNode;
  /**
   * Specifies classes for additional styles
   */
  className?: string;
}

/**
 * Renders the TopPanel Component
 * @param {React.PropsWithChildren<TopPanelProps>} props TopPanelProps properties
 * @returns
 */
const TopPanel: React.FC<TopPanelProps> = ({ children, className = "" }) => {
  return <header className={`top_panel ${className}`}>{children}</header>;
};

export default TopPanel;
