import React, { useEffect, ReactElement } from 'react';
import { useMsal } from "@azure/msal-react";
import { getAccessToken } from "../../authConfig";
import GFLoader from "../../components/GFLoader";
import { ORG_SELECTED_KEY } from "../../shared/constants";

const Logout = (): ReactElement => {
  const { instance } = useMsal();

  useEffect(() => {
    const getTokenResponse = async () => {
      const res = await getAccessToken();
      
      if (localStorage.getItem(ORG_SELECTED_KEY)) {
        localStorage.removeItem(ORG_SELECTED_KEY);
      }

      const logoutRequest = {
        postLogoutRedirectUri: instance.getConfiguration().auth.redirectUri,
        idTokenHint: res?.idToken,
        mainWindowRedirectUri: instance.getConfiguration().auth.redirectUri,
      };

      instance.logoutRedirect(logoutRequest);
    };
    getTokenResponse();
  }, [instance]);

  return <GFLoader />;
};

export default Logout;