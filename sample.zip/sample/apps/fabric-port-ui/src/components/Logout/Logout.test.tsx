import React from "react";
import { render, waitFor } from "@testing-library/react";
import { useMsal } from "@azure/msal-react";
import Logout from "./Logout";

jest.mock("@azure/msal-react", () => ({
  useMsal: jest.fn(),
}));

jest.mock("../../authConfig", () => ({
  getAccessToken: jest.fn().mockResolvedValue({ idToken: "mockIdToken" }),
}));

// Mocking localStorage.removeItem
const mockRemoveItem = jest.fn();
Object.defineProperty(window.localStorage, "removeItem", {
  value: mockRemoveItem,
});

const mockInstance = {
  getConfiguration: jest.fn().mockReturnValue({
    auth: {
      redirectUri: process.env.REACT_APP_LOGOUT_URL,
    },
  }),
  logoutRedirect: jest.fn(),
};

beforeEach(() => {
  (useMsal as jest.Mock).mockReturnValue({ instance: mockInstance });
});

afterEach(() => {
  jest.clearAllMocks();
});

test("renders Logout component and performs logout", async () => {
  render(<Logout />);

  await waitFor(() => {
    expect(mockInstance.logoutRedirect).toHaveBeenCalledWith({
      postLogoutRedirectUri: process.env.REACT_APP_LOGOUT_URL,
      idTokenHint: "mockIdToken",
      mainWindowRedirectUri: process.env.REACT_APP_LOGOUT_URL,
    });
  });
});
