import React from "react";
import { render } from "@testing-library/react";
import Paginator from "./index";
import { BrowserRouter } from "react-router-dom";
import "regenerator-runtime";
import { Provider } from "react-redux";
import store from "../../redux/store";

describe("test Paginator component", () => {
  test("renders the Paginator component", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <Paginator
            currentPage={1}
            totalPages={5}
            onPageChange={() => {}}
            previousPage={() => {}}
            nextPage={() => {}}
          />
        </BrowserRouter>
      </Provider>,
    );
  });
});
