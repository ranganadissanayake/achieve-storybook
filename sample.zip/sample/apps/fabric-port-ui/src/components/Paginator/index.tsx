import React from "react";
import "./Paginator.scss";
import images from "../../shared/assets";

export interface PaginatorProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  previousPage: () => void;
  nextPage: () => void;
}

const Paginator: React.FC<PaginatorProps> = ({
  currentPage,
  onPageChange,
  totalPages,
  previousPage,
  nextPage,
}) => {
  const numbers = Array.from({ length: totalPages }, (_, index) => index + 1);
  return (
    <>
      <nav className="pagination-wrapper">
        <ul className="paginator">
          <li className="page-item">
            <a className="page-link" onClick={previousPage}>
              <img
                src={currentPage === 1 ? images.backDisabled : images.back}
                alt=""
                srcSet=""
              />
            </a>
          </li>
          {numbers.map((page, i) => (
            <li
              className={`page-item ${
                currentPage === page ? "active" : "default"
              }`}
              key={i}
            >
              <a className="page-item" onClick={() => onPageChange(page)}>
                {page}
              </a>
            </li>
          ))}
          <li className="page-item">
            <a className="page-link" onClick={nextPage}>
              <img
                src={
                  currentPage === totalPages ? images.nextDisabled : images.next
                }
                alt=""
                srcSet=""
              />
            </a>
          </li>
        </ul>
      </nav>
    </>
  );
};

export default Paginator;
