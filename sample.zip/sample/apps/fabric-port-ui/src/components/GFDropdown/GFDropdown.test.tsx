import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import GFDropdown from ".";

const presentationArray = [
  {
    label: ["Media Type", "Interface Standard", "Interface Connector"],
    value: ["Multi-Mode Fiber", "1000BASE-T", "RJ-45"],
  },
  {
    label: ["Media Type", "Interface Standard", "Interface Connector"],
    value: ["Copper", "10BASE-T", "LC-45"],
  },
  {
    label: ["Media Type", "Interface Standard", "Interface Connector"],
    value: ["Single-Mode Fiber", "100GBASE-ER", "SC-45"],
  },
];
const mockSelect = jest.fn();

describe("GFDropdown component", () => {
  it("should render GFDropdown", () => {
    const { container } = render(
      <GFDropdown options={presentationArray} onSelect={mockSelect} />,
    );
    const expandIcon = container.querySelectorAll(
      ".add-icon>svg",
    )[0];
    fireEvent.click(expandIcon);
    expect(screen.getByText("1000BASE-T")).toBeInTheDocument();
  });
});
