import React, { FC, useState } from "react";
import "./index.scss";
import { Input } from "@btdigital/nayan-component-library";
import GFHeading from "../../components/GFHeading";

export interface Options {
  label: string[];
  value: string[];
}

interface GFDropdownProps {
  options: Options[];
  onSelect: (selectedOption: string[]) => void;
}

const GFDropdown: FC<GFDropdownProps> = ({ options, onSelect }) => {
  const [selectedOptions, setSelectedOptions] = useState<string[]>(
    options && options.length > 0 ? options[0].value : [],
  );
  const [isOpen, setIsOpen] = useState(false);

  const handleOptionClick = (newOptions: string[]) => {
    setSelectedOptions(newOptions);
    setIsOpen(false);
    onSelect(newOptions);
  };

  const handleChevronClick = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      <div className="dropdown">
        <Input
          iconName={isOpen ? "chevron_up" : "chevron_down"}
          iconAfter
          iconSize="sm"
          className="pb-8"
          value={selectedOptions.join("+")}
          onClick={handleChevronClick}
        />
        {isOpen && (
          <div className="dropdown-content">
            {options.map((item) => (
              <>
                <div
                  className="fp-row mr-0 ml-0 pb-10 options"
                  onClick={() => handleOptionClick(item.value)}
                >
                  <div className="col-8">
                    {item.label.map((itemLabel) => (
                      <GFHeading
                        key={itemLabel}
                        weight="bold"
                        size="S6"
                        text={itemLabel}
                        className="content-position-right"
                      />
                    ))}
                  </div>
                  <div className="col-8">
                    {item.value.map((itemValue) => (
                      <GFHeading
                        key={itemValue}
                        weight="light"
                        size="S6"
                        text={itemValue}
                        className="content-position-left"
                      />
                    ))}
                  </div>
                </div>
                <div className="separator"></div>
              </>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default GFDropdown;
