import React from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

import {
  Button,
  Modal,
  Crumb,
} from "@btdigital/nayan-component-library";

import CreateNewIpHeader from "./CreateNewIpHeader";
import { selectCurrentStep } from "../../redux/newIpAddressSlice";
import {
  UNSAVED_POPUP_MESAGE,
  UNSAVED_POPUP_TITLE,
} from "../../shared/constants";

import "./index.scss";
import PageWrap from "../../components/PageWrap";

export interface CreateNewIpWrapperProps extends React.PropsWithChildren {
  selectedPort?: boolean;
  portsPreview?: boolean;
  hideHeader?: boolean;
  selectedPorts?: any[];
  currentStep?: number;
  handleBack?: () => void;
  handleNext?: () => void;
}

const CreateNewIpWrapper: React.FC<CreateNewIpWrapperProps> = ({
  selectedPort,
  children,
  currentStep,
  handleBack,
  handleNext,
  hideHeader = false,
}) => {
  const navigate = useNavigate();
  const _currentStep = useSelector(selectCurrentStep);

  const [_showModal, setShowModal] = React.useState(false);

  const handleBreadcrumbRouting = (): Crumb[] => {
    const breadcrumbItems: Crumb[] = [
      {
        name: "Network Services",
        onClick: () => setShowModal(true),
      },
      {
        name: "Create New IP Address",
      },
    ];

    const updatedBreadcrumb: Crumb[] = [];

    breadcrumbItems.forEach((crumb) => {
      if (!updatedBreadcrumb.some((item) => item.name === crumb.name)) {
        updatedBreadcrumb.push(crumb);
      }
    });

    return updatedBreadcrumb;
  };

  return (
    <section className="create-new-ip-wrapper">
        <PageWrap
          className="internet-wrapper-header m-0 p-0"
          steps={["Enter details", "Summary"]}
          currentStep={_currentStep}
          handleBreadcrumbRouting={handleBreadcrumbRouting}
        />
      <div
        className="internet-wrapper--content"
        data-testid="internet-wrapper"
      >
        {!hideHeader && (
          <div className="fp-container">
            <div className="fp-row">
              <div className="col-16 ip_address_header">
                <CreateNewIpHeader />
              </div>
            </div>
          </div>
        )}
        {children}
        <div className="fp-container">
          <div className="fp-row">
            <div className="col-16">
              <div className="actions actions__bottom">
                {(selectedPort || handleBack) && currentStep !== 1 && (
                  <Button
                    label="Back"
                    variant="link"
                    dataTestId="back_btn"
                    onPress={handleBack}
                  />
                )}
                {handleNext && (
                  <Button
                    label="Continue"
                    variant="gradient"
                    dataTestId="continue_btn"
                    onPress={() => {
                      handleNext();
                    }}
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        topIconSize="md"
        title={UNSAVED_POPUP_TITLE}
        complementaryMessage={UNSAVED_POPUP_MESAGE}
        contentAlign="center"
        actionText="Leave"
        onOk={() => navigate("/network-services")}
        closeModal={!_showModal}
        onCancel={() => setShowModal(false)}
      />
    </section>
  );
};

export default CreateNewIpWrapper;
