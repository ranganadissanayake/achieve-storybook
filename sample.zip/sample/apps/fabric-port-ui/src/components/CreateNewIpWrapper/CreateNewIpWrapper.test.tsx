import React from "react";
import { render } from "@testing-library/react";
import { useSelector } from "react-redux";
import CreateNewIpWrapper from "./index";
import { BrowserRouter } from "react-router-dom";
import "regenerator-runtime";

jest.mock("../../authConfig", () => ({
  getAccessToken: jest.fn(),
}));

jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
}));
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: jest.fn(),
}));
describe("CreateNewIpWrapper", () => {
  const selectCurrentStepMock = useSelector as jest.Mock;
  beforeEach(() => {
    selectCurrentStepMock.mockClear();
  });
  it("renders without errors", () => {
    selectCurrentStepMock.mockReturnValue(1);
    render(
      <BrowserRouter>
        <CreateNewIpWrapper />
      </BrowserRouter>
    );
  });
});
