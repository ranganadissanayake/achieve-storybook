import { Label } from "@btdigital/nayan-component-library";
import React from "react";
import images from "../../../shared/assets";
import "./CreateNewIpHeader.scss";

export interface CreateNewIpHeaderProps {}

const CreateNewIpHeader: React.FC<CreateNewIpHeaderProps> = () => {
  return (
    <div className="header-wrapper" data-testid="header-wrapper">
      <div className="header-image">
        <img src={images.ipAddress} alt="" srcSet="" />
      </div>
      <div className="header-content">
        <Label text="Create a new IP address" labelTextStyles="header_title" />
        <div className="header-content--caption">
          <p>Please enter your details below to order a public IP address from BT.</p>
        </div>
      </div>
    </div>
  );
};

export default CreateNewIpHeader;
