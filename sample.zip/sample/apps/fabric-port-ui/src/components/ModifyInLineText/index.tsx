import React from "react";

import { Label } from "@btdigital/nayan-component-library";

import "./ModifyInLineText.scss";

type ModifyInLineTextProps = {
  text: string;
};

const ModifyInLineText = ({ text }: ModifyInLineTextProps) => {
  return (
    <div
      className="modify_inline_text_container"
      data-testid="modify_inline_text"
    >
      <Label helper={text} size="xs" helperTextStyles="text" />
    </div>
  );
};

export default ModifyInLineText;
