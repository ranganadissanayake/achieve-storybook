import React from "react";
import { render, screen } from "@testing-library/react";
import ModifyInLineText from "./index";

describe("ModifyInLineText", () => {
  test("should render the ModifyInLineText component", () => {
    render(<ModifyInLineText text="Test Test" />);
    expect(screen.getByText("Test Test")).toBeInTheDocument();
  });
});