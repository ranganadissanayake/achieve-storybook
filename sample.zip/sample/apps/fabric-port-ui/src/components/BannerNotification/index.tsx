import { Tile, Icon } from "@btdigital/nayan-component-library";
import React from "react";
import "./BannerNotification.scss";

export interface IBannerNotificationProps {
  title: string;
  description: string;
}
const BannerNotification: React.FC<IBannerNotificationProps> = ({
  title,
  description,
}) => {
  const [show, setShow] = React.useState(true);
  return (
    <>
      {show && (
        <Tile customClassName="banner-notification__wrapper">
          <Icon color="#5514B4" size="sm" title="info" />
          <div className="banner-notification__content">
            <h3>{title}</h3>
            <p>{description}</p>
          </div>
          <Icon
            color="#5514B4"
            title="cross_new"
            onClick={() => setShow(!show)}
          />
        </Tile>
      )}
    </>
  );
};

export default BannerNotification;
