import type { Meta, StoryObj } from '@storybook/react';
import BannerNotification from '.';


const meta: Meta<typeof BannerNotification> = {
  title: 'FabricPortWebApp/BannerNotification',
  component: BannerNotification,
  tags: ['autodocs'],
  parameters: {
    layout: 'centered',
  },
};

export default meta;
type Story = StoryObj<typeof BannerNotification>;

export const Default: Story = {
  args: {
    title: "sample title",
    description: "sample meaningful description"
  },
};