import React from "react";
import { render } from "@testing-library/react";
import BannerNotification from "./index";

describe("BannerNotification", () => {
  const title = "Test Title";
  const description = "Test Description";

  it("renders without errors", () => {
    render(<BannerNotification title={title} description={description} />);
  });
});
