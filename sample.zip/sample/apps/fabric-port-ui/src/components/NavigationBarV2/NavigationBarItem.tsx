import { Button } from "@btdigital/nayan-component-library";
import { AnimatePresence, motion } from "framer-motion";
import React, { useEffect } from "react";
import { NavLink } from "react-router-dom";
import Svg from "react-inlinesvg";

import useLocalStorage from "../../shared/hooks/useLocalStorage";
import { NavItemProp } from ".";
import { BT_NAV_SUBMENU } from "../../shared/constants";
import images from "../../shared/assets";
import Tooltip from "../../components/TooltipV2";

const menuAnimation = {
  hidden: {
    opacity: 0,
    height: 0,
    padding: 0,
    transition: { duration: 0.3, when: "afterChildren" },
  },
  show: {
    opacity: 1,
    height: "auto",
    transition: {
      duration: 0.3,
      when: "beforeChildren",
    },
  },
};

const menuItemAnimation = {
  hidden: (i) => ({
    x: 0,
    transition: {
      duration: (i + 1) * 0.1,
      when: "beforeChildren",
    },
  }),
  show: (i) => ({
    x: 0,
    transition: {
      duration: (i + 1) * 0.1,
    },
  }),
};

const SidebarMenu = ({
  route,
  showAnimation,
  isOpen,
  toggleMainMenu,
}: {
  route: NavItemProp;
  showAnimation: any;
  isOpen: boolean;
  toggleMainMenu: () => void;
}) => {
  const [isMenuOpen, setIsMenuOpen] = useLocalStorage(BT_NAV_SUBMENU, []);

  const currentMenuOpen = isMenuOpen.includes(route.route);

  const expandMenu = () => {
    setIsMenuOpen(
      currentMenuOpen
        ? isMenuOpen.filter(
            (currentRoute: string) => currentRoute !== route.route
          )
        : [route.route]
    );
  };

  const toggleMenu = () => {
    expandMenu();

    if (!isOpen) {
      toggleMainMenu();
    }
  };

  useEffect(() => {
    if (!isOpen) {
      setIsMenuOpen([]);
    }
  }, [isOpen]);

  return (
    <>
      <Tooltip content={isOpen ? "" : route.title} placement="right" trigger="mouseover">
        <div className="side-nav--routes__menu">
          <NavLink
            to={route.route ? route?.route as string : '#'}
            key={route.title}
            className={({ isActive }) =>
              [ isActive && route.route!==""  ? "active" : ""].join(" ")
              + " link"
            }
            style={({isActive}) => {
              return {
                fontWeight: isActive && route.route!==""  ? "bold" : "",
              };
            }}
          >
            <div className="side-nav--routes__menu--item" onClick={toggleMenu}>
              {route.navIcon ? (
                <div
                  id={`${route.iconName}-icon`}
                  className={`side-nav--routes__item--nav-icon `}
                >
                  <Svg src={route.navIcon} />
                </div>
              ) : (
                <Button
                  iconBefore
                  variant="link"
                  iconTitle={route.iconName}
                  className="item-button"
                  enableOriginalIcon
                />
              )}
              <AnimatePresence>
                {isOpen && (
                  <motion.div
                    variants={showAnimation}
                    initial="hidden"
                    animate="show"
                    exit="hidden"
                    className="link_text"
                  >
                    {route.title}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </NavLink>
          {isOpen && (
            <AnimatePresence>
              <motion.div
                initial="hidden"
                animate="show"
                exit="hidden"
                className="state"
                onClick={expandMenu}
              >
                <motion.div
                  animate={{
                    rotateX: currentMenuOpen ? 180 : 360,
                    transition: {
                      duration: 0.5,
                      when: "beforeChildren",
                    },
                  }}
                >
                  <div className="chevron">
                    <Svg src={images.chevronDown} />
                  </div>
                </motion.div>
              </motion.div>
            </AnimatePresence>
          )}
        </div>
      </Tooltip>

      <AnimatePresence>
        {currentMenuOpen && (
          <motion.div
            variants={menuAnimation}
            initial="hidden"
            animate="show"
            exit="hidden"
            className="side-nav--routes__sub-menu-container"
            data-testid="sub-menu-container"
          >
            {route.subMenu?.map((subMenu, i) => (
              <>
                {subMenu.route && (
                  <NavLink
                    to={subMenu.route}
                    key={subMenu.title}
                    className="link"
                    style={({ isActive }) => {
                      return {
                        fontWeight: isActive ? "bold" : "",
                      };
                    }}
                    onClick={route.onClick}
                  >
                    <motion.div
                      className="sub-item"
                      variants={menuItemAnimation}
                      key={i}
                      custom={i}
                    >
                      <motion.div className="link_text">
                        {subMenu.title}
                      </motion.div>
                      {subMenu.isComingSoon && (
                        <motion.div className="soon-lozenge">
                          Coming soon
                        </motion.div>
                      )}
                    </motion.div>
                  </NavLink>
                )}
                {!subMenu.route && (
                  <div onClick={subMenu?.onClick} className="nav-link-btn">
                    <motion.div
                      className="sub-item"
                      variants={menuItemAnimation}
                      key={i}
                      custom={i}
                    >
                      <motion.div className="link_text">
                        {subMenu.title}
                      </motion.div>
                      {subMenu.isComingSoon && (
                        <motion.div className="soon-lozenge">
                          Coming soon
                        </motion.div>
                      )}
                    </motion.div>
                  </div>
                )}
              </>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default SidebarMenu;
