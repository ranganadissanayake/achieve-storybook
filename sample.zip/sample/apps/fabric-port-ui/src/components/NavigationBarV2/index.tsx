import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import SidebarMenu from "./NavigationBarItem";
import "./NavigationBar.scss";
import { IconName, Button } from "@btdigital/nayan-component-library";
import { NavLink } from "react-router-dom";
import Svg from "react-inlinesvg";
import Tooltip from "../../components/TooltipV2";

export interface MenuItemProp {
  title: string;
  iconName?: IconName;
  iconInverted?: boolean;
  route?: string;
  isActive?: boolean;
  isDisabled?: boolean;
  navIcon?: string;
  isComingSoon?: boolean;
  onClick?: () => void;
}

export interface NavItemProp extends MenuItemProp {
  isBackRoute?: boolean;
  isFooterItems?: boolean;
  subMenu?: MenuItemProp[];
}

export interface NavItems {
  header?: NavItemProp[];
  main?: NavItemProp[];
  footer?: NavItemProp[];
}

export interface NavigationBarProps {
  navItems?: NavItems;
  toggleCollapseCb?: VoidFunction;
}

const SideNav: React.FC<NavigationBarProps> = ({
  navItems,
  toggleCollapseCb,
}) => {
  const [isOpen, setIsOpen] = useState(true);

  const toggle = () => {
    setIsOpen(!isOpen);
    toggleCollapseCb && toggleCollapseCb();
  };

  const showAnimation = {
    hidden: {
      width: 0,
      opacity: 0,
      transition: {
        duration: 0.5,
      },
    },
    show: {
      opacity: 1,
      width: "auto",
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <div className="navigation-bar" data-testid="navigation-bar">
      <motion.div
        animate={{
          width: isOpen ? "280px" : "64px",

          transition: {
            duration: 0.5,
            damping: 10,
          },
        }}
        className={`side-nav`}
      >
        <section className="side-nav--routes">
          {navItems?.main?.map((route) => {
            if (route?.subMenu) {
              return (
                <SidebarMenu
                  key={route.title}
                  toggleMainMenu={toggle}
                  route={route}
                  showAnimation={showAnimation}
                  isOpen={isOpen}
                />
              );
            }

            return (
              <NavLink
                to={route.route as string}
                key={route.title}
                className="link"
                style={({ isActive }) => {
                  return {
                    fontWeight: isActive ? "bold" : "",
                  };
                }}
                onClick={route.onClick}
              >
                <Tooltip content={isOpen ? "Open" : route.title} placement="right" trigger="mouseover">
                  <div
                    className="side-nav--routes__item"
                    key={route.title}
                    data-testid={`current-route-${route.route}`}
                  >
                    {route.navIcon ? (
                      <div
                        id={`${route.iconName}-icon`}
                        className={`side-nav--routes__item--nav-icon`}
                      >
                        <Svg src={route.navIcon} />
                      </div>
                    ) : (
                      <Button
                        iconBefore
                        variant="link"
                        iconTitle={route.iconName}
                        onPress={toggle}
                        className="item-button"
                        enableOriginalIcon
                      />
                    )}
                    <AnimatePresence>
                      {isOpen && (
                        <motion.div
                          variants={showAnimation}
                          initial="hidden"
                          animate="show"
                          exit="hidden"
                          className="link_text"
                        >
                          {route.title}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </Tooltip>
              </NavLink>
            );
          })}
        </section>
        <section className="side-nav--bottom-routes">
          {navItems?.footer?.map((route) => (
            <NavLink
              to={route.route as string}
              key={route.title}
              className="link"
              style={({ isActive }) => {
                return {
                  fontWeight: isActive ? "bold" : "",
                };
              }}
            >
              <Tooltip content={isOpen ? "" : route.title} placement="right" trigger="mouseover">
                <div
                  className="side-nav--routes__item"
                  key={route.title}
                  onClick={route.onClick}
                >
                  {route.navIcon ? (
                    <div
                      id={`${route.iconName}-icon`}
                      className={`side-nav--routes__item--nav-icon`}
                    >
                      <Svg src={route.navIcon} />
                    </div>
                  ) : (
                    <Button
                      iconBefore
                      variant="link"
                      iconTitle={route.iconName}
                      onPress={toggle}
                      className="item-button"
                      enableOriginalIcon
                    />
                  )}

                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        variants={showAnimation}
                        initial="hidden"
                        animate="show"
                        exit="hidden"
                        className="link_text"
                      >
                        {route.title}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </Tooltip>
            </NavLink>
          ))}
          <div className="link">
            <Tooltip content={isOpen ? "" : "Collapse"} placement="right" trigger="mouseover">
              <div className="side-nav--bottom-routes__item">
                <Button
                  dataTestId="collapse-section"
                  iconBefore
                  variant="link"
                  iconTitle={isOpen ? "side_nav_expand" : "side_nav_collapse"}
                  onPress={toggle}
                  className="item-button collapse_button"
                  enableOriginalIcon
                />
                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      variants={showAnimation}
                      initial="hidden"
                      animate="show"
                      exit="hidden"
                      className="collapse-link_text"
                    >
                      Collapse
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </Tooltip>
          </div>
        </section>
      </motion.div>
    </div>
  );
};

export default SideNav;
