import React from "react";
import { render, fireEvent } from "@testing-library/react";
import NavigationBar from "./";
import { BrowserRouter } from "react-router-dom";
import { BT_NAV, BT_NAV_SUBMENU } from "../../shared/constants";
jest.mock("react-inlinesvg");

const navItemsMock = {
  main: [
    {
      title: "Main Item 1",
      route: "/main1",
      subMenu: [
        {
          title: "Submenu Item 1",
          route: "/submenu1",
        },
        {
          title: "Submenu Item 2",
          route: "/submenu2",
        },
      ],
    },
    {
      title: "Main Item 2",
      route: "/main2",
    },
  ],
  footer: [
    {
      title: "Footer Item 1",
      route: "/footer1",
    },
  ],
};

describe("NavigationBar component", () => {
  const toggleCallbackMock = jest.fn();

  beforeEach(() => {
    jest.useFakeTimers();

    window.localStorage.setItem(BT_NAV, JSON.stringify(true));
    window.localStorage.setItem(BT_NAV_SUBMENU, JSON.stringify([]));
  });

  it("renders correctly when open", () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <NavigationBar navItems={navItemsMock} />
      </BrowserRouter>
    );
    expect(getByTestId("navigation-bar")).toHaveClass("navigation-bar");
  });

  it("calls navigate function when a navigation item is clicked", () => {
    const { getByText, getByTestId } = render(
      <BrowserRouter>
        <NavigationBar navItems={navItemsMock} />
      </BrowserRouter>
    );
    fireEvent.click(getByText("Main Item 2"));
    expect(getByTestId("current-route-/main2")).toBeInTheDocument();
  });

  it("calls toggleCallback function when the collapse button is clicked", () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <NavigationBar
          navItems={navItemsMock}
          toggleCollapseCb={toggleCallbackMock}
        />
      </BrowserRouter>
    );
    fireEvent.click(getByTestId("collapse-section"));
    expect(toggleCallbackMock).toHaveBeenCalledTimes(1);
  });

  it("toggles open and close correctly", () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <NavigationBar
          navItems={navItemsMock}
          toggleCollapseCb={toggleCallbackMock}
        />
      </BrowserRouter>
    );
    fireEvent.click(getByTestId("collapse-section"));
    expect(getByTestId("navigation-bar")).toHaveClass("navigation-bar");
    expect(toggleCallbackMock).toHaveBeenCalledTimes(1);
  });

  it("calculates initial active submenu index correctly", () => {
    const localStorageMock = {
      getItem: jest.fn().mockReturnValue("/submenu1"),
      setItem: jest.fn().mockReturnValue("/submenu1"),
    };
    Object.defineProperty(window, "localStorage", { value: localStorageMock });
    const { container } = render(
      <BrowserRouter>
        <NavigationBar navItems={navItemsMock} />
      </BrowserRouter>
    );
    const component = container.firstChild as HTMLElement;
    const initialActiveSubMenuIndex = component
      .querySelector(".navigation-bar")
      ?.querySelector(".side-nav--routes__sub-menu-container");
    expect(initialActiveSubMenuIndex).not.toBeNull();
  });

  it("handles submenu open and close correctly", () => {
    const localStorageMock = {
      getItem: jest.fn().mockReturnValue("/submenu1"),
      setItem: jest.fn().mockReturnValue("/submenu1"),
    };
    Object.defineProperty(window, "localStorage", { value: localStorageMock });
    const { getByText, getByTestId } = render(
      <BrowserRouter>
        <NavigationBar navItems={navItemsMock} />
      </BrowserRouter>
    );

    fireEvent.click(getByTestId("collapse-section"));

    const mainItem = getByText("Main Item 1");

    fireEvent.click(mainItem);
    const submenuItem = getByText("Submenu Item 1");
    expect(submenuItem).toBeInTheDocument();
  });

  afterEach(() => {
    jest.restoreAllMocks();
    jest.useRealTimers();
  });
});
