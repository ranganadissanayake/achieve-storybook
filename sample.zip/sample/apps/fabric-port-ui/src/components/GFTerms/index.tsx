import React, { useState } from "react";
import GFHeading from "../GFHeading";
import GFBadge from "../GFBadge";
import "./index.scss";

export interface GFTermsProps {
  onAccepted?: () => void;
}
const GFTerms: React.FC<GFTermsProps> = ({ onAccepted }) => {
  const [isAgreed, setIsAgreed] = useState(false);
  const [isAccepted, setIsAccepted] = useState(false);
  const termRef = React.createRef<HTMLInputElement>();

  const onScroll = () => {
    const scrollHeight = termRef.current?.scrollHeight
      ? termRef.current?.scrollHeight
      : 0;
    const scrollTop = termRef.current?.scrollHeight
      ? termRef.current?.scrollTop
      : 0;
    const offsetHeight = termRef.current?.scrollHeight
      ? termRef.current?.offsetHeight
      : 0;

    setIsAgreed(
      (30 > scrollHeight - scrollTop - offsetHeight &&
        scrollHeight - scrollTop - offsetHeight > -5) ||
        isAgreed,
    );
  };

  const onClick = () => {
    if (isAgreed) {
      setIsAccepted(true);
      onAccepted?.();
    }
  };

  return (
    <>
      <div
        className="gfTerms"
        ref={termRef}
        onScroll={onScroll}
        data-testid="gfTerms"
      >
        <GFHeading
          size="S6"
          text="Terms & Conditions:"
          color="brand"
          weight="regular"
        />
        <div className="mt-8">
          <GFHeading
            size="S6"
            text="Before you submit this Order, please check the summary details of your Order. If any details are incorrect, please select the back button and make corrections. Once you are happy that the details in the Order are correct, then please read and click the ‘I agree’ button below in order to submit the Order:"
            weight="light"
          />
        </div>

        <ol>
          <li>
            <GFHeading
              size="S6"
              text="I confirm that the details in this Order are correct and that I am duly authorized to place this Order on behalf of [Customer entity name]."
              weight="light"
            />
          </li>
          <li>
            <GFHeading size="S6" weight="light">
              <>
                I acknowledge and agree that the master services agreement
                [Customer name] previously entered with [BT entity] for Global
                Fabric will apply to this Order (the “Agreement”). This Order
                shall be subject to, amnd governed by, the terms of the
                Agreement and the latest Global Fabric Schedule which can be
                found here{" "}
                <a
                  href="https://www.globalservices.bt.com/en/terms-and-conditions/serviceschedules"
                  rel="noreferrer"
                  target="_blank"
                >
                  https://www.globalservices.bt.com/en/terms-and-conditions/serviceschedules
                </a>
                {""}
              </>
            </GFHeading>
          </li>
          <li>
            <GFHeading
              size="S6"
              text="I accept that this Order will only be deemed accepted once I have received a confirmation email from BT. The email will contain a link to the website where the Agreement and Global Fabric Schedule is stored and downloadable."
              weight="light"
            />
          </li>
        </ol>
      </div>

      <div className="fp-row">
        <div className="col-11">
          <GFHeading
            size="S6"
            text="You must read the Terms and Conditions before proceeding to accept them."
            weight="light"
          />
        </div>
        <div className="col-5 mt-8 agree_btn">
          <GFBadge
            style={isAgreed ? (isAccepted ? "accepted" : "accept") : "agree"}
            onClick={onClick}
            text="I accept"
            iconTitle={isAccepted}
          />
        </div>
      </div>
    </>
  );
};

export default GFTerms;
