import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import GFTerms from "./index";

const mockOnAccepted = jest.fn();
describe("GFTerms", () => {
  test("should render terms", () => {
    render(<GFTerms onAccepted={mockOnAccepted} />);
    const termsDiv = screen.getByText("Terms & Conditions:").closest("div");
    expect(termsDiv).toBeInTheDocument();
    termsDiv &&
      fireEvent.scroll(termsDiv, {
        target: { scrollingElement: { scrollTop: 473 } },
      });
    const accept = screen.getByText("I accept");
    expect(accept).toBeInTheDocument();
    fireEvent.click(accept);
  });
});
