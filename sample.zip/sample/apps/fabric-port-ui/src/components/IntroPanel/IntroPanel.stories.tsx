import type { Meta, StoryObj } from '@storybook/react';
import IntroPanel from '.';


const meta: Meta<typeof IntroPanel> = {
    title: 'FabricPortWebApp/IntroPanel',
    component: IntroPanel,
    parameters: {
        layout: 'centered',
    },
    tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof IntroPanel>;

export const Default: Story = {
    args: {
        header: "Introducing Cloud Ports & Cloud Port Groups",
        showCloseIcon: true,
        showReadMoreButton: true,
        showDontShowAgainButton: true
    },
};