import React from 'react';
import { render } from '@testing-library/react';
import IntroPanel from './index';

describe('IntroPanel', () => {
  it('renders the header and children', () => {
    const headerText = 'Welcome to IntroPanel';
    const contentText = 'This is the content of IntroPanel';

    const { getByText } = render(
      <IntroPanel header={headerText}>
        {contentText}
      </IntroPanel>
    );

    expect(getByText(headerText)).toBeInTheDocument();
    expect(getByText(contentText)).toBeInTheDocument();
  });

 
});
