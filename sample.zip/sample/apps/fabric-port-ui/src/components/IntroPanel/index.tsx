import { Button, Icon, Label } from '@btdigital/nayan-component-library';
import React from 'react';
import './IntroPanel.scss';

export type IntroPanelProps = {
    header: string;
    headerIcon?: any;
    showCloseIcon?: boolean;
    children: React.ReactNode;
    showReadMoreButton?: boolean;
    showDontShowAgainButton?: boolean;
    onClose?: () => void
}

const IntroPanel: React.FC<React.PropsWithChildren<IntroPanelProps>> = ({
    header,
    headerIcon,
    showCloseIcon,
    children,
    showReadMoreButton,
    showDontShowAgainButton,
    onClose = () => { }
}: IntroPanelProps) => {
    return (
        <div className="intro-panel-wrapper">
            <div className="container">
                <div className="header-container">
                    <div className="left">
                        {
                            headerIcon ??
                            (<Icon
                                size="md"
                                title="stars"
                                color="#5514B4"
                                showOriginal
                            />)
                        }

                        <Label
                            text={header}
                            containerStyles="header-container"
                            labelTextStyles="header-text"
                        />
                    </div>
                    <div className="right">
                        {
                            showCloseIcon && (<Icon
                                size="lg"
                                title="cross_alt_2px"
                                color="#2A2A2A"
                                onClick={onClose}
                            />
                            )
                        }
                    </div>
                </div>
                <div className="body">
                    <div className="inner-space">
                        {children}
                    </div>
                </div>
                <div className="actions">
                    {
                        showReadMoreButton && (<Button
                            variant="solid"
                            label="Read more"
                            className="read-more-button"
                        />)
                    }
                    {
                        showDontShowAgainButton && (<Button
                            variant="link"
                            label="Don't show again"
                            className="dont-show-button"
                        />)
                    }

                </div>
            </div>
        </div>
    )
}

export default IntroPanel
