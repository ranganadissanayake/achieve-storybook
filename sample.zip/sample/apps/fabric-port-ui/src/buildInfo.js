export default {
  buildVersion: "0.17.3",
  buildDate: 1723197142572,
}