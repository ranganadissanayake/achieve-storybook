import {
  PublicClientApplication,
  LogLevel,
  Configuration,
  IPublicClientApplication,
  InteractionRequiredAuthError,
  AccountInfo,
} from '@azure/msal-browser';

export const isTestUser = !!Number(process.env.REACT_APP_USE_TEST_USER);
export const isDEVMode = String(process.env.MODE) === "development";
export const isCSTMode = !!Number(process.env.REACT_APP_IS_CST);
export const isDemoMode = !!Number(process.env.REACT_APP_IS_DEMO);
export const isLocalMode = String(process.env.MODE) === "local";

const clientId = String(process.env.REACT_APP_AUTH_CLIENT_ID);
const authority = String(process.env.REACT_APP_AUTH_AUTHORITY);
const redirectUri = String(process.env.REACT_APP_AUTH_REDIRECT_URL);
const knownAuthorities = [String(process.env.REACT_APP_AUTH_KNOWN_AUTHORITIES)];
const postLogoutRedirectUri = String(process.env.REACT_APP_LOGOUT_URL);
const allowedUris = [
  `https://${knownAuthorities}/api/digico.widget.read`,
  `https://${knownAuthorities}/api/digico.sidebar.read`,
  `https://${knownAuthorities}/api/digico.ticketdetails.read`,
  `https://${knownAuthorities}/api/digico.userprofile.read`,
  `https://${knownAuthorities}/api/digico.userlist.read`,
  `https://${knownAuthorities}/api/digico.userlist.delete`,
  `https://${knownAuthorities}/api/digico.user.write`,
  `https://${knownAuthorities}/api/digico.productlist.read`,
  `https://${knownAuthorities}/api/digico.productdetails.read`,
  `https://${knownAuthorities}/api/digico.search.write`,
  `https://${knownAuthorities}/api/voicequality.metricsinformation.read`,
  `https://${knownAuthorities}/api/voicequality.metricnames.read`,
  `https://${knownAuthorities}/api/voicequality.trunkids.read`,
  `https://${knownAuthorities}/api/voicequality.trunkinfo.read`,
  `https://${knownAuthorities}/api/voicequality.metricsinformation.write`,
  `https://${knownAuthorities}/api/custhub.soldproducts.read`,
  `https://${knownAuthorities}/api/custhub.widgetdata.read`,
  `https://${knownAuthorities}/api/custhub.inv.custloc.read`,
  `https://${knownAuthorities}/api/custhub.inv.siptrunks.read`,
  `https://${knownAuthorities}/api/custhub.knowledge.read`,
  `https://${knownAuthorities}/api/custhub.ticketdetails.read`,
  `https://${knownAuthorities}/api/custhub.inv.oc.read`,
  `https://${knownAuthorities}/api/global.geographicallocations.read`,
  `https://${knownAuthorities}/api/global.btsites.write`,
  `https://${knownAuthorities}/api/global.customerportpricing.write`,
  `https://${knownAuthorities}/api/global.datacenterprices.write`,
  `https://${knownAuthorities}/api/global.loadetails.read`,
  `https://${knownAuthorities}/api/global.ipaddress.price.write`,
  `https://${knownAuthorities}/api/global.ipaddress.order.write`,
  `https://${knownAuthorities}/api/global.ipaddress.ip.all`,
  `https://${knownAuthorities}/api/global.ipaddress.contacts.all`,
  `https://${knownAuthorities}/api/global.ipaddress.search.write`,
  `https://${knownAuthorities}/api/global.ipaddress.ip.read`,
  `https://${knownAuthorities}/api/global.internet.price.write`,
  `https://${knownAuthorities}/api/global.internet.order.write`,
  `https://${knownAuthorities}/api/global.internet.search.write`,
  `https://${knownAuthorities}/api/global.internet.net.read`,
  `https://${knownAuthorities}/api/global.loadownloads.read`,
  `https://${knownAuthorities}/api/global.portonlyports.all`,
  `https://${knownAuthorities}/api/global.customerpremises.all`,
  `https://${knownAuthorities}/api/global.connectivityoptions.write`,
  `https://${knownAuthorities}/api/global.quotes.all`,
  `https://${knownAuthorities}/api/global.internet.net.all`,
  `https://${knownAuthorities}/api/global.datacenter.all`,
  `https://${knownAuthorities}/api/global.notifications.all`,
  `https://${knownAuthorities}/api/global.billingaccounts.read`,
  `https://${knownAuthorities}/api/global.cases.read`,
  `https://${knownAuthorities}/api/global.performancereports.all`,
  `https://${knownAuthorities}/api/global.validateaddresses.write`,
  `https://${knownAuthorities}/api/global.charges.read`,
  `https://${knownAuthorities}/api/customerhub.notificationpreference.all`,
];

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) to any login request.
 * For more information about OIDC scopes, visit:
 * https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-permissions-and-consent#openid-connect-scopes
 */
export const scopes: string[] = ["openid", "profile", ...allowedUris];

export const loginRequest = {
  scopes,
  authority,
  redirectUri,
};

/**
 * Configuration object to be passed to MSAL instance on creation.
 * For a full list of MSAL.js configuration parameters, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md
 */
const msalConfig: Configuration = {
  auth: {
    clientId,
    authority,
    redirectUri,
    knownAuthorities,
    postLogoutRedirectUri,
  },
  cache: {
    cacheLocation: 'localStorage',
    storeAuthStateInCookie: false,
  },
  system: {
    allowRedirectInIframe: true,
    iframeHashTimeout: 10000,
    loggerOptions: {
      loggerCallback: (
        level: LogLevel,
        message: string,
        containsPii: boolean,
      ) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
        }
      },
      piiLoggingEnabled: isDEVMode || isCSTMode,
    },
  },
};

/**
 * Initialize a PublicClientApplication instance which is provided to the MsalProvider component
 * We recommend initializing this outside of your root component to ensure it is not re-initialized on re-renders
 */
export const pca: IPublicClientApplication = new PublicClientApplication(msalConfig);

export const getAccessToken = async (): Promise<
  { accessToken: string; idToken: string; activeAccount: AccountInfo | null } | undefined
> => {
  let account = pca.getActiveAccount();

  if (!account) {
    console.log('NO ACTIVE ACCOUNT');
    const accounts = pca.getAllAccounts();
    account = accounts[0];
  }

  try {
    console.log('ACTIVE ACCOUNT: ', account);
    const response = await pca.acquireTokenSilent({ scopes, account });
    console.log('Token response: ', response);

    return { accessToken: response.accessToken, idToken: response.idToken, activeAccount: account };
  } catch (error) {
    console.log(error);
    if (error instanceof InteractionRequiredAuthError) {
      console.log('Token redirect');
      localStorage.clear();
      pca.loginRedirect(loginRequest);
    }

    return;
  }
};
