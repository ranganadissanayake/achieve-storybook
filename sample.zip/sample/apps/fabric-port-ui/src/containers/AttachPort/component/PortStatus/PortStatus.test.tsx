import React from "react";
import PortStatus from ".";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { RowDataInterfacePortIn } from "shared/types";

describe("Port Status", () => {

    const row: RowDataInterfacePortIn = {
        index: 1,
        portId: '',
        serviceId: '',
        getToggleRowExpandedProps: () => { },
        isExpanded: false,
        canExpand: true,
        id: 1,
        isSubRow: false,
        portIdSecondary:"",
        original: {
            "portName": "UI test 8 22Aug1812",
            "portId": "02i3L00000Amw8aQAB",
            "serviceId": "Sinprefix-YY-90000-00001",
            "isDiverse": true,
            "primaryPortMetadata": {
                "portId": "02i3L00000Amw8aQAB",
                "serviceId": "Sinprefix-YY-90000-00001",
                "portSpeed": "100000",
                "portStatus": "Active",
                "siteId": "1486819",
                "encapsulation": ""
            },
            "secondaryPortMetadata": {
                "portId": "02i3L00000AspUvQAJ",
                "serviceId": "Sinprefix-YY-90000-00002",
                "portSpeed": "100000",
                "portStatus": "Active",
                "siteId": "1486819",
                "encapsulation": ""
            },
            "isPrimaryLAG": true,
            "primaryLAGMetadata": {
                "lagPortsCount": 2,
                "lagPortSpeed": "200000"
            },
            "isSecondaryLAG": true,
            "secondaryLAGMetadata": {
                "lagPortsCount": 2,
                "lagPortSpeed": "250000"
            },
            "BTPoPSiteId": "GBLONA039",
            "portSpeed": "100 Gbps",
            "countryISOCode": "GB",
            "country": "United Kingdom",
            "portStatus": "acknowledged",
            "diversity": "diverse-single-pop",
            "portDiversity": "diverse-single-pop",
            "portType": "Port Only",
            "isSelectedParent": false,
            "subRows": [
                {
                    "portId": "02i3L00000Amw8aQAB",
                    "serviceId": "Sinprefix-YY-90000-00001",
                    "portSpeed": "100000",
                    "portStatus": "acknowledged",
                    "countryISOCode": "GB",
                    "country": "United Kingdom",
                    "portName": "UI test 8 22Aug1812",
                    "isDiverse": true,
                    "isSubRow": true,
                    "disablePort": false,
                    "portResielienceType": "primary",
                    "location": "",
                    "isChecked": true,
                    "parentPortId": "02i3L00000Amw8aQAB",
                    isEnabled: true,
                    speedUnit: "100",
                    BTPoPSiteId: '',
                    diverseBTPoPSiteId: '',
                    provider: '',
                    isLag: false,
                    subRows: [],
                    isBandwidthUtilisationMonitoring: false,
                    isPredictiveBandwidthOptimisation: false,
                    isEnableOversubscription: false,
                    portDiversity: ''
                },
                {
                    "portId": "02i3L00000AspUvQAJ",
                    "serviceId": "Sinprefix-YY-90000-00002",
                    "portSpeed": "100000",
                    "portStatus": "acknowledged",
                    "countryISOCode": "GB",
                    "country": "United Kingdom",
                    "portName": "UI test 8 22Aug1812",
                    "isDiverse": true,
                    "isSubRow": true,
                    "isSecondary": true,
                    "disablePort": false,
                    "portResielienceType": "secondary",
                    "location": "",
                    "isChecked": false,
                    "parentPortId": "02i3L00000Amw8aQAB",
                    isEnabled: true,
                    speedUnit: "100",
                    BTPoPSiteId: '',
                    diverseBTPoPSiteId: '',
                    provider: '',
                    isLag: false,
                    subRows: [],
                    isBandwidthUtilisationMonitoring: false,
                    isPredictiveBandwidthOptimisation: false,
                    isEnableOversubscription: false,
                    portDiversity: ''
                }
            ],
            isEnabled: false,
            speedUnit: "",
            diverseBTPoPSiteId: "",
            disablePort: false,
            provider: undefined,
            isBandwidthUtilisationMonitoring: false,
            isLag: false,
            isPredictiveBandwidthOptimisation: false,
            isEnableOversubscription: false
        }
    }


    test("renders status component", () => {
        render(
            <PortStatus row={row} />
        );

        expect(screen.getByTestId("port-status")).toBeInTheDocument();
    });
    test("Mouse over the icon to show tooltip", async () => {
      render(
        <PortStatus row={row} />
      );

      fireEvent.click(screen.getByRole('img'));
      await waitFor(() => screen.getByTestId("tooltip-content"));
      expect(screen.getByText("deploying")).toBeInTheDocument();
    });

    test("if port status disabled it should render disabled", async () => {
        render(
          <PortStatus row={{...row, canExpand: false, original:{ ...row?.original, disablePort: true}}} />
        );
  
        fireEvent.click(screen.getByRole('img'));
        await waitFor(() => screen.getByTestId("tooltip-content"));
        expect(screen.getByText("disabled")).toBeInTheDocument();
      });

      test("if port status is live it should render Up", async () => {
        render(
          <PortStatus row={{...row, canExpand: true, original:{ ...row?.original,  portStatus: 'live'}}} />
        );
  
        fireEvent.click(screen.getByTestId("icon"));
        await waitFor(() => screen.getByTestId("tooltip-content"));
        expect(screen.getByText("Up")).toBeInTheDocument();
      });
});