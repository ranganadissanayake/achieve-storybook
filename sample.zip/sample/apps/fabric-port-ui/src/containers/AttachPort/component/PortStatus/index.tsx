import { RowDataInterfacePortIn } from "shared/types";
import StatusIcon from "../../../../components/StatusIcon";
import Tooltip from "../../../../components/TooltipV2";
import React from "react";

const PortStatus = ({ row }: { row: RowDataInterfacePortIn }) => {

    let status = row.original.portStatus;

    if (row.original.disablePort) {
        status = "disabled";
    } else if (row.canExpand) {
        if (row.original.portStatus === "live") {
            status = "Up";
        } else {
            const subRowStatus = row.original?.subRows?.map(subRow => subRow.portStatus) ?? [];
            if (subRowStatus.includes("acknowledged")) {
                status = "deploying";
            } else if (subRowStatus.includes("disconnected")) {
                status = "unknown";
            }
        }
    }

        return (
            <div data-testId="port-status">
                <Tooltip
                    content={status}
                    placement="top"
                >
                    <div>
                        <StatusIcon status={status} />
                    </div>
                </Tooltip>
            </div>
        );
};

export default PortStatus