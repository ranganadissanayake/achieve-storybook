import React from "react";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
  within
} from "@testing-library/react";

import AttachPort from "./index";
import store from "../../redux/store";
import { ApiProvider, useApi } from "../../shared/helpers/api";
import { portsWithAllStatus } from "../../shared/constants/portInventory";
import { internetTestData } from "../../shared/constants/internetConnection";
import { mockIpAddressResponse } from "../../shared/constants/IPAddressInventory";
import { geoLocationData } from "../../shared/constants/locationTable";

jest.mock("../../shared/helpers/api", () => ({
  ...jest.requireActual("../../shared/helpers/api"),
  useApi: jest.fn(),
}));

const portSearchData = {
  results: [
    {
      portName: "Test001:Available 1 Mbps-lag",
      portType: "Port Only",
      isDiverse: false,
      diversityPattern: "",
      primaryPort: {
        portId: "02i3GA10001ljL8QAI",
        serviceId: "Sinprefix-PO-90000-00001",
        portSpeed: 1000,
        status: "active",
        siteId: "AUSYDA014",
        siteName:
          "SYDNEY MACQUARIE PARK NEXTDC S1 EDEN PARK DRIVE, SYDNEY, AUSTRALIA",
        siteAddress: {
          countryISOCode: "AU",
          countryOrState: "AUSTRALIA",
        },
        isLAG: true,
        lagPortsCount: 2,
        lagPortSpeed: 2000,
        connectivity: {
          circuitId: "",
          circuitSpeed: 0,
          circuitTechnology: "",
          supplierProduct: "BTCFNEthernetFranceOnnetDCp2a",
          btPopSiteId: "",
        },
        createdDateTime: "2023-11-01T06:42:22.000Z",
      },
      secondaryPort: {},
    },
    {
      portName: "Test002:Available 0 Mbps-lag",
      portType: "Port Only",
      isDiverse: false,
      diversityPattern: "",
      primaryPort: {
        portId: "02i3GA10002ljL8QAI",
        serviceId: "Sinprefix-PO-90000-00002",
        portSpeed: 1000,
        status: "active",
        siteId: "AUMELA005",
        siteName:
          "MELBOURNE NEXTDC M1 LORIMER STREET 826, MELBOURNE, AUSTRALIA",
        siteAddress: {
          countryISOCode: "DE",
          countryOrState: "GERMANY",
        },
        isLAG: true,
        lagPortsCount: 1,
        lagPortSpeed: 1000,
        connectivity: {
          circuitId: "",
          circuitSpeed: 0,
          circuitTechnology: "",
          supplierProduct: "BTCFNEthernetFranceOnnetDCp2a",
          btPopSiteId: "",
        },
        createdDateTime: "2023-11-01T06:42:22.000Z",
      },
      secondaryPort: {},
    },
    {
      portName: "Test004:Available 1&2 Mbps-lag",
      portType: "Port Only",
      isDiverse: true,
      diversityPattern: "",
      primaryPort: {
        portId: "02i3GA10004ljL8QAI",
        serviceId: "Sinprefix-PO-90000-00003",
        portSpeed: 100000,
        status: "Active",
        siteId: "AUMELA005",
        siteName:
          "MELBOURNE NEXTDC M1 LORIMER STREET 826, MELBOURNE, AUSTRALIA",
        siteAddress: {
          countryISOCode: "BE",
          countryOrState: "BELGIUM",
        },
        isLAG: true,
        lagPortsCount: 2,
        lagPortSpeed: 200000,
        connectivity: {
          circuitId: "",
          circuitSpeed: 0,
          circuitTechnology: "",
          supplierProduct: "BTCFNEthernetFranceOnnetDCp2a",
          btPopSiteId: "GBLONA039",
        },
        createdDateTime: "2024-02-23T08:36:02.000Z",
      },
      secondaryPort: {
        portId: "02i3GA10005ljL8QAI",
        serviceId: "Sinprefix-PO-90000-00004",
        portSpeed: 25000,
        status: "Active",
        siteId: "AUSYDA014",
        siteName:
          "SYDNEY MACQUARIE PARK NEXTDC S1 EDEN PARK DRIVE, SYDNEY, AUSTRALIA",
        siteAddress: {
          countryISOCode: "BE",
          countryOrState: "BELGIUM",
        },
        isLAG: true,
        lagPortsCount: 1,
        lagPortSpeed: 25000,
        connectivity: {
          circuitId: "",
          circuitSpeed: 0,
          circuitTechnology: "",
          supplierProduct: "BTCFNEthernetFranceOnnetDCp2a",
          btPopSiteId: "GBLONA039",
        },
        createdDateTime: "2024-02-23T08:36:02.000Z",
      },
    },
    {
      portName: "Test003:Available 2 Mbps-lag",
      portType: "Port Only",
      isDiverse: false,
      diversityPattern: "",
      primaryPort: {
        portId: "02i3GA10003ljL8QAI",
        serviceId: "Sinprefix-PO-90000-00005",
        portSpeed: 1000,
        status: "active",
        siteId: "AUMELA005",
        siteName:
          "MELBOURNE NEXTDC M1 LORIMER STREET 826, MELBOURNE, AUSTRALIA",
        siteAddress: {
          countryISOCode: "ES",
          countryOrState: "SPAIN",
        },
        isLAG: true,
        lagPortsCount: 3,
        lagPortSpeed: 3000,
        connectivity: {
          circuitId: "",
          circuitSpeed: 0,
          circuitTechnology: "",
          supplierProduct: "BTCFNEthernetFranceOnnetDCp2a",
          btPopSiteId: "",
        },
        createdDateTime: "2024-02-23T06:42:22.000Z",
      },
      secondaryPort: {},
    },
  ],
  pagination: {
    limit: 25,
    offset: 1,
    total: 13,
  },
};

const internetData = [
  {
    name: "Internet-Test19",
    description: "",
    isResilient: false,
    billingAccountId: "SBE202306061740",
    primaryConnection: {
      connectionId: "02i3L00000AskexQAB",
      portId: "02i3GA10001ljL8QAI",
      VLANID: 2032,
      encapsulation: "dot1q",
      isEnabled: true,
      bandwidthType: "static",
      isBFD: false,
      IPVersion: "ipv4",
      routingType: "bgp",
      routingConfig: {
        bgpConfig: {
          ASNType: "private",
          bgpPeerASN: "65530",
          btRoutesAdvertised: "default-only",
          ipv4Config: {
            bgpPeerAddress: "100.9.8.29",
            ebgpMultihop: "",
            gracefulRestart: false,
            isMD5Authentication: true,
            enableAdvanceBGP: "",
            advancedBGPConfig: false,
          },
        },
      },
      isTelemetryStreamingEnabled: false,
      IPAddressConfiguration: {
        ipv4Config: {
          WANId: "02i3L00000AskBJQAZ",
          LANConfig: [
            {
              LANId: "02i3L00000AskBOQAZ",
            },
          ],
          BTWANAddress: "100.9.8.28",
          CustomerWANAddress: "100.9.8.29",
          isDHCP: true,
        },
      },
      staticBandwidthConfig: {
        staticBandwidth: 3000,
        isStaticBandwidthThreshold: false,
      },
    },
  },
];

const portDetailsData = {
  portName: "LAG",
  isDiverse: true,
  primaryPortMetadata: {
    portId: "02i3L000008KoVdQAK",
    portSpeed: 200000,
    sfpType: "100GBASE-LR4",
    mtu: 9216,
    isOversubscription: false,
    isUtilisationThreshold: true,
    highUtilisationThreshold: 80,
    lowUtilisationThreshold: 10,
    isPredictiveOptimisation: false,
    encapsulation: "unspecified",
    portStatus: "On",
    isEnabled: false,
    description: "",
    isPrimaryLAG: true,
    isTelemetryStreamingEnabled: false,
    associatedNetworkServices: [
      {
        connectionId: "InternetOnStandardPortPS",
        type: "",
        VLANID: "101",
        bandwidth: "2000",
        name: "",
      },
    ],
    btPopSiteId: "GBLONA039",
    isLAGEnabled: true,
    primaryLAGMetadata: {
      lagPortsCount: 1,
      lagPortSpeed: 200000,
      lagMemberPorts: [
        {
          lagPortId: "G4i3L000008KoVdPKS",
          lagPortStatus: "On",
        },
      ],
    },
  },
  secondaryPortMetadata: {
    portId: "U2i3L000008KoVdLPS",
    portSpeed: 200000,
    sfpType: "100GBASE-LR4",
    mtu: 9216,
    isOversubscription: false,
    isUtilisationThreshold: true,
    highUtilisationThreshold: 80,
    lowUtilisationThreshold: 10,
    isPredictiveOptimisation: false,
    encapsulation: "unspecified",
    portStatus: "On",
    isEnabled: false,
    description: "",
    isTelemetryStreamingEnabled: false,
    associatedNetworkServices: [
      {
        connectionId: "InternetOnStandardPortPS",
        type: "",
        VLANID: "101",
        bandwidth: "2000",
        name: "",
      },
    ],
    btPopSiteId: "GBLONA039",
    isLAGEnabled: true,
    secondaryLAGMetadata: {
      lagPortsCount: 2,
      lagPortSpeed: 200000,
      lagMemberPorts: [
        {
          lagPortId: "G4i3L000008KoVdPPS",
          lagPortStatus: "On",
        },
        {
          lagPortId: "G4i5L000008KoVdPPS",
          lagPortStatus: "On",
        },
      ],
    },
  },
  countryISOCode: "GB",
  portTerm: 12,
  createdBy: {
    dateTime: "2023-11-01T06:42:22.000Z",
  },
};

describe("AttachPort", () => {
  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getGeoLocations: jest.fn().mockResolvedValue(geoLocationData),
      portSearch: jest.fn().mockResolvedValue(portSearchData),
      getPortDetails: jest.fn().mockResolvedValue(portDetailsData),
      getInternetConnectionSearch: jest.fn().mockResolvedValue(internetData),
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("renders without errors", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });
    await waitFor(() => {
      expect(screen.getByTestId("attach_port")).toBeInTheDocument();
    }, {
      timeout: 10000
    });
  });

  it("renders the correct step", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });
    jest.advanceTimersByTime(3000);
    await waitFor(() => {
      expect(screen.getByTestId("attach_port")).toBeInTheDocument();
    }, {
      timeout: 10000
    });
    expect(screen.getByText("Select Ports")).toBeInTheDocument();
    expect(screen.getByText("Step 1 of 3")).toBeInTheDocument();
  });

  it("Renders table columns", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });
    await waitFor(() => {
      expect(screen.getByTestId("attach_port")).toBeInTheDocument();
    });

    expect(screen.getByText("Port Name")).toBeInTheDocument();
    expect(screen.getByText("Port Type")).toBeInTheDocument();
    expect(screen.getByText("Resilience")).toBeInTheDocument();
    expect(screen.getByText("Country")).toBeInTheDocument();
    expect(screen.getByText("Port Speed")).toBeInTheDocument();
    expect(screen.getByText("Service ID")).toBeInTheDocument();
  });

  it("Renders table filters", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });
    await waitFor(() => {
      expect(screen.getByTestId("attach_port")).toBeInTheDocument();
    });

    expect(screen.getByText("Filter")).toBeInTheDocument();
  });


  it("Renders table card component", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });
    await waitFor(() => {
      expect(screen.getByTestId("attach_port")).toBeInTheDocument();
    });
  });

  it("Clicking Continue without selecting a port displays live port warning", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });

    const continueButton = await screen.findByTestId("continue_btn");
    await fireEvent.click(continueButton);

    expect(
      screen.getByText("You haven’t selected a live port")
    ).toBeInTheDocument();
    expect(
      screen.getByText("You cannot continue without selecting a live port")
    ).toBeInTheDocument();
  });

  it("Clicking Continue after selecting port with negative available bandwidth shows warning", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });

    const radioBtns = await screen.findAllByRole("radio");
    await fireEvent.click(radioBtns[0]);

    const continueButton = await screen.findByTestId("continue_btn");
    await fireEvent.click(continueButton);

    expect(
      screen.getByText("Create an Internet connection from an existing Port"),
    ).toBeInTheDocument();
  });

  it("Clicking Continue after selecting port with available bandwidth of 0 shows warning", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });

    const radioBtns = await screen.findAllByRole("radio");
    await fireEvent.click(radioBtns[1]);

    const continueButton = await screen.findByTestId("continue_btn");
    await fireEvent.click(continueButton);

    expect(
      screen.getByText("Create an Internet connection from an existing Port"),
    ).toBeInTheDocument();
  });

  it("Selecting Non-diverse port displays the appropriate title card", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });

    const [radioBtn] = await screen.findAllByRole("radio");
    await fireEvent.click(radioBtn);

    expect(screen.getByTestId("internet-wrapper")).toBeInTheDocument();

    const nonDiverseCard = screen.getByTestId("non_diverse_title");
    expect(nonDiverseCard).toBeInTheDocument();
    expect(within(nonDiverseCard).getByText("Non Diverse")).toBeInTheDocument();
    expect(within(nonDiverseCard).getByText("Test001:Available 1 Mbps-lag")).toBeInTheDocument();
    expect(within(nonDiverseCard).getByText("Australia")).toBeInTheDocument();
  });

  it("Selecting Diverse port displays the appropriate title card", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });

    const [_, __, radioBtn] = await screen.findAllByRole("radio");
    await fireEvent.click(radioBtn);

    expect(screen.getByTestId("internet-wrapper")).toBeInTheDocument();

    const diverseCard = screen.getByTestId("diverse_title")
    expect(diverseCard).toBeInTheDocument();
    expect(within(diverseCard).getByText("Diverse - Primary")).toBeInTheDocument();
    expect(within(diverseCard).getByText("Diverse - Secondary")).toBeInTheDocument();
    expect(within(diverseCard).getAllByText("Test004:Available 1&2 Mbps-lag")).toHaveLength(2);
    expect(within(diverseCard).getAllByText("Belgium")).toHaveLength(2);
  });
});

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useSearchParams: () => [new URLSearchParams({ status: "edit" })],
}));

describe("AttachPort is editing internet", () => {
  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getGeoLocations: jest.fn().mockResolvedValue(geoLocationData),
      portSearch: jest.fn().mockResolvedValue([
        {
          portName: "sprint end demo diverse without lag",
          portDescription: "Data Centre Connection",
          isDiverse: true,
          primaryPortMetadata: {
            siteId: "GBLONA039",
            portId: "02i3L000009ljLSQAY",
            portSpeed: 100000,
            sfpType: "25GBASE-ER",
            mtu: 9216,
            isOversubscription: false,
            isUtilisationThreshold: false,
            highUtilisationThreshold: 0,
            lowUtilisationThreshold: 0,
            isPredictiveOptimisation: false,
            encapsulation: "unspecified",
            portStatus: "active",
            isLOAAvailable: true,
            isEnabled: false,
          },
          primaryPorData: {
            siteId: "GBLONA039",
            portId: "02i3L000009ljLSQAY",
            portSpeed: 100000,
            sfpType: "25GBASE-ER",
            mtu: 9216,
            isOversubscription: false,
            isUtilisationThreshold: false,
            highUtilisationThreshold: 0,
            lowUtilisationThreshold: 0,
            isPredictiveOptimisation: false,
            encapsulation: "unspecified",
            portStatus: "active",
            isLOAAvailable: true,
            isEnabled: false,
          },
          secondaryPortMetadata: {
            siteId: "GBLONA039",
            portId: "02i3L000009ljLUQAY",
            portSpeed: 100000,
            sfpType: "25GBASE-ER",
            mtu: 9216,
            isOversubscription: false,
            isUtilisationThreshold: false,
            highUtilisationThreshold: 0,
            lowUtilisationThreshold: 0,
            isPredictiveOptimisation: false,
            encapsulation: "unspecified",
            portStatus: "active",
            isLOAAvailable: true,
            isEnabled: false,
          },
          isPrimaryLAG: false,
          primaryLAGMetadata: {},
          isSecondaryLAG: false,
          secondaryLAGMetadata: {},
          portTerm: 25,
          currencyFormat: "Diverse Split Site",
          countryISOCode: "GB",
          telemetryStreamingEnabled: false,
        },
        {
          portName: "DC01-US-ASH-100G",
          portDescription: "Diverse Dual PoP",
          isDiverse: true,
          primaryPortMetadata: {
            siteId: "GBLONA039",
            portId: "02i3L0000093jLSQAY",
            portSpeed: 100000,
            sfpType: "100GBASE-LR4",
            mtu: 9216,
            isOversubscription: false,
            isUtilisationThreshold: false,
            highUtilisationThreshold: 0,
            lowUtilisationThreshold: 0,
            isPredictiveOptimisation: false,
            encapsulation: "",
            portStatus: "active",
            isLOAAvailable: true,
            isEnabled: true,
          },
          secondaryPortMetadata: {
            siteId: "GBLONA009",
            portId: "02i3L0000094jLUQAY",
            portSpeed: 100000,
            sfpType: "100GBASE-LR4",
            mtu: 9216,
            isOversubscription: false,
            isUtilisationThreshold: false,
            highUtilisationThreshold: 0,
            lowUtilisationThreshold: 0,
            isPredictiveOptimisation: false,
            encapsulation: "",
            portStatus: "active",
            isLOAAvailable: true,
            isEnabled: true,
          },
          isPrimaryLAG: true,
          primaryLAGMetadata: {
            lagPortsCount: 2,
            lagPortSpeed: 200000,
            memberPort: [
              {
                memberPortId: "02i3L0000093jLSQAY",
                portStatus: "active",
                isLOAAvailable: true,
                isEnabled: true,
              },
              {
                memberPortId: "02i3L0000093jLSQAY",
                portStatus: "active",
                isLOAAvailable: true,
                isEnabled: true,
              },
            ],
          },
          isSecondaryLAG: true,
          secondaryLAGMetadata: {
            lagPortsCount: 1,
            lagPortSpeed: 100000,
            memberPort: [
              {
                memberPortId: "02i3L0000094jLUQAY",
                portStatus: "active",
                isLOAAvailable: true,
                isEnabled: true,
              },
            ],
          },
          portTerm: 25,
          currencyFormat: "GBP",
          countryISOCode: "US",
          telemetryStreamingEnabled: false,
        },
        {
          portName: "Test001:Available 1 Mbps-lag",
          portId: "02i3GA10001ljL8QAI",
          isDiverse: false,
          primaryPortMetadata: {
            portId: "02i3GA10001ljL8QAI",
            portSpeed: 1000,
            portStatus: "active",
            siteId: "AUSYDA014",
          },
          secondaryPortMetadata: {
            portId: null,
            portSpeed: null,
            portStatus: null,
            siteId: null,
          },
          isPrimaryLAG: true,
          primaryLAGMetadata: {
            lagPortsCount: 2,
            lagPortSpeed: 2000,
          },
          isSecondaryLAG: null,
          secondaryLAGMetadata: {
            lagPortsCount: null,
            lagPortSpeed: null,
          },
          BTPoPSiteId: "",
          portSpeed: "",
          countryISOCode: "AU",
          country: "",
          canExpand: false,
          location: "",
          resilience: "Non diverse",
          diversity: "standard-single-pop",
          portDiversity: "standard-single-pop",
        },
      ]),
    });
  });
  afterEach(() => {
    jest.clearAllMocks();
  });

  it("Check if in editing mode", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider>
            <AttachPort />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );

    expect(await screen.findByText("Edit")).toBeInTheDocument();
    expect(await screen.findByText("Internet Inventory")).toBeInTheDocument();
  });

  it("In edit mode clicking continue calls the navigate method", async () => {
    const handleNext = jest.fn();

    jest
      .spyOn(require("react-router-dom"), "useNavigate")
      .mockReturnValue(handleNext);

    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider>
            <AttachPort />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );

    const continueButton = await screen.findByTestId("continue_btn");
    await fireEvent.click(continueButton);
    expect(handleNext).not.toHaveBeenCalledTimes(1);
  });

  it("In edit mode clicking continue takes you to the configuration page", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider>
            <AttachPort />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );

    const continueButton = await screen.findByTestId("continue_btn");
    await fireEvent.click(continueButton);

    setTimeout(() => {
      expect(window.location.pathname).toBe("/");
    }, 500);
  });

  it("Renders live port", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider>
            <AttachPort />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );

    const continueButton = await screen.findByTestId("continue_btn");
    await fireEvent.click(continueButton);

    setTimeout(async () => {
      expect(
        await screen.findByAltText("Please do not refresh the page")
      ).toBeInTheDocument();
    }, 500);
  });


  it("Renders table with mock data", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });
    await waitFor(() => {
      expect(screen.getByTestId("attach_port")).toBeInTheDocument();
    });
    expect(screen.getAllByRole("table").length).toBe(1);
  });

  it("should able to open apply filters", async () => {
    (useApi as jest.Mock).mockReturnValueOnce({
      getGeoLocations: jest.fn().mockResolvedValue(geoLocationData),
      portSearch: jest.fn().mockResolvedValue(portsWithAllStatus),
      getIpAddressSearch: jest.fn().mockResolvedValue(mockIpAddressResponse),
      getInternetConnectionSearch: jest
        .fn()
        .mockResolvedValue(internetTestData),
    });
    await act(async () =>
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      )
    );

    const createNewPortButton = screen.getByText("Filter");
    fireEvent.click(createNewPortButton);
    fireEvent.click(screen.getAllByText("Resilience")[0]);
    expect(
      screen.getByText("Create an Internet connection from an existing Port")
    ).toBeInTheDocument();
  });

  it("shoud able to API errors", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <ApiProvider>
              <AttachPort />
            </ApiProvider>
          </BrowserRouter>
        </Provider>
      );
    });
    jest.advanceTimersByTime(2000);
    expect(await screen.findByTestId("attach_port")).toBeInTheDocument();
  });
});
