import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useSearchParams } from "react-router-dom";

import { Card, Modal, TableV2 } from "@btdigital/nayan-component-library";

import InternetConnectionWrapper from "../../components/InternetConnectionWrapper";
import {
  selectInternetEditItem,
  updateInternetInfo,
  updateLevel,
  updatePortInformation,
  updateStep,
} from "../../redux/internetSlice";
import { formatDataSet } from "../../shared/constants/portInventory";
import { useApi } from "../../shared/helpers";
import { IPortADetail, isAnError } from "../../shared/models";
import {
  dataMapper,
  fetchLoopResponse,
  getInternetServicesAllocationByPortId,
  getPageCounts,
  getPortSearchRes,
} from "../../shared/utils";
import GFLoader from "../../components/GFLoader";
import { getPortSearchResponseDTO } from "../../shared/mappers/services/portSearch.service";
import CreateIpVpnConnection from "../../containers/IpVpn/components/AttachPort/components/IPVpnPortConnection/IpVpnCreatePortB";

import "./index.scss";
import { generateColumns } from "../../containers/PortInventory/utils";
import {
  filterPortInventoryReducer,
  initialState,
  FilterState,
} from "../../containers/PortInventory/PortInventoryFilters/portFiltersReducer";
import PortInventoryFilters from "../../containers/PortInventory/PortInventoryFilters";
import { PaginationState, PORT_STATUS } from "../../shared/types";
import useAppContext from "../../shared/hooks/useAppContext";

export interface AttachPortProps {}

const AttachPort: React.FC<AttachPortProps> = () => {
  const navigate = useNavigate();
  const [searchParams, _] = useSearchParams();
  const dispatch = useDispatch();
  const api = useApi();
  const { loadingInventory, setLoadingDashboardInventory } = useAppContext();

  const editInternetItem = useSelector(selectInternetEditItem);

  const isEdit = searchParams.get("status") === "edit";

  const [selectedPort, setSelectedPort] = React.useState(
    editInternetItem ? editInternetItem.associatedPort : "",
  );

  const [isSelectedLivePort, setIsSelectedLivePort] = React.useState(false);

  const [filteredData, setFiltered] = React.useState<IPortADetail[]>([]);
  const [portData, setPortData] = React.useState<IPortADetail[]>([]);
  const [filterInputs, setFilterInputs] = React.useState<any>();
  const [pageCountsAttachPort, setPageCountsAttachPort] =
    React.useState<number>(0);
  const [pageTotalAttachPort, setPageTotalAttachPort] =
    React.useState<number>();

  const currentPort = portData.find(
    (data) =>
      data.primaryPortMetadata?.serviceId === selectedPort ||
      (data.isDiverse && data.secondaryPort?.serviceId === selectedPort),
  );
  const selectedPorts = [currentPort];

  const [showAlert, setShowAlert] = React.useState(false);
  const [showBandwidthAlert, setShowBandwidthAlert] = React.useState(false);
  const [_showDiversityChangeModal, setShowDiversityChangeModal] =
    React.useState(false);

  const [diversePrimaryPortName, setDiversePrimaryPortName] =
    React.useState("");
  const [diverseSecondaryPortName, setDiverseSecondaryPortName] =
    React.useState("");
  const [diverseSecondaryLocation] = React.useState("");

  React.useEffect(() => {
    if (
      currentPort &&
      currentPort.isDiverse &&
      currentPort.subRows[0].portId === editInternetItem?.associatedPort
    ) {
      setDiversePrimaryPortName(currentPort.subRows[0].portName);
    }
    if (
      currentPort &&
      currentPort.isDiverse &&
      currentPort.subRows[1].portId === editInternetItem?.associatedPort
    ) {
      setDiverseSecondaryPortName(currentPort.subRows[1].portName);
    }
  }, [currentPort, editInternetItem]);

  const [_availableBandwidth, setAvailableBandwidth] = React.useState(0);

  const [portSelections, setPortSelections] = React.useState<{
    primary: boolean;
    secondary: boolean;
  }>({
    primary: false,
    secondary: false,
  });

  const [showLoader, setShowLoader] = React.useState(true);
  const [hasApiError, setHasApiError] = React.useState(false);

  const [state, filterDispatch] = React.useReducer(
    filterPortInventoryReducer,
    initialState,
  );

  React.useEffect(() => {
    const getBandwidthInfor = async () => {
      if (currentPort?.primaryPortMetadata?.serviceId) {
        let portDetailsResponse;
        if (currentPort?.portType === "Customer Premise") {
          portDetailsResponse = await api.getPortCDetails(
            currentPort.primaryPortMetadata.serviceId,
          );
        } else if (currentPort?.portType === "Data Centre Connection") {
          portDetailsResponse = await api.getPortBDetails(
            currentPort.primaryPortMetadata.serviceId,
          );
        } else {
          portDetailsResponse = await api.getPortDetails(
            currentPort.primaryPortMetadata.serviceId,
          );
        }

        const isOversubscription =
          portDetailsResponse.primaryPortMetadata.isOversubscription;

        const { totalUsedBandwidth } =
          await getInternetServicesAllocationByPortId(
            currentPort.primaryPortMetadata.serviceId,
            api,
            isOversubscription,
          );

        const portBandwidth = Number(
          dataMapper(
            currentPort.isPrimaryLAG
              ? Number(currentPort.primaryLAGMetadata?.lagPortSpeed)
              : Number(
                  currentPort.primaryPortMetadata?.portSpeed ??
                    currentPort.portSpeed,
                ),
          ).split(" ")[0],
        );

        let availableBandwidth = portBandwidth - totalUsedBandwidth;

        if (
          portSelections.secondary &&
          currentPort.secondaryPortMetadata?.portId
        ) {
          const { totalUsedBandwidth: secTotalUsedBandwidth } =
            await getInternetServicesAllocationByPortId(
              currentPort.secondaryPortMetadata.portId,
              api,
              isOversubscription,
            );

          const secPortBandwidth = Number(
            dataMapper(
              currentPort.isSecondaryLAG
                ? Number(currentPort.secondaryLAGMetadata?.lagPortSpeed)
                : Number(currentPort.secondaryPortMetadata?.portSpeed ?? ""),
            ).split(" ")[0],
          );

          const secAvailableBandwidth =
            secPortBandwidth - secTotalUsedBandwidth;

          if (portSelections.primary) {
            availableBandwidth =
              availableBandwidth > secAvailableBandwidth
                ? secAvailableBandwidth
                : availableBandwidth;
          } else {
            availableBandwidth = secAvailableBandwidth;
          }
        }

        setAvailableBandwidth(availableBandwidth);
      }
    };
    getBandwidthInfor();
  }, [currentPort, portSelections, api]);

  React.useEffect(() => {
    onChangeFiltersAttach(state);
  }, [state]);

  React.useEffect(() => {
    if (isEdit && editInternetItem) {
      setSelectedPort(editInternetItem.associatedPort || "");
      setPortSelections((prev) => ({ ...prev, primary: true }));
      setIsSelectedLivePort(true);
      if (editInternetItem.isDiverse) {
        setPortSelections((prev) => ({ ...prev, secondary: true }));
      }
    }
  }, [isEdit, editInternetItem]);

  React.useEffect(() => {
    const getPortSearch = async (currentPage: number, pageSize: number) => {
      setShowLoader(true);
      const res: any = await api.portSearch({}, currentPage, pageSize);
      if (!isAnError(res)) {
        let resObj: any = {
          length: res.pagination.total,
          data: res.results,
          currentPage: currentPage,
          pageSize: pageSize,
        };
        setShowLoader(false);
        return resObj;
      } else {
        setShowLoader(false);
        navigate("/internet-connection");
        return res;
      }
    };

    (async () => {
      const fetchResponseData = await fetchLoopResponse(getPortSearch, 0, 1);

      const mappedRespDTO: any = getPortSearchResponseDTO(
        fetchResponseData as any[],
      );
      setHasApiError(!fetchResponseData);
      setShowLoader(false);
      if (!Array.isArray(mappedRespDTO)) {
        return;
      }
      const formattedData = formatDataSet(mappedRespDTO);
      setFiltered(formattedData);
      setPortData(formattedData);
    })();
  }, []);

  const updateTableDataSet = (tableSet: IPortADetail[]) => {
    const updatedDataSet = tableSet.map((data: IPortADetail) => {
      if (
        selectedPort &&
        (data.portId === selectedPort ||
          data.secondaryPort?.portId === selectedPort)
      ) {
        if (data.subRows) {
          if (diversePrimaryPortName && diverseSecondaryPortName) {
            data["subRows"][0].isChecked = true;
            data["subRows"][1].isChecked = true;
            return { ...data, isSelectedParent: true, isExpanded: true };
          } else if (!diversePrimaryPortName && diverseSecondaryPortName) {
            data["subRows"][0].isChecked = false;
            data["subRows"][1].isChecked = true;
            return { ...data, isSelectedParent: true, isExpanded: true };
          } else {
            data["subRows"][0].isChecked = true;
            data["subRows"][1].isChecked = false;
            return { ...data, isSelectedParent: true, isExpanded: true };
          }
        } else {
          setDiverseSecondaryPortName("");
          return { ...data, isSelectedParent: true };
        }
      } else {
        if (data.subRows) {
          data["subRows"][0].isChecked = false;
          data["subRows"][1].isChecked = false;
          return { ...data, isSelectedParent: false };
        } else {
          return { ...data, isSelectedParent: false };
        }
      }
    });
    setFiltered(updatedDataSet);
  };

  React.useMemo(() => {
    if (portData) {
      if (selectedPort) {
        updateTableDataSet(filteredData);
      } else {
        setFiltered(portData);
      }
    } else {
      setFiltered([]);
    }
  }, [portData, selectedPort]);

  const [_isAllowDiversityChanged, setIsAllowDiversityChanged] =
    React.useState(false);

  const handleNext = React.useCallback(() => {
    if (
      isSelectedLivePort &&
      currentPort &&
      (currentPort.isDiverse
        ? portSelections.primary || portSelections.secondary
        : true)
    ) {
      if (
        _availableBandwidth <= 0 &&
        (!isEdit ||
          (isEdit && editInternetItem?.associatedPort !== selectedPort))
      ) {
        setShowBandwidthAlert(true);
        return;
      }

      const journeyType =
        currentPort.isDiverse &&
        portSelections.primary &&
        portSelections.secondary
          ? "diverse"
          : "non-diverse";

      const isDiversityChanged = editInternetItem?.subRows
        ? !portSelections.primary || !portSelections.secondary
        : portSelections.primary && portSelections.secondary;

      if (isEdit && isDiversityChanged && !_isAllowDiversityChanged) {
        setShowDiversityChangeModal(true);
      } else {
        dispatch(
          updatePortInformation([
            {
              portName: currentPort.portName,
              portId: currentPort.portId,
              serviceId: currentPort.serviceId,
              portLocation: currentPort.country ? currentPort.country : "",
              resilience: currentPort.resilience ?? "",
              secondaryPortName: diverseSecondaryPortName,
              secondaryPortLocation: diverseSecondaryLocation,
              secondaryResilience: "Diverse-Secondary",
              diversePortSubRows: currentPort?.subRows
                ? currentPort?.subRows
                : [currentPort?.primaryPortMetadata],
              journeyType,
              isPrimarySelected: portSelections.primary,
              isSecondarySelected: portSelections.secondary,
              isPrimaryLAG: currentPort.isPrimaryLAG,
              isSecondaryLAG: currentPort.isSecondaryLAG,
              primaryLAGMetadata: currentPort.primaryLAGMetadata,
              secondaryLAGMetadata: currentPort.secondaryLAGMetadata,
              isDiversityChanged,
              portDiversity: currentPort.diversity!,
              countryISOCode: currentPort.countryISOCode,
              currencyFormat: currentPort.currencyFormat,
            },
          ]),
        );
        if (editInternetItem) {
          dispatch(updateInternetInfo(editInternetItem));
        }
        dispatch(updateStep(2));
        dispatch(updateLevel(1));
        navigate(
          `/internet-connection/configuration${
            journeyType === "diverse" ? "-diverse" : ""
          }${isEdit ? "?status=edit" : ""}`,
        );
      }
    } else {
      setShowAlert(true);
    }
  }, [
    isSelectedLivePort,
    currentPort,
    portSelections.primary,
    portSelections.secondary,
    _availableBandwidth,
    isEdit,
    editInternetItem,
    selectedPort,
    _isAllowDiversityChanged,
    dispatch,
    diverseSecondaryPortName,
    diverseSecondaryLocation,
    navigate,
  ]);

  React.useEffect(() => {
    if (_isAllowDiversityChanged) {
      handleNext();
      setIsAllowDiversityChanged(false);
    }
  }, [_isAllowDiversityChanged]);

  const handleSelectPort = (value: any) => {
    const { isDiverse, primaryPort, portStatus } = value;

    if (!isDiverse) {
      setSelectedPort(value?.serviceId ?? value?.primaryPort.serviceId);
      setIsSelectedLivePort(
        portStatus?.toLowerCase() === PORT_STATUS.live ||
          portStatus?.toLowerCase() === PORT_STATUS.active ||
          primaryPort?.portStatus?.toLowerCase() === PORT_STATUS.active,
      );
      setPortSelections((prev) => ({
        ...prev,
        primary: true,
      }));
    }
  };

  const handleMultiSelect = (value: any) => {
    const primaryPort = value.find(
      (val) => val.portResielienceType === "primary",
    );
    const secondaryPort = value.find(
      (val) => val.portResielienceType === "secondary",
    );

    if (primaryPort || secondaryPort) {
      setSelectedPort(primaryPort?.serviceId ?? secondaryPort.serviceId);

      if (primaryPort && secondaryPort) {
        setIsSelectedLivePort(
          (primaryPort?.portStatus?.toLowerCase() === PORT_STATUS.live ||
            primaryPort?.portStatus?.toLowerCase() === PORT_STATUS.active) &&
            (secondaryPort?.portStatus?.toLowerCase() === PORT_STATUS.live ||
              secondaryPort?.portStatus?.toLowerCase() === PORT_STATUS.active),
        );
        if (!portSelections.primary || !portSelections.secondary) {
          setPortSelections((prev) => ({
            ...prev,
            primary: true,
            secondary: true,
          }));
        }
      } else if (primaryPort) {
        setIsSelectedLivePort(
          primaryPort?.portStatus?.toLowerCase() === PORT_STATUS.live ||
            primaryPort?.portStatus?.toLowerCase() === PORT_STATUS.active,
        );
        if (!portSelections.primary) {
          setPortSelections((prev) => ({
            ...prev,
            primary: true,
          }));
        }
      } else if (secondaryPort) {
        setIsSelectedLivePort(
          secondaryPort?.portStatus?.toLowerCase() === PORT_STATUS.live ||
            secondaryPort?.portStatus?.toLowerCase() === PORT_STATUS.active,
        );
        if (!portSelections.secondary) {
          setPortSelections((prev) => ({
            ...prev,
            secondary: true,
          }));
        }
      }

      setDiversePrimaryPortName(primaryPort?.portName);
      setDiverseSecondaryPortName(secondaryPort?.portName);
    }
  };

  const onChangePaginationAttach = async (pagination: PaginationState) => {
    setLoadingDashboardInventory({ attachPort: true });
    try {
      const { pageIndex, pageSize } = pagination;
      const formattedList = await getPortSearchRes(
        api.portSearch,
        pageIndex * pageSize,
        pageSize,
        {
          countryISOCode: filterInputs?.country ? filterInputs?.country[0] : "",
          portName: filterInputs?.search ?? "",
          portType: filterInputs?.portType ? filterInputs?.portType[0] : "",
        },
      );
      setFiltered(formatDataSet(formattedList?.results));
      const pageCount = getPageCounts(
        formattedList?.pagination?.total,
        pageSize,
      );
      setPageCountsAttachPort(pageCount ?? 0);
      setPageTotalAttachPort(formattedList?.pagination?.total);
    } catch {
      setLoadingDashboardInventory({ attachPort: false });
    } finally {
      setLoadingDashboardInventory({ attachPort: false });
    }
  };

  const onChangeFiltersAttach = async (filterValues: FilterState) => {
    setLoadingDashboardInventory({ attachPort: true });
    try {
      setFilterInputs(filterValues);
      const formattedList = await getPortSearchRes(api.portSearch, 0, 10, {
        countryISOCode: filterValues?.country ? filterValues?.country[0] : "",
        portName: filterValues?.search ?? "",
        portType: filterValues?.portType ? filterValues?.portType[0] : "",
      });
      setFiltered(formatDataSet(formattedList?.results));
      const pageCount = getPageCounts(formattedList?.pagination?.total, 10);
      setPageCountsAttachPort(pageCount ?? 0);
      setPageTotalAttachPort(formattedList?.pagination?.total);
    } catch {
      setLoadingDashboardInventory({ attachPort: false });
    } finally {
      setLoadingDashboardInventory({ attachPort: false });
    }
  };

  const noDataActionAttach = () => {
    navigate("/customer-ports");
  };
  return (
    <div
      data-testid="attach_port"
      className={
        portData && portData.length === 0 && !hasApiError
          ? "attach-port-new"
          : "attach-port-content"
      }
    >
      {loadingInventory.attachPort && <GFLoader />}
      {showLoader ? (
        <GFLoader />
      ) : (
        <InternetConnectionWrapper
          portsPreview={true}
          selectedPort={
            isSelectedLivePort ||
            (selectedPorts && selectedPorts[0] !== undefined)
          }
          selectedPorts={selectedPorts}
          diversePortSubRows={currentPort?.subRows ? currentPort?.subRows : []}
          handleNext={handleNext}
          handleBack={() => navigate("/internet-connection")}
          currentStep={1}
          isSelectedDiversePrimaryPort={portSelections.primary}
          isSelectedDiverseSecondaryPort={portSelections.secondary}
          dataLength={filteredData?.length}
          checkNextJourney={true}
        >
          <div className="fp-container attach-port">
            <div className="fp-row">
              <div
                className="col-16 attach-port-table"
                data-testid="attach-port-table"
              >
                <Card data-testid="attach-port-card">
                  <PortInventoryFilters
                    state={state}
                    dispatch={filterDispatch}
                    portData={portData}
                    filteredData={filteredData ?? []}
                  />
                  <TableV2
                    data={filteredData ?? []}
                    columns={generateColumns()}
                    enableExpand={true}
                    enableSingleSelectExpand={true}
                    enablePagination={true}
                    defaultPageSize={10}
                    pageSizes={[10, 25, 50, 100]}
                    onSelectValue={handleSelectPort}
                    onMultiSelectValue={handleMultiSelect}
                    enableFixHeader={true}
                    enableStickyColumn={true}
                    tableMaxHeight="900px"
                    tableMaxWidth="1400px"
                    onChangePaginationFn={onChangePaginationAttach}
                    setManualPagination
                    setPageCount={pageCountsAttachPort}
                    setTotalCount={pageTotalAttachPort}
                    enableSingleRowSelectionWithExpandRow={true}
                    noDatadescription={
                      "It appears you don't have any ports at the moment. To begin, let's get started by creating your very first port."
                    }
                    noDataMessage={"No ports to show"}
                    noDataActionLabel={"Create New Port"}
                    noDataAction={noDataActionAttach}
                  />
                </Card>
              </div>
            </div>
            <div
              className="create-port-messagebox"
              data-testid="create-port-btn"
            >
              <CreateIpVpnConnection />
            </div>
          </div>
        </InternetConnectionWrapper>
      )}
      {showAlert && (
        <Modal
          topIcon="cloud_desktop"
          topIconStyle="critical"
          size="md"
          title="You haven't selected a live port"
          complementaryMessage="You cannot continue without selecting a live port"
          contentAlign="center"
          hideButtons={true}
          onCancel={() => setShowAlert(false)}
          closeModal={!showAlert}
        />
      )}
      {showBandwidthAlert && (
        <Modal
          topIcon="cloud_desktop"
          topIconStyle="critical"
          size="md"
          title={`Available bandwidth is ${
            _availableBandwidth < 0 ? "negative" : "0"
          }`}
          complementaryMessage="Cannot create internet connection. Please select a different port"
          contentAlign="center"
          hideButtons={true}
          onCancel={() => setShowBandwidthAlert(false)}
          closeModal={!showBandwidthAlert}
        />
      )}
      {_showDiversityChangeModal && (
        <Modal
          topIcon="info"
          topIconStyle="warning"
          size="md"
          title="Diversity Changes Notice"
          contentAlign="center"
          actionText="Continue"
          className="diversity_change_modal"
          onCancel={() => setShowDiversityChangeModal(false)}
          onOk={() => {
            setIsAllowDiversityChanged(true);
          }}
          closeModal={!_showDiversityChangeModal}
        >
          <label className="diversity_description">
            Changing the diversity of your port will result in a price change.
            Are you sure you want to proceed?{" "}
            <span className="more_link">Learn more</span>
          </label>
        </Modal>
      )}
    </div>
  );
};

export default AttachPort;
