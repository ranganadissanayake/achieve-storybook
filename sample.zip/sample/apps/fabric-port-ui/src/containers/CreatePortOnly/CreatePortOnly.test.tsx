import React from "react";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { render } from "@testing-library/react";

import { ApiProvider } from "../../shared/helpers/api";
import store from "../../redux/store";
import CreatePortOnly from ".";
import "regenerator-runtime";

jest.mock("@btdigital/nayan-component-library", () => ({
  ...jest.requireActual("@btdigital/nayan-component-library"),
  Map: () => <div data-testid="map-component" />,
}));

describe("AttachPort", () => {
  it("renders without errors", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider>
            <CreatePortOnly />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );
  });
});
