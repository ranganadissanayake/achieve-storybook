import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

import { Crumb } from "@btdigital/nayan-component-library";

import SelectLocation from "./components/SelectLocation";
import ConfigStandard from "./components/ConfigStandard";
import ConfigDiverse from "./components/ConfigDiverse";
import Summary from "./components/Summary";
import {
  selectCurrentStep,
  selectIsInModifyPortMode,
  selectPortDiversity,
  updateStep,
} from "../../redux/portOnlySlice";
import { PortDiversityType } from "../../shared/types";
import PageWrap from "../../components/PageWrap";
import { containerVariants } from "../../shared/constants/animationVariants";

import "./CreatePortOnly.scss";

const CreatePortOnly = () => {
  const _currentStep = useSelector(selectCurrentStep);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const configRef = React.useRef<null | HTMLDivElement>(null);

  const _portDiversity = useSelector(selectPortDiversity);
  const _isInModifyPortMode = useSelector(selectIsInModifyPortMode);

  React.useEffect(() => {
    if (_currentStep === 2 && configRef.current) {
      configRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
        inline: "nearest",
      });
    }
  }, [_currentStep, configRef]);

  React.useEffect(() => {
    if (_isInModifyPortMode) {
      dispatch(updateStep(2));
    }
  }, [_isInModifyPortMode]);

  const handleBreadcrumbRouting = (): Crumb[] => {
    let breadcrumbItems: Crumb[];
    if (_isInModifyPortMode) {
      breadcrumbItems = [
        {
          name: "Port Inventory",
          onClick: () => {
            navigate("/port-inventory");
          },
        },
        {
          name: "Edit port",
        },
      ];
    } else {
      breadcrumbItems = [
        {
          name: "Create a port",
          onClick: () => {
            navigate("/customer-ports");
          },
        },
        {
          name: "Port Only",
        },
      ];
    }

    const updatedBreadcrumb: Crumb[] = [];

    breadcrumbItems.forEach((crumb) => {
      if (!updatedBreadcrumb.some((item) => item.name === crumb.name)) {
        updatedBreadcrumb.push(crumb);
      }
    });

    return updatedBreadcrumb;
  };

  return (
    <div className="port_only_container">
      <PageWrap
        className="port-A-connectivity m-0 p-0"
        steps={["Select Location", "Configuration", "Price and Summary"]}
        currentStep={_currentStep}
        handleBreadcrumbRouting={handleBreadcrumbRouting}
      />
      <main className="fp-container port_only_main">
        {_currentStep === 1 || _currentStep === 2 ? (
          <>
            <SelectLocation />
            {_currentStep === 2 && (
              <motion.div
                ref={configRef}
                variants={containerVariants}
                initial="initialLoad"
                animate="fullLoad"
                layout
              >
                {_portDiversity === PortDiversityType.StandardSinglePop ? (
                  <ConfigStandard />
                ) : (
                  <ConfigDiverse />
                )}
              </motion.div>
            )}
          </>
        ) : (
          <motion.div
            variants={containerVariants}
            initial="initialLoad"
            animate="fullLoad"
            layout
          >
            <Summary />
          </motion.div>
        )}
      </main>
    </div>
  );
};

export default CreatePortOnly;
