import React from "react";
import { render, screen } from "@testing-library/react";

import PortResilience from "./index";

describe("PortResilience", () => {
  test("renders the PortResilience component", () => {
    render(<PortResilience onClickAction={jest.fn()} />);
    expect(screen.getByTestId("port-res-wrapper")).toBeInTheDocument();
  });
});
