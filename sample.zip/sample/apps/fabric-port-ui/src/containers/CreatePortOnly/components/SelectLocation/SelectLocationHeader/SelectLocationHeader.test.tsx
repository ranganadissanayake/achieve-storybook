import React from "react";
import { render, screen } from "@testing-library/react";

import SelectLocationHeader from "./index";

describe("SelectLocationHeader", () => {
  test("renders the SelectLocationHeader component", () => {
    render(<SelectLocationHeader />);
    expect(screen.getByTestId("header-wrapper")).toBeInTheDocument();
  });
  test('alt contains correct value', () => {
    render(<SelectLocationHeader />)
    const testImage = document.querySelector("img") as HTMLImageElement;
    expect(testImage.alt).toContain("Edit Port Image");
  })
});
