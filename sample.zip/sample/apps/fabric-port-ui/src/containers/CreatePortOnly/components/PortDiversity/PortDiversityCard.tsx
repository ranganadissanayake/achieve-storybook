import React from "react";
import { Card, Icon, Label } from "@btdigital/nayan-component-library";
import Tooltip from "../../../../components/TooltipV2";

type PortDiversityCardCardProps = {
  checked: boolean;
  onRadioButtonClick: (event: any) => void;
  radioButtonValue: string;
  imageUrl: string;
  cardLabel: string;
};

const PortDiversityCard = ({
  checked,
  onRadioButtonClick,
  radioButtonValue,
  imageUrl,
  cardLabel,
}: PortDiversityCardCardProps) => {

  const tooltipContent = React.useMemo(() => {
    switch (radioButtonValue) {
      case "standard-single-pop":
        return "One Point of Presence (PoP) on a port. No backup or alternative location provided to route traffic of services in case of an outage.";
      case "diverse-single-pop":
        return "Within a single Point of Presence (PoP) multiple different network ports are available to enhance reliability.";
      case "diverse-dual-pop":
        return "Two separate Points of Presence (PoP) in different locations to ensure network reliability by giving alternative paths in case one experiences outages."; 
      default:
        return ""
    }
  }, [radioButtonValue]);

  return (
    <div
      className={`wrapper ${checked ? "selected-card" : ""}`}
      data-testid="port-diversity-card"
      onClick={() =>
        onRadioButtonClick({ target: { value: radioButtonValue } })
      }
    >
      <Card>
        <div className="radio-button-container">
          <input
            type="radio"
            name="resilience"
            value={radioButtonValue}
            id={radioButtonValue}
            checked={checked}
            onChange={onRadioButtonClick}
          />
          <Label
            htmlFor={radioButtonValue}
            text={cardLabel}
            labelTextStyles="zone-label"
            containerStyles="zone-container"
            isFontHeadline={true}
          />
          <Tooltip content={tooltipContent} placement="bottom">
            <Icon title="info_alt" size="sm" className="tooltip_icon" />
          </Tooltip>
        </div>
        <div className="image-container">
          <img src={imageUrl} />
        </div>
      </Card>
    </div>
  );
};

export default PortDiversityCard;
