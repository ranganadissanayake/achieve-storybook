import { render, screen } from "@testing-library/react";
import React from "react";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import store from "../../../../redux/store";
import images from "./../../../../shared/assets";
import PortDiversityCard from "./PortDiversityCard";

describe("PortDiversityCard", () => {
  test("renders the PortDiversity component", () => {
    render(
      <Router>
        <Provider store={store}>
          <PortDiversityCard
            checked={true}
            onRadioButtonClick={() => jest.fn()}
            radioButtonValue="diverse-single-pop"
            imageUrl={images.diverseSinglePoP}
            cardLabel="Diverse - Single PoP"
          />
        </Provider>
      </Router>,
    );
    expect(screen.getByTestId("port-diversity-card")).toBeInTheDocument();
  });
});
