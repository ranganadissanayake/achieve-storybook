import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import {
  Badge,
  Button,
  Card,
  Divider,
  Label,
  Modal,
  useToast,
} from "@btdigital/nayan-component-library";

import {
  selectPortClass,
  selectPortDiversity,
  selectPortOnlyState,
  selectPortStatus,
  updateDiversityTransition,
  updateHasports,
  updateIsDeploymentRequestEnabled,
  updatePortId,
  updateStep,
  updateIsUpdateRequestEnabled,
  selectCountryValue
} from "../../../../redux/portOnlySlice";
import {
  errorToast,
  errorToastOptions,
} from "../../../../shared/constants/errorToast";
import { useApi } from "../../../../shared/helpers/api";
import { IPortPriceResponse } from "../../../../shared/models";
import {
  IPortPricingRequest,
  PortDiversityType,
  PortResilienceType,
  PRODUCT,
} from "../../../../shared/types";
import { BT_NOTIFICATIONS } from "../../../../shared/constants";

import { buildNotification } from "../../../../shared/constants/toastBuilder";
import useLocalStorage from "../../../../shared/hooks/useLocalStorage";
import { portToPortPricingRequestDTO } from "../../../../shared/mappers/services/port.service";
import PortAModifyHeader from "../ModifyJourney/PortA/PortAModifyHeader";
import {
  _advancedSetting,
  _summaryDetails,
  defaultPricingItem,
} from "./components/SummaryUtils/SummaryUtils";
import BillingAccount from "../../../../components/BillingAccount";
import TagDataLayerService from "../../../../shared/services/TagDatalayer.service";
import GFTerms from "../../../../components/GFTerms";
import GFLoader from "../../../../components/GFLoader";
import TextLoader from "../../../../components/TextLoader";
import { selectUserProfile } from "../../../../redux/userProfileSlice";
import { formatCurrency } from "../../../../shared/utils";
import { BillingAccount as BillingAccountDTO } from "../../../../shared/mappers/classes/dto/billingAccount.dto";
import { updateSelectedBillingAccount } from "../../../../redux/billingAccountsSlice";

import "./Summary.scss";

export type PortType = "primary" | "secondary";

const Summary = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const toast = useToast();
  const api = useApi();

  const {
    resilience,
    standardItem,
    diverseItem,
    portLocation,
    isInModifyPortMode,
    diversityTransition,
    portId,
    standardItemOriginal,
    diverseItemOriginal
  } = useSelector(selectPortOnlyState);

  const _portDiversity = useSelector(selectPortDiversity);

  const [_showAdvancedSettings, setShowAdvancedSettings] = useState({
    standardItem: false,
    primaryItem: false,
    secondaryItem: false,
  });
  const [showLoader, setShowLoader] = useState(true);
  const [_oneTimePrice, setOneTimePrice] = useState<number>(0);
  const [_recurringMonthlyPrice, setRecurringMonthlyPrice] =
    useState<number>(0);

  const [_billingAccounts, setBillingAccounts] = useState<BillingAccountDTO[]>();
  const [_selectedBillingAccount, setSelectedBillingAccount] =
    useState<BillingAccountDTO>();

  const [notificationStorage, setNotificationStorage] = useLocalStorage(
    BT_NOTIFICATIONS,
    []
  );

  const _portStatus = useSelector(selectPortStatus);
  const _portClass = useSelector(selectPortClass);
  const [_showModal, setShowModal] = React.useState(false);
  const [isCheckboxChecked, setIsCheckboxChecked] = useState(false);

  const handleCheckboxChange = () => {
    setIsCheckboxChecked(true);
  };

  const _deployPort = () => {
    if (isCheckboxChecked) {
      dispatch(updateHasports(true));
      dispatch(updateIsDeploymentRequestEnabled(true));
      TagDataLayerService.pushCtaData("Deploy");
      navigate("/port-a-deployment", {
        state: {
          isDeployAllRequest: false,
          oneTimePrice: _oneTimePrice,
          recurringPrice: _recurringMonthlyPrice,
        },
      });
    }
  };

  const mapPricingData = () => portToPortPricingRequestDTO(_portClass);
  const [isLoadingPricingApi, setIsLoadingPricingApi] = useState(false);
  const currentUserProfile = useSelector(selectUserProfile);
  const _countryValue = useSelector(selectCountryValue);

  const _onSelectBillingAccount = (accountId: string) => {
    const selectedBillingAcc = _billingAccounts?.find(acc => acc.id === accountId);
    if (selectedBillingAcc) {
      setSelectedBillingAccount(selectedBillingAcc);
    }
  };

  useEffect(() => {
    if (_countryValue) {
      api
        .getBillingAccounts(_countryValue, PRODUCT.port)
        .then((response) => {
          const billingAccountDefault = response.billingAccounts.find(
            (acc) => acc.default
          );
          setBillingAccounts(response.billingAccounts);
          if (
            billingAccountDefault &&
            billingAccountDefault.id ===
              currentUserProfile.currentUser.defaultBillingAccount
          ) {
            setSelectedBillingAccount(billingAccountDefault);
          }
        })
        .catch((Error) => console.log({ Error }));
    }
  }, [api, _countryValue, currentUserProfile]);

  useEffect(() => {
    const billingId = _selectedBillingAccount?.id;
    if (!isInModifyPortMode && billingId) {
      dispatch(
        updateSelectedBillingAccount({
          billingAccountId: _selectedBillingAccount?.id,
          currencyFormat: _selectedBillingAccount?.currency,
        })
      );
      setIsLoadingPricingApi(true);
      const isStandard = resilience === PortResilienceType.standard;
      const requestPayload: IPortPricingRequest = mapPricingData();
      const requestPayloadFormatted = {
        ...requestPayload,
        billingAccountId: billingId,
        currencyFormat: currentUserProfile.currentUser.defaultCurrencyCode,
      };
      api
        .getPortAPricing(requestPayloadFormatted)
        .then((response: IPortPriceResponse) => {
          setShowLoader(false);
          const primaryPortPrice =
            response.primaryPortPrice || defaultPricingItem;
          const secondaryPortPrice =
            response.secondaryPortPrice || defaultPricingItem;
          const { oneTimePrice, recurringMonthlyPrice } = primaryPortPrice;
          const {
            oneTimePrice: secondaryOneTimePrice,
            recurringMonthlyPrice: secondaryMonthlyPrice,
          } = secondaryPortPrice;
          const totalOneTimePrice =
            oneTimePrice + (!isStandard ? secondaryOneTimePrice : 0);
          const totalRecurringMonthlyPrice =
            recurringMonthlyPrice + (!isStandard ? secondaryMonthlyPrice : 0);
          setOneTimePrice(totalOneTimePrice);
          setRecurringMonthlyPrice(totalRecurringMonthlyPrice);
          setIsLoadingPricingApi(false);
        })
        .catch((error) => {
          const pricingErrorNotification = buildNotification(
            errorToast,
            "Port"
          );
          TagDataLayerService.pushErrorData(error, "API");
          toast.addToast(pricingErrorNotification.view(), {
            ...errorToastOptions,
            deleteSideEffect: () => {
              pricingErrorNotification.save({
                notificationStorage,
                setNotificationStorage,
              });
            },
          });
          setIsLoadingPricingApi(false);
        });
    } else {
      setShowLoader(false);
    }
  }, [_selectedBillingAccount, isInModifyPortMode]);

  const _advancedSettingsButton = (key: string, value: boolean) => {
    return (
      <Button
        className="advanced_settings"
        iconSize="sm"
        iconTitle={value ? "chevron_down_2px" : "chevron_up_2px"}
        label="Advanced Settings"
        onPress={() =>
          setShowAdvancedSettings({
            ..._showAdvancedSettings,
            [key]: value,
          })
        }
        variant="link"
        dataTestId="advanced_settings_btn"
      />
    );
  };

  const _onEdit = () => {
    TagDataLayerService.pushCtaData("Edit");
    TagDataLayerService.pushPageData("Create PortOnly", "Diversity");
    dispatch(updateStep(2));
    dispatch(updatePortId(portId!));
    navigate("/create-port-only");
  };

  const __updatePort = () => {
    dispatch(updateIsUpdateRequestEnabled(true))
    dispatch(updateDiversityTransition(""));
    TagDataLayerService.pushCtaData("Update");
    TagDataLayerService.pushPageData("Modify PortOnly", "Deployment");
    setTimeout(() => {
      navigate("/port-a-modify-deployment", {
        state: {
          isDeployAllRequest: false,
          oneTimePrice: _oneTimePrice,
          recurringPrice: _recurringMonthlyPrice,
        },
      });
      dispatch(updateStep(1));
    }, 200);
  };

  const getModifyPortName = () => {
    if (_portDiversity === PortDiversityType.StandardSinglePop) {
      return standardItem?.port_name;
    } else {
      return diverseItem?.primaryItem.port_name;
    }
  };

  const _onModalOk = () => {
    setShowModal(false);
    navigate("/port-inventory");
  };

  React.useEffect(() => {
    TagDataLayerService.pushPageData("Create Port Only", "Summary");
  }, []);

  return (
    <section
      className="standard_container summary_container-port-a"
      data-testid="summary_standard"
    >
      <main className="standard_content summary_content">
        {showLoader ? (
          <GFLoader />
        ) : (
          <>
            <div>
              <div className="fp-row">
                <div className="col-16 xl:col-8 sm:col-16 md:col-8">
                  {isInModifyPortMode && (
                    <PortAModifyHeader
                      title={getModifyPortName()}
                      statusText={_portStatus}
                    />
                  )}
                </div>
              </div>
              <div className="fp-row">
                <div className="col-16 xl:col-8 sm:col-16 md:col-8 sm:mb-16">
                  <Card width="100%" height="100%">
                    <div className="summary_alignment card_header">
                      <h2 className="title">Summary</h2>
                      <Button
                        onPress={_onEdit}
                        label="Edit"
                        variant="link"
                        className="edit_button summary_btn"
                        dataTestId="edit_btn"
                      />
                    </div>
                    <Divider margin="xl" className="divider" />
                    <section className="summary_body">
                      <div className="summary_alignment">
                        <Label
                          text="Port"
                          size="sm"
                          labelTextStyles="summary_subtitle"
                        />
                        <Badge
                          text={standardItem ? "Non Diverse" : "Diverse"}
                          customStyle="complete-badge"
                        />
                      </div>
                      <div className="summary_alignment">
                        <label className="summary_text_key">Name</label>
                        <label className="summary_text_value">
                          {standardItem?.port_name ||
                            diverseItem?.primaryItem.port_name}
                        </label>
                      </div>
                      {standardItem ? (
                        <>
                          {_summaryDetails(
                            portLocation,
                            standardItem,
                            PortResilienceType.standard
                          )}
                          {_advancedSettingsButton(
                            "standardItem",
                            !_showAdvancedSettings.standardItem
                          )}
                          {_showAdvancedSettings.standardItem &&
                            _advancedSetting(
                              standardItem,
                              PortResilienceType.standard,
                              "primary",
                              standardItemOriginal
                            )}
                        </>
                      ) : (
                        diverseItem && (
                          <>
                            {_summaryDetails(
                              portLocation,
                              diverseItem.primaryItem,
                              PortResilienceType.diverse,
                              "primary"
                            )}
                            {_advancedSettingsButton(
                              "primaryItem",
                              !_showAdvancedSettings.primaryItem
                            )}
                            {_showAdvancedSettings.primaryItem &&
                              _advancedSetting(
                                diverseItem.primaryItem,
                                PortResilienceType.diverse,
                                "primary",
                                diverseItemOriginal?.primaryItem
                              )}
                            {_summaryDetails(
                              portLocation,
                              diverseItem.secondaryItem,
                              PortResilienceType.diverse,
                              "secondary",
                            )}
                            {_advancedSettingsButton(
                              "secondaryItem",
                              !_showAdvancedSettings.secondaryItem
                            )}
                            {_showAdvancedSettings.secondaryItem &&
                              _advancedSetting(
                                diverseItem.secondaryItem,
                                PortResilienceType.diverse,
                                "secondary",
                                diverseItemOriginal?.secondaryItem,
                              )}
                          </>
                        )
                      )}
                    </section>
                  </Card>
                </div>
                <div className="col-16 xl:col-8 sm:col-16 md:col-8 sm:mb-16 price-card">
                  <Card width="100%" height="100%">
                    <div className="summary_alignment card_header">
                      <h2 className="title">Price</h2>
                      <span className="item_number">1 item</span>
                    </div>
                    <Divider margin="xl" className="divider" />
                    <section className="summary_body">
                      {!isInModifyPortMode && (
                        <BillingAccount
                          billingAccounts={_billingAccounts}
                          selectedBillingAccount={_selectedBillingAccount}
                          onSelectBilling={_onSelectBillingAccount}
                        />
                      )}
                      <span className="sub-title-label-wrp">
                        <Label text="Port" size="sm" />
                      </span>
                      <div className="summary_alignment price_item">
                        <label className="summary_text_value price_text_key">
                          {standardItem ? (
                            standardItem?.port_name
                          ) : (
                            <div>
                              <label>
                                [Primary] - {diverseItem?.primaryItem.port_name}
                              </label>
                              <label>
                                [Secondary] -{" "}
                                {diverseItem?.secondaryItem.port_name}
                              </label>
                            </div>
                          )}
                        </label>
                        <label className="price_text_value">
                          {!isLoadingPricingApi ? (
                            <>
                              {`${formatCurrency(_recurringMonthlyPrice, currentUserProfile.currentUser.defaultCurrencyCode)}`}
                              <span className="price_text_unit">/month</span>
                            </>
                          ) : (
                            <TextLoader />
                          )}
                        </label>
                      </div>
                      <span className="sub-title-label-wrp subtotal">
                        <Label text="Subtotal" size="sm" />
                      </span>
                      <div className="summary_alignment">
                        <label className="summary_text_value price_text_key">
                          Recurring (MRC)
                        </label>
                        <label className="price_text_value total">
                          {!isLoadingPricingApi ? (
                            `${formatCurrency(_recurringMonthlyPrice, currentUserProfile.currentUser.defaultCurrencyCode)}/month`
                          ) : (
                            <TextLoader />
                          )}
                        </label>
                      </div>
                      <div className="summary_alignment">
                        <label className="summary_text_value price_text_key">
                          Non - Recurring (NRC)
                        </label>
                        <label className="price_text_value total">
                          {" "}
                          {!isLoadingPricingApi ? (
                            `${formatCurrency(_oneTimePrice, currentUserProfile.currentUser.defaultCurrencyCode)}`
                          ) : (
                            <TextLoader />
                          )}
                        </label>
                      </div>
                      {isInModifyPortMode && diversityTransition === "" && 
                        (<div className="total-info">Your total amount has not been affected</div>)
                      }

                      <GFTerms onAccepted={handleCheckboxChange} />
                      <div className="summary_alignment">
                        {isInModifyPortMode ? (
                          <>
                            <Button
                              label="Cancel"
                              onPress={() => setShowModal(true)}
                              variant="outline"
                              fullWidth
                              size="large"
                              className="summary_btn"
                              dataTestId="deploy_btn"
                            />
                            <Button
                              label="Update"
                              onPress={__updatePort}
                              variant="gradient"
                              fullWidth
                              size="large"
                              className="deploy_btn summary_btn"
                              dataTestId="add_to_basket_btn"
                              disabled={!isCheckboxChecked}
                            />
                          </>
                        ) : (
                          <>
                            <Button
                              label="Order"
                              primaryBadgeVariant="disabled"
                              onPress={_deployPort}
                              variant="gradient"
                              fullWidth
                              size="large"
                              className={`deploy_btn summary_btn ${
                                isCheckboxChecked ? "" : "btn-disabled"
                              }`}
                              dataTestId="deploy_btn"
                              disabled={!isCheckboxChecked}
                            />
                          </>
                        )}
                      </div>
                    </section>
                  </Card>
                </div>
              </div>
            </div>
          </>
        )}
      </main>
      <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        topIconSize="md"
        title="Leave without saving changes"
        complementaryMessage="Are you sure you want to leave this page? Your setup information will be lost."
        contentAlign="center"
        actionText="Leave"
        onOk={_onModalOk}
        closeModal={!_showModal}
        onCancel={() => setShowModal(false)}
        outsideClose={true}
      />
    </section>
  );
};

export default Summary;
