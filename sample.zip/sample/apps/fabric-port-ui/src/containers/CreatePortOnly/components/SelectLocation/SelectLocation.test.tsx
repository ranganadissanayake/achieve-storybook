import React from "react";
import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";
import { render } from "@testing-library/react";

import store from "../../../../redux/store";
import SelectLocation from "./index";
import { ApiProvider } from "../../../../shared/helpers/api";
import "regenerator-runtime";

jest.mock("@btdigital/nayan-component-library", () => ({
  ...jest.requireActual("@btdigital/nayan-component-library"),
  Map: () => <div data-testid="map-component" />,
}));

describe("SelectLocation", () => {
  test("renders the SelectLocation component", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider>
            <SelectLocation />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );
  });
});
