import { Button, ErrorMessage } from "@btdigital/nayan-component-library";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  selectPortDiversity,
  updatePortDiversity,
  updateResilienceType,
  updateStandardItem,
  updateStep,
} from "../../../../redux/portOnlySlice";
import {
  PortDiversityType,
  PortResilienceType,
} from "../../../../shared/types/index";
import TitleBar from "../../../../components/TitleBar";
import images from "./../../../../shared/assets";
import PortDiversityCard from "./PortDiversityCard";
import PageWrap from "../../../../components/PageWrap";
import TagDataLayerService from "./../../../../shared/services/TagDatalayer.service";

import "./PortDiversity.scss";

const PortDiversity = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const _portDiversity = useSelector(selectPortDiversity);

  const [_resilience, setResilience] = React.useState(_portDiversity ?? "");

  const [_showErrorMessage, setShowErrorMessage] = React.useState(false);

  const _onOptionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setResilience(e.target.value as PortDiversityType);
    setShowErrorMessage(false);
  };

  const _onContinue = () => {
    const hasAnyDiverseTypeSelected = _resilience !== "";
    setShowErrorMessage(!hasAnyDiverseTypeSelected);
    if (hasAnyDiverseTypeSelected) {
      dispatch(updateStep(1));
      dispatch(updatePortDiversity(_resilience));
      dispatch(
        updateResilienceType(
          _resilience === "standard-single-pop"
            ? PortResilienceType.standard
            : PortResilienceType.diverse,
        ),
      );
      TagDataLayerService.pushCtaData("Continue");
      navigate("/create-port-only");
      if (_resilience !== _portDiversity) {
        dispatch(updateStandardItem(undefined))
      }
    }
  };

  const _onBack = () => {
    TagDataLayerService.pushCtaData("Back");
    dispatch(updatePortDiversity(""));
    navigate("/customer-ports");
  };

  return (
    <PageWrap
      className="port-diversity-selection"
      testId="port-diversity-selection"
    >
      <div className="port-diversity-selection__content">
        <TitleBar
          imageUrl={images.chooseYourPort}
          title="Port Diversity"
          subTitleContent={
            <p className="sub-title">
              Visit <span>Global Fabric Knowledge Hub</span> for more information on port connections.
            </p>
          }
        />
        <div
          className="port-diversity-selection__actions port-diversity-selection fp-row"
          data-testid="port-card-container"
        >
          <div className="col-16 xl:col-5 lg:col-5 sm:col-8 md:col-5 mb-16">
            <PortDiversityCard
              checked={_resilience === PortDiversityType.StandardSinglePop}
              onRadioButtonClick={_onOptionChange}
              radioButtonValue="standard-single-pop"
              imageUrl={images.standardSinglePop}
              cardLabel="Non-Diverse"
            />
          </div>
          <div className="col-16 xl:col-5 lg:col-5 sm:col-8 md:col-5 mb-16">
            <PortDiversityCard
              checked={_resilience === PortDiversityType.DiverseSinglePop}
              onRadioButtonClick={_onOptionChange}
              radioButtonValue="diverse-single-pop"
              imageUrl={images.diverseSinglePoP}
              cardLabel="Diverse — Same PoP"
            />
          </div>
          <div className="col-16 xl:col-5 lg:col-5 sm:col-8 md:col-5 mb-16">
            <PortDiversityCard
              checked={_resilience === PortDiversityType.DiverseDualPop}
              onRadioButtonClick={_onOptionChange}
              radioButtonValue="diverse-dual-pop"
              imageUrl={images.diverseDualPoP}
              cardLabel="Diverse — Dual PoP"
            />
          </div>
        </div>
        <div className="action-with-error-diversity fp-row">
          <div className="button-row col-16 xl:col-15 lg:col-15 md:col-15 mt-16">
            <Button
              label="Back"
              variant="link"
              dataTestId="back_btn"
              onPress={_onBack}
              className="back-button"
            />
            <Button
              label="Continue"
              variant="gradient"
              onPress={_onContinue}
              className="continue-button"
            />
          </div>
          <div className="error-row col-16 xl:col-15 lg:col-15 md:col-15">
            {_showErrorMessage && (
              <ErrorMessage
                message="Please choose Port Diversity first"
                showIcon={false}
                className="choose-port-error-message"
              />
            )}
          </div>
        </div>
      </div>
    </PageWrap>
  );
};

export default PortDiversity;
