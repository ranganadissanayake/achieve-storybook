import React from "react";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import * as router from "react-router"; 
import user from "@testing-library/user-event";

import { useApi } from "../../../../shared/helpers/api";
import { render, screen, fireEvent, act } from "@testing-library/react";
import { MAX_NUMBER_OF_CHARACTERS } from "../../../../shared/constants/common";
import store from "../../../../redux/store";
import ConfigDiverse from "./index";

const navigate = jest.fn();

jest.mock("../../../../shared/helpers/api", () => ({
  useApi: jest.fn(),
}));

afterEach(() => {
  jest.clearAllMocks(); // Clear all mock calls after each test
});

describe("Config Diverse", () => {
  beforeAll(() => {
    jest.spyOn(router, "useNavigate").mockImplementation(() => navigate);
  });

  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getPortAPricing: jest.fn().mockResolvedValue({
        primaryPortPrice: {
          oneTimePrice: 100,
          recurringMonthlyPrice: 200,
        },
        secondaryPortPrice: {
          oneTimePrice: 100,
          recurringMonthlyPrice: 200,
        },
      }),
    });
  });
  afterEach(() => {
    jest.clearAllMocks();
  });


  test("renders the Diverse Configuration component", async () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    expect(screen.getByTestId("config_diverse")).toBeInTheDocument();
  });

  test("renders the Diverse configuration main titles", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    expect(screen.getByText("Configure Port")).toBeInTheDocument();
    expect(screen.getByText("Port Setting")).toBeInTheDocument();
  });

  test("displays 'Back' and 'Continue' buttons", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    expect(screen.getByTestId("back_btn")).toBeInTheDocument();
    expect(screen.getByTestId("continue_btn")).toBeInTheDocument();
  });

  test("port interfaces are disabled by default", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    const [portInterfacePrimary, portInterfaceSecondary] = screen.getAllByPlaceholderText("Please select an interface");
    expect(portInterfacePrimary).toBeInTheDocument();
    expect(portInterfaceSecondary).toBeInTheDocument();
  });

  test("displays only one port name", async () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    const portNames = await screen.findAllByText("Diverse Port Name");
    expect(portNames).toHaveLength(1);
  });

  test("clicks the Back button", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    act(() => {
      const backButton = screen.getByTestId("back_btn");
      fireEvent.click(backButton);
    })

    expect(screen.getByText("Leave without saving changes")).toBeInTheDocument();
  });

  test("clicks the Leave button in the modal navigates to customer-ports", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    act(() => {
      const backButton = screen.getByTestId("back_btn");
      fireEvent.click(backButton);
    });

    act(() => {
      const leaveButton = screen.getByText("Leave");
      fireEvent.click(leaveButton);
    });

    setTimeout(() => {
      expect(window.location.pathname).toBe("/customer-ports");
    }, 500);
  });

  test("it should update the selected threshold on button click - primary low", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    act(() => {
      const bandwidthMonitoringToggle = screen.getByTestId("pri_bandwidth_monitoring_toggle");
      fireEvent.click(bandwidthMonitoringToggle);
    });
    act(() => {
      const input = screen.getByPlaceholderText("0 to 99%");
      fireEvent.click(input);
    });
    const option = screen.getByText("0%");
    act(() => {
      fireEvent.click(option);
    });
    expect(option).toBeInTheDocument();
  });

  test("it should update the selected threshold on button click - primary high", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    act(() => {
      const bandwidthMonitoringToggle = screen.getByTestId("pri_bandwidth_monitoring_toggle");
      fireEvent.click(bandwidthMonitoringToggle);
    });
    act(() => {
      const input = screen.getByPlaceholderText("0 to 99%");
      fireEvent.click(input);
    });
    const option = screen.getByText("100%");
    act(() => {
      fireEvent.click(option);
    });
    expect(option).toBeInTheDocument();
  });

  test("it should update the selected threshold on button click - secondary low", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    act(() => {
      const bandwidthMonitoringToggleSec = screen.getByTestId("sec_bandwidth_monitoring_toggle");
      fireEvent.click(bandwidthMonitoringToggleSec);
    });
    act(() => {
      const input = screen.getByPlaceholderText("0 to 99%");
      fireEvent.click(input);
    });
    const option = screen.getByText("0%");
    act(() => {
      fireEvent.click(option);
    });
    expect(option).toBeInTheDocument();
  });

  test("it should update the selected threshold on button click - secondary high", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    act(() => {
      const bandwidthMonitoringToggleSec = screen.getByTestId("sec_bandwidth_monitoring_toggle");
      fireEvent.click(bandwidthMonitoringToggleSec);
    });
    act(() => {
      const input = screen.getByPlaceholderText("0 to 99%");
      fireEvent.click(input);
    });
    const option = screen.getByText("100%");
    act(() => {
      fireEvent.click(option);
    });
    expect(option).toBeInTheDocument();
  });

  test("displays error message if port name is more than 30 characters", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    act(() => {
      const portName = screen.getByRole("textbox", { name: "Diverse Port Name" });
      user.click(portName);
      user.keyboard("Lorem ipsum dolor sit amet consectetur");
    });
    expect(screen.getByText(MAX_NUMBER_OF_CHARACTERS(30))).toBeInTheDocument();
  });

  test("displays error message if port description is more than 500 characters", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    act(() => {
      const [portDescPri, portDesSec] = screen.getAllByRole("textbox", { name: "Port Description (optional)" });
      user.click(portDescPri);
      user.keyboard("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ligula magna, hendrerit et turpis consequat, rutrum consectetur tortor. Nulla ut efficitur velit. Aliquam non tellus vel eros sollicitudin tristique a non elit. Cras dictum augue ut magna mollis, vitae rhoncus dui tristique. Morbi at sagittis nulla. Quisque neque sem, ullamcorper id odio bibendum, facilisis condimentum nisi. Cras viverra blandit dolor, eget tincidunt erat sodales id. Aenean ac est vel elit ultricies vehicula non vitae cuz");
      expect(screen.getByText(MAX_NUMBER_OF_CHARACTERS(500))).toBeInTheDocument();

      user.click(portDesSec);
      user.keyboard("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ligula magna, hendrerit et turpis consequat, rutrum consectetur tortor. Nulla ut efficitur velit. Aliquam non tellus vel eros sollicitudin tristique a non elit. Cras dictum augue ut magna mollis, vitae rhoncus dui tristique. Morbi at sagittis nulla. Quisque neque sem, ullamcorper id odio bibendum, facilisis condimentum nisi. Cras viverra blandit dolor, eget tincidunt erat sodales id. Aenean ac est vel elit ultricies vehicula non vitae cuz");
    });
    expect(screen.getAllByText(MAX_NUMBER_OF_CHARACTERS(500))).toHaveLength(2);
  });

  test("displays the telemetry streaming field", () => {
    render(
      <Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>,
    );

    expect(screen.getAllByText("Telemetry Streaming Enabled")).toHaveLength(2);
  });
});

describe('Config Diverse for each port speeds', () => {
  // Mock PORT_INTERFACE data
  const PORT_INTERFACE = [
    {
      port_speed: '1000',
      lag_ports: [1, 2, 3]
    },
    {
      port_speed: '10000',
      lag_ports: [4, 5, 6]
    }
  ];
  let useMemoMock: any;
  let useStateMock: any;

  beforeEach(() => {
    // Mock React useMemo
    useMemoMock = jest.spyOn(React, 'useMemo').mockImplementation((factory) => {
      return factory();
    });
    useStateMock = jest.spyOn(React, 'useState');
  });

  afterEach(() => {
    // Restore React useMemo
    useMemoMock.mockRestore();
    useStateMock.mockRestore();
  });

  it('renders lag options correctly for valid port speed', () => {
    useStateMock.mockReturnValueOnce([true, jest.fn()]);

    act(() => {
      render(<Provider store={store}>
        <Router>
          <ConfigDiverse />
        </Router>
      </Provider>);
    });

    const expectedOptions = PORT_INTERFACE[0].lag_ports.map(pi => ({ id: `${pi}`, value: `${pi}` }));
    expect (expectedOptions).toEqual([{id:'1', value:'1'}, {id:'2', value:'2'}, {id:'3', value:'3'}])
    expect(screen.getAllByText("Link Aggregation Group (LAG)")).toHaveLength(2);
  });

});
