import {
  PortLocation,
  PortOnlyItem,
  PortResilienceType,
} from "../../../../../../shared/types";
import {
  _advancedSetting,
  _summaryDetails,
  subRowsMapperDualtoDualPop,
  subRowsMapperSingletoDualPop,
  subRowsMapperStandardPop,
} from "./SummaryUtils";

describe("Summaryutils component", () => {
  test("_advancedSetting should return react node", () => {
    expect(
      _advancedSetting(
        {
          predictive_bandwidth: true,
          banwidth_monitoring: true,
          low_threshold: 0,
          high_threshold: 10,
        } as PortOnlyItem,
        PortResilienceType.diverse,
        "primary",
      ),
    ).toBeTruthy();
  });

  test("_advancedSetting should return react node with previous values and new values", () => {
    expect(
      _advancedSetting(
        {
          predictive_bandwidth: true,
          banwidth_monitoring: true,
          low_threshold: 0,
          high_threshold: 10,
        } as PortOnlyItem,
        PortResilienceType.diverse,
        "primary",
        {
          predictive_bandwidth: true,
          banwidth_monitoring: true,
          low_threshold: 5,
          high_threshold: 20,
        } as PortOnlyItem,
      ),
    ).toBeTruthy();
  });

  test("_summaryDetails should return react node", () => {
    expect(
      _summaryDetails(
        {
          primaryLocationDisplayLabel: "test1",
          secondaryLocationDisplayLabel: "test2",
        } as PortLocation,
        {
          port_speed: "100 Gbps",
        } as PortOnlyItem,
        PortResilienceType.diverse,
        "primary",
      ),
    ).toBeTruthy();
  });
});
describe("subRowsMapperStandardPop", () => {
  it("should return the mapped object with correct properties", () => {
    const item = { someProperty: "someValue" };
    const diverseItem = {
      banwidth_monitoring: true,
      enable_oversubscription: false,
      predictive_bandwidth: true,
      lag: false,
      number_of_lag_ports: 2,
      mtu_size: 1500,
      port_description: "Description",
      low_threshold: 10,
      high_threshold: 20,
    };

    const result = subRowsMapperStandardPop(item, diverseItem);

    expect(result).toEqual({
      ...item,
      isBandwidthUtilisationMonitoring: true,
      isEnableOversubscription: false,
      isPredictiveBandwidthOptimisation: true,
      isLag: false,
      lagPortsCount: 2,
      mtuSize: 1500,
      description: "Description",
      lowThreshold: 10,
      highThreshold: 20,
    });
  });
});

describe("subRowsMapperSingletoDualPop", () => {
  it("should map the provided data to the expected output object", () => {
    const _portDiversity = "TestDiversity";
    const portLocation = {
      countryName: "TestCountry",
      countryIsoCode: "TestISO",
      primaryLocationDisplayLabel: "PrimaryLocation",
      primaryPort: "PrimaryPort",
    };
    const diverseItem = {
      port_id: "TestPortId",
      port_speed: "10 Gbps",
      banwidth_monitoring: true,
      enable_oversubscription: false,
      predictive_bandwidth: true,
      lag: false,
      number_of_lag_ports: 0,
      mtu_size: 1500,
      port_description: "TestPortDescription",
      low_threshold: 20,
      high_threshold: 80,
    };

    const result = subRowsMapperSingletoDualPop(
      _portDiversity,
      portLocation,
      diverseItem,
    );

    const expectedOutput = {
      portId: "TestPortId",
      country: "TestCountry",
      countryISOCode: "TestISO",
      portSpeed: "10 Gbps",
      location: "PrimaryLocation",
      isBandwidthUtilisationMonitoring: true,
      isEnableOversubscription: false,
      isPredictiveBandwidthOptimisation: true,
      isLag: false,
      lagPortsCount: 0,
      mtuSize: 1500,
      portDescription: "TestPortDescription",
      portLocationId: "PrimaryPort",
      portName: undefined,
      portDiversity: "TestDiversity",
      description: "TestPortDescription",
      lowThreshold: 20,
      highThreshold: 80,
      isSubRow: true,
      isDiverse: true,
    };

    expect(result).toEqual(expectedOutput);
  });
});

describe("subRowsMapperDualtoDualPop", () => {
  it("should map the provided data to the expected output object", () => {
    const item = {
      itemId: "TestItemId",
      itemName: "TestItemName",
    };
    const _portDiversity = "TestDiversity";
    const portLocation = {
      countryName: "TestCountry",
      countryIsoCode: "TestISO",
      primaryLocationDisplayLabel: "PrimaryLocation",
      primaryPort: "PrimaryPort",
    };
    const diverseItem = {
      port_id: "TestPortId",
      port_speed: "10 Gbps",
      banwidth_monitoring: true,
      enable_oversubscription: false,
      predictive_bandwidth: true,
      lag: false,
      number_of_lag_ports: 0,
      mtu_size: 1500,
      port_description: "TestPortDescription",
      low_threshold: 20,
      high_threshold: 80,
    };

    const result = subRowsMapperDualtoDualPop(
      item,
      _portDiversity,
      portLocation,
      diverseItem,
    );

    const expectedOutput = {
      itemId: "TestItemId",
      itemName: "TestItemName",
      portId: "TestPortId",
      country: "TestCountry",
      countryISOCode: "TestISO",
      portSpeed: "10 Gbps",
      location: "PrimaryLocation",
      isBandwidthUtilisationMonitoring: true,
      isEnableOversubscription: false,
      isPredictiveBandwidthOptimisation: true,
      isLag: false,
      lagPortsCount: 0,
      mtuSize: 1500,
      portLocationId: "PrimaryPort",
      portName: undefined,
      portDescription: "TestPortDescription",
      portDiversity: "TestDiversity",
      description: "TestPortDescription",
      lowThreshold: 20,
      highThreshold: 80,
    };

    expect(result).toEqual(expectedOutput);
  });
});
