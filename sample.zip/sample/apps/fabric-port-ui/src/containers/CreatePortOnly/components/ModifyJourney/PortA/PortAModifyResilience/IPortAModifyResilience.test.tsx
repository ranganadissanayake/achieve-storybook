import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import PortAModifyResilience from "./index";

describe("PortAModifyResilience", () => {
  const onChangeDiversityMock = jest.fn();

  beforeEach(() => {
    onChangeDiversityMock.mockClear();
  });

  it("renders without errors", () => {
    render(
      <PortAModifyResilience
        isNonDiverse={false}
        isDiverseSingle={false}
        isDiverseDual={false}
        isModify={false}
        onChangeDiversity={onChangeDiversityMock}
      />,
    );
  });

  it("displays the main title correctly", () => {
    render(
      <PortAModifyResilience
        isNonDiverse={false}
        isDiverseSingle={false}
        isDiverseDual={false}
        isModify={false}
        onChangeDiversity={onChangeDiversityMock}
      />,
    );
    const mainTitle = screen.getByText("Port Resilience");
    expect(mainTitle).toBeInTheDocument();
  });

  it("calls onChangeDiversity function with correct value when 'Non-Diverse' button is clicked", () => {
    render(
      <PortAModifyResilience
        isNonDiverse={true}
        isDiverseSingle={false}
        isDiverseDual={false}
        isModify={false}
        onChangeDiversity={onChangeDiversityMock}
      />,
    );

    const nonDiverseButton = screen.getByText("Non-Diverse");
    fireEvent.click(nonDiverseButton);

    expect(onChangeDiversityMock).toHaveBeenCalledTimes(1);
    expect(onChangeDiversityMock).toHaveBeenCalledWith("standard-single-pop");
  });

  it("calls onChangeDiversity function with correct value when 'Diverse-Single PoP' button is clicked", () => {
    render(
      <PortAModifyResilience
        isNonDiverse={false}
        isDiverseSingle={true}
        isDiverseDual={false}
        isModify={false}
        onChangeDiversity={onChangeDiversityMock}
      />,
    );

    const diverseSingleButton = screen.getByText("Diverse-Single PoP");
    fireEvent.click(diverseSingleButton);

    expect(onChangeDiversityMock).toHaveBeenCalledTimes(1);
    expect(onChangeDiversityMock).toHaveBeenCalledWith("diverse-single-pop");
  });

  it("calls onChangeDiversity function with correct value when 'Diverse-Dual PoP' button is clicked", () => {
    render(
      <PortAModifyResilience
        isNonDiverse={false}
        isDiverseSingle={false}
        isDiverseDual={true}
        isModify={false}
        onChangeDiversity={onChangeDiversityMock}
      />,
    );

    const diverseDualButton = screen.getByText("Diverse-Dual PoP");
    fireEvent.click(diverseDualButton);

    expect(onChangeDiversityMock).toHaveBeenCalledTimes(1);
    expect(onChangeDiversityMock).toHaveBeenCalledWith("diverse-dual-pop");
  });

  it("renders without errors whi isModify is true", () => {
    render(
      <PortAModifyResilience
        isNonDiverse={false}
        isDiverseSingle={false}
        isDiverseDual={false}
        isModify={false}
        onChangeDiversity={onChangeDiversityMock}
      />,
    );
  });
});
