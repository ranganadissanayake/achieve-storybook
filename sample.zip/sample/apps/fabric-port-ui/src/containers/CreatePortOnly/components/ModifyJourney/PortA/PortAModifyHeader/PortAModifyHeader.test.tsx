import React from "react";

import { render } from "@testing-library/react";

import PortAModifyHeader from "./index";

describe("PortAModifyHeader", () => {
  it("should render the component with title and statusText", () => {
    const title = "Sample Title";

    const statusText = "Sample Status";

    const { getByTestId, getByText } = render(
      <PortAModifyHeader title={title} statusText={statusText} />,
    );

    const headerWrapper = getByTestId("header-wrapper");

    const titleElement = getByText(title);

    const statusLabel = getByText(statusText);

    expect(headerWrapper).toBeInTheDocument();

    expect(titleElement).toBeInTheDocument();

    expect(statusLabel).toBeInTheDocument();
  });

  it("should render the component with title only", () => {
    const title = "Sample Title";

    const { getByTestId, getByText, queryByText } = render(
      <PortAModifyHeader title={title} />,
    );

    const headerWrapper = getByTestId("header-wrapper");

    const titleElement = getByText(title);

    const statusLabel = queryByText("Sample Status");

    expect(headerWrapper).toBeInTheDocument();

    expect(titleElement).toBeInTheDocument();

    expect(statusLabel).toBeNull();
  });

  it("should render the component with statusText only", () => {
    const statusText = "Sample Status";

    const { getByTestId, getByText, queryByText } = render(
      <PortAModifyHeader statusText={statusText} />,
    );

    const headerWrapper = getByTestId("header-wrapper");

    const titleElement = queryByText("Sample Title");

    const statusLabel = getByText(statusText);

    expect(headerWrapper).toBeInTheDocument();

    expect(titleElement).toBeNull();

    expect(statusLabel).toBeInTheDocument();
  });

  it("should render the component without title and statusText", () => {
    const { getByTestId, queryByText } = render(<PortAModifyHeader />);

    const headerWrapper = getByTestId("header-wrapper");

    const titleElement = queryByText("Sample Title");

    const statusLabel = queryByText("Sample Status");

    expect(headerWrapper).toBeInTheDocument();

    expect(titleElement).toBeNull();

    expect(statusLabel).toBeNull();
  });
});
