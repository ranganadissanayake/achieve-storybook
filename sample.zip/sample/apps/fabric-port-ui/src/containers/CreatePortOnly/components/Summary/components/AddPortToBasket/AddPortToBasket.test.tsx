import { fireEvent, render } from "@testing-library/react";
import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import PortAddedToBasket from ".";
import * as router from 'react-router';

const navigateSpy = jest.fn()

describe("AddPortToBasket", () => {

    beforeEach(() => {
        jest.spyOn(router, 'useNavigate').mockImplementation(() => navigateSpy)
    });

    afterAll(() => {
        jest.clearAllMocks();
    })

    test("should render properly", () => {
        const { getByTestId } = render(
            <Router>
                <PortAddedToBasket />
            </Router>
        );
        expect(getByTestId("deploy_to_basket")).toBeInTheDocument();
    })

    test("should navigate to basket page on click on View in Basket", () => {
        const { getByTestId } = render(
            <Router>
                <PortAddedToBasket />
            </Router>
        );
        fireEvent.click(getByTestId("view_in_basket_btn"));
        expect(navigateSpy).toHaveBeenCalledWith('/basket');
    })
})