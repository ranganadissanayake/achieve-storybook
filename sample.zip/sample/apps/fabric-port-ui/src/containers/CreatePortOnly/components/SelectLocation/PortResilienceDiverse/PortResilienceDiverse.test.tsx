import React from "react";
import { render, screen } from "@testing-library/react";

import PortResilienceDiverse from "./index";

describe("PortResilienceDiverse", () => {
  test("renders the PortResilienceDiverse component", () => {
    render(<PortResilienceDiverse onClickAction={jest.fn()} />);
    expect(screen.getByTestId("port-res-wrapper")).toBeInTheDocument();
  });
  test("calls onClickAction with 'standard' when Standard button is clicked", () => {
    const onClickActionMock = jest.fn();
    render(<PortResilienceDiverse onClickAction={onClickActionMock} />);
    const standardButton = screen.getByText("Standard");
    standardButton.click();
    expect(onClickActionMock).toHaveBeenCalledWith("standard");
  });
});
