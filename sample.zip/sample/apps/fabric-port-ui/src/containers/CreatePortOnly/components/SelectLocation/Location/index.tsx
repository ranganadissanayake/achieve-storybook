import React, { useState } from "react";

import { useDispatch, useSelector } from "react-redux";
import { isEmpty, sortBy } from "lodash";
import {
  Card,
  Label,
  DropdownInput,
  useToast,
} from "@btdigital/nayan-component-library";

import { useApi } from "../../../../../shared/helpers/api";
import {
  updatePortLocation,
  selectPortLocation,
  updatePrimaryPortSpeed,
  selectPortDiversity,
  updateSecondaryPortSpeed,
  selectIsInModifyPortMode,
  selectDiversityTransition,
  selectCountryCheck,
  selectLocationCheck,
  updateLocationValue,
  updateCountryValue,
  updateLocationCheck,
  updateCountryCheck,
} from "../../../../../redux/portOnlySlice";
import { IBTSite } from "../../../../../shared/models";
import {
  errorToast,
  errorToastOptions,
} from "../../../../../shared/constants/errorToast";
import "./Location.scss";
import { PortDiversityType } from "../../../../../shared/types";
import {
  BT_NOTIFICATIONS,
  initialSiteState,
} from "../../../../../shared/constants";
import { buildNotification } from "../../../../../shared/constants/toastBuilder";
import useLocalStorage from "../../../../../shared/hooks/useLocalStorage";
import { getBtSitesRequestDTO } from "../../../../../shared/mappers/services/port.service";
import { JOURNEY_TYPE } from "../../../../../shared/helpers/enumsCommon";
import Tooltip from "../../../../../components/TooltipV2";
import { FlagMap } from "../../../../../shared/assets/images/flags";
import { ProviderMap } from "../../../../../shared/assets/images/providers";
import loadingSpinner from '../../../../../shared/assets/gifs/loading-spinner-black-20.gif';
import {
  getMapItems,
  mapConstants,
} from "../../../../../containers/PortConnectivity/components/SelectPortBLocation";
import { selectGeoLocation } from "../../../../../redux/geoLocationSlice";
export interface LocationProps {
  countryList: any;
  onLocationUpdate: () => void;
  onPressNext?: () => void;
  onSetMapData?: (data: any) => void;
  onSetMapPropsData?: (data: any) => void;
}

export interface Option {
  id: string;
  value: string;
  name?: React.JSX.Element;
}

const Location: React.FC<LocationProps> = ({
  countryList,
  onLocationUpdate,
  onPressNext,
  onSetMapData,
  onSetMapPropsData,
}) => {
  const dispatch = useDispatch();

  // custom hook for api calls
  const api = useApi();
  const toast = useToast();

  const geolocations = useSelector(selectGeoLocation);
  const _portLocation = useSelector(selectPortLocation);
  const [country, setCountry] = useState<string>(
    _portLocation.countryIsoCode ?? ""
  );
  const _countryCheck = useSelector(selectCountryCheck);
  const _locationCheck = useSelector(selectLocationCheck);
  const [port, setPort] = useState<string>(_portLocation.primaryPort ?? "");
  const [locationOptions, setlocationOptions] = useState<Option[]>([
    { id: "", value: "" },
  ]);
  const [locationDetail, setlocationDetails] = useState<IBTSite[]>();
  const [btSiteError, setBtSiteError] = useState(false);
  const [isCountrySelected, setIsCountrySelected] = useState<boolean>(
    !isEmpty(country)
  );
  const [error, setError] = useState({ portLocation: "" });
  const [errorCountry, setErrorCountry] = useState({ portCountry: "" });
  const [notificationStorage, setNotificationStorage] = useLocalStorage(
    BT_NOTIFICATIONS,
    []
    );
  const [isPortLocationLoading, setIsPortLocationLoading] = useState(false);
  const _portDiversity = useSelector(selectPortDiversity);
  const _isInModifyPortMode = useSelector(selectIsInModifyPortMode);
  const _portDiversityTransition = useSelector(selectDiversityTransition);

  React.useEffect(() => {
    if (port) {
      onSetMapData &&
        onSetMapData({
          ...mapConstants.facility,
        });

      const locationDetails = locationDetail?.find((subItem) => {
        return subItem.siteId === port;
      }) as IBTSite;

      if (locationDetails) {
        const {
          country,
          latitude,
          longitude,
          city,
          siteAddressLine1,
          siteAddressLine2,
        } = locationDetails.facilityAddress;

        onSetMapPropsData &&
          onSetMapPropsData({
            data: [
              {
                label: city,
                position: { lat: latitude, lng: longitude },
                type: "city",
              },
              getMapItems({
                siteId: locationDetails?.siteId,
                latitude: latitude,
                longitude: longitude,
                facilityName: locationDetails?.facilityName,
                facilityProvider: locationDetails?.facilityProvider,
                addressLocation: `${siteAddressLine1}, ${siteAddressLine2}, ${city}, ${country}`,
              }),
            ],
          });
      }
    }
  }, [port]);

  React.useEffect(() => {
    if (isCountrySelected) {
      setIsPortLocationLoading(true);
      const locationListRes: {
        value: string;
        id: string;
        facilityProvider: string;
        name: React.JSX.Element;
      }[] = [];
      api
        .getBtSites(
          getBtSitesRequestDTO({
            ...initialSiteState,
            countryISOCode: country,
            siteType: JOURNEY_TYPE.PORT_A,
          })
        )
        .then((data) => {
          data?.forEach((item) => {
            locationListRes.push({
              id: item.siteId,
              facilityProvider: item.facilityProvider,
              value: `${item.facilityName} - ${item.facilityAddress.city},  ${item.facilityAddress.country}`,
              name: (
                <>
                  <div className="provider-option port-a-non-diverse">
                    <span className="facility-name">{item.facilityName}</span>
                    <span>
                      {item.facilityAddress.city.charAt(0).toUpperCase() +
                        item.facilityAddress.city.slice(1).toLowerCase()}
                      ,{item.facilityAddress.country}
                    </span>
                  </div>
                </>
              ),
            });
          });

          const locationDetails = data?.find((subItem) => {
            const countryName =
              geolocations.geoLocationDetails.find(
                (geolocation) => geolocation.countryISOCode === country
              )?.countryDisplayName || "";
            return (
              subItem.facilityAddress.country.toLowerCase() ===
              countryName.toLowerCase()
            );
          });

          setlocationOptions(locationListRes);
          setlocationDetails(data);
          setError({ portLocation: "" });
          setBtSiteError(false);
          onSetMapData && onSetMapData({ ...mapConstants.country });
          onSetMapPropsData &&
            onSetMapPropsData({
              focus: {
                lat: locationDetails?.facilityAddress.latitude || 0,
                lng: locationDetails?.facilityAddress.longitude || 0,
              },
            });
        })
        .catch(() => {
          const locationsErrorNotification = buildNotification(
            errorToast,
            "Port"
          );

          toast.addToast(locationsErrorNotification.view(), {
            ...errorToastOptions,
            deleteSideEffect: () => {
              locationsErrorNotification.save({
                notificationStorage,
                setNotificationStorage,
              });
            },
          });
          setlocationOptions([{ id: "", value: "" }]);
          setError({ portLocation: "Please select another country" });
          setBtSiteError(true);
        })
        .finally(()=>{
          setIsPortLocationLoading(false);
        });
    }
  }, [country]);

  const onSelectCountry = (countryData: string) => {
    if (countryData !== country) {
      dispatch(updateCountryValue(countryData));
      if (countryData) {
        dispatch(updateCountryCheck(false));
      }
      if (countryData !== "") {
        setCountry(countryData);
        setIsCountrySelected(true);
      }
      setPort("");
    }
    onLocationUpdate();
  };

  const filterSelectedLocation = (key: string, filterObj: any) => {
    return filterObj.find((x: { siteId: string }) => x.siteId === key);
  };

  const _onSetPort = (portData: string) => {
    dispatch(updateLocationValue(portData));
    setPort(portData);

    if (portData) {
      dispatch(updateLocationCheck(false));
    }

    if (locationDetail && port != "") {
      const filteredData: IBTSite = filterSelectedLocation(
        port,
        locationDetail
      );
      if (filteredData) {
        dispatch(
          updatePrimaryPortSpeed(
            filteredData?.products.customerPorts.portOnly ?? []
          )
        );
        if (_portDiversity === PortDiversityType.DiverseSinglePop) {
          dispatch(
            updateSecondaryPortSpeed(
              filteredData?.products.customerPorts.portOnly ?? []
            )
          );
        }
      }
    }
  };

  React.useEffect(() => {
    if (_isInModifyPortMode) {
      dispatch(updateCountryValue(country));
    }
  }, [_isInModifyPortMode]);

  React.useEffect(() => {
    if (country !== "" && port !== "") {
      const isDiverSinglePop =
        _portDiversity === PortDiversityType.DiverseSinglePop;
      const portLocation =
        locationOptions?.find((a: any) => a.id === port)?.value || "";
      const countryIsoCode = country;
      const countryName =
        countryList?.find((a: any) => a.id === country)?.value || "";

      if (country !== "" && port !== "") {
        onPressNext && onPressNext();
      }
      dispatch(
        updatePortLocation({
          countryIsoCode,
          countryName,
          primaryPort: port,
          primaryLocationDisplayLabel: portLocation,
          secondaryLocationDisplayLabel: isDiverSinglePop ? portLocation : "",
          secondaryPort: isDiverSinglePop ? port : "",
        })
      );
    }
  }, [port, country, locationOptions]);

  React.useEffect(() => {
    if (
      _portDiversityTransition === "diverse-dual-pop->standard-single-pop" ||
      _portDiversityTransition === "diverse-single-pop->standard-single-pop" ||
      _portDiversityTransition === "standard-single-pop->diverse-single-pop" ||
      _portDiversityTransition === "diverse-dual-pop->diverse-single-pop"
    ) {
      setCountry("");
      setPort("");
    }
  }, [_portDiversityTransition]);

  React.useEffect(() => {
    if (_locationCheck) {
      setError({ portLocation: "Please select a location" });
    }
    if (_countryCheck) {
      setErrorCountry({ portCountry: "Please select a country" });
    }
    if (btSiteError) {
      setErrorCountry({ portCountry: "Please select another country" });
    }
  }, [_locationCheck, _countryCheck, btSiteError]);

  const determineState = () => {
    return (!btSiteError) && ((country && !_isInModifyPortMode) ||(country && _isInModifyPortMode && _portDiversityTransition))
    ? (_locationCheck && !_isInModifyPortMode)
      ? "error"
      : isPortLocationLoading
      ? "loading"
      : "default"
    : "disabled"
  };

  return (
    <Card width="100%" data-testid="location-wrapper">
      <div className="card-content-wrapper-location">
        <div className="content-title">
          <Label text="Select Location" size="lg"></Label>
        </div>
        <div className="con-row">
          <Tooltip
            content={
              _isInModifyPortMode ? "Country selection cannot be changed." : ""
            }
            placement="top"
          >
            <DropdownInput
              label="Country"
              name="country"
              placeholder="Search Country"
              onSelect={onSelectCountry}
              options={countryList}
              showErrorIcon={false}
              value={country}
              state={
                _isInModifyPortMode && !_portDiversityTransition
                  ? "disabled"
                  : (errorCountry.portCountry && _countryCheck) || btSiteError
                  ? "error"
                  : countryList === null || undefined
                  ? 'loading'
                  : 'default'
              }
              errorMessageSize="sm"
              errorMessage={errorCountry.portCountry}
              assetCategory="flags"
              showAsset
              assetMap={FlagMap}
              assertSrc={loadingSpinner}
            />
          </Tooltip>
        </div>
        <div>
          <Tooltip
            content={
              country
                ? _isInModifyPortMode
                  ? "Port location cannot be modified"
                  : ""
                : "Please select country before selecting the port location"
            }
            placement="bottom"
          >
            <DropdownInput
              label="Port Location"
              name="location"
              placeholder="Search Port"
              onSelect={_onSetPort}
              options={
                btSiteError
                  ? [{ id: "", value: "" }]
                  : sortBy(locationOptions, ["value"])
              }
              value={btSiteError ? "" : port}
              state={determineState()}
              errorMessageSize="sm"
              errorMessage={error.portLocation}
              showErrorIcon={false}
              showAsset
              assetCategory="providers"
              assetMap={ProviderMap}
              assertSrc={loadingSpinner}
            />
          </Tooltip>
        </div>
      </div>
    </Card>
  );
};

export default Location;
