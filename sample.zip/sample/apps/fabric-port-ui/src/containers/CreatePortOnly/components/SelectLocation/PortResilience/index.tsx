import React from "react";

import {
  Button,
  Card,
  Divider,
  Label,
} from "@btdigital/nayan-component-library";
import { ResilienceType } from "../../../../../redux/portOnlySlice";

import "./PortResilience.scss";

export interface PortResilienceProps {
  onClickAction: (v: ResilienceType) => void;
}

const PortResilience: React.FC<PortResilienceProps> = ({ onClickAction }) => {
  return (
    <Card width="100%" height="90%">
      <div className="card-content-wrapper" data-testid="port-res-wrapper">
        <div className="main-title">
          <Label text="Port Resilience" size="lg"></Label>
        </div>
        <div className="description">
          Visit <span>BT Global Fabric knowledge centre</span> for more
          information on ports connection.
        </div>
        <Divider />
        <div className="actions-wrapper">
          <div className="action-title">Resilience </div>
          <div className="action-items">
            <Button
              label="Standard"
              iconBefore
              iconTitle="radio_checked"
              className="btn-action"
              size="medium"
              iconSize="sm"
            ></Button>
            <Button
              label="Diverse"
              iconBefore
              variant="outline"
              iconTitle="radio_unchecked"
              className="btn-action"
              size="medium"
              iconSize="sm"
              onPress={() => onClickAction("diverse")}
            ></Button>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default PortResilience;
