import { Button } from '@btdigital/nayan-component-library';
import dayjs from "dayjs";
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { v4 as uuidv4 } from "uuid";
import { updateCount } from '../../../../../../redux/basketSlice';
import { selectPortOnlyState, updatePortId } from '../../../../../../redux/portOnlySlice';
import images from "../../../../../../shared/assets";
import { Basket, PortResilienceType } from '../../../../../../shared/types';

type AddToBasketButtonProps = {
    onClickAddToBasket: () => void,
    recurringMonthlyPrice: number,
    oneTimePrice: number,
}

const AddToBasketButton = ({
    onClickAddToBasket,
    recurringMonthlyPrice,
    oneTimePrice
}: AddToBasketButtonProps) => {
    const {
        resilience,
        standardItem,
        diverseItem,
        portLocation,
        portDiversity,
        portId
    } = useSelector(selectPortOnlyState);
    const dispatch = useDispatch();

    const _addToBasket = () => {
        const portUUID = portId ?? uuidv4()
        const portData = {
            uuid: portUUID,
            portName:
                (resilience === PortResilienceType.standard
                    ? standardItem?.port_name
                    : diverseItem?.primaryItem.port_name) || "",
            resilience: resilience,
            diversity: portDiversity,
            country: portLocation.countryName,
            lastAdded: dayjs(Date.now()).format("DD/MM/YYYY"),
            portSpeed:
                (resilience === PortResilienceType.standard
                    ? standardItem?.port_speed
                    : diverseItem?.primaryItem.port_speed) || "",
            logoURL: images.clientLogo1,
            monthlyPrice: recurringMonthlyPrice,
            oneOffPayment: oneTimePrice,
            type: "Port Only",
            location: portLocation.primaryPort,
            timeToDeploy: "Immediate deploy",
        };

        let ports: Basket[] = [];
        if (localStorage.portsData) {
            ports = JSON.parse(localStorage.portsData);
        }
        const portIndex = ports.findIndex(p => p.uuid && p.uuid === portData.uuid);
        if (portIndex !== -1) {
            ports[portIndex] = portData;
        } else {
            ports = [...ports, portData];
        }
        localStorage.portsData = JSON.stringify(ports);
        dispatch(updateCount(ports.length));
        dispatch(updatePortId(portUUID));
        onClickAddToBasket();
    };

    return (
        <Button
            label="Add to Basket"
            onPress={_addToBasket}
            variant="gradient"
            fullWidth
            size="large"
            className="summary_btn"
            dataTestId="add_to_basket_btn"
        />
    )
}

export default AddToBasketButton;
