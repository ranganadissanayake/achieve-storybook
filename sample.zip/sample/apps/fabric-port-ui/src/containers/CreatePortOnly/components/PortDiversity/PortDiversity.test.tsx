import { render, screen, fireEvent } from "@testing-library/react";
import React from "react";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import store from "../../../../redux/store";
import PortDiversity from "./index";

describe("PortDiversity", () => {
  test("renders the PortDiversity component", () => {
    render(
      <Router>
        <Provider store={store}>
          <PortDiversity />
        </Provider>
      </Router>,
    );
    expect(screen.getByTestId("port-diversity-selection")).toBeInTheDocument();
  });
  test("selects the 'Diverse - Dual PoP' option when the corresponding radio button is clicked", () => {
    render(
      <Router>
        <Provider store={store}>
          <PortDiversity />
        </Provider>
      </Router>,
    );
    const radioButton = screen.getByLabelText("Diverse — Dual PoP");
    fireEvent.click(radioButton);
  });
  test("triggers the 'Continue' action when a port diversity option is selected and 'Continue' button is clicked", () => {
    render(
      <Router>
        <Provider store={store}>
          <PortDiversity />
        </Provider>
      </Router>,
    );

    const radioButton = screen.getByLabelText("Diverse — Dual PoP");
    fireEvent.click(radioButton);

    const continueButton = screen.getByText("Continue");
    fireEvent.click(continueButton);
  });
  test("triggers the 'Back' action when the 'Back' button is clicked", () => {
    render(
      <Router>
        <Provider store={store}>
          <PortDiversity />
        </Provider>
      </Router>,
    );

    const backButton = screen.getByText("Back");
    fireEvent.click(backButton);
  });
});
