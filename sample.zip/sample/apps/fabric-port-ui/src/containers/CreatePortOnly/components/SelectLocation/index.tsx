import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { useToast, Map, Button } from "@btdigital/nayan-component-library";

import Location from "./Location";
import SelectLocationHeader from "./SelectLocationHeader";
import LocationDiverse from "./LocationDiverse";
import {
  ResilienceType,
  selectDiverseItem,
  selectPortDiversity,
  selectResilienceType,
  selectStandardItem,
  updateDiverseItem,
  updatePortLocation,
  updateStandardItem,
  updateStep,
  resetPortOnly,
  selectIsInModifyPortMode,
  PortDiversityOptions,
  updatePortDiversity,
  updateDiversityTransition,
  PortDiversityTransition,
  selectDiversityTransition,
  selectCurrentStep,
} from "../../../../redux/portOnlySlice";

import "./SelectLocation.scss";
import { useApi } from "../../../../shared/helpers/api";
import { dropdownDataMapper } from "../../../../shared/utils";
import {
  errorToast,
  errorToastOptions,
} from "../../../../shared/constants/errorToast";
import { PortDiversityType } from "../../../../shared/types";
import PortAModifyResilience from "../ModifyJourney/PortA/PortAModifyResilience";
import { buildNotification } from "../../../../shared/constants/toastBuilder";
import { BT_NOTIFICATIONS } from "../../../../shared/constants";
import useLocalStorage from "../../../../shared/hooks/useLocalStorage";
import TagDataLayerService from "../../../../shared/services/TagDatalayer.service";
import useDetectNavigationChange from "../../../../shared/hooks/useDetectNavigationChange";
import useAppContext from "../../../../shared/hooks/useAppContext";
import {
  IMapDataProps,
  defaultdataCheck,
} from "../../../../containers/PortConnectivity/components/SelectPortBLocation";

export interface SelectLocationProps {}

export interface CountryOption {
  id: string;
  value: string;
}
const SelectLocation: React.FC<SelectLocationProps> = () => {
  const dispatch = useDispatch();

  const api = useApi();
  const toast = useToast();

  const _resilience = useSelector(selectResilienceType);
  const _standardItem = useSelector(selectStandardItem);
  const _diverseItem = useSelector(selectDiverseItem);
  const _currentStep = useSelector(selectCurrentStep);
  const [_countryList, setCountryList] = useState<CountryOption[]>();
  const [mapData, setMapData] = useState<IMapDataProps>(defaultdataCheck);
  const [mapProps, setMapProps] = useState({});

  const [resilienceType, setResilienceType] = React.useState<ResilienceType>(
    _resilience ?? "standard"
  );
  const [_showModal, setShowModal] = React.useState(false);
  const [isNextEnabled, setNextEnabled] = React.useState(false);

  const _portDiversity = useSelector(selectPortDiversity);
  const _isInModifyPortMode = useSelector(selectIsInModifyPortMode);
  const _portDiversityTransition = useSelector(selectDiversityTransition);
  const [notificationStorage, setNotificationStorage] = useLocalStorage(
    BT_NOTIFICATIONS,
    []
  );

  const [showPrompt, confirmNavigation, cancelNavigation] =
    useDetectNavigationChange(_showModal);

  const { showModal } = useAppContext();

  const handleShowModal = () => {
    showModal({
      onOk: handleModalOk,
      onCancel: handleModalCancel,
    });
  };

  React.useEffect(() => {
    if (showPrompt) {
      handleShowModal();
    }
  }, [showPrompt, confirmNavigation, cancelNavigation]);

  const handleModalCancel = () => {
    setShowModal(false);
    cancelNavigation();
  };

  const onLocationUpdate = () => {
    setShowModal(true);
  };

  React.useEffect(() => {
    TagDataLayerService.pushPageData("Create Port", "Select Port Location");
  }, []);

  useEffect(() => {
    api
      .getGeoLocations()
      .then((data) => {
        setCountryList(dropdownDataMapper(data));
      })
      .catch((error) => {
        const locationsErrorNotification = buildNotification(
          errorToast,
          "Port"
        );

        TagDataLayerService.pushErrorData(error, "API");

        toast.addToast(locationsErrorNotification.view(), {
          ...errorToastOptions,
          deleteSideEffect: () => {
            locationsErrorNotification.save({
              notificationStorage,
              setNotificationStorage,
            });
          },
        });
      });
    const focus = { focus: { lat: 0, lng: 0 } };
    setMapProps({ ...focus, data: [] });
  }, []);

  const _onModalOk = React.useCallback(() => {
    dispatch(
      updatePortLocation({
        countryIsoCode: "",
        countryName: "",
        primaryPort: "",
        secondaryPort: "",
      })
    );
    dispatch(updateStep(1));
    dispatch(resetPortOnly());
    if (_standardItem) {
      dispatch(updateStandardItem(undefined));
    } else if (_diverseItem) {
      dispatch(updateDiverseItem(undefined));
    }

    if (resilienceType === "standard") {
      setResilienceType("diverse");
    } else {
      setResilienceType("standard");
    }
  }, [resilienceType, _standardItem, _diverseItem]);

  const handleModalOk = () => {
    TagDataLayerService.pushCtaData("Leave");
    _onModalOk();
    confirmNavigation();
  };

  const getNonDiverse = () =>
    _portDiversity === PortDiversityType.StandardSinglePop;
  const getDiverseSingle = () =>
    _portDiversity === PortDiversityType.DiverseSinglePop;
  const getDiverseDual = () =>
    _portDiversity === PortDiversityType.DiverseDualPop;

  const onChangeDiversity = (diversity: PortDiversityOptions) => {
    dispatch(
      updateDiversityTransition(
        (_portDiversity + "->" + diversity) as PortDiversityTransition
      )
    );
    dispatch(updatePortDiversity(diversity));
  };

  const getModifyPortName = () => {
    if (_portDiversityTransition) {
      if (_diverseItem?.primaryItem.port_name) {
        return _diverseItem?.primaryItem.port_name;
      } else {
        return _standardItem?.port_name;
      }
    } else {
      if (_portDiversity === PortDiversityType.StandardSinglePop) {
        return _standardItem?.port_name;
      } else {
        return _diverseItem?.primaryItem.port_name;
      }
    }
  };

  getModifyPortName();

  return (
    <React.Fragment>
      <div className="fp-row select-location-header">
        <div>
          <SelectLocationHeader
            title={_isInModifyPortMode ? "Edit Customer Port" : undefined}
          />
        </div>
      </div>
      <div className="fp-row">
        {_isInModifyPortMode && (
          <div className="col-16 xl:col-8 sm:col-16 md:col-8 mb-16">
            <PortAModifyResilience
              onChangeDiversity={(diversity) => onChangeDiversity(diversity)}
              isNonDiverse={getNonDiverse()}
              isDiverseSingle={getDiverseSingle()}
              isDiverseDual={getDiverseDual()}
              isModify={_isInModifyPortMode}
            />
          </div>
        )}
        <div className="col-16 xl:col-8 sm:col-16 md:col-8 mb-16">
          {_portDiversity === PortDiversityType.StandardSinglePop ||
          _portDiversity === PortDiversityType.DiverseSinglePop ? (
            <Location
              countryList={_countryList}
              onLocationUpdate={onLocationUpdate}
              onSetMapData={(data) => setMapData({ ...mapData, ...data })}
              onSetMapPropsData={(data) =>
                setMapProps({ ...mapProps, ...data })
              }
              onPressNext={() => setNextEnabled(true)}
            />
          ) : (
            <LocationDiverse
              countryList={_countryList}
              onLocationUpdate={onLocationUpdate}
              onSetMapData={(data) => setMapData({ ...mapData, ...data })}
              onSetMapPropsData={(data) =>
                setMapProps({ ...mapProps, ...data })
              }
              onPressNext={() => setNextEnabled(true)}
            />
          )}
        </div>

        <div className="col-16 xl:col-8 sm:col-16 md:col-8 mb-16">
          <div className="config_card">
            <Map
              mapType={mapData?.mapType}
              mapId="portALocation"
              zoom={mapData?.zoom || 1}
              coordinate={mapProps}
            />
          </div>
        </div>
      </div>
      {_currentStep < 2 && (
        <div className="buttons_container">
          <Button
            label="Back"
            variant="link"
            onPress={() => handleShowModal()}
            dataTestId="back_btn"
          />
          <Button
            label="Next"
            variant="gradient"
            onPress={() => dispatch(updateStep(2))}
            dataTestId="continue_btn"
            disabled={!isNextEnabled}
          />
        </div>
      )}
    </React.Fragment>
  );
};

export default SelectLocation;
