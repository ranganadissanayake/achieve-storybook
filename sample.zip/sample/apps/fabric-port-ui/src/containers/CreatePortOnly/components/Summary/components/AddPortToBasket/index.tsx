import { Button, Icon } from '@btdigital/nayan-component-library'
import React from 'react'
import { useNavigate } from 'react-router-dom';
import TagDataLayerService from '../../../../../../shared/services/TagDatalayer.service';


const AddPortToBasket = () => {
    const navigate = useNavigate();
    return (
        <div className="deploy_to_basket" data-testid="deploy_to_basket">
            <div className="success_message">
                <Icon
                    title="tick_variant"
                    inverse
                    className="tick_icon"
                />
                <span className="summary_text_key">
                    Port added to basket successfully
                </span>
            </div>
            <Button
                label="View in Basket"
                variant="link"
                size="medium"
                className="view_in_basket_btn summary_btn"
                dataTestId="view_in_basket_btn"
                onPress={() => {
                    TagDataLayerService.pushCtaData("View in Basket");
                    navigate("/basket")
                }}
            />
        </div>
    )
}

export default AddPortToBasket;
