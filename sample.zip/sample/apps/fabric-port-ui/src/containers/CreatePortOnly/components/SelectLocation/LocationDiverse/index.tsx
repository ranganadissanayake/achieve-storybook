import React, { ReactNode, useState } from "react";

import { useDispatch, useSelector } from "react-redux";
import { isEmpty, sortBy } from "lodash";
import {
  Card,
  Label,
  DropdownInput,
  useToast,
} from "@btdigital/nayan-component-library";

import { useApi } from "../../../../../shared/helpers/api";
import {
  updateResilienceType,
  updatePortLocation,
  selectPortLocation,
  updatePrimaryPortSpeed,
  updateSecondaryPortSpeed,
  selectPortDiversity,
  selectIsInModifyPortMode,
  selectDiversityTransition,
  selectCountryCheck,
  selectLocationCheck,
  selectDiverseCheck,
  updateLocationValue,
  updateCountryValue,
  updateDiverseValue,
  updateLocationCheck,
  updateCountryCheck,
  updateDiverseCheck,
} from "../../../../../redux/portOnlySlice";
import { IBTSite } from "../../../../../shared/models";
import {
  errorToast,
  errorToastOptions,
} from "../../../../../shared/constants/errorToast";

import "../Location/Location.scss";
import { PortDiversityType } from "../../../../../shared/types";
import {
  BT_NOTIFICATIONS,
  initialSiteState,
} from "../../../../../shared/constants";
import { buildNotification } from "../../../../../shared/constants/toastBuilder";
import useLocalStorage from "../../../../../shared/hooks/useLocalStorage";
import { getBtSitesRequestDTO } from "../../../../../shared/mappers/services/port.service";
import { JOURNEY_TYPE } from "../../../../../shared/helpers/enumsCommon";
import Tooltip from "../../../../../components/TooltipV2";
import { FlagMap } from "../../../../../shared/assets/images/flags";
import { ProviderMap } from "../../../../../shared/assets/images/providers";
import {
  getMapItems,
  mapConstants,
} from "../../../../../containers/PortConnectivity/components/SelectPortBLocation";
import { selectGeoLocation } from "../../../../../redux/geoLocationSlice";

export interface LocationProps {
  countryList: any;
  onLocationUpdate: () => void;
  onPressNext?: () => void;
  onSetMapData?: (data: any) => void;
  onSetMapPropsData?: (data: any) => void;
}

export interface Option {
  id: string;
  value: string;
}

const LocationDiverse: React.FC<LocationProps> = ({
  countryList,
  onLocationUpdate,
  onPressNext,
  onSetMapData,
  onSetMapPropsData,
}) => {
  const dispatch = useDispatch();

  // custom hook for api calls
  const api = useApi();
  const toast = useToast();

  const _portLocation = useSelector(selectPortLocation);
  const geolocations = useSelector(selectGeoLocation);

  const _portDiversity = useSelector(selectPortDiversity);

  const [country, setCountry] = useState<string>(
    _portLocation.countryIsoCode ?? ""
  );
  const [primaryPort, setPrimaryPort] = useState<string>(
    _portLocation.primaryPort ?? ""
  );
  const [secondaryPort, setSecondaryPort] = useState<string>(
    _portLocation.secondaryPort ?? ""
  );
  const _countryCheck = useSelector(selectCountryCheck);
  const _locationCheck = useSelector(selectLocationCheck);
  const _diverseCheck = useSelector(selectDiverseCheck);
  const [locationOptions, setlocationOptions] = useState<Option[]>([
    { id: "", value: "" },
  ]);
  const [locationDetail, setlocationDetails] = useState<IBTSite[]>();
  const [isCountrySelected, setIsCountrySelected] = useState<boolean>(
    !isEmpty(country)
  );
  const [btSiteError, setBtSiteError] = useState(false);
  const [sameLocationSelected, setSameLocationSelected] =
    useState<boolean>(false);
  const [notificationStorage, setNotificationStorage] = useLocalStorage(
    BT_NOTIFICATIONS,
    []
  );
  const _isInModifyPortMode = useSelector(selectIsInModifyPortMode);
  const _portDiversityTransition = useSelector(selectDiversityTransition);
  const [errorCountry, setErrorCountry] = useState({ portCountry: "" });
  const [errorPrimaryLocation, setErrorPrimaryLocation] = useState({
    primaryLocation: "",
  });
  const [errorDiverseLocation, setErrorDiverseLocation] = useState({
    diverseLocation: "",
  });

  React.useEffect(() => {
    if (isCountrySelected) {
      const locationListRes: {
        value: string;
        id: string;
        name: ReactNode;
        facilityProvider: string;
      }[] = [];

      api
        .getBtSites(
          getBtSitesRequestDTO({
            ...initialSiteState,
            countryISOCode: country,
            siteType: JOURNEY_TYPE.PORT_A,
          })
        )
        .then((data) => {
          data?.forEach(
            ({ facilityName, facilityAddress, siteId, facilityProvider }) => {
              locationListRes.push({
                id: siteId,
                value: `${facilityName} - ${facilityAddress.city},  ${facilityAddress.country}`,
                facilityProvider: facilityProvider,
                name: (
                  <div className="provider-option port-a-diverse">
                    <span className="facility-name">{facilityName}</span>
                    <span>
                      {facilityAddress.city.charAt(0).toUpperCase() +
                        facilityAddress.city.slice(1).toLowerCase()}
                      ,{facilityAddress.country}
                    </span>
                  </div>
                ),
              });
            }
          );

          const countryDetails = data?.find((subItem) => {
            const countryName =
              geolocations.geoLocationDetails.find(
                (geolocation) => geolocation.countryISOCode === country
              )?.countryDisplayName || "";

            return (
              subItem.facilityAddress.country.toLowerCase() ===
              countryName.toLowerCase()
            );
          });

          onSetMapData && onSetMapData({ ...mapConstants.country });
          onSetMapPropsData &&
            onSetMapPropsData({
              focus: {
                lat: countryDetails?.facilityAddress.latitude || 0,
                lng: countryDetails?.facilityAddress.longitude || 0,
              },
            });

          setlocationOptions(locationListRes);
          setlocationDetails(data);
          setBtSiteError(false);
        })
        .catch(() => {
          const locationsErrorNotification = buildNotification(
            errorToast,
            "Port"
          );

          toast.addToast(locationsErrorNotification.view(), {
            ...errorToastOptions,
            deleteSideEffect: () => {
              locationsErrorNotification.save({
                notificationStorage,
                setNotificationStorage,
              });
            },
          });
          setlocationOptions([{ id: "", value: "" }]);
          setBtSiteError(true);
        });
    }
  }, [country]);

  React.useEffect(() => {
    if (primaryPort || secondaryPort) {
      onSetMapData &&
        onSetMapData({
          ...mapConstants.facility,
        });

      const primaryPortDetails = locationDetail?.find((subItem) => {
        return subItem.siteId === primaryPort;
      }) as IBTSite;

      const secondaryPortDetails = locationDetail?.find((subItem) => {
        return subItem.siteId === secondaryPort;
      }) as IBTSite;

      onSetMapPropsData &&
        onSetMapPropsData({
          data: [
            ...(primaryPortDetails
              ? [
                  {
                    label: primaryPortDetails.facilityAddress.city,
                    position: {
                      lat: primaryPortDetails.facilityAddress.latitude,
                      lng: primaryPortDetails.facilityAddress.longitude,
                    },
                    type: "city",
                  },
                ]
              : []),
            ...(primaryPortDetails
              ? [
                  getMapItems({
                    siteId: primaryPortDetails?.siteId,
                    latitude: primaryPortDetails?.facilityAddress.latitude,
                    longitude: primaryPortDetails?.facilityAddress.longitude,
                    facilityName: primaryPortDetails?.facilityName,
                    facilityProvider: primaryPortDetails?.facilityProvider,
                    addressLocation: `${primaryPortDetails.facilityAddress.siteAddressLine1}, ${primaryPortDetails.facilityAddress.siteAddressLine2}, ${primaryPortDetails.facilityAddress.city}, ${primaryPortDetails.facilityAddress.country}`,
                  }),
                ]
              : []),
            ...(secondaryPortDetails
              ? [
                  getMapItems({
                    siteId: secondaryPortDetails?.siteId,
                    latitude: secondaryPortDetails?.facilityAddress.latitude,
                    longitude: secondaryPortDetails?.facilityAddress.longitude,
                    facilityName: secondaryPortDetails?.facilityName,
                    facilityProvider: secondaryPortDetails?.facilityProvider,
                    addressLocation: `${secondaryPortDetails.facilityAddress.siteAddressLine1}, ${secondaryPortDetails.facilityAddress.siteAddressLine2}, ${secondaryPortDetails.facilityAddress.city}, ${secondaryPortDetails.facilityAddress.country}`,
                  }),
                ]
              : []),
          ],
        });
    }
  }, [primaryPort, secondaryPort]);

  const onSelectCountry = (countryData: string) => {
    if (countryData !== country) {
      dispatch(updateCountryValue(countryData));
      if (countryData) {
        dispatch(updateCountryCheck(false));
      }
      if (countryData !== "") {
        setIsCountrySelected(true);
        setCountry(countryData);
      }
      setPrimaryPort("");
      setSecondaryPort("");
    }
    onLocationUpdate();
  };

  const filterSelectedLocation = (key: string, filterObj: any) => {
    const filteredData = filterObj.find(
      (x: { siteId: string }) => x.siteId === key
    );
    return filteredData;
  };

  const _onSetPrimaryPort = (p: string) => {
    setPrimaryPort(p);
    dispatch(updateLocationValue(p));
    if (p) {
      dispatch(updateLocationCheck(false));
    }

    if (locationDetail && p !== "") {
      const filteredData: IBTSite = filterSelectedLocation(p, locationDetail);
      if (filteredData) {
        if (_portDiversity === PortDiversityType.DiverseDualPop) {
          const { facilityAddress } = filteredData;
          const relatedMetroArea = locationDetail.find(
            (a) =>
              a.facilityName
                .toLowerCase()
                .includes(facilityAddress.city.toLowerCase()) &&
              a.siteId !== filteredData.siteId
          );
          if (!isEmpty(relatedMetroArea)) {
            const { siteId } = relatedMetroArea;
            setSecondaryPort(siteId);
          }
        }
        dispatch(
          updatePrimaryPortSpeed(
            filteredData?.products.customerPorts.portOnly ?? []
          )
        );
      }
    }
  };

  const _onSetSecondaryPort = (p: string) => {
    setSecondaryPort(p);
    dispatch(updateDiverseValue(p));
    if (p) {
      dispatch(updateDiverseCheck(false));
    }
    if (locationDetail && p !== "") {
      const filteredData = filterSelectedLocation(p, locationDetail);
      if (filteredData) {
        dispatch(
          updateSecondaryPortSpeed(
            filteredData?.products.customerPorts.portOnly ?? []
          )
        );
      }
    }
  };

  React.useEffect(() => {
    const primaryPortLocation =
      locationOptions?.find((a: any) => a.id === primaryPort)?.value || "";
    const secondaryPortLocation =
      locationOptions?.find((a: any) => a.id === secondaryPort)?.value || "";
    const countryIsoCode = country;
    const countryName =
      countryList?.find((a: any) => a.id === country)?.value || "";

    if (
      primaryPort.length > 0 &&
      secondaryPort.length > 0 &&
      _portDiversity === "diverse-dual-pop" &&
      primaryPort === secondaryPort
    ) {
      setSameLocationSelected(true);
    } else {
      setSameLocationSelected(false);
      if (country !== "" && primaryPort !== "" && secondaryPort !== "") {
        onPressNext && onPressNext();
      }
      dispatch(updateResilienceType("diverse"));
      dispatch(
        updatePortLocation({
          countryIsoCode,
          countryName,
          primaryPort,
          secondaryPort,
          primaryLocationDisplayLabel: primaryPortLocation,
          secondaryLocationDisplayLabel: secondaryPortLocation,
        })
      );
    }
  }, [country, primaryPort, secondaryPort, locationOptions]);

  React.useEffect(() => {
    if (
      _portDiversityTransition === "standard-single-pop->diverse-dual-pop" ||
      _portDiversityTransition === "diverse-single-pop->diverse-dual-pop" ||
      _portDiversityTransition === "diverse-dual-pop->diverse-single-pop"
    ) {
      setCountry("");
      setPrimaryPort("");
      setSecondaryPort("");
    }
  }, [_portDiversityTransition]);

  React.useEffect(() => {
    if (_locationCheck) {
      setErrorPrimaryLocation({
        primaryLocation: "Please select a primary location",
      });
    }
    if (_countryCheck) {
      setErrorCountry({ portCountry: "Please select a country" });
    }
    if (_diverseCheck) {
      setErrorDiverseLocation({
        diverseLocation: "Please select a secondary location",
      });
    }
    if (btSiteError) {
      setErrorCountry({ portCountry: "Please select another country" });
    }
  }, [_locationCheck, _countryCheck, _diverseCheck, btSiteError]);

  return (
    <>
      <Card width="100%" data-testid="location-wrapper">
        <div className="card-content-wrapper-location card-content-wrapper-location-diverse">
          <div className="content-title">
            <Label text="Select Location" size="lg"></Label>
          </div>
          <div className="con-row">
            <Tooltip
              content={
                _isInModifyPortMode
                  ? "Country selection cannot be changed."
                  : ""
              }
              placement="top"
            >
              <DropdownInput
                label="Country"
                name="country"
                state={
                  _isInModifyPortMode && !_portDiversityTransition
                    ? "disabled"
                    : (errorCountry.portCountry && _countryCheck) || btSiteError
                    ? "error"
                    : "default"
                }
                placeholder="Search Country"
                onSelect={onSelectCountry}
                options={countryList}
                showErrorIcon={false}
                value={country}
                errorMessageSize="sm"
                errorMessage={errorCountry.portCountry}
                showAsset
                assetMap={FlagMap}
                assetCategory="flags"
              />
            </Tooltip>
          </div>
          <div className="con-row">
            <Tooltip
              content={
                country
                  ? _isInModifyPortMode
                    ? "Primary Port location cannot be changed."
                    : ""
                  : "Please select country before selecting the primary port location"
              }
              placement="bottom"
            >
              <DropdownInput
                label="Primary Port Location"
                name="location-primary"
                placeholder="Search Port"
                onSelect={_onSetPrimaryPort}
                options={
                  btSiteError
                    ? [{ id: "", value: "" }]
                    : sortBy(locationOptions, ["value"])
                }
                value={btSiteError ? "" : primaryPort}
                state={
                  !btSiteError &&
                  ((country && !_isInModifyPortMode) ||
                    (country &&
                      _isInModifyPortMode &&
                      _portDiversityTransition))
                    ? sameLocationSelected ||
                      (_locationCheck && !_isInModifyPortMode)
                      ? "error"
                      : "default"
                    : "disabled"
                }
                errorMessage={
                  _locationCheck
                    ? errorPrimaryLocation.primaryLocation
                    : "Please select two different locations"
                }
                showErrorIcon={false}
                errorMessageSize="sm"
                showAsset
                assetCategory="providers"
                assetMap={ProviderMap}
              />
            </Tooltip>
          </div>

          <div className="con-row">
            <Tooltip
              content={
                country
                  ? _isInModifyPortMode
                    ? "Secondary Port location cannot be changed."
                    : ""
                  : "Please select country before selecting the secondary port location"
              }
              placement="bottom"
            >
              <DropdownInput
                label="Secondary Port Location"
                name="location-secondary"
                placeholder="Search Port"
                onSelect={_onSetSecondaryPort}
                options={
                  btSiteError
                    ? [{ id: "", value: "" }]
                    : sortBy(locationOptions, ["value"])
                }
                value={btSiteError ? "" : secondaryPort}
                state={
                  !btSiteError &&
                  ((country && !_isInModifyPortMode) ||
                    (country &&
                      _isInModifyPortMode &&
                      _portDiversityTransition))
                    ? sameLocationSelected ||
                      (_diverseCheck && !_isInModifyPortMode)
                      ? "error"
                      : "default"
                    : "disabled"
                }
                errorMessage={
                  _diverseCheck
                    ? errorDiverseLocation.diverseLocation
                    : "Please select two different locations"
                }
                showErrorIcon={false}
                errorMessageSize="sm"
                showAsset
                assetCategory="providers"
                assetMap={ProviderMap}
              />
            </Tooltip>
          </div>
        </div>
      </Card>
    </>
  );
};

export default LocationDiverse;
