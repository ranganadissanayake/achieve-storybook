import { Badge, Label } from "@btdigital/nayan-component-library";
import classnames from "classnames";
import React from "react";

import { PortType } from "../..";
import {
  PortLocation,
  PortOnlyItem,
  PortResilienceType,
} from "../../../../../../shared/types";
import { dataMapper } from "../../../../../../shared/utils";

export const _advancedSetting = (
  item: PortOnlyItem,
  resilience: PortResilienceType,
  portType?: PortType,
  itemOriginal?: PortOnlyItem,
) => (
  <section
    className={classnames("summary_body", {
      secondary_start: portType === "secondary",
    })}
  >
    {resilience === PortResilienceType.diverse && (
      <Label
        text={`${portType === "primary" ? "Primary" : "Secondary"} Port`}
        size="lg"
      />
    )}
    <div className="summary_alignment">
      <label className="summary_text_key">Telemetry Streaming Enabled</label>
      <Badge
        text={item.telemetry_streaming ? "Enabled" : "Disabled"}
        style={item.telemetry_streaming ? "success" : "disabled"}
        customStyle="summary-badge"
        outline={!item.telemetry_streaming}
      />
    </div>
    <div className="summary_alignment">
      <label className="summary_text_key">
        Bandwidth Utilisation Monitoring
      </label>
      <Badge
        text={item.banwidth_monitoring ? "Enabled" : "Disabled"}
        style={item.banwidth_monitoring ? "success" : "disabled"}
        customStyle="summary-badge"
        outline={!item.banwidth_monitoring}
      />
    </div>
    {item.banwidth_monitoring && (
      <>
        <div className="summary_alignment">
          <label className="summary_text_value price_text_key">
            Low threshold
          </label>
          <label className="summary_text_value">
            <span className="prev-val-txt">{itemOriginal?.low_threshold && itemOriginal?.low_threshold!==item.low_threshold ? `${itemOriginal?.low_threshold}%` : ``}</span>
            {`${item.low_threshold}%`}
          </label>
        </div>
        <div className="summary_alignment">
          <label className="summary_text_value price_text_key">
            High threshold
          </label>
          <label className="summary_text_value">
          <span className="prev-val-txt">{itemOriginal?.high_threshold && itemOriginal?.high_threshold!==item.high_threshold ? `${itemOriginal?.high_threshold}%` : ``}</span>
            {`${item.high_threshold}%`}
          </label>
        </div>
      </>
    )}
    <div className="summary_alignment">
      <label className="summary_text_key">Link Aggregation Group (LAG)</label>
      <Badge
        text={item.lag ? "Enabled" : "Disabled"}
        customStyle={
          item.lag ? "summary-badge success" : "summary-badge disabled"
        }
        outline={!item.lag}
      />
    </div>
    <div className="summary_alignment">
      <label className="summary_text_key">Standard MTU</label>
      <label className="summary_text_value">{item.mtu_size}</label>
    </div>
    <div className="summary_alignment">
      <label className="summary_text_key">Enable Oversubscription</label>
      <Badge
        text={item.enable_oversubscription ? "Enabled" : "Disabled"}
        customStyle={
          item.enable_oversubscription
            ? "summary-badge success"
            : "summary-badge disabled"
        }
        outline={!item.enable_oversubscription}
      />
    </div>
  </section>
);

export const _summaryDetails = (
  portLocation: PortLocation,
  item: PortOnlyItem,
  resilience: PortResilienceType,
  portType?: PortType
) => (
  <>
    {resilience !== PortResilienceType.standard && (
      <div>
        {portType === "primary" ? (
          <div>
            <span className="summary_diverse_port">1</span>
            <span className="summary_diverse_port_text">
              Primary Connection
            </span>
          </div>
        ) : (
          <div className="summary_secondary_port">
            <span className="summary_diverse_port secondary_port">2</span>
            <span className="summary_diverse_port_text">
              Secondary Connection
            </span>
          </div>
        )}
      </div>
    )}
    <div className="summary_alignment">
      <label className="summary_text_key">Location</label>
      <label className="summary_text_value group">
        <span>{`${
          resilience === PortResilienceType.standard || portType === "primary"
            ? portLocation.primaryLocationDisplayLabel
            : portLocation.secondaryLocationDisplayLabel
        }`}</span>
      </label>
    </div>
    <div className="summary_alignment">
      <label className="summary_text_key">Speed</label>
      <label className="summary_text_value">
        {dataMapper(item?.port_speed)}
      </label>
    </div>
  </>
);

export const subRowsMapperSingletoDualPop = (
  _portDiversity: any,
  portLocation: any,
  diverseItem: any
) => {
  return {
    portId: diverseItem?.port_id,
    country: portLocation.countryName,
    countryISOCode: portLocation.countryIsoCode,
    portSpeed: diverseItem?.port_speed,
    location: portLocation.primaryLocationDisplayLabel,
    isBandwidthUtilisationMonitoring: diverseItem?.banwidth_monitoring,
    isEnableOversubscription: diverseItem?.enable_oversubscription,
    isPredictiveBandwidthOptimisation: diverseItem?.predictive_bandwidth,
    isLag: diverseItem?.lag,
    lagPortsCount: diverseItem?.number_of_lag_ports,
    mtuSize: diverseItem?.mtu_size,
    portDescription: diverseItem?.port_description,
    portLocationId: portLocation.primaryPort,
    portName: diverseItem?.port_name,
    portDiversity: _portDiversity,
    description: diverseItem?.port_description,
    lowThreshold: diverseItem?.low_threshold,
    highThreshold: diverseItem?.high_threshold,
    isSubRow: true,
    isDiverse: true,
  };
};

export const subRowsMapperDualtoDualPop = (
  item: any,
  _portDiversity: any,
  portLocation: any,
  diverseItem: any
) => {
  return {
    ...item,
    portId: diverseItem?.port_id,
    country: portLocation.countryName,
    countryISOCode: portLocation.countryIsoCode,
    portSpeed: diverseItem?.port_speed,
    location: portLocation.primaryLocationDisplayLabel,
    isBandwidthUtilisationMonitoring: diverseItem?.banwidth_monitoring,
    isEnableOversubscription: diverseItem?.enable_oversubscription,
    isPredictiveBandwidthOptimisation: diverseItem?.predictive_bandwidth,
    isLag: diverseItem?.lag,
    lagPortsCount: diverseItem?.number_of_lag_ports,
    mtuSize: diverseItem?.mtu_size,
    portLocationId: portLocation.primaryPort,
    portName: diverseItem?.port_name,
    portDescription: diverseItem?.port_description,
    portDiversity: _portDiversity,
    description: diverseItem?.port_description,
    lowThreshold: diverseItem?.low_threshold,
    highThreshold: diverseItem?.high_threshold,
  };
};

export const subRowsMapperStandardPop = (item: any, diverseItem: any) => {
  return {
    ...item,
    isBandwidthUtilisationMonitoring: diverseItem?.banwidth_monitoring,
    isEnableOversubscription: diverseItem?.enable_oversubscription,
    isPredictiveBandwidthOptimisation: diverseItem?.predictive_bandwidth,
    isLag: diverseItem?.lag,
    lagPortsCount: diverseItem?.number_of_lag_ports,
    mtuSize: diverseItem?.mtu_size,
    description: diverseItem?.port_description,
    lowThreshold: diverseItem?.low_threshold,
    highThreshold: diverseItem?.high_threshold,
  };
};

export const defaultPricingItem = {
  oneTimePrice: 0,
  recurringMonthlyPrice: 0,
  currencyFormat: "GBP",
  PoPSiteId: "",
};
