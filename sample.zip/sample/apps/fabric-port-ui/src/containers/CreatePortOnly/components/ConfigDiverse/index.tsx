import React, { useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import {
  Card,
  Divider,
  Input,
  Label,
  Textarea,
  Toggle,
  DropdownInput,
  Button,
  Modal,
  Icon,
} from "@btdigital/nayan-component-library";

import {
  updateStep,
  updateDiverseItem,
  selectDiverseItem,
  updatePortLocation,
  selectPrimaryPortSpeed,
  selectSecondaryPortSpeed,
  selectPortLocation,
  updatePortDiversity,
  selectPortDiversity,
  resetPortOnly,
  selectIsInModifyPortMode,
  selectDiversityTransition,
  updateLocationCheck,
  updateCountryCheck,
  updateDiverseCheck,
  selectCountryValue,
  selectLocationValue,
  selectDiverseValue,
} from "../../../../redux/portOnlySlice";
import {
  DiverseItem,
  PortDiversityType,
  PortOnlyItem,
} from "../../../../shared/types";
import {
  THRESHOLD_OPTIONS,
  PORT_INTERFACE,
  MAX_NUMBER_OF_CHARACTERS,
} from "../../../../shared/constants";
import {
  dataMapper,
  validateLength,
  validateRange,
} from "../../../../shared/utils";
import Tooltip from "../../../../components/TooltipV2";
import TagDataLayerService from "../../../../shared/services/TagDatalayer.service";
import TooltipText from "../../../../components/TooltipText";

import "../ConfigStandard/ConfigStandard.scss";
import "./ConfigDiverse.scss";

export interface ConfigDiverseProps {}

const ConfigDiverse: React.FC<ConfigDiverseProps> = () => {
  const configurePortRef = useRef<HTMLInputElement>(null);
  const portSettingRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const _diverseItem = useSelector(selectDiverseItem);

  const _selectedPrimaryPortSpeed = useSelector(selectPrimaryPortSpeed);
  const _selectedSecondaryPortSpeed = useSelector(selectSecondaryPortSpeed);
  const _selectPortLocation = useSelector(selectPortLocation);
  const _portDiversity = useSelector(selectPortDiversity);
  const _countryValue = useSelector(selectCountryValue);
  const _locationValue = useSelector(selectLocationValue);
  const _diverseValue = useSelector(selectDiverseValue);

  const [_isEdit, setIsEdit] = React.useState(_diverseItem !== undefined);
  const [_portName, setPortName] = React.useState(
    _diverseItem?.primaryItem.port_name ?? "",
  );
  const [_portDescription, setPortDescription] = React.useState(
    _diverseItem?.primaryItem.port_description ?? "",
  );
  const [_secPortDescripition, setSecPortDescription] = React.useState(
    _diverseItem?.secondaryItem.port_description ?? "",
  );
  const [_portSpeed, setPortSpeed] = React.useState(
    _diverseItem?.primaryItem.port_speed ?? "",
  );
  const [_secPortSpeed, setSecPortSpeed] = React.useState(
    _diverseItem?.secondaryItem.port_speed ?? "",
  );
  const [_portInterface, setPortInterface] = React.useState(
    _diverseItem?.primaryItem.port_interface
      ? _diverseItem?.primaryItem.port_interface
      : "",
  );
  const [_secPortInterface, setSecPortInterface] = React.useState(
    _diverseItem?.secondaryItem.port_interface
      ? _diverseItem?.secondaryItem.port_interface
      : "",
  );
  const [_portLocation, setPortLocation] = React.useState<string>();

  const [_isTelemetryStreamingEnabled, setIsTelemetryStreamingEnabled] =
    React.useState(_diverseItem?.primaryItem.telemetry_streaming ?? false);
  const [_isSecTelemetryStreamingEnabled, setIsSecTelemetryStreamingEnabled] =
    React.useState(_diverseItem?.secondaryItem.telemetry_streaming ?? false);

  const [_isBandwidthMonitoring, setIsBandwidthMonitoring] = React.useState(
    _diverseItem?.primaryItem.banwidth_monitoring ?? false,
  );
  const [_isSecBandwidthMonitoring, setIsSecBandwidthMonitoring] =
    React.useState(_diverseItem?.secondaryItem.banwidth_monitoring ?? false);

  const [_lowThreshold, setLowThreshold] = React.useState<number | undefined>(
    _diverseItem?.primaryItem.low_threshold,
  );
  const [_secLowThreshold, setSecLowThreshold] = React.useState<
    number | undefined
  >(_diverseItem?.secondaryItem.low_threshold);
  const [_highThreshold, setHighThreshold] = React.useState<number | undefined>(
    _diverseItem?.primaryItem.high_threshold,
  );
  const [_secHighThreshold, setSecHighThreshold] = React.useState<
    number | undefined
  >(_diverseItem?.secondaryItem.high_threshold);
  const [_isPredictiveBandwidth, setIsPredictiveBandwidth] = React.useState(
    _diverseItem?.primaryItem.predictive_bandwidth ?? false,
  );
  const [_isSecPredictiveBandwidth, setIsSecPredictiveBandwidth] =
    React.useState(_diverseItem?.secondaryItem.predictive_bandwidth ?? false);
  const [_isOverSubscription, setIsOverSubscription] = React.useState(
    _diverseItem?.primaryItem.enable_oversubscription ?? false,
  );
  const [_isSecOverSubscription, setIsSecOverSubscription] = React.useState(
    _diverseItem?.secondaryItem.enable_oversubscription ?? false,
  );
  const [_isLAG, setIsLAG] = React.useState(
    _diverseItem?.primaryItem.lag ?? false,
  );
  const [_isSecLAG, setIsSecLAG] = React.useState(
    _diverseItem?.secondaryItem.lag ?? false,
  );
  const [_lagPort, setLagPort] = React.useState(
    _diverseItem?.primaryItem.number_of_lag_ports ??
      `${PORT_INTERFACE[0].lag_ports[0]}`,
  );
  const [_secLagPort, setSecLagPort] = React.useState(
    _diverseItem?.secondaryItem.number_of_lag_ports ??
      `${PORT_INTERFACE[0].lag_ports[0]}`,
  );

  const _mtuSize = _diverseItem?.primaryItem.mtu_size ?? 9216;
  const _secMtuSize = _diverseItem?.secondaryItem.mtu_size ?? 9216;

  const [_isPortNameValid, setIsPortNameValid] = React.useState(true);
  const [_isPortDescripitionValid, setIsPortDescriptionValid] =
    React.useState(true);
  const [_isSecPortDescripitionValid, setIsSecPortDescriptionValid] =
    React.useState(true);
  const [_isLowThresholdValid, setIsLowThresholdValid] = React.useState(true);
  const [_isSecLowThresholdValid, setIsSecLowThresholdValid] =
    React.useState(true);
  const [_isHighThresholdValid, setIsHighThresholdValid] = React.useState(true);
  const [_isSecHighThresholdValid, setIsSecHighThresholdValid] =
    React.useState(true);
  const [_isThresholdValid, setIsThresholdValid] = React.useState(true);
  const [_isSecThresholdValid, setIsSecThresholdValid] = React.useState(true);
  const [_isMtuSizeValid, setIsMtuSizeValid] = React.useState(true);
  const [_isSecMtuSizeValid, setIsSecMtuSizeValid] = React.useState(true);
  const [_isDisablePortSpeed, setIsDisablePortSpeed] = React.useState(false);
  const [_isPrimaryPortSpeedValid, setPrimaryIsPortSpeedValid] =
    React.useState(true);
  const [_isSecondaryPortSpeedValid, setSecondaryIsPortSpeedValid] =
    React.useState(true);

  const [_displayedLowThreshold, setDisplayLowThreshold] =
    React.useState<string>(
      _diverseItem?.primaryItem.low_threshold?.toString() ?? "",
    );
  const [_displayedSecLowThreshold, setDisplaySecLowThreshold] =
    React.useState<string>(
      _diverseItem?.secondaryItem.low_threshold?.toString() ?? "",
    );
  const [_displayedHighThreshold, setDisplayHighThreshold] =
    React.useState<string>(
      _diverseItem?.primaryItem.high_threshold?.toString() ?? "",
    );
  const [_displayedSecHighThreshold, setDisplaySecHighThreshold] =
    React.useState<string>(
      _diverseItem?.secondaryItem.high_threshold?.toString() ?? "",
    );
  const [_showModal, setShowModal] = React.useState(false);
  const [_selectedPrimaryThreshold, setSelectedPrimaryThreshold] =
    React.useState<string>("none");
  const [_selectedSecondaryThreshold, setSelectedSecondaryThreshold] =
    React.useState<string>("none");
  const [isPrimaryPortLoading, setIsPrimaryPortLoading] = React.useState(false);
  const [isSecondaryPortLoading, setIsSecondaryPortLoading] =
    React.useState(false);
  const [isPrimaryInterfaceLoading, setIsPrimaryInterfaceLoading] =
    React.useState(false);
  const [isSecondaryInterfaceLoading, setIsSecondaryInterfaceLoading] =
    React.useState(false);
  const _isInModifyPortMode = useSelector(selectIsInModifyPortMode);
  const _portDiversityTransition = useSelector(selectDiversityTransition);

  const _onContinue = React.useCallback(() => {
    let isFormSubmittable = true;
    if (!_isPortNameValid || _portName.trim() === "") {
      isFormSubmittable = false;
      setIsPortNameValid(false);
      if (configurePortRef.current) {
        (configurePortRef.current as HTMLElement).scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    }

    if (!_isPortDescripitionValid) {
      isFormSubmittable = false;
      setIsPortDescriptionValid(false);
    }

    if (!_isSecPortDescripitionValid) {
      isFormSubmittable = false;
      setIsSecPortDescriptionValid(false);
    }

    if (_locationValue === "") {
      isFormSubmittable = false;
      dispatch(updateLocationCheck(true));
    }

    if (_countryValue === "" && !_isInModifyPortMode) {
      isFormSubmittable = false;
      dispatch(updateCountryCheck(true));
    }

    if (_diverseValue === "" && !_isInModifyPortMode) {
      isFormSubmittable = false;
      dispatch(updateDiverseCheck(true));
    }

    if (
      _diverseValue === "" &&
      _locationValue &&
      _countryValue &&
      _portName.trim() !== "" &&
      _isPortNameValid
    ) {
      isFormSubmittable = true;
      dispatch(updateDiverseCheck(false));
    }

    if (!_portSpeed || _portSpeed === "") {
      isFormSubmittable = false;
      setPrimaryIsPortSpeedValid(false);
    }

    if (!_secPortSpeed || _secPortSpeed === "") {
      isFormSubmittable = false;
      setSecondaryIsPortSpeedValid(false);
    }

    if (_isBandwidthMonitoring) {
      if (
        _lowThreshold === undefined ||
        isNaN(_lowThreshold) ||
        !_isLowThresholdValid
      ) {
        isFormSubmittable = false;
        setIsLowThresholdValid(false);
        if (portSettingRef.current) {
          (portSettingRef.current as HTMLElement).scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }
      }
      if (!_highThreshold || !_isHighThresholdValid) {
        isFormSubmittable = false;
        setIsHighThresholdValid(false);
        if (portSettingRef.current) {
          (portSettingRef.current as HTMLElement).scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }
      }
      if (!_isThresholdValid) {
        isFormSubmittable = false;
      }
    }

    if (_isSecBandwidthMonitoring) {
      if (
        _secLowThreshold === undefined ||
        isNaN(_secLowThreshold) ||
        !_isSecLowThresholdValid
      ) {
        isFormSubmittable = false;
        setIsSecLowThresholdValid(false);
      }
      if (!_secHighThreshold || !_isSecHighThresholdValid) {
        isFormSubmittable = false;
        setIsSecHighThresholdValid(false);
      }
      if (!_isSecThresholdValid) {
        isFormSubmittable = false;
      }
    }

    if (!_isMtuSizeValid || !_mtuSize) {
      isFormSubmittable = false;
      setIsMtuSizeValid(false);
    }

    if (!_isSecMtuSizeValid || !_secMtuSize) {
      isFormSubmittable = false;
      setIsSecMtuSizeValid(false);
    }

    if (isFormSubmittable) {
      const primaryItem: PortOnlyItem = {
        port_id: _diverseItem?.primaryItem.port_id
          ? _diverseItem.primaryItem.port_id
          : "",
        service_id: _diverseItem?.primaryItem.service_id
          ? _diverseItem.primaryItem.service_id
          : "",
        port_name: _portName.trim(),
        port_description: _portDescription,
        port_speed: _portSpeed,
        port_interface: _portInterface,
        telemetry_streaming: _isTelemetryStreamingEnabled,
        banwidth_monitoring: _isBandwidthMonitoring,
        enable_oversubscription: _isOverSubscription,
        predictive_bandwidth: _isBandwidthMonitoring
          ? _isPredictiveBandwidth
          : false,
        lag: _isLAG,
        mtu_size: _mtuSize,
      };

      if (_isBandwidthMonitoring) {
        primaryItem.low_threshold = _lowThreshold;
        primaryItem.high_threshold = _highThreshold;
      }

      if (_isLAG) {
        primaryItem.number_of_lag_ports = _lagPort;
      }

      const secondaryItem: PortOnlyItem = {
        port_id: _diverseItem?.secondaryItem.port_id
          ? _diverseItem.secondaryItem.port_id
          : "",
        service_id: _diverseItem?.secondaryItem.service_id
          ? _diverseItem.secondaryItem.service_id
          : "",
        port_name: _portName,
        port_description: _secPortDescripition,
        port_speed: _secPortSpeed,
        port_interface: _secPortInterface,
        telemetry_streaming: _isSecTelemetryStreamingEnabled,
        banwidth_monitoring: _isSecBandwidthMonitoring,
        enable_oversubscription: _isSecOverSubscription,
        predictive_bandwidth: _isSecBandwidthMonitoring
          ? _isSecPredictiveBandwidth
          : false,
        lag: _isSecLAG,
        mtu_size: _secMtuSize,
      };

      if (_isSecBandwidthMonitoring) {
        secondaryItem.low_threshold = _secLowThreshold;
        secondaryItem.high_threshold = _secHighThreshold;
      }

      if (_isSecLAG) {
        secondaryItem.number_of_lag_ports = _secLagPort;
      }

      const formItem: DiverseItem = {
        primaryItem,
        secondaryItem,
      };
      TagDataLayerService.pushCtaData("Continue");
      TagDataLayerService.pushPageData("Create PortOnly", "Summary");
      dispatch(updateDiverseItem(formItem));
      dispatch(updateStep(3));
    }
  }, [
    _isPortNameValid,
    _portName,
    _isPortDescripitionValid,
    _portDescription,
    _portSpeed,
    _portInterface,
    _isBandwidthMonitoring,
    _lowThreshold,
    _isThresholdValid,
    _isLowThresholdValid,
    _isHighThresholdValid,
    _highThreshold,
    _isPredictiveBandwidth,
    _isOverSubscription,
    _isLAG,
    _lagPort,
    _mtuSize,
    _isMtuSizeValid,
    _isSecPortDescripitionValid,
    _secPortDescripition,
    _secPortSpeed,
    _secPortInterface,
    _isSecBandwidthMonitoring,
    _secLowThreshold,
    _isSecThresholdValid,
    _secHighThreshold,
    _isSecLowThresholdValid,
    _isSecHighThresholdValid,
    _isSecPredictiveBandwidth,
    _isSecOverSubscription,
    _isSecLAG,
    _secLagPort,
    _secMtuSize,
    _isSecMtuSizeValid,
    _isPrimaryPortSpeedValid,
    _isSecondaryPortSpeedValid,
    _countryValue,
    _locationValue,
    _isTelemetryStreamingEnabled,
    _isSecTelemetryStreamingEnabled,
  ]);

  const _lagOptions = React.useMemo(() => {
    let _portSpeedVal: number = Number(_portSpeed);
    if (!Number(_portSpeed)) {
      _portSpeedVal = parseInt(_portSpeed) * 1000; // Ex: Convert '10 Gbps' to 10000
    }
    return PORT_INTERFACE.find(
      (pi) => Number(pi.port_speed) === _portSpeedVal,
    )?.lag_ports.map((pi) => {
      return { id: `${pi}`, value: `${pi}` };
    });
  }, [_portSpeed]);

  const _secLagOptions = React.useMemo(() => {
    let _portSpeedVal: number = Number(_secPortSpeed);
    if (!Number(_secPortSpeed)) {
      _portSpeedVal = parseInt(_secPortSpeed) * 1000;
    }
    return PORT_INTERFACE.find(
      (pi) => Number(pi.port_speed) === _portSpeedVal,
    )?.lag_ports.map((pi) => {
      return { id: `${pi}`, value: `${pi}` };
    });
  }, [_secPortSpeed]);

  const _interfaceOptions = React.useMemo(() => {
    return PORT_INTERFACE.find(
      (pi) => pi.port_speed == _portSpeed,
    )?.interfaces.map((pi) => {
      return { id: pi, value: pi };
    });
  }, [_portSpeed]);

  const _secInterfaceOptions = React.useMemo(() => {
    return PORT_INTERFACE.find(
      (pi) => pi.port_speed == _secPortSpeed,
    )?.interfaces.map((pi) => {
      return { id: pi, value: pi };
    });
  }, [_secPortSpeed]);

  const _onSelectPortSpeed = (val: string, port = "primary") => {
    if (port === "primary") {
      setPortSpeed(val);
    } else {
      setSecPortSpeed(val);
    }

    const validPIs = PORT_INTERFACE.find((pi) => pi.port_speed == val)
      ?.interfaces;

    const validLagPorts = PORT_INTERFACE.find((pi) => pi.port_speed == val)
      ?.lag_ports;

    if (port === "primary") {
      if (validPIs && !validPIs.includes(_portInterface)) {
        setPortInterface(validPIs[0]);
      }
      if (validLagPorts && !validLagPorts.includes(parseInt(_lagPort))) {
        setLagPort(`${validLagPorts[0]}`);
      }
    }

    if (port === "secondary") {
      if (validPIs && !validPIs.includes(_secPortInterface)) {
        setSecPortInterface(validPIs[0]);
      }
      if (validLagPorts && !validLagPorts.includes(parseInt(_secLagPort))) {
        setSecLagPort(`${validLagPorts[0]}`);
      }
    }
  };

  const _onSelectThreshold = React.useCallback(
    (val: string, threshold: string, port = "primary") => {
      let newVal: string;
      const isNum = val ? /^\d+$/.test(val.replace("%", "")) : false;

      if (val) {
        if (val.includes("%")) {
          const removePercent = val.replace("%", "");
          newVal = `${parseInt(removePercent)}%`;
        } else {
          newVal = `${val}%`;
        }

        const intVal = parseInt(val.replace("%", ""));

        if (threshold === "low") {
          if (isNum && validateRange(intVal, -1, 100)) {
            if (port === "primary") {
              setIsLowThresholdValid(true);
            } else {
              setIsSecLowThresholdValid(true);
            }
          } else {
            if (port === "primary") {
              setIsLowThresholdValid(false);
            } else {
              setIsSecLowThresholdValid(false);
            }
          }
        } else {
          if (isNum && validateRange(intVal, 0, 101)) {
            if (port === "primary") {
              setIsHighThresholdValid(true);
            } else {
              setIsSecHighThresholdValid(true);
            }
          } else {
            if (port === "primary") {
              setIsHighThresholdValid(false);
            } else {
              setIsSecHighThresholdValid(false);
            }
          }
        }
      } else {
        newVal = val;
      }

      if (threshold === "low") {
        if (port === "primary") {
          setLowThreshold(parseInt(val));
          setDisplayLowThreshold(
            _diverseItem?.primaryItem?.low_threshold === 0 &&
              newVal === undefined
              ? "0"
              : newVal,
          );
        } else {
          setSecLowThreshold(parseInt(val));
          setDisplaySecLowThreshold(
            _diverseItem?.secondaryItem?.low_threshold === 0 &&
              newVal === undefined
              ? "0"
              : newVal,
          );
        }
      } else {
        if (port === "primary") {
          setHighThreshold(parseInt(val));
          setDisplayHighThreshold(newVal);
        } else {
          setSecHighThreshold(parseInt(val));
          setDisplaySecHighThreshold(newVal);
        }
      }

      if (port === "primary") {
        if ((_lowThreshold ?? 1) >= (_highThreshold ?? 100)) {
          setIsThresholdValid(false);
        } else {
          setIsThresholdValid(true);
        }
      } else {
        if ((_secLowThreshold ?? 1) >= (_secHighThreshold ?? 100)) {
          setIsSecThresholdValid(false);
        } else {
          setIsSecThresholdValid(true);
        }
      }
    },
    [_lowThreshold, _highThreshold, _secLowThreshold, _secHighThreshold],
  );

  const _onModalOk = () => {
    if (_isInModifyPortMode) {
      navigate("/port-inventory");
    } else {
      navigate("/customer-ports");
    }
    dispatch(updateStep(1));
    dispatch(
      updatePortLocation({
        countryIsoCode: "",
        countryName: "",
        primaryPort: "",
        secondaryPort: "",
      }),
    );
    dispatch(updatePortDiversity(""));
    dispatch(resetPortOnly());
    setShowModal(false);
  };

  React.useEffect(() => {
    if (_diverseItem?.primaryItem.low_threshold) {
      _onSelectThreshold(
        `${_diverseItem.primaryItem.low_threshold}`,
        "low",
        "primary",
      );
    }
    if (_diverseItem?.secondaryItem.low_threshold) {
      _onSelectThreshold(
        `${_diverseItem.secondaryItem.low_threshold}`,
        "low",
        "secondary",
      );
    }
    if (_diverseItem?.primaryItem.high_threshold) {
      _onSelectThreshold(
        `${_diverseItem.primaryItem.high_threshold}`,
        "high",
        "primary",
      );
    }
    if (_diverseItem?.secondaryItem.high_threshold) {
      _onSelectThreshold(
        `${_diverseItem.secondaryItem.high_threshold}`,
        "high",
        "secondary",
      );
    }
  }, [_diverseItem]);

  React.useEffect(() => {
    if (
      !_diverseItem?.primaryItem.port_speed ||
      _diverseItem?.primaryItem.port_speed == ""
    ) {
      if (_portDiversity === PortDiversityType.DiverseSinglePop) {
        if (
          !_selectPortLocation.primaryLocationDisplayLabel ||
          _selectPortLocation.primaryLocationDisplayLabel === ""
        ) {
          setPortSpeed("");
          setSecPortSpeed("");
          setPortInterface("");
          setSecPortInterface("");
          setIsDisablePortSpeed(true);
        } else {
          setIsDisablePortSpeed(false);
        }
      } else {
        if (
          !_selectPortLocation.primaryLocationDisplayLabel ||
          _selectPortLocation.primaryLocationDisplayLabel === "" ||
          !_selectPortLocation.secondaryLocationDisplayLabel ||
          _selectPortLocation.secondaryLocationDisplayLabel === ""
        ) {
          setPortSpeed("");
          setSecPortSpeed("");
          setPortInterface("");
          setSecPortInterface("");
          setIsDisablePortSpeed(true);
        } else {
          setIsDisablePortSpeed(false);
        }
      }
    }
  }, [_selectPortLocation, _diverseItem]);

  React.useEffect(() => {
    if (_portSpeed) {
      setPrimaryIsPortSpeedValid(true);
    }
    if (_secPortSpeed) {
      setSecondaryIsPortSpeedValid(true);
    }
  }, [_portSpeed, _secPortSpeed]);

  React.useEffect(() => {
    TagDataLayerService.pushPageData(
      "Create Port Only",
      "Diverse Configuration",
    );
  }, []);

  React.useEffect(() => {
    if (!_isEdit) {
      setPortSpeed("");
      setSecPortSpeed("");
      setPortInterface("");
      setSecPortInterface("");
      setPortLocation(
        _portDiversity === "diverse-single-pop" ||
          (_locationValue && _diverseValue)
          ? _locationValue
          : "",
      );
    }
    setIsEdit(false);
  }, [_countryValue, _locationValue, _portLocation, _diverseValue]);

  React.useEffect(() => {
    setSelectedPrimaryThreshold("high");
  }, [_highThreshold]);

  React.useEffect(() => {
    setSelectedPrimaryThreshold("low");
  }, [_lowThreshold]);

  React.useEffect(() => {
    setSelectedSecondaryThreshold("high");
  }, [_secHighThreshold]);

  React.useEffect(() => {
    setSelectedSecondaryThreshold("low");
  }, [_secLowThreshold]);

  const usePortLoadingEffect = (
    portSpeed: string,
    setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  ) => {
    const prevPortSpeed = React.useRef<string>();
    React.useEffect(() => {
      setIsLoading(false);

      prevPortSpeed.current = portSpeed;
    }, [portSpeed, setIsLoading]);
  };

  usePortLoadingEffect(_portSpeed, setIsPrimaryPortLoading);
  usePortLoadingEffect(_secPortSpeed, setIsSecondaryPortLoading);
  usePortLoadingEffect(_portInterface, setIsPrimaryInterfaceLoading);
  usePortLoadingEffect(_secPortInterface, setIsSecondaryInterfaceLoading);

  return (
    <section
      className="standard_container diverse_container"
      data-testid="config_diverse"
    >
      <main className="standard_content diverse_content" ref={configurePortRef}>
        <Card width="100%">
          <h2 className="title">Configure Port</h2>
          <Divider margin="xxl" className="divider" />

          <div className="fp-row">
            <div className="col-16 xl:col-8 sm:col-8 md:col-8">
              <form
                id="myform"
                method="get"
                className="standard_form diverse_form"
              >
                <Input
                  className="port_name"
                  name="port_name"
                  label="Diverse Port Name"
                  labelSize="sm"
                  labelTextStyles={"label_styles"}
                  value={_portName}
                  onChange={(val) => {
                    setIsPortNameValid(validateLength(val, 31));
                    setPortName(val.replace("  ", " "));
                  }}
                  state={_isPortNameValid ? "default" : "error"}
                  errorMessage={MAX_NUMBER_OF_CHARACTERS(30)}
                  placeholder={MAX_NUMBER_OF_CHARACTERS(30)}
                  errorMessageSize="sm"
                  showErrorIcon={false}
                />
              </form>
            </div>
            <div className="col-16 xl:col-8 sm:col-8 md:col-8 " />
          </div>

          <div>
            <div className="fp-row mt-16">
              <div className="col-16 xl:col-8 md:col-8 mb-24 md:mb-16">
                <h3 className="port_subtitle">Primary Port</h3>
                <form
                  id="myform"
                  method="get"
                  className="standard_form diverse_form"
                >
                  <Textarea
                    name="port_description"
                    id="port_description"
                    label="Port Description (optional)"
                    value={_portDescription}
                    onChange={(val) => {
                      setIsPortDescriptionValid(validateLength(val, 501));
                      setPortDescription(val);
                    }}
                    state={_isPortDescripitionValid ? "default" : "error"}
                    errorMessage={
                      !_isPortDescripitionValid
                        ? MAX_NUMBER_OF_CHARACTERS(500)
                        : ""
                    }
                    errorMessageSize="sm"
                    showErrorIcon={false}
                    rows={10}
                    placeholder={MAX_NUMBER_OF_CHARACTERS(500)}
                    keepErrorSpace
                  />
                  <Label text="Physical Port Interface" />
                  <div className="group_fields port_interface">
                    <Tooltip
                      content={
                        _isInModifyPortMode
                          ? "Primary Port speed cannot be modified"
                          : ""
                      }
                      placement="bottom"
                    >
                      <DropdownInput
                        name="port_speed"
                        label="Port Speed"
                        value={
                          _isInModifyPortMode
                            ? dataMapper(_portSpeed)
                            : _portSpeed
                        }
                        allowSearch={false}
                        onSelect={_onSelectPortSpeed}
                        options={_selectedPrimaryPortSpeed
                          ?.map((selectedSpeed) => {
                            return {
                              id: selectedSpeed.toString() || "",
                              value: dataMapper(selectedSpeed || 0),
                            };
                          })
                          .sort((a, b) => parseInt(a.id) - parseInt(b.id))}
                        placeholder={
                          !_portSpeed ||
                          (!_selectPortLocation.primaryLocationDisplayLabel &&
                            !_selectPortLocation.secondaryLocationDisplayLabel)
                            ? "Please select a port speed"
                            : ""
                        }
                        state={
                          !_isInModifyPortMode && isPrimaryPortLoading
                            ? "loading"
                            : (_isDisablePortSpeed &&
                                !_diverseItem?.primaryItem.port_speed &&
                                !_portDiversityTransition) ||
                              (!_portDiversityTransition &&
                                _isInModifyPortMode) ||
                              _portLocation === ""
                            ? "disabled"
                            : _isPrimaryPortSpeedValid
                            ? "default"
                            : "error"
                        }
                        errorMessage={
                          _isPrimaryPortSpeedValid
                            ? ""
                            : "Please select a port speed"
                        }
                        showErrorIcon={false}
                        errorMessageSize="sm"
                      />
                    </Tooltip>
                    <Tooltip
                      content={
                        _portSpeed
                          ? _isInModifyPortMode
                            ? "Primary interface cannot be modified"
                            : ""
                          : "Please select port speed before selecting the interface"
                      }
                      placement="bottom"
                    >
                      <DropdownInput
                        name="interface"
                        label="Interface"
                        value={_portInterface}
                        allowSearch={false}
                        onSelect={setPortInterface}
                        options={_interfaceOptions}
                        state={
                          !_isInModifyPortMode && isPrimaryInterfaceLoading
                            ? "loading"
                            : (_portSpeed && !_isInModifyPortMode) ||
                              (_portDiversityTransition && _isInModifyPortMode)
                            ? "default"
                            : "disabled"
                        }
                        placeholder={
                          !_portSpeed ? "Please select an interface" : ""
                        }
                      />
                    </Tooltip>
                  </div>
                </form>
              </div>
              <div className="col-16 xl:col-8 md:col-8 mb-24 md:mb-16">
                <h3 className="port_subtitle">Secondary Port</h3>
                <form
                  id="myform"
                  method="get"
                  className="standard_form diverse_form"
                >
                  <Textarea
                    name="sec_port_description"
                    id="sec_port_description"
                    label="Port Description (optional)"
                    value={_secPortDescripition}
                    onChange={(val) => {
                      setIsSecPortDescriptionValid(validateLength(val, 501));
                      setSecPortDescription(val);
                    }}
                    state={_isSecPortDescripitionValid ? "default" : "error"}
                    errorMessage={
                      !_isSecPortDescripitionValid
                        ? MAX_NUMBER_OF_CHARACTERS(500)
                        : ""
                    }
                    errorMessageSize="sm"
                    showErrorIcon={false}
                    rows={10}
                    placeholder={MAX_NUMBER_OF_CHARACTERS(500)}
                    keepErrorSpace
                  />
                  <Label text="Physical Port Interface" />
                  <div className="group_fields port_interface">
                    <Tooltip
                      content={
                        _isInModifyPortMode
                          ? "Secondary Port speed can be modified"
                          : ""
                      }
                      placement="bottom"
                    >
                      <DropdownInput
                        name="sec_port_speed"
                        label="Port Speed"
                        value={
                          _isInModifyPortMode
                            ? dataMapper(_secPortSpeed)
                            : _secPortSpeed
                        }
                        allowSearch={false}
                        onSelect={(val) => _onSelectPortSpeed(val, "secondary")}
                        options={_selectedSecondaryPortSpeed
                          ?.map((selectedSpeed) => {
                            return {
                              id: selectedSpeed.toString() || "",
                              value: dataMapper(selectedSpeed || 0),
                            };
                          })
                          .sort((a, b) => parseInt(a.id) - parseInt(b.id))}
                        placeholder={
                          !_secPortSpeed ||
                          (!_selectPortLocation.primaryLocationDisplayLabel &&
                            !_selectPortLocation.secondaryLocationDisplayLabel)
                            ? "Please select a port speed"
                            : ""
                        }
                        state={
                          !_isInModifyPortMode && isSecondaryPortLoading
                            ? "loading"
                            : (_isDisablePortSpeed &&
                                !_diverseItem?.secondaryItem.port_speed &&
                                !_portDiversityTransition) ||
                              _portLocation === ""
                            ? "disabled"
                            : _isSecondaryPortSpeedValid
                            ? "default"
                            : "error"
                        }
                        errorMessage={
                          _isSecondaryPortSpeedValid
                            ? ""
                            : "Please select a port speed"
                        }
                        showErrorIcon={false}
                        errorMessageSize="sm"
                      />
                    </Tooltip>
                    <Tooltip
                      content={
                        _portSpeed
                          ? _isInModifyPortMode
                            ? "Secondary interface cannot be modified"
                            : ""
                          : "Please select port speed before selecting the interface"
                      }
                      placement="bottom"
                    >
                      <DropdownInput
                        name="sec_interface"
                        label="Interface"
                        value={_secPortInterface}
                        allowSearch={false}
                        onSelect={setSecPortInterface}
                        options={_secInterfaceOptions}
                        state={
                          !_isInModifyPortMode && isSecondaryInterfaceLoading
                            ? "loading"
                            : (_secPortSpeed && !_isInModifyPortMode) ||
                              (_portDiversityTransition && _isInModifyPortMode)
                            ? "default"
                            : "disabled"
                        }
                        placeholder={
                          !_secPortSpeed ? "Please select an interface" : ""
                        }
                      />
                    </Tooltip>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </Card>

        <Card width="100%">
          <h2 className="title" ref={portSettingRef}>
            Port Setting
          </h2>
          <Divider margin="xxl" className="divider" />
          <div className="fp-row">
            <div className="col-16 xl:col-8 md:col-8 mb-24 md:mb-16">
              <h3 className="port_subtitle">Primary Port</h3>
              <form
                id="myform"
                method="get"
                className="standard_form diverse_form no-gap"
              >
                <div className="group_fields">
                  <TooltipText
                    labelText="Telemetry Streaming Enabled"
                    htmlFor="telemetry_streaming"
                    tooltipContent="Enabling real-time data transfer provides insights to optimise performance and speed up troubleshooting."
                  />
                  <Toggle
                    size="md"
                    checked={_isTelemetryStreamingEnabled}
                    onChange={setIsTelemetryStreamingEnabled}
                  />
                </div>
                <div className="group_fields major">
                  <TooltipText
                    labelText="Bandwidth Utilisation Monitoring"
                    htmlFor="monitoring"
                    tooltipContent="Tracking and optimising the real-time usage of available bandwidth for better performance."
                  />
                  <Toggle
                    size="md"
                    checked={_isBandwidthMonitoring}
                    onChange={setIsBandwidthMonitoring}
                    dataTestId="pri_bandwidth_monitoring_toggle"
                  />
                </div>
                {_isBandwidthMonitoring && (
                  <>
                    <div>
                      <div className="group_fields">
                        <DropdownInput
                          name="low_threshold"
                          className="sm:mb-12"
                          helper="Low threshold"
                          placeholder="0 to 99%"
                          value={_displayedLowThreshold}
                          onSelect={(val) => _onSelectThreshold(val, "low")}
                          onlySelectedValue={false}
                          type="number"
                          state={
                            (_selectedPrimaryThreshold === "low" &&
                              _highThreshold &&
                              _lowThreshold! >= _highThreshold) ||
                            (!_isLowThresholdValid &&
                              _selectedPrimaryThreshold === "low")
                              ? "error"
                              : "default"
                          }
                          errorMessage={
                            !_isLowThresholdValid
                              ? "Out of Range (0 to 99%)"
                              : _selectedPrimaryThreshold === "low" &&
                                _highThreshold &&
                                _lowThreshold! >= _highThreshold
                              ? "Value must be less than max threshold"
                              : ""
                          }
                          errorMessageSize="sm"
                          showErrorIcon={false}
                          options={THRESHOLD_OPTIONS.map((option) =>
                            option.id === "100"
                              ? { id: "99", value: "99%" }
                              : option,
                          )}
                        />
                        <DropdownInput
                          name="high_threshold"
                          helper="High threshold"
                          placeholder="1 to 100%"
                          value={_displayedHighThreshold}
                          onSelect={(val) => _onSelectThreshold(val, "high")}
                          onlySelectedValue={false}
                          type="number"
                          state={
                            (_selectedPrimaryThreshold === "high" &&
                              _lowThreshold &&
                              _lowThreshold >= _highThreshold!) ||
                            (!_isHighThresholdValid &&
                              _selectedPrimaryThreshold === "high") ||
                            (!_isHighThresholdValid && _isLowThresholdValid)
                              ? "error"
                              : "default"
                          }
                          errorMessage={
                            !_isHighThresholdValid
                              ? "Out of Range (1 to 100%)"
                              : _selectedPrimaryThreshold === "high" &&
                                _lowThreshold &&
                                _lowThreshold >= _highThreshold!
                              ? "Value must be greater than min threshold"
                              : ""
                          }
                          showErrorIcon={false}
                          errorMessageSize="sm"
                          options={THRESHOLD_OPTIONS.filter(
                            (a) => a.id !== "0",
                          )}
                        />
                      </div>
                    </div>
                    <div className="group_fields">
                      <TooltipText
                        labelText="Predictive Bandwidth Optimisation"
                        htmlFor="optimization"
                        tooltipContent="Intelligently manages bandwidth based on usage patterns and real-time data."
                      />
                      <Toggle
                        size="md"
                        checked={_isPredictiveBandwidth}
                        onChange={setIsPredictiveBandwidth}
                      />
                    </div>
                  </>
                )}
                <div className="group_fields major">
                  <TooltipText
                    labelText="Enable Oversubscription"
                    htmlFor="oversubscription"
                    tooltipContent="Enabling oversubscription allows you to use network speed faster than one or all services need at the same time on a port."
                  />
                  <Toggle
                    size="md"
                    checked={!!_isOverSubscription}
                    onChange={setIsOverSubscription}
                  />
                </div>
                <div className="group_fields lag">
                  <div className="lag-message-box">
                    <Label text="Link Aggregation Group (LAG)" />
                    <div className="lag-message">
                      Configuring LAG upfront will avoid unnecessary downtime if
                      multiple connections in a LAG are later required.
                    </div>
                  </div>
                  <Tooltip
                    content={
                      _isInModifyPortMode
                        ? "Primary LAG cannot be modified"
                        : ""
                    }
                    placement="top"
                  >
                    <Toggle
                      size="md"
                      checked={_isLAG}
                      onChange={setIsLAG}
                      checkedTitle="Yes"
                      unCheckedTitle="No"
                    />
                  </Tooltip>
                </div>
                {_isLAG && (
                  <DropdownInput
                    name="lag_port_number"
                    label="Select the maximum number of LAG ports allowed in a bundle."
                    value={_lagPort}
                    allowSearch={false}
                    onSelect={setLagPort}
                    options={_lagOptions}
                    state={!_portSpeed ? "disabled" : "default"}
                    className="lag-dropdown"
                  />
                )}
                <div className="mtu-section">
                  <div className="group_fields">
                    <div className="tooltip_text mtu_size">
                      <Label text="Standard MTU" />
                      <Tooltip
                        content="The default MTU size is 9216 bytes."
                        placement="bottom"
                      >
                        <Icon
                          title="info_alt"
                          size="sm"
                          className="tooltip_icon"
                        />
                      </Tooltip>
                    </div>
                  </div>
                  <div className="input-section">
                    <Tooltip
                      content="The default MTU size is 9216 bytes."
                      placement="bottom"
                    >
                      <Input
                        name="mtu_size"
                        className="mtu_input"
                        type="number"
                        placeholder="Default MTU Size is 9216"
                        state={"disabled"}
                        showErrorIcon={false}
                        value={`${_mtuSize}`}
                      />
                    </Tooltip>
                  </div>
                </div>
              </form>
            </div>
            <div className="col-16 xl:col-8 md:col-8 mb-24 md:mb-16">
              <h3 className="port_subtitle">Secondary Port</h3>
              <form
                id="myform"
                method="get"
                className="standard_form diverse_form no-gap"
              >
                <div className="group_fields">
                  <TooltipText
                    labelText="Telemetry Streaming Enabled"
                    htmlFor="sec_telemetry_streaming"
                    tooltipContent="Enabling real-time data transfer provides insights to optimise performance and speed up troubleshooting."
                  />
                  <Toggle
                    size="md"
                    checked={_isSecTelemetryStreamingEnabled}
                    onChange={setIsSecTelemetryStreamingEnabled}
                  />
                </div>
                <div className="group_fields major">
                  <TooltipText
                    labelText="Bandwidth Utilisation Monitoring"
                    htmlFor="sec_monitoring"
                    tooltipContent="Tracking and optimising the real-time usage of available bandwidth for better performance."
                  />
                  <Toggle
                    size="md"
                    checked={_isSecBandwidthMonitoring}
                    onChange={setIsSecBandwidthMonitoring}
                    dataTestId="sec_bandwidth_monitoring_toggle"
                  />
                </div>
                {_isSecBandwidthMonitoring && (
                  <>
                    <div>
                      <div className="group_fields">
                        <DropdownInput
                          name="sec_low_threshold"
                          className="sm:mb-12"
                          helper="Low threshold"
                          placeholder="0 to 99%"
                          value={_displayedSecLowThreshold}
                          onSelect={(val) =>
                            _onSelectThreshold(val, "low", "secondary")
                          }
                          onlySelectedValue={false}
                          type="number"
                          state={
                            (_selectedSecondaryThreshold === "low" &&
                              _secHighThreshold &&
                              _secLowThreshold! >= _secHighThreshold) ||
                            (!_isSecLowThresholdValid &&
                              _selectedSecondaryThreshold === "low")
                              ? "error"
                              : "default"
                          }
                          errorMessage={
                            !_isSecLowThresholdValid
                              ? "Out of Range (0 to 99%)"
                              : _selectedSecondaryThreshold === "low" &&
                                _secHighThreshold &&
                                _secLowThreshold! >= _secHighThreshold
                              ? "Value must be less than max threshold"
                              : ""
                          }
                          errorMessageSize="sm"
                          showErrorIcon={false}
                          options={THRESHOLD_OPTIONS.map((option) =>
                            option.id === "100"
                              ? { id: "99", value: "99%" }
                              : option,
                          )}
                        />
                        <DropdownInput
                          name="sec_high_threshold"
                          helper="High threshold"
                          placeholder="1 to 100%"
                          value={_displayedSecHighThreshold}
                          onSelect={(val) =>
                            _onSelectThreshold(val, "high", "secondary")
                          }
                          onlySelectedValue={false}
                          type="number"
                          state={
                            (_selectedSecondaryThreshold === "high" &&
                              _secLowThreshold &&
                              _secLowThreshold >= _secHighThreshold!) ||
                            (!_isSecHighThresholdValid &&
                              _selectedSecondaryThreshold === "high") ||
                            (!_isSecHighThresholdValid &&
                              _isSecLowThresholdValid)
                              ? "error"
                              : "default"
                          }
                          errorMessage={
                            !_isSecHighThresholdValid
                              ? "Out of Range (1 to 100%)"
                              : _selectedSecondaryThreshold === "high" &&
                                _secLowThreshold &&
                                _secLowThreshold >= _secHighThreshold!
                              ? "Value must be greater than min threshold"
                              : ""
                          }
                          showErrorIcon={false}
                          errorMessageSize="sm"
                          options={THRESHOLD_OPTIONS.filter(
                            (a) => a.id !== "0",
                          )}
                        />
                      </div>
                    </div>
                    <div className="group_fields">
                      <TooltipText
                        labelText="Predictive Bandwidth Optimisation"
                        htmlFor="sec_optimization"
                        tooltipContent="Intelligently manages bandwidth based on usage patterns and real-time data."
                      />
                      <Toggle
                        size="md"
                        checked={_isSecPredictiveBandwidth}
                        onChange={setIsSecPredictiveBandwidth}
                      />
                    </div>
                  </>
                )}
                <div className="group_fields major">
                  <TooltipText
                    labelText="Enable Oversubscription"
                    htmlFor="sec_oversubscription"
                    tooltipContent="Enabling oversubscription allows you to use network speed faster than one or all services need at the same time on a port."
                  />
                  <Toggle
                    size="md"
                    checked={_isSecOverSubscription}
                    onChange={setIsSecOverSubscription}
                  />
                </div>
                <div className="group_fields lag">
                  <div className="lag-message-box">
                    <Label text="Link Aggregation Group (LAG)" />
                    <div className="lag-message">
                      Configuring LAG upfront will avoid unnecessary downtime if
                      multiple connections in a LAG are later required.
                    </div>
                  </div>
                  <Tooltip
                    content={
                      _isInModifyPortMode
                        ? "Secondary LAG cannot be modified"
                        : ""
                    }
                    placement="top"
                  >
                    <Toggle
                      size="md"
                      checked={_isSecLAG}
                      onChange={setIsSecLAG}
                      checkedTitle="Yes"
                      unCheckedTitle="No"
                    />
                  </Tooltip>
                </div>
                {_isSecLAG && (
                  <DropdownInput
                    name="sec_lag_port_number"
                    label="Select the maximum number of LAG ports allowed in a bundle."
                    value={_secLagPort}
                    allowSearch={false}
                    onSelect={setSecLagPort}
                    placeholder="Select No of LAG ports"
                    options={_secLagOptions}
                    state={!_secPortSpeed ? "disabled" : "default"}
                    className="lag-dropdown"
                  />
                )}
                <div className="mtu-section">
                  <div className="group_fields">
                    <div className="tooltip_text mtu_size">
                      <Label text="Standard MTU" />
                      <Tooltip
                        content="The default MTU size is 9216 bytes."
                        placement="bottom"
                      >
                        <Icon
                          title="info_alt"
                          size="sm"
                          className="tooltip_icon"
                        />
                      </Tooltip>
                    </div>
                  </div>
                  <div className="input-section">
                    <Tooltip
                      content="The default MTU size is 9216 bytes."
                      placement="bottom"
                    >
                      <Input
                        name="sec_mtu_size"
                        type="number"
                        placeholder="Default MTU Size is 9216"
                        state={"disabled"}
                        showErrorIcon={false}
                        value={`${_secMtuSize}`}
                        className="mtu-input"
                      />
                    </Tooltip>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </Card>
      </main>
      <div className="buttons_container mt-24">
        <Button
          label="Back"
          variant="link"
          onPress={() => setShowModal(true)}
          dataTestId="back_btn"
        />
        <Button
          label="Continue"
          variant="gradient"
          onPress={_onContinue}
          dataTestId="continue_btn"
        />
      </div>
      <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        topIconSize="md"
        title="Leave without saving changes"
        complementaryMessage="Are you sure you want to leave this page? Your setup information will be lost."
        contentAlign="center"
        actionText="Leave"
        onOk={_onModalOk}
        closeModal={!_showModal}
        onCancel={() => setShowModal(false)}
        outsideClose={true}
      />
    </section>
  );
};

export default ConfigDiverse;
