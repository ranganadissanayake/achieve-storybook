import { Label } from "@btdigital/nayan-component-library";
import React from "react";
import images from "../../../../../shared/assets";
import "./SelectLocationHeader.scss";

export interface SelectLocationHeaderProps {
  title?: string;
}

const SelectLocationHeader: React.FC<SelectLocationHeaderProps> = ({
  title = "Port Diversity",
}) => {
  return (
    <div className="header-wrapper mt-8" data-testid="header-wrapper">
      <div className="header-image">
        <img src={images.createPort} alt="Edit Port Image" srcSet="" />
      </div>
      <div className="header-content">
        <Label text={title} />
        <div className="header-content--caption">
          <p>
            Visit <span>BT Cloud Fabric Knowledge center</span> for more
            information on port resilience.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SelectLocationHeader;
