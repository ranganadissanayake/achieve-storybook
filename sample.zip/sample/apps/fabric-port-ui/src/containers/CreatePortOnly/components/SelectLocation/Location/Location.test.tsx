import React from "react";
import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import Location from "./index";
import { useDispatch, useSelector } from "react-redux";
import { useApi } from "../../../../../shared/helpers/api";

jest.mock("react-redux", () => ({
  useDispatch: jest.fn() as () => jest.Mock,
  useSelector: jest.fn() as () => jest.Mock,
}));

jest.mock("../../../../../shared/helpers/api", () => ({
  useApi: jest.fn(),
}));
jest.mock("@btdigital/nayan-component-library", () => ({
  Card: jest.fn(({ children }) => <div>{children}</div>),
  Label: jest.fn(({ text }) => <span>{text}</span>),
  DropdownInput: jest.fn(
    ({ label, name, placeholder, onSelect, options, value }) => (
      <div>
        <label>{label}</label>
        <input
          type="text"
          name={name}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onSelect(e.target.value)}
        />
      </div>
    )
  ),
  Container: jest.fn(({ children }) => <div>{children}</div>),
  ContainerRow: jest.fn(({ children }) => <div>{children}</div>),
  Column: jest.fn(({ children }) => <div>{children}</div>),
  useToast: jest.fn(() => ({
    addToast: jest.fn(),
  })),
}));
describe("Location Component", () => {
  const updateLocation = jest.fn();
  beforeEach(() => {
    (useSelector as jest.Mock).mockReturnValue({
      countryIsoCode: "US",
      primaryPort: "1",
      secondaryPort: "2",
      geolocations: {
        geoLocationDetails: [
          { isoCode: "AU", countryName: "Australia", metro: [] },
        ],
      },
    });

    (useDispatch as jest.Mock).mockReturnValue(jest.fn());

    (useApi as jest.Mock).mockReturnValue({
      getBtSites: jest.fn().mockResolvedValue([
        {
          siteId: "AUMELA004",
          siteType: {
            btPop: true,
            dataCentre: true,
          },
          facilityProvider: "Equinix",
          facilityName: "Equinix ME1 Data Centre",
          facilityAddress: {
            siteAddressLine1: "578",
            siteAddressLine2: "LORIMER STREET",
            city: "MELBOURNE",
            countyOrState: "VICTORIA",
            postcode: "3207",
            country: "Australia",
            latitude: -37.8230112,
            longitude: 144.9153835,
          },
          products: {
            customerPorts: {
              portOnly: [1000, 10000, 25000, 100000],
              dataCentreConnection: [1000, 10000, 100000],
              customerPremises: [
                {
                  lowPortSpeed: 1,
                },
                {
                  highPortSpeed: 100000,
                },
              ],
            },
            networkServices: {
              ipVPN: true,
              internet: true,
              eLine: true,
              ipRegionCode: "AU-01",
            },
          },
        },
      ]),
    });
  });
  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders Location component correctly", async () => {
    render(<Location countryList={[]} onLocationUpdate={updateLocation} />);

    expect(screen.getByText("Select Location")).toBeInTheDocument();
  });
  test("renders Location component correctly", () => {
    (useSelector as jest.Mock).mockReturnValue({
      country: "US",
      primaryPort: "1",
      primaryLocationDisplayLabel: "Port Location 1",
    });

    (useApi as jest.Mock).mockReturnValue({
      getBtSites: jest.fn().mockResolvedValue({
        result: [
          {
            siteId: "1",
            siteName: "Port Location 1",
            city: "City 1",
            country: "Country 1",
            siteAddressLine1: "Address Line 1",
            siteAddressLine2: "Address Line 2",
          },
        ],
      }),
    });

    render(<Location countryList={[]} onLocationUpdate={updateLocation} />);

    expect(screen.getByText("Select Location")).toBeInTheDocument();
    expect(screen.getByText("Country")).toBeInTheDocument();
  });

  test("updates Redux store on country selection", () => {
    const mockDispatch = jest.fn();
    (useDispatch as jest.Mock).mockReturnValue(mockDispatch);

    render(
      <Location
        countryList={["US", "UK", "AU"]}
        onLocationUpdate={updateLocation}
      />
    );
  });
  test("displays error toast when API call fails", async () => {
    const mockApi = useApi as jest.Mock;
    const mockBtSites = jest.fn().mockRejectedValue(new Error("API Error"));
    mockApi.mockReturnValue({ getBtSites: mockBtSites });

    render(
      <Location
        countryList={["US", "UK", "AU"]}
        onLocationUpdate={updateLocation}
      />
    );

    await waitFor(() => expect(mockBtSites).toHaveBeenCalled());
  });
  test("displays an error message when selecting an invalid country", () => {
    render(
      <Location
        countryList={["US", "UK", "AU"]}
        onLocationUpdate={updateLocation}
      />
    );
    const countryInput = screen.getByPlaceholderText("Search Country");

    fireEvent.change(countryInput, { target: { value: "InvalidCountry" } });

    expect(screen.getByText("Port Location")).toBeInTheDocument();
  });
  test("Can select map props", () => {
    render(
      <Location
        countryList={["US", "UK", "AU"]}
        onLocationUpdate={updateLocation}
        onPressNext={jest.fn()}
        onSetMapData={jest.fn()}
        onSetMapPropsData={jest.fn()}
      />
    );
    const countryInput = screen.getByPlaceholderText("Search Country");

    fireEvent.change(countryInput, { target: { value: "AU" } });

    const portInpurt = screen.getByPlaceholderText("Search Port");

    fireEvent.change(portInpurt, { target: { value: "1" } });

    expect(screen.getByText("Port Location")).toBeInTheDocument();
  });
});
