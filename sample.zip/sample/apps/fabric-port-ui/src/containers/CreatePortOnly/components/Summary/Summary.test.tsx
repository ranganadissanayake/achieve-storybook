import React from "react";
import * as router from "react-router";
import { act, fireEvent, screen, waitFor } from "@testing-library/react";
import { BrowserRouter as Router } from "react-router-dom";
import { RootState } from "../../../../redux/store";
import {
  renderWithProviders,
  testPreloadedStatePortOnly,
  testPreloadedStatePortOnlyModify
} from "../../../../shared/helpers";
import { useApi } from "../../../../shared/helpers/api";
import { TEST_BILLING_ACCOUNTS } from "../../../../shared/constants/common";
import Summary from "./index";

const navigate = jest.fn();

jest.mock("../../../../shared/helpers/api", () => ({
  useApi: jest.fn(),
}));

describe("Summary component", () => {
  beforeAll(() => {
    jest.spyOn(router, "useNavigate").mockImplementation(() => navigate);
  });

  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getBillingAccounts: jest.fn().mockResolvedValue(TEST_BILLING_ACCOUNTS),
      getPortAPricing: jest.fn().mockResolvedValue({
        primaryPortPrice: {
          oneTimePrice: 100,
          recurringMonthlyPrice: 200,
        },
        secondaryPortPrice: {
          oneTimePrice: 100,
          recurringMonthlyPrice: 200,
        },
      }),
    });
  });
  afterEach(() => {
    jest.clearAllMocks();
  });

  it("should able to expand the advanced settings", async () => {
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnly as unknown as RootState,
        }
      );
    });

    const advancedSettingButton = await screen.findByText("Advanced Settings");
    fireEvent.click(advancedSettingButton);
    expect(screen.getByTestId("summary_standard")).toBeInTheDocument();
  });

  it("displays the billing account dropdown with no value", async () => {
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnly as unknown as RootState,
        }
      );
    });

    expect(screen.getByText("Select Billing Account")).toBeInTheDocument();

    const [billingDropdown] = await screen.getAllByPlaceholderText("Select");
    expect(billingDropdown).toBeInTheDocument();
    expect(billingDropdown).toHaveValue("");
  });

  it("displays the billing account dropdown with default value", async () => {
    await act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: {
            ...testPreloadedStatePortOnly,
            portOnly: { ...testPreloadedStatePortOnly.portOnly, countryValue: "AU" },
          } as unknown as RootState,
        }
      );
    });

    await waitFor(() => {
      expect(screen.getByText("Select Billing Account")).toBeInTheDocument();

      const [billingDropdown] = screen.getAllByPlaceholderText("Select");
      expect(billingDropdown).toBeInTheDocument();
      expect(billingDropdown).toHaveValue("");
    });
  });

  it("displays the billing account dropdown values when clicked on", async () => {
    await act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: {
            ...testPreloadedStatePortOnly,
            portOnly: { ...testPreloadedStatePortOnly.portOnly, countryValue: "AU" },
          } as unknown as RootState,
        }
      );
    });

    await waitFor(() => {
      const [billingDropdown] = screen.getAllByPlaceholderText("Select");
      fireEvent.click(billingDropdown);
      const dropOptions = screen.getAllByTestId("dropdown-option");
      expect(dropOptions).toHaveLength(4);
    });
  });

  it("displays purchase order select dropdown if purchase orders available", async () => {
    await act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: {
            ...testPreloadedStatePortOnly,
            portOnly: { ...testPreloadedStatePortOnly.portOnly, countryValue: "AU" },
          } as unknown as RootState,
        }
      );
    });

    await waitFor(() => {
      const [billingDropdown] = screen.getAllByPlaceholderText("Select");
      fireEvent.click(billingDropdown);

      const dropOptions = screen.getAllByTestId("dropdown-option");
      fireEvent.click(dropOptions[3]);

      expect(screen.getByTestId("purchase-order-select")).toBeInTheDocument();
      expect(screen.getByText("Select Purchase Order")).toBeInTheDocument();
    });
  });

  it("should render when only primary port pricing provided", async () => {
    (useApi as jest.Mock).mockReturnValue({
      getPortAPricing: jest.fn().mockResolvedValue({
        primaryPortPrice: {
          oneTimePrice: 100,
          recurringMonthlyPrice: 200,
        },
      }),
    });

    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnly as unknown as RootState,
        }
      );
    });

    const deploy = await screen.findByText("Order");
    fireEvent.click(deploy);
    expect(screen.getByTestId("summary_standard")).toBeInTheDocument();
  });

  it("should render when only secondary port pricing provided", async () => {
    (useApi as jest.Mock).mockReturnValue({
      getPortAPricing: jest.fn().mockResolvedValue({
        secondaryPortPrice: {
          oneTimePrice: 100,
          recurringMonthlyPrice: 200,
        },
      }),
    });

    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnly as unknown as RootState,
        }
      );
    });

    const deploy = await screen.findByText("Order");
    fireEvent.click(deploy);
    expect(screen.getByTestId("summary_standard")).toBeInTheDocument();
  });

  it("should able to deploy port properly", async () => {
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnly as unknown as RootState,
        }
      );
    });

    const deploy = await screen.findByText("Order");
    fireEvent.click(deploy);
    expect(screen.getByTestId("summary_standard")).toBeInTheDocument();
  });

  it("should able to update port properly", async () => {
    const portOnlyDataModify = {
      ...testPreloadedStatePortOnly.portOnly,
      isInModifyPortMode: true,
    };
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: {
            portOnly: portOnlyDataModify,
          } as unknown as RootState,
        }
      );
    });
    const updateButton = await screen.findByText("Update");
    fireEvent.click(updateButton);
    expect(screen.getByTestId("summary_standard")).toBeInTheDocument();
  });

  it("should able to update port properly diverse", async () => {
    const portOnlyDataModify = {
      ...testPreloadedStatePortOnly.portOnly,
      isInModifyPortMode: true,
      diversityTransition: "",
    };
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: {
            portOnly: portOnlyDataModify,
          } as unknown as RootState,
        }
      );
    });
    const updateButton = await screen.findByText("Update");
    fireEvent.click(updateButton);
    expect(screen.getByTestId("summary_standard")).toBeInTheDocument();
  });

  it("should able to update port properly diverse diverse-single-pop->standard-single-pop transition", async () => {
    const portOnlyDataModify = {
      ...testPreloadedStatePortOnly.portOnly,
      isInModifyPortMode: true,
      diversityTransition: "diverse-single-pop->standard-single-pop",
    };
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: {
            portOnly: portOnlyDataModify,
          } as unknown as RootState,
        }
      );
    });
    const updateButton = await screen.findByText("Update");
    fireEvent.click(updateButton);
    expect(screen.getByTestId("summary_standard")).toBeInTheDocument();
  });

  it("should able to edit", async () => {
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnly as unknown as RootState,
        }
      );
    });
    const editButton = await screen.findByText("Edit");
    fireEvent.click(editButton);
    expect(navigate).toHaveBeenCalledWith("/create-port-only");
  });

  it("should handle pricing error", async () => {
    jest.clearAllMocks();
    (useApi as jest.Mock).mockReturnValue({
      getPortAPricing: jest.fn().mockRejectedValue({}),
    });
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnly as unknown as RootState,
        }
      );
    });
    expect(await screen.findByTestId("summary_standard")).toBeInTheDocument();
  });

  it("should able to cancel the modify journey", async () => {
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnly as unknown as RootState,
        }
      );
    });
    const cancelButton = await screen.findByText("Cancel");
    fireEvent.click(cancelButton);
    expect(
      screen.getByText(
        "Are you sure you want to leave this page? Your setup information will be lost."
      )
    ).toBeInTheDocument();
    fireEvent.click(await screen.findByText("Leave"));
    expect(screen.getByTestId("summary_standard")).toBeInTheDocument();
  });

  it("Clicking on 'I accept' in terms and conditions", async () => {
    let contain;
    act(() => {
      const { container } = renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnly as unknown as RootState,
        }
      );
      contain = container;
    });

    const gfTerms = await screen.findByTestId("gfTerms");
    fireEvent.scroll(gfTerms, { target: { scrollY: 1000 } });
    const accept = await screen.findAllByText(/I accept/i);
    fireEvent.click(accept[1]);
    const disabledBtn = contain!.querySelector(".btn-disabled");
    expect(disabledBtn).not.toBeInTheDocument();
    const summary = await screen.findAllByText(/I accept/i);
    expect(summary[0]).toBeInTheDocument();
  });

  it("Click on Update Button", async () => {
    act(() => {
      renderWithProviders(
        <Router>
          <Summary />
        </Router>,
        {
          preloadedState: testPreloadedStatePortOnlyModify as unknown as RootState,
        }
      );
    });
    const termsDiv = screen.getByText("Terms & Conditions:").closest("div");
    expect(termsDiv).toBeInTheDocument();
    termsDiv &&
      fireEvent.scroll(termsDiv, {
        target: { scrollingElement: { scrollTop: 473 } },
      });
    const acceptButton = await screen.findByText("I accept");
    fireEvent.click(acceptButton);
    
    await waitFor(() => {
      const updateButton = screen.getByTestId("add_to_basket_btn");
      fireEvent.click(updateButton);
      setTimeout(() => {
        expect(navigate).toHaveBeenCalledWith("/port-a-modify-deployment", {state: {
          isDeployAllRequest: false,
          oneTimePrice: 0,
          recurringPrice: 0,
        }});
      }, 300);
    });
  });
});
