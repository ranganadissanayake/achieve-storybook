import React from "react";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { render, screen, act, waitFor } from "@testing-library/react";
import configureMockStore from "redux-mock-store";

import PortAModifyDeployment from "./index";
import { useApi } from "../../../../../../shared/helpers";
import "regenerator-runtime";

const mockStore = configureMockStore();

jest.mock("../../../../../../shared/helpers");

const portOnly = {
  hasPorts: false,
  portDiversity: "",
  currentStep: 1,
  resilience: "diverse",
  portLocation: {
    countryIsoCode: "",
    countryName: "",
    primaryPort: "",
    secondaryPort: "",
    primaryLocationDisplayLabel: "",
    secondaryLocationDisplayLabel: "",
  },
  primaryPortSpeed: [1000, 10000, 25000, 100000],
  secondaryPortSpeed: [],
  isDeploymentRequestEnabled: false,
  isInModifyPortMode: false,
  isUpdatetRequestEnabled: true,
  portStatus: "active",
  diversityTransition: "",
  countryCheck: false,
  locationCheck: false,
  locationCheckDiverse: false,
  countryValue: "AU",
  locationValue: "",
  locationValueDiverse: "",
  standardItemOriginal: {
    port_id: "02i3L000008KoVdQAK",
    port_name: "LAG",
    port_description: "Test LAG enabled port",
    banwidth_monitoring: true,
    telemetry_streaming: false,
    enable_oversubscription: false,
    lag: true,
    predictive_bandwidth: false,
    mtu_size: 9216,
    port_interface: "10GBASE-ER",
    port_speed: "10000",
    number_of_lag_ports: 3,
    low_threshold: 10,
    high_threshold: 80,
  },
  standardItem: {
    port_id: "02i3L000008KoVdQAK",
    port_name: "LAGadsfasdf",
    port_description: "Test LAG enabled port",
    port_speed: "10 Gbps",
    port_interface: "10GBASE-ER",
    telemetry_streaming: false,
    banwidth_monitoring: true,
    predictive_bandwidth: false,
    enable_oversubscription: false,
    lag: true,
    mtu_size: 9216,
    low_threshold: 10,
    high_threshold: 80,
    number_of_lag_ports: 3,
  },
};

const billingAccounts = {
  billingAccountDetails: {
    customerID: "29055",
    customerName: "CSA-29055",
    billingAccounts: [
      {
        id: "0013L00000WLYrAQAX",
        name: "BAC-0013L00000WLYrAQAX",
        currency: "GBP",
        default: true,
      },
      {
        id: "0014L00000WLYrAQAY",
        name: "DAC-0014L00000WLYrAQAY",
        currency: "GBP",
        default: false,
      },
      {
        id: "b100",
        name: "Hindustan Unilever Ltd Account",
        currency: "INR",
        default: false,
        customerPurchaseOrder: [
          {
            purchaseOrderNumber: "112414",
            purchaseOrderName: "PO1",
            purchaseOrderType: "mrc",
          },
        ],
      },
      {
        id: "b400",
        name: "Unilever UK Account",
        currency: "GBP",
        default: false,
        customerPurchaseOrder: [
          {
            purchaseOrderNumber: "112414",
            purchaseOrderName: "PO1",
            purchaseOrderType: "mrc",
          },
          {
            purchaseOrderNumber: "112417",
            purchaseOrderName: "PO2",
            purchaseOrderType: "nrc",
          },
        ],
      },
    ],
  },

  selectedBillingAccount: {
    billingAccountId: "b100",
  },
  selectedCustomerPurchaseOrder: {
    purchaseOrderNumber: "",
    purchaseOrderName: "",
    purchaseOrderType: "",
  },
};

describe("PortAModifyDeployment", () => {
  const store = mockStore({ portOnly, billingAccounts });
  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      updatePortStatus: jest.fn().mockResolvedValue({
        result: {
          externalId: "8F5q6prx-xdKV-1Kt8-Aoyy-DnjeQpeWAGKj",
          productOrderItem: [
            {
              id: "8F5q6prx-xdKV-1Kt8-Aoyy-DnjeQpeWAGKj",
              action: "add",
            },
          ],
          state: "acknowledged",
          type: "ProductOrder",
          serviceId: "Sinprefix-YY-90000-00001",
          requestId: "BTC1234567",
        }
      }),
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("Render the appropriate message", async () => {
    await act(async () => {
      render(
        <Provider store={store}>
          <BrowserRouter>
            <PortAModifyDeployment />
          </BrowserRouter>
        </Provider>
      );
    });

    expect(screen.getByText("Create a New Port")).toBeInTheDocument();
    expect(
      screen.getByText(
        "Meanwhile, you can check your deployment status in your Port Inventory"
      )
    ).toBeInTheDocument();

    expect(
      await waitFor(() =>
        screen.getByText(
          "This is your Request ID: BTC1234567 for modification of this Service ID: Sinprefix-YY-90000-00001. These ID's can be used in Service Now to Support any questions regarding this modification."
        )
      )
    ).toBeInTheDocument();
  });
});
