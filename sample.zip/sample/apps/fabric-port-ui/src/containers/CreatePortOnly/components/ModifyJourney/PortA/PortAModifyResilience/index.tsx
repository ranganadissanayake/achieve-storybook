import {
  Card,
  Divider,
  Button,
  Label,
} from "@btdigital/nayan-component-library";
import React from "react";
import "./PortAModifyResilience.scss";
import { PortDiversityOptions } from "redux/portOnlySlice";
import Tooltip from "../../../../../../components/TooltipV2";

export interface IPortAModifyResilience {
  isNonDiverse: boolean;
  isDiverseSingle: boolean;
  isDiverseDual: boolean;
  onChangeDiversity: (diversity: PortDiversityOptions) => void;
  isModify: boolean;
}
const PortAModifyResilience: React.FC<IPortAModifyResilience> = ({
  isNonDiverse,
  isDiverseDual,
  isDiverseSingle,
  onChangeDiversity,
  isModify,
}) => {
  return (
    <>
      <Card width="100%" height="100%">
        <div className="card-content-wrapper" data-testid="port-res-wrapper">
          <div className="main-title">
            <Label text="Port Resilience" size="lg"></Label>
          </div>
          <div className="description">
            Visit <span>BT Global Fabric knowledge centre</span> for more
            information on ports connection.
          </div>
          <Divider className="resilience-divider"/>
          <div className="actions-wrapper">
            <div className="action-title">Resilience </div>
            <div className="action-items">
              <div className="item-row-above">
                <Tooltip
                  content={
                    isModify
                      ? "Resilience cannot be modified"
                      : ""
                  }
                  placement="top"
                >
                  <Button
                    label="Non-Diverse"
                    iconBefore
                    iconTitle={isNonDiverse ? "radio_checked" : "radio_unchecked"}
                    className={`btn-action ${isModify ? "button-disabled" : ""}`}
                    size="medium"
                    iconSize="sm"
                    variant={isNonDiverse || isModify ? "solid" : "outline"}
                    onPress={() => onChangeDiversity("standard-single-pop")}
                    disabled={isModify}
                  />
                </Tooltip>
                {isModify && (
                  <Tooltip
                    content={
                      isModify
                        ? "Resilience cannot be modified"
                        : ""
                    }
                    placement="top"
                  >
                    <Button
                      label="Diverse"
                      iconBefore
                      variant={"solid"}
                      iconTitle={
                        isDiverseSingle || isDiverseDual
                          ? "radio_checked"
                          : "radio_unchecked"
                      }
                      className={`btn-action ${isModify ? "button-disabled" : ""
                        }`}
                      size="medium"
                      iconSize="sm"
                      onPress={() => { }}
                      disabled={isModify}
                    />
                  </Tooltip>
                )}
              </div>
              {!isModify && (
                <>
                  <div className="item-row-above">
                    <Button
                      label="Diverse-Single PoP"
                      iconBefore
                      variant={isDiverseSingle ? "solid" : "outline"}
                      iconTitle={
                        isDiverseSingle ? "radio_checked" : "radio_unchecked"
                      }
                      className="btn-action"
                      size="medium"
                      iconSize="sm"
                      onPress={() => onChangeDiversity("diverse-single-pop")}
                    ></Button>
                  </div>
                  <div className="item-row-above">
                    <Button
                      label="Diverse-Dual PoP"
                      iconBefore
                      variant={isDiverseDual ? "solid" : "outline"}
                      iconTitle={
                        isDiverseDual ? "radio_checked" : "radio_unchecked"
                      }
                      className="btn-action"
                      size="medium"
                      iconSize="sm"
                      onPress={() => onChangeDiversity("diverse-dual-pop")}
                    ></Button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </Card>
    </>
  );
};

export default PortAModifyResilience;
