import React from "react";
import { useNavigate } from "react-router-dom";

import { useDispatch, useSelector } from "react-redux";
import {
  Card,
  Divider,
  Input,
  Label,
  Textarea,
  Toggle,
  DropdownInput,
  Button,
  Modal,
  Icon,
} from "@btdigital/nayan-component-library";

import {
  updateStandardItem,
  updateStep,
  selectStandardItem,
  updatePortLocation,
  selectPrimaryPortSpeed,
  selectPortLocation,
  updatePortDiversity,
  resetPortOnly,
  selectIsInModifyPortMode,
  selectDiversityTransition,
  selectLocationValue,
  selectCountryValue,
  updateLocationCheck,
  updateCountryCheck,
} from "../../../../redux/portOnlySlice";
import { PortOnlyItem } from "../../../../shared/types";
import {
  THRESHOLD_OPTIONS,
  PORT_INTERFACE,
  MAX_NUMBER_OF_CHARACTERS,
} from "../../../../shared/constants";
import {
  validateLength,
  validateRange,
  dataMapper,
} from "../../../../shared/utils";
import Tooltip from "../../../../components/TooltipV2";
import TagDataLayerService from "../../../../shared/services/TagDatalayer.service";
import TooltipText from "../../../../components/TooltipText";

import "./ConfigStandard.scss";

export interface ConfigStandardProps {}

const ConfigStandard: React.FC<ConfigStandardProps> = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const _standardItem = useSelector(selectStandardItem);
  const _selectedPortSpeed = useSelector(selectPrimaryPortSpeed);
  const _selectPortLocation = useSelector(selectPortLocation);

  const _countryValue = useSelector(selectCountryValue);
  const _locationValue = useSelector(selectLocationValue);

  const [_isEdit, setIsEdit] = React.useState(_standardItem !== undefined);

  const [_portName, setPortName] = React.useState(
    _standardItem?.port_name ?? "",
  );
  const [_portDescription, setPortDescription] = React.useState(
    _standardItem?.port_description ?? "",
  );
  const [_portSpeed, setPortSpeed] = React.useState(
    _standardItem?.port_speed ?? "",
  );
  const [_portInterface, setPortInterface] = React.useState(
    _standardItem?.port_interface ? _standardItem?.port_interface : "",
  );

  const [_portLocation, setPortLocation] = React.useState<string>();

  const [_isTelemetryStreaming, setIsTelemetryStreaming] = React.useState(
    _standardItem?.telemetry_streaming ?? false,
  );

  const [_isBandwidthMonitoring, setIsBandwidthMonitoring] = React.useState(
    _standardItem?.banwidth_monitoring ?? false,
  );
  const [_lowThreshold, setLowThreshold] = React.useState<number | undefined>(
    _standardItem?.low_threshold,
  );
  const [_highThreshold, setHighThreshold] = React.useState<number | undefined>(
    _standardItem?.high_threshold,
  );
  const [_isPredictiveBandwidth, setIsPredictiveBandwidth] = React.useState(
    _standardItem?.predictive_bandwidth ?? false,
  );
  const [_isOverSubscription, setIsOverSubscription] = React.useState(
    _standardItem?.enable_oversubscription ?? false,
  );
  const [_isLAG, setIsLAG] = React.useState(_standardItem?.lag ?? false);
  const [_lagPort, setLagPort] = React.useState(
    _standardItem?.number_of_lag_ports ?? `${PORT_INTERFACE[0].lag_ports[0]}`,
  );

  const _mtuSize = _standardItem?.mtu_size ?? 9216;

  const [_isPortNameValid, setIsPortNameValid] = React.useState(true);
  const [_isPortDescripitionValid, setIsPortDescriptionValid] =
    React.useState(true);
  const [_isLowThresholdValid, setIsLowThresholdValid] = React.useState(true);
  const [_isHighThresholdValid, setIsHighThresholdValid] = React.useState(true);
  const [_isThresholdValid, setIsThresholdValid] = React.useState(true);
  const [_isMtuSizeValid, setIsMtuSizeValid] = React.useState(true);
  const [_isDisablePortSpeed, setIsDisablePortSpeed] = React.useState(false);
  const [_isPortSpeedValid, setIsPortSpeedValid] = React.useState(true);

  const [_displayedLowThreshold, setDisplayLowThreshold] =
    React.useState<string>(_standardItem?.low_threshold?.toString() ?? "");
  const [_displayedHighThreshold, setDisplayHighThreshold] =
    React.useState<string>(_standardItem?.high_threshold?.toString() ?? "");

  const [_showModal, setShowModal] = React.useState(false);
  const [_selectedThreshold, setSelectedThreshold] =
    React.useState<string>("none");
  const [isPortLoading, setIsPortLoading] = React.useState(false);
  const [isInterfaceLoading, setIsInterfaceLoading] = React.useState(false);

  const _isInModifyPortMode = useSelector(selectIsInModifyPortMode);
  const _portDiversityTransition = useSelector(selectDiversityTransition);

  const _onContinue = React.useCallback(() => {
    let isFormSubmittable = true;

    if (!_isPortNameValid || _portName.trim() === "") {
      isFormSubmittable = false;
      setIsPortNameValid(false);
    }

    if (_locationValue === "") {
      isFormSubmittable = false;
      dispatch(updateLocationCheck(true));
    }

    if (_countryValue === "" && !_isInModifyPortMode) {
      isFormSubmittable = false;
      dispatch(updateCountryCheck(true));
    }

    if (!_portSpeed || _portSpeed === "") {
      isFormSubmittable = false;
      setIsPortSpeedValid(false);
    }

    if (!_isPortDescripitionValid) {
      isFormSubmittable = false;
      setIsPortDescriptionValid(false);
    }

    if (_isBandwidthMonitoring) {
      if (
        _lowThreshold === undefined ||
        isNaN(_lowThreshold) ||
        !_isLowThresholdValid
      ) {
        isFormSubmittable = false;
        setIsLowThresholdValid(false);
      }
      if (!_highThreshold || !_isHighThresholdValid) {
        isFormSubmittable = false;
        setIsHighThresholdValid(false);
      }
      if (!_isThresholdValid) {
        isFormSubmittable = false;
      }
    }

    if (!_isMtuSizeValid || !_mtuSize) {
      isFormSubmittable = false;
      setIsMtuSizeValid(false);
    }

    if (isFormSubmittable) {
      const standardItem: PortOnlyItem = {
        port_id: _standardItem?.port_id ? _standardItem.port_id : "",
        service_id: _standardItem?.service_id ? _standardItem.service_id : "",
        port_name: _portName.trim(),
        port_description: _portDescription,
        port_speed: _portSpeed,
        port_interface: _portInterface,
        telemetry_streaming: _isTelemetryStreaming,
        banwidth_monitoring: _isBandwidthMonitoring,
        predictive_bandwidth: _isBandwidthMonitoring
          ? _isPredictiveBandwidth
          : false,
        enable_oversubscription: _isOverSubscription,
        lag: _isLAG,
        mtu_size: _mtuSize,
      };

      if (_isBandwidthMonitoring) {
        standardItem.low_threshold = _lowThreshold;
        standardItem.high_threshold = _highThreshold;
      }

      if (_isLAG) {
        standardItem.number_of_lag_ports = _lagPort;
      }

      TagDataLayerService.pushCtaData("Continue");
      TagDataLayerService.pushPageData("Create PortOnly", "Summary");
      dispatch(updateStandardItem(standardItem));
      dispatch(updateStep(3));
    }
  }, [
    _isPortNameValid,
    _portName,
    _isPortDescripitionValid,
    _portDescription,
    _portSpeed,
    _portInterface,
    _isBandwidthMonitoring,
    _lowThreshold,
    _isThresholdValid,
    _isLowThresholdValid,
    _isHighThresholdValid,
    _highThreshold,
    _isPredictiveBandwidth,
    _isOverSubscription,
    _isLAG,
    _lagPort,
    _mtuSize,
    _isMtuSizeValid,
    _isPortSpeedValid,
    _countryValue,
    _locationValue,
    _isTelemetryStreaming,
  ]);

  const _interfaceOptions = React.useMemo(() => {
    const portSpeed = !_isInModifyPortMode
      ? _portSpeed
      : JSON.stringify(Number(_portSpeed.split(" ")[0]) * 1000);
    const interfaces = PORT_INTERFACE.find((pi) => pi.port_speed === portSpeed)
      ?.interfaces;

    if (_isInModifyPortMode && _portInterface.length < 1) {
      setPortInterface(interfaces?.[0] || "");
    }
    return interfaces?.map((pi) => {
      return { id: pi, value: pi };
    });
  }, [_portSpeed, _isInModifyPortMode]);

  const _lagOptions = React.useMemo(() => {
    return PORT_INTERFACE.find(
      (pi) => pi.port_speed == _portSpeed,
    )?.lag_ports.map((pi) => {
      return { id: `${pi}`, value: `${pi}` };
    });
  }, [_portSpeed]);

  const _onSelectPortSpeed = React.useCallback(
    (val: string) => {
      setPortSpeed(val);

      const validPIs = PORT_INTERFACE.find((pi) => pi.port_speed == val)
        ?.interfaces;

      const validLagPorts = PORT_INTERFACE.find((pi) => pi.port_speed == val)
        ?.lag_ports;

      if (validPIs && !validPIs.includes(_portInterface)) {
        setPortInterface(validPIs[0]);
      }

      if (validLagPorts && !validLagPorts.includes(parseInt(_lagPort))) {
        setLagPort(`${validLagPorts[0]}`);
      }
    },
    [_portInterface, _lagPort],
  );

  const _onSelectThreshold = React.useCallback(
    (val: string, threshold: string) => {
      let newVal: string;
      const isNum = val ? /^\d+$/.test(val.replace("%", "")) : false;

      if (val) {
        if (val.includes("%")) {
          const removePercent = val.replace("%", "");
          newVal = `${parseInt(removePercent)}%`;
        } else {
          newVal = `${val}%`;
        }

        const intVal = parseInt(val.replace("%", ""));

        if (threshold === "low") {
          if (isNum && validateRange(intVal, -1, 100)) {
            setIsLowThresholdValid(true);
          } else {
            setIsLowThresholdValid(false);
          }
        } else {
          if (isNum && validateRange(intVal, 0, 101)) {
            setIsHighThresholdValid(true);
          } else {
            setIsHighThresholdValid(false);
          }
        }
      } else {
        newVal = val;
      }

      if (threshold === "low") {
        setLowThreshold(parseInt(val));
        setDisplayLowThreshold(
          _standardItem?.low_threshold === 0 && newVal === undefined
            ? "0"
            : newVal,
        );
      } else {
        setHighThreshold(parseInt(val));
        setDisplayHighThreshold(newVal);
      }

      if ((_lowThreshold ?? 1) >= (_highThreshold ?? 100)) {
        setIsThresholdValid(false);
      } else {
        setIsThresholdValid(true);
      }
    },
    [_lowThreshold, _highThreshold],
  );

  const _onModalOk = () => {
    if (_isInModifyPortMode) {
      navigate("/port-inventory");
    } else {
      navigate("/customer-ports");
    }
    dispatch(updateStep(1));
    dispatch(
      updatePortLocation({
        countryIsoCode: "",
        countryName: "",
        primaryPort: "",
        primaryLocationDisplayLabel: "",
        secondaryPort: "",
      }),
    );
    dispatch(resetPortOnly());
    dispatch(updatePortDiversity(""));
    setShowModal(false);
  };

  React.useEffect(() => {
    setSelectedThreshold("high");
  }, [_highThreshold]);

  React.useEffect(() => {
    setSelectedThreshold("low");
  }, [_lowThreshold]);

  React.useEffect(() => {
    if (_standardItem?.low_threshold) {
      _onSelectThreshold(`${_standardItem.low_threshold}`, "low");
    }
    if (_standardItem?.high_threshold) {
      _onSelectThreshold(`${_standardItem.high_threshold}`, "high");
    }
  }, [_standardItem]);

  React.useEffect(() => {
    if (!_standardItem?.port_speed || _standardItem?.port_speed == "") {
      if (
        !_selectPortLocation.primaryLocationDisplayLabel ||
        _selectPortLocation.primaryLocationDisplayLabel === ""
      ) {
        setPortSpeed("");
        setPortInterface("");
        setIsDisablePortSpeed(true);
      } else {
        setIsDisablePortSpeed(false);
      }
    }
  }, [_selectPortLocation, _standardItem]);

  React.useEffect(() => {
    if (!_isEdit) {
      setPortSpeed("");
      setPortInterface("");
      setPortLocation(_locationValue);
    }
    setIsEdit(false);
  }, [_countryValue, _locationValue, _portLocation]);

  React.useEffect(() => {
    if (_portSpeed) {
      setIsPortSpeedValid(true);
    }
  }, [_portSpeed]);

  React.useEffect(() => {
    TagDataLayerService.pushPageData(
      "Create Port Only",
      "Standard Configuration",
    );
  }, []);

  const prevPortSpeed = React.useRef<string>();
  React.useEffect(() => {
    setIsPortLoading(false);
    prevPortSpeed.current = _portSpeed;
  }, [_portSpeed]);

  const prevInterface = React.useRef<string>();
  React.useEffect(() => {
    setIsInterfaceLoading(false);
    prevInterface.current = _portInterface;
  }, [_portInterface]);

  return (
    <section className="standard_container" data-testid="config_standard">
      <main className="standard_content">
        <div className="fp-row">
          <div className="col-16 xl:col-8 sm:col-8 md:col-8 mb-32">
            <Card width="100%">
              <h2 className="title">Configure Port</h2>
              <Divider margin="xxl" className="divider" />
              <form id="myform" method="get" className="standard_form">
                <Input
                  name="port_name"
                  label="Port Name"
                  placeholder={MAX_NUMBER_OF_CHARACTERS(30)}
                  value={_portName}
                  onChange={(val) => {
                    setIsPortNameValid(validateLength(val, 31));
                    setPortName(val.replace("  ", " "));
                  }}
                  state={_isPortNameValid ? "default" : "error"}
                  errorMessage={MAX_NUMBER_OF_CHARACTERS(30)}
                  errorMessageSize="sm"
                  showErrorIcon={false}
                />
                <Textarea
                  name="port_description"
                  id="port_description"
                  label="Port Description (optional)"
                  value={_portDescription}
                  onChange={(val) => {
                    setIsPortDescriptionValid(validateLength(val, 501));
                    setPortDescription(val);
                  }}
                  state={_isPortDescripitionValid ? "default" : "error"}
                  errorMessage={
                    !_isPortDescripitionValid
                      ? MAX_NUMBER_OF_CHARACTERS(500)
                      : ""
                  }
                  errorMessageSize="sm"
                  showErrorIcon={false}
                  rows={10}
                  placeholder={MAX_NUMBER_OF_CHARACTERS(500)}
                  keepErrorSpace
                />
                <Label text="Physical Port Interface" />
                <div className="group_fields port_interface">
                  <Tooltip
                    content={
                      _isInModifyPortMode ? "Port speed cannot be modified" : ""
                    }
                    placement="bottom"
                  >
                    <DropdownInput
                      name="port_speed"
                      label="Port Speed"
                      value={
                        _isInModifyPortMode
                          ? dataMapper(_portSpeed)
                          : _portSpeed
                      }
                      allowSearch={false}
                      onSelect={_onSelectPortSpeed}
                      errorMessage={
                        _isPortSpeedValid ? "" : "Please select a port speed"
                      }
                      showErrorIcon={false}
                      errorMessageSize="sm"
                      state={
                        !_isInModifyPortMode && isPortLoading
                          ? "loading"
                          : (_isDisablePortSpeed &&
                              !_standardItem?.port_speed) ||
                            (_isInModifyPortMode &&
                              !_portDiversityTransition) ||
                            _portLocation === ""
                          ? "disabled"
                          : _isPortSpeedValid
                          ? "default"
                          : "error"
                      }
                      options={_selectedPortSpeed
                        ?.map((selectedSpeed) => {
                          return {
                            id: selectedSpeed.toString() || "",
                            value: dataMapper(selectedSpeed.toString() || 0),
                          };
                        })
                        .sort((a, b) => parseInt(a.id) - parseInt(b.id))}
                      placeholder={
                        !_portSpeed ||
                        !_selectPortLocation.primaryLocationDisplayLabel
                          ? "Please select a port speed"
                          : ""
                      }
                    />
                  </Tooltip>
                  <Tooltip
                    content={
                      _portSpeed
                        ? _isInModifyPortMode
                          ? "interface cannot be modified"
                          : ""
                        : "Please select port speed before selecting the interface"
                    }
                    placement="bottom"
                  >
                    <DropdownInput
                      name="interface"
                      label="Interface"
                      value={_portInterface}
                      allowSearch={false}
                      onSelect={setPortInterface}
                      options={_interfaceOptions}
                      state={
                        !_isInModifyPortMode && isInterfaceLoading
                          ? "loading"
                          : (_portSpeed && !_isInModifyPortMode) ||
                            (_isInModifyPortMode &&
                              _portSpeed &&
                              _portDiversityTransition)
                          ? "default"
                          : "disabled"
                      }
                      placeholder={
                        !_portSpeed ? "Please select an interface" : ""
                      }
                    />
                  </Tooltip>
                </div>
              </form>
            </Card>
          </div>
          <div className="col-16 xl:col-8 sm:col-8 md:col-8 mb-32">
            <Card width="100%" height="100%">
              <h2 className="title">Port Setting</h2>
              <Divider margin="xxl" className="divider" />
              <form className="standard_form no-gap">
                <div className="group_fields">
                  <TooltipText
                    labelText="Telemetry Streaming Enabled"
                    htmlFor="telemetry_streaming"
                    tooltipContent="Enabling real-time data transfer provides insights to optimise performance and speed up troubleshooting."
                  />
                  <Toggle
                    size="md"
                    checked={_isTelemetryStreaming}
                    onChange={setIsTelemetryStreaming}
                  />
                </div>
                <div className="group_fields major">
                  <TooltipText
                    labelText="Bandwidth Utilisation Monitoring"
                    htmlFor="monitoring"
                    tooltipContent="Tracking and optimising the real-time usage of available bandwidth for better performance."
                  />
                  <Toggle
                    size="md"
                    checked={_isBandwidthMonitoring}
                    onChange={setIsBandwidthMonitoring}
                    dataTestId="bandwidth_monitoring_toggle"
                  />
                </div>
                {_isBandwidthMonitoring && (
                  <>
                    <div>
                      <div className="group_fields">
                        <DropdownInput
                          name="low_threshold"
                          className="sm:mb-12"
                          helper="Low threshold"
                          placeholder="0 to 99%"
                          value={_displayedLowThreshold}
                          onSelect={(val) => _onSelectThreshold(val, "low")}
                          onlySelectedValue={false}
                          type="integer"
                          state={
                            (_selectedThreshold === "low" &&
                              _highThreshold &&
                              _lowThreshold! >= _highThreshold) ||
                            (!_isLowThresholdValid &&
                              _selectedThreshold === "low")
                              ? "error"
                              : "default"
                          }
                          errorMessage={
                            !_isLowThresholdValid
                              ? "Out of Range (0 to 99%)"
                              : _selectedThreshold === "low" &&
                                _highThreshold &&
                                _lowThreshold! >= _highThreshold
                              ? "Value must be less than max threshold"
                              : ""
                          }
                          errorMessageSize="sm"
                          showErrorIcon={false}
                          options={THRESHOLD_OPTIONS.map((option) =>
                            option.id === "100"
                              ? { id: "99", value: "99%" }
                              : option,
                          )}
                        />
                        <DropdownInput
                          name="high_threshold"
                          helper="High threshold"
                          placeholder="1 to 100%"
                          value={_displayedHighThreshold}
                          onSelect={(val) => _onSelectThreshold(val, "high")}
                          onlySelectedValue={false}
                          type="integer"
                          state={
                            (_selectedThreshold === "high" &&
                              _lowThreshold &&
                              _lowThreshold >= _highThreshold!) ||
                            (!_isHighThresholdValid &&
                              _selectedThreshold === "high") ||
                            (_isLowThresholdValid && !_isHighThresholdValid)
                              ? "error"
                              : "default"
                          }
                          errorMessage={
                            !_isHighThresholdValid
                              ? "Out of Range (1 to 100%)"
                              : _selectedThreshold === "high" &&
                                _lowThreshold &&
                                _lowThreshold >= _highThreshold!
                              ? "Value must be greater than min threshold"
                              : ""
                          }
                          showErrorIcon={false}
                          errorMessageSize="sm"
                          options={THRESHOLD_OPTIONS.filter(
                            (a) => a.id !== "0",
                          )}
                        />
                      </div>
                    </div>
                    <div className="group_fields">
                      <TooltipText
                        labelText="Predictive Bandwidth Optimisation"
                        htmlFor="predictive_bandwidth"
                        tooltipContent="Intelligently manages bandwidth based on usage patterns and real-time data."
                      />
                      <Toggle
                        size="md"
                        checked={_isPredictiveBandwidth}
                        onChange={setIsPredictiveBandwidth}
                      />
                    </div>
                  </>
                )}
                <div className="group_fields major">
                  <TooltipText
                    labelText="Enable Oversubscription"
                    htmlFor="oversubscription"
                    tooltipContent="Enabling oversubscription allows you to use network speed faster than one or all services need at the same time on a port."
                  />
                  <Toggle
                    size="md"
                    checked={_isOverSubscription}
                    onChange={setIsOverSubscription}
                  />
                </div>
                <div className="group_fields lag">
                  <div className="lag-message-box">
                    <Label text="Link Aggregation Group (LAG)" />
                    <div className="lag-message">
                      Configuring LAG upfront will avoid unnecessary downtime if
                      multiple connections in a LAG are later required.
                    </div>
                  </div>
                  <Tooltip
                    content={
                      _isInModifyPortMode ? "LAG cannot be modified" : ""
                    }
                    placement="top"
                  >
                    <Toggle
                      size="md"
                      checked={_isLAG}
                      onChange={setIsLAG}
                      checkedTitle="Yes"
                      unCheckedTitle="No"
                      disabled={
                        _isInModifyPortMode && !_portDiversityTransition
                      }
                    />
                  </Tooltip>
                </div>
                {_isLAG && (
                  <DropdownInput
                    name="lag_port_number"
                    label="Select the maximum number of LAG ports allowed in a bundle."
                    value={_lagPort}
                    allowSearch={false}
                    onSelect={setLagPort}
                    options={_lagOptions}
                    state={
                      _isInModifyPortMode || !_portSpeed
                        ? "disabled"
                        : "default"
                    }
                  />
                )}
                <div className="mtu-section">
                  <div className="group_fields">
                    <div className="tooltip_text mtu_size">
                      <Label text="Standard MTU" />
                      <Tooltip
                        content="The default MTU size is 9216 bytes."
                        placement="bottom"
                      >
                        <Icon
                          title="info_alt"
                          size="sm"
                          className="tooltip_icon"
                        />
                      </Tooltip>
                    </div>
                  </div>
                  <div className="input-section">
                    <Tooltip
                      content={
                        _isInModifyPortMode
                          ? "Standard MTU cannot be modified"
                          : "The default MTU size is 9216 bytes."
                      }
                      placement="bottom"
                    >
                      <Input
                        name="mtu_size"
                        type="number"
                        placeholder="Default MTU Size is 9216"
                        state={"disabled"}
                        showErrorIcon={false}
                        value={`${_mtuSize}`}
                      />
                    </Tooltip>
                  </div>
                </div>
              </form>
            </Card>
          </div>
        </div>
      </main>

      <div className="buttons_container">
        <Button
          label="Back"
          variant="link"
          onPress={() => setShowModal(true)}
          dataTestId="back_btn"
        />
        <Button
          label="Continue"
          variant="gradient"
          onPress={_onContinue}
          dataTestId="continue_btn"
        />
      </div>
      <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        topIconSize="md"
        title="Leave without saving changes"
        complementaryMessage="Are you sure you want to leave this page? Your setup information will be lost."
        contentAlign="center"
        actionText="Leave"
        onOk={_onModalOk}
        closeModal={!_showModal}
        onCancel={() => setShowModal(false)}
      />
    </section>
  );
};

export default ConfigStandard;
