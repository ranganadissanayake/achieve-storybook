import { Badge, Label } from "@btdigital/nayan-component-library";
import React from "react";
import images from "../../../../../../shared/assets";
import "./PortAModifyHeader.scss";

export interface IPortAModifyHeader {
  title?: string;
  statusText?: string;
}
const PortAModifyHeader: React.FC<IPortAModifyHeader> = ({
  title,
  statusText,
}) => {
  return (
    <>
      <div
        className="port-a-modify-header-wrapper"
        data-testid="header-wrapper"
      >
        <div className="header-image">
          <img src={images.block} alt="" srcSet="" />
        </div>
        <div className="header-content">
          <Label text={title}></Label>
          <span className="status-label">
            {statusText && (
              <Badge
                text={statusText}
                style="default"
                customStyle="custom-badge custom-badge-success"
              />
            )}
          </span>
        </div>
      </div>
    </>
  );
};

export default PortAModifyHeader;
