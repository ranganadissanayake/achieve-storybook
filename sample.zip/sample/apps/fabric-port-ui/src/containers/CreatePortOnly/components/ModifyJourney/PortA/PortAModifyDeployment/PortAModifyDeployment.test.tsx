import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import * as reactRedux from "react-redux";
import * as router from "react-router";
import { BrowserRouter as Router, useNavigate, useLocation } from "react-router-dom";
import PortAModifyDeployment from "./index";
import store from "../../../../../../redux/store";
import * as apiModule from "../../../../../../shared/helpers/api";
const { Provider, useDispatch, useSelector } = reactRedux
jest.mock("../../../../../../shared/helpers/api", () => ({
  useApi: jest.fn(),
}));
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
  useLocation: jest.fn()
}));
jest.mock('react-redux', () => ({
  ...jest.requireActual('react-redux'),
  useDispatch: jest.fn(),
  useSelector: jest.fn()
}));

const mockUpdatePortOnly = jest.fn();

const navigate = jest.fn();

const mockLocation = {
  state: {
    selectedPortName: 'selectedPortNameValue' // Set the state value you want to test
  }
};

// Mock the useDispatch hook to return a mock function
const mockDispatch = jest.fn();


beforeAll(() => {
  jest.spyOn(router, "useNavigate").mockImplementation(() => navigate);
});

const mockSelectedPortClass = 'mockSelectedPortClassValue';

beforeEach(() => {
  (apiModule.useApi as jest.Mock).mockReturnValue({
    updatePortStatus: mockUpdatePortOnly
  });
  (useNavigate as jest.Mock).mockReturnValue(navigate);
  (useLocation as jest.Mock).mockReturnValue(mockLocation);
  (useDispatch as jest.Mock).mockReturnValue(mockDispatch);
  (useSelector as jest.Mock).mockReturnValue(mockSelectedPortClass);
});

afterEach(() => {
  jest.clearAllMocks(); // Clear all mock calls after each test
});

describe("PortAModifyDeployment", () => {

  it('makes API request when isUpdatetRequestEnabled is false', async () => {
      const expectedPayload = {
        primaryPortMetadata: { portId: 'primaryPortId' },
        secondaryPortMetadata: { portId: 'secondaryPortId' }
      };
    const mockApi = {
      updatePortStatus: jest.fn()
    };
    (apiModule.useApi as jest.Mock).mockReturnValue(mockApi);
    // Mock the useSelector hook to return true for isUpdatetRequestEnabled
    (useSelector as jest.Mock).mockReturnValueOnce(true);
    render(<Provider store={store}>
      <Router>
        <PortAModifyDeployment />
      </Router>
    </Provider>);

    expect(mockUpdatePortOnly).not.toHaveBeenCalledWith(expectedPayload);
  });

  test('calls makeApiRequest when isUpdatetRequestEnabled is true', () => {
    // Mock useSelector to return true for isUpdatetRequestEnabled
    (useSelector as jest.Mock).mockReturnValue(true);
    (useSelector as jest.Mock).mockReturnValue({});
    (useSelector as jest.Mock).mockReturnValue({});

    // Mock the api.updatePortStatus function
    const makeApiRequest = jest.fn();
    jest.mock('../../../../../../shared/helpers/api', () => ({
      useApi: () => ({
        makeApiRequest: mockUpdatePortOnly,
      }),
    }));

    // Render the component
    render(<Provider store={store}>
      <Router>
        <PortAModifyDeployment />
      </Router>
    </Provider>);

    // Assert that makeApiRequest is called
    expect(makeApiRequest).not.toHaveBeenCalled();
  });

  test("navigates back to dashboard", () => {
    render(
      <Provider store={store}>
        <Router>
          <PortAModifyDeployment />
        </Router>
      </Provider>,
    );

    const backButton = screen.getByText("Back to Home");
    fireEvent.click(backButton);
    expect(navigate).toHaveBeenCalledWith('/')
  });

  test("render message", () => {
    render(
      <Provider store={store}>
        <Router>
          <PortAModifyDeployment />
        </Router>
      </Provider>,
    );

    expect(
      screen.getByText(
        "We're working on your request :)"
      )
    ).toBeInTheDocument();
    expect(screen.getByText("Create a New Port")).toBeInTheDocument();
    expect(screen.getByText("View My Ports")).toBeInTheDocument();
  });

  it('navigates to create-new-port page when "Create a New Port" button is clicked', () => {
    render(
      <Provider store={store}>
        <Router>
          <PortAModifyDeployment />
        </Router>
      </Provider>,
    );
    const createNewPortButton = screen.getByText("Create a New Port");

    // Simulate clicking the "Create a New Port" button
    fireEvent.click(createNewPortButton);
    expect(navigate).toHaveBeenCalledWith('/create-new-port')
  });

  test("data is added into local storage", () => {
    render(
      <Provider store={store}>
        <Router>
          <PortAModifyDeployment />
        </Router>
      </Provider>,
    );
    const mockData = "bucketData";
    window.localStorage.setItem("basketPayloads", "bucketData");
    expect(localStorage.getItem("basketPayloads")).toEqual((mockData));
  });
});
