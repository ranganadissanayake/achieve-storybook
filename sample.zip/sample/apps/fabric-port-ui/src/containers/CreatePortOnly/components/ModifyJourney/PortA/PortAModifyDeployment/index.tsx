import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Button, useToast } from "@btdigital/nayan-component-library";

import DeploymentStatusCard from "../../../../../../components/DeploymentStatusCard";
import { DeploymentStatus } from "../../../../../../shared/types";
import images from "../../../../../../shared/assets";
import { updateStep } from "../../../../../../redux/internetSlice";
import {
  selectPortOnlyState,
  updatePortLocation,
  updateStandardItem,
  updateDiverseItem,
  updateIsDeploymentRequestEnabled,
  updateIsInModifyPortMod,
  updatePortDiversity,
  selectIsUpdatetRequestEnabled,
  selectPortClass
} from "../../../../../../redux/portOnlySlice";
import { selectSelectedBillingAccount, selectSelectedPurchaseOrder } from "../../../../../../redux/billingAccountsSlice";
import { useApi } from "../../../../../../shared/helpers";
import { portToPortOrderModifyRequestDTO, portToPortOrderRequestDTO } from "../../../../../../shared/mappers/services/port.service";
import { buildNotification } from "../../../../../../shared/constants/toastBuilder";
import {
  errorToast,
  errorToastOptions,
} from "../../../../../../shared/constants/errorToast";
import useLocalStorage from "../../../../../../shared/hooks/useLocalStorage";
import { PortOrderRequestDTO, UpdateDTO } from "../../../../../../shared/mappers/classes/dto/port.dto";
import { BASKET_PAYLOADS, TOAST_TIMEOUT, BT_NOTIFICATIONS, PORT_UPDATE_DEPLOYMENT_AWAITED_MESSAGE } from "../../../../../../shared/constants";

import "./PortAModifyDeployment.scss";
import { removeNullEmptyPropsformodify } from "../../../../../../shared/utils/common";

const PortAModifyDeployment: React.FC = () => {
  const toast = useToast();
  const navigate = useNavigate();
  const dispatch = useDispatch<any>();
  const { state } = useLocation();
  const api = useApi();

  const [deploymentStatus] = React.useState<DeploymentStatus>(DeploymentStatus.awaited);
  const [_serviceId, setServiceId] = React.useState("");
  const [_requestId, setRequestId] = React.useState("");

  const isUpdatetRequestEnabled = useSelector(selectIsUpdatetRequestEnabled)
  const { selectedPortName } = state || {};
  const _portClass = useSelector(selectPortClass);
  const _portOnlyState = useSelector(selectPortOnlyState);
  const _selectedBillingAccount = useSelector(selectSelectedBillingAccount);
  const _selectedPurchaseOrder = useSelector(selectSelectedPurchaseOrder);

  const [notificationStorage, setNotificationStorage] = useLocalStorage(
    BT_NOTIFICATIONS,
    []
  );

  React.useEffect(() => {
    if (isUpdatetRequestEnabled) {
      makeApiRequest();
    }
  }, []);

  let mapBasketPayload: any[] = [];
  let mapOrderData: () => PortOrderRequestDTO;
  let mapOrderDataUpdate: () => UpdateDTO;
  if (localStorage.getItem(BASKET_PAYLOADS) && selectedPortName) {
    mapBasketPayload = JSON.parse(localStorage.getItem(BASKET_PAYLOADS) || "");
    const getBasketIndex: number = mapBasketPayload.findIndex((port) => port.name == selectedPortName);
    mapOrderData = () => portToPortOrderRequestDTO(mapBasketPayload[getBasketIndex]);
    mapOrderDataUpdate = () => portToPortOrderModifyRequestDTO(mapBasketPayload[getBasketIndex]);
  } else {
    mapOrderData = () => portToPortOrderRequestDTO(_portClass);
    mapOrderDataUpdate = () => portToPortOrderModifyRequestDTO(_portClass);
  }

  const sentUpdatePortRequest = async (updateRequestPayload: any) => {
    const orderNotification = buildNotification(
      {
        type: "info",
        title: "Port Only is being updated",
        description: (
          <p className="content">
            <b>{_portOnlyState?.standardItem?.port_name || "Port"}</b> is being
            updated and will take approximately 5 minutes
          </p>
        ),
      },
      "Port",
    );

    const orderErrorNotification = buildNotification(errorToast, "Port");
    const updatedPayload = removeNullEmptyPropsformodify(updateRequestPayload);
    api
      .updatePortStatus({ ...updatedPayload })
      .then((res) => {
        if (res) {
          setServiceId(res.result.serviceId);
          setRequestId(res.result.requestId);
          toast.addToast(orderNotification.view(), {
            position: "top",
            timeout: TOAST_TIMEOUT,
            deleteSideEffect: () => {
              orderNotification.save({
                notificationStorage,
                setNotificationStorage,
              });
            },
          });
        }
      })
      .catch((error) => {
        if (error) {
          toast.addToast(orderErrorNotification.view(), {
            ...errorToastOptions,
            deleteSideEffect: () => {
              orderErrorNotification.save({
                notificationStorage,
                setNotificationStorage,
              });
            },
          });
        }
      });
  };
  const makeApiRequest = async () => {
    let requestPayload: any = mapOrderData();
    let requestPayloadPortA: any = mapOrderDataUpdate();
    if (!_portOnlyState.standardItem) {
      requestPayload.billingAccountId = _selectedBillingAccount.billingAccountId;
      requestPayload.currencyFormat = _selectedBillingAccount.currencyFormat;
    }
    if (_selectedPurchaseOrder.purchaseOrderNumber && _selectedPurchaseOrder.purchaseOrderNumber !== "") {
      requestPayload.customerPurchaseOrder = _selectedPurchaseOrder.purchaseOrderNumber
    }

    if (_portOnlyState.diverseItem && _portOnlyState.diverseItemOriginal) {
      requestPayload.primaryPortMetadata.portId = _portOnlyState.diverseItemOriginal.primaryItem.port_id
      requestPayload.primaryPortMetadata.serviceId = _portOnlyState.diverseItemOriginal.primaryItem.service_id
      requestPayload.secondaryPortMetadata.portId = _portOnlyState.diverseItemOriginal.secondaryItem.port_id
      requestPayload.secondaryPortMetadata.serviceId = _portOnlyState.diverseItemOriginal.secondaryItem.service_id
      await sentUpdatePortRequest({ ...requestPayload })
    } else if (_portOnlyState.standardItem) {
      requestPayloadPortA.primaryPortMetadata.serviceId = _portOnlyState.standardItem.service_id
      requestPayloadPortA.portName = _portOnlyState.standardItem.port_name;
      if(_portOnlyState.standardItem.port_description !="" ){
        requestPayloadPortA.portDescription = _portOnlyState.standardItem.port_description;
      }
      requestPayloadPortA.isDiverse = false;
      requestPayloadPortA.primaryPortMetadata.isOversubscription = _portOnlyState.standardItem.enable_oversubscription
      requestPayloadPortA.primaryPortMetadata.isPredictiveOptimisation = _portOnlyState.standardItem.predictive_bandwidth
      requestPayloadPortA.primaryPortMetadata.highUtilisationThreshold = _portOnlyState.standardItem.high_threshold ?? 0
      requestPayloadPortA.primaryPortMetadata.lowUtilisationThreshold = _portOnlyState.standardItem.low_threshold ?? 0
      requestPayloadPortA.primaryPortMetadata.telemetryStreamingEnabled = _portOnlyState.standardItem.telemetry_streaming
      requestPayloadPortA.primaryPortMetadata.isUtilisationThreshold = _portOnlyState.standardItem.banwidth_monitoring
      await sentUpdatePortRequest({...requestPayloadPortA})
    }
  };

  const _onCreateNewPort = () => {
    navigate("/create-new-port");
  };

  const resetPorts = () => {
    dispatch(
      updatePortLocation({
        countryIsoCode: "",
        countryName: "",
        primaryPort: "",
        secondaryPort: "",
        primaryLocationDisplayLabel: "",
        secondaryLocationDisplayLabel: "",
      }),
    );
    dispatch(updateStandardItem(undefined));
    dispatch(updateDiverseItem(undefined));
    dispatch(updateIsDeploymentRequestEnabled(false));
    dispatch(updateStep(1));
    dispatch(updateIsInModifyPortMod(false));
    dispatch(updatePortDiversity(""));
  };

  const renderCurrentStatus = React.useCallback(() => {
    switch (deploymentStatus) {
      case DeploymentStatus.awaited:
        return (
          <DeploymentStatusCard
            statusImageURL={images.portADeploymentAwaited}
            imageWidth="120px"
            imageHeight="120px"
            containerClassName="awaited-container"
            title="We're working on your request :)"
            description={PORT_UPDATE_DEPLOYMENT_AWAITED_MESSAGE(_requestId, _serviceId)}
            leftButtonTitle="Create a New Port"
            leftButtonClassName="try-again-button"
            leftButtonClick={_onCreateNewPort}
            rightButtonTitle="View My Ports"
            rightButtonClassName="view-ports-button"
            rightButtonClick={() => navigate("/port-inventory")}
          />
        );

      case DeploymentStatus.failed:
        return (
          <DeploymentStatusCard
            statusImageURL={images.portADeploymentFailed}
            imageWidth="64px"
            imageHeight="64px"
            containerClassName="failed-container"
            title="Sorry, we can't connect your port  :("
            description={[]}
            leftButtonTitle="Try Again"
            leftButtonClassName="try-again-button"
            leftButtonClick={() => { }}
            rightButtonTitle="Save it to basket"
            rightButtonClassName="save-it-button"
            rightButtonClick={() => { }}
          />
        );
      default:
        return null;
    }
  }, [deploymentStatus, _requestId, _serviceId]);

  const _onBackToDashboard = () => {
    navigate("/");
  };

  React.useEffect(() => {
    resetPorts();
  }, []);
  return (
    <>
      <section
        className="port-a-deployment-container"
        data-testid="port-a-deployment-container"
      >
        <div className="fp-container">
          <div className="fp-row jstfy-cont-ctr">
            <div className="col-16 md:col-12 lg:col-8">
              <div>
                <div className="deployment-status-container">
                  {renderCurrentStatus()}
                </div>
                <div className="action-btn-wrapper">
                  <Button
                    variant="link"
                    label="Back to Home"
                    iconBefore={true}
                    className="back-to-home-button"
                    iconTitle="previous_arrow"
                    onPress={_onBackToDashboard}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default PortAModifyDeployment;
