import React from "react";
import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";
import { render, screen, fireEvent } from "@testing-library/react";
import * as router from "react-router";
import user from "@testing-library/user-event";

import store from "../../../../redux/store";
import { useApi } from "../../../../shared/helpers/api";
import { MAX_NUMBER_OF_CHARACTERS } from "../../../../shared/constants/common";
import ConfigStandard from "./index";

const navigate = jest.fn();

jest.mock("../../../../shared/helpers/api", () => ({
  useApi: jest.fn(),
}));

afterEach(() => {
  jest.clearAllMocks(); // Clear all mock calls after each test
});

describe("Config Standard", () => {
  beforeAll(() => {
    jest.spyOn(router, "useNavigate").mockImplementation(() => navigate);
  });

  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getPortAPricing: jest.fn().mockResolvedValue({
        primaryPortPrice: {
          oneTimePrice: 100,
          recurringMonthlyPrice: 200,
        },
        secondaryPortPrice: {
          oneTimePrice: 100,
          recurringMonthlyPrice: 200,
        },
      }),
      getBillingAccounts: jest.fn().mockResolvedValue({
        customerID: "29055",
        customerName: "CSA-29055",
        billingAccounts: [
          {
            id: "0013L00000WLYrAQAX",
            name: "BAC-0013L00000WLYrAQAX",
            currency: "USD",
            default: true,
          },
          {
            id: "0015L00000WLYrAQAY",
            name: "EAC-0015L00000WLYrAQAY",
            currency: "GBP",
            default: false,
          },
          {
            id: "0014L00000WLYrAQAZ",
            name: "DAC-0014L00000WLYrAQAZ",
            currency: "LKR",
            default: false,
          },
        ],
      }),
    });
  });
  afterEach(() => {
    jest.clearAllMocks();
  });

  test("renders the Standard Configuration component", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    expect(screen.getByTestId("config_standard")).toBeInTheDocument();
  });

  test("renders the Standard configuration main titles", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    expect(screen.getByText("Configure Port")).toBeInTheDocument();
    expect(screen.getByText("Port Setting")).toBeInTheDocument();
  });

  test("displays 'Back' and 'Continue' buttons", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    expect(screen.getByTestId("back_btn")).toBeInTheDocument();
    expect(screen.getByTestId("continue_btn")).toBeInTheDocument();
  });

  test("port interface is disabled by default", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    const portInterface = screen.getByPlaceholderText(
      "Please select an interface"
    );
    expect(portInterface).toBeDisabled();
  });

  test("clicking back button dispays unsave changes popup", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    const backButton = screen.getByTestId("back_btn");
    user.click(backButton);
    expect(
      screen.getByText("Leave without saving changes")
    ).toBeInTheDocument();
  });

  test("displays error message if port name input is empty and continue button is clicked", async () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    const continueBtn = screen.getByTestId("continue_btn");
    fireEvent.click(continueBtn);
    expect(screen.getAllByText(MAX_NUMBER_OF_CHARACTERS(30)).length).toBeGreaterThanOrEqual(1);
  });

  test("clicks the Leave button in the modal and navigates to customer-ports", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    const backButton = screen.getByTestId("back_btn");
    fireEvent.click(backButton);

    const leaveButton = screen.getByText("Leave");
    fireEvent.click(leaveButton);

    setTimeout(() => {
      expect(window.location.pathname).toBe("/customer-ports");
    }, 500);
  });

  test("displays error message if port description input exceeds the character limit", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    const portDescriptionInput = screen.getByLabelText(
      "Port Description (optional)"
    );
    fireEvent.change(portDescriptionInput, {
      target: {
        value:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ligula magna, hendrerit et turpis consequat, rutrum consectetur tortor. Nulla ut efficitur velit. Aliquam non tellus vel eros sollicitudin tristique a non elit. Cras dictum augue ut magna mollis, vitae rhoncus dui tristique. Morbi at sagittis nulla. Quisque neque sem, ullamcorper id odio bibendum, facilisis condimentum nisi. Cras viverra blandit dolor, eget tincidunt erat sodales id. Aenean ac est vel elit ultricies vehicula non vitae cuz",
      },
    });

    const continueBtn = screen.getByTestId("continue_btn");
    fireEvent.click(continueBtn);

    expect(screen.getByText(MAX_NUMBER_OF_CHARACTERS(500))).toBeInTheDocument();
  });

  test("it should update the selected threshold on button click - low", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    const bandwidthMonitoringToggle = screen.getByTestId("bandwidth_monitoring_toggle");
    fireEvent.click(bandwidthMonitoringToggle);
    const input = screen.getByPlaceholderText("0 to 99%");
    fireEvent.click(input);
    const option = screen.getByText("0%");
    fireEvent.click(option);
    expect(option).toBeInTheDocument();
  });

  test("it should update the selected threshold on button click - high", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    const bandwidthMonitoringToggle = screen.getByTestId("bandwidth_monitoring_toggle");
    fireEvent.click(bandwidthMonitoringToggle);
    const input = screen.getByPlaceholderText("0 to 99%");
    fireEvent.click(input);
    const option = screen.getByText("100%");
    fireEvent.click(option);
    expect(option).toBeInTheDocument();
  });

  test("displays error message if port name is more than 30 characters", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    const portName = screen.getByRole("textbox", { name: "Port Name" });
    user.click(portName);
    user.keyboard("Lorem ipsum dolor sit amet consectetur");
    expect(screen.getByText(MAX_NUMBER_OF_CHARACTERS(30))).toBeInTheDocument();
  });

  test("displays error message if port description is more than 500 characters", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    const portDescription = screen.getByRole("textbox", { name: "Port Description (optional)" });
    user.click(portDescription);
    user.keyboard("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ligula magna, hendrerit et turpis consequat, rutrum consectetur tortor. Nulla ut efficitur velit. Aliquam non tellus vel eros sollicitudin tristique a non elit. Cras dictum augue ut magna mollis, vitae rhoncus dui tristique. Morbi at sagittis nulla. Quisque neque sem, ullamcorper id odio bibendum, facilisis condimentum nisi. Cras viverra blandit dolor, eget tincidunt erat sodales id. Aenean ac est vel elit ultricies vehicula non vitae cuz");
    expect(screen.getByText(MAX_NUMBER_OF_CHARACTERS(500))).toBeInTheDocument();
  });

  test("displays the telemetry streaming field", () => {
    render(
      <BrowserRouter>
        <Provider store={store}>
          <ConfigStandard />
        </Provider>
      </BrowserRouter>
    );

    expect(screen.getByText("Telemetry Streaming Enabled")).toBeInTheDocument();
  });
});
