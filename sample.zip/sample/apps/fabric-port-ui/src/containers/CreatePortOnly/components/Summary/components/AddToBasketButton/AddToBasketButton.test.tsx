import React from "react";
import AddToBasketButton from ".";
import { testPreloadedStatePortOnly } from "../../../../../../shared/helpers";
import { renderWithProviders } from "../../../../../../shared/helpers";
import { fireEvent } from "@testing-library/react";

describe("AddToBasketButton", () => {
    
    test('should render the add to basket button', () => {
        const { getByTestId } = renderWithProviders(
            <AddToBasketButton
                onClickAddToBasket={() => jest.fn()}
                oneTimePrice={100}
                recurringMonthlyPrice={200}
            />, {
            preloadedState: testPreloadedStatePortOnly as any
        });

        expect(getByTestId("add_to_basket_btn")).toBeInTheDocument();
    });

    test('should able to click and add to basket button', () => {
        const spy = jest.fn();
        const { getByTestId } = renderWithProviders(
            <AddToBasketButton
                onClickAddToBasket={spy}
                oneTimePrice={100}
                recurringMonthlyPrice={200}
            />, {
            preloadedState: testPreloadedStatePortOnly as any
        });
        fireEvent.click(getByTestId("add_to_basket_btn"));
        expect(spy).toHaveBeenCalled();
    })
});