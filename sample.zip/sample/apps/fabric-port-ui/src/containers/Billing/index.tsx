import React from "react";
import { Card, TableV2 } from "@btdigital/nayan-component-library";

import "./index.scss";
import PageWrap from "../../components/PageWrap";
import TitleBar from "../../components/TitleBar";
import { generateColumns } from "./utils";
import {
  filterBillingInventoryReducer,
  initialState,
  searchAndFilter,
} from "./BillingFilters/billingFiltersReducer";
import { BillingAccount } from "../../shared/mappers/classes/dto/billingAccount.dto";
import BillingFilters from "./BillingFilters";
import { selectBillingAccounts } from "../../redux/billingAccountsSlice";
import { useDispatch, useSelector } from "react-redux";
import { generateBillingAccounts } from "../../shared/utils";
import { PRODUCT } from "../../shared/types";
import { useApi } from "../../shared/helpers";
import { useNavigate } from "react-router";

const Billing: React.FC = () => {
  const navigate = useNavigate();
  const billingAccounts = useSelector(selectBillingAccounts);
  const [state, filterDispatch] = React.useReducer(
    filterBillingInventoryReducer,
    initialState
  );
  const api = useApi();
  const dispatch = useDispatch();

  const [filteredData, setFiltered] = React.useState<BillingAccount[]>([]);
  const [inventoryData, setInventoryData] = React.useState<BillingAccount[]>(
    []
  );

  React.useEffect(() => {
    generateBillingAccounts(api, "GB", PRODUCT.port, dispatch);
  }, []);

  React.useEffect(() => {
    const mapIpAddresses = () => {
      setFiltered(billingAccounts);
      setInventoryData(billingAccounts);
    };
    mapIpAddresses();
  }, [billingAccounts]);

  React.useEffect(() => {
    const searched = searchAndFilter(state, inventoryData);
    setFiltered(searched);
  }, [state]);

  const handleNavigate = (billingId: string) => {
    navigate(`/billing-accounts/purchase-orders?billingId=${billingId}`);
  };

  return (
    <section>
      <PageWrap className="billing-page" testId="billing-page">
        <>
          <div className="fp-row">
            <div className="col-16 xl:col-8 sm:col-8 md:col-8">
              <TitleBar
                title="Billing"
                wrapperClassName="align"
                subTitle="Manage all your organization's billing accounts and purchase orders."
              />
            </div>
          </div>
          <div className="fp-row">
            <div className="col-16 billing-table">
              <Card data-testid="port-type-card">
                <BillingFilters
                  state={state}
                  dispatch={filterDispatch}
                  filteredData={filteredData ?? []}
                />
                <TableV2
                  data={filteredData ?? []}
                  columns={generateColumns(handleNavigate)}
                  enablePagination={true}
                  defaultPageSize={10}
                  pageSizes={[10, 25, 50, 100]}
                  enableFixHeader={true}
                  tableMaxHeight="100%"
                  tableMaxWidth="1400px"
                  noDatadescription={
                    "It appears you don't have any billing accounts at the moment."
                  }
                  noDataMessage={"No accounts to show"}
                />
              </Card>
            </div>
          </div>
        </>
      </PageWrap>
    </section>
  );
};

export default Billing;
