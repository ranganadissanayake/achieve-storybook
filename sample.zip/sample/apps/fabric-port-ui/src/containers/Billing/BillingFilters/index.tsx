import React, { useState } from "react";
import { Input } from "@btdigital/nayan-component-library";

import { FilterState } from "./billingFiltersReducer";
import { FilterAction } from "../../../shared/constants/filterHelpers";
import ExportTableDataButton from "../../../components/ExportTableDataButton";
import { billingHeaders } from "../../../shared/constants";

type BillingFiltersProps = {
  state: FilterState;
  dispatch: any;
  filteredData: any[];
};
const BillingFilters: React.FC<BillingFiltersProps> = ({
  state,
  dispatch,
  filteredData,
}) => {
  const [searchValue, setSearchValue] = useState("");

  return (
    <React.Fragment>
      <div className="fp-row filter-row">
        <Input
          value={state.search}
          onChange={(value) => {
            setSearchValue(value);
            dispatch({
              type: FilterAction.SEARCH,
              payload: value,
            });
          }}
          name="searchInput"
          iconName="search"
          placeholder="Search"
          className="filter-input"
          size="sm"
          iconSize="sm"
          onBlur={() => {
            dispatch({
              type: FilterAction.SEARCH,
              payload: searchValue,
            });
          }}
          keyEnter={() => {
            dispatch({
              type: FilterAction.SEARCH,
              payload: searchValue,
            });
          }}
        />
        <ExportTableDataButton
          headers={billingHeaders}
          rawData={filteredData.slice(0, 100)}
          exportFileName="Billings"
        />
      </div>
    </React.Fragment>
  );
};

export default BillingFilters;
