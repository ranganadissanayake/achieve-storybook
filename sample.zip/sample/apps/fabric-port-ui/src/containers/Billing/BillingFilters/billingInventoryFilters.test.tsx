import React from "react";
import { screen, render } from "@testing-library/react";
import PortInventoryFilters from "./index";

const mockDispatch = jest.fn();
const mockState = {
  search: "",
};

describe("BillingFilters", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it("renders without crashing", () => {
    render(
      <PortInventoryFilters
        state={mockState}
        dispatch={mockDispatch}
        filteredData={[]}
      />
    );
    expect(screen.getByPlaceholderText("Search")).toBeInTheDocument();
  });
});
