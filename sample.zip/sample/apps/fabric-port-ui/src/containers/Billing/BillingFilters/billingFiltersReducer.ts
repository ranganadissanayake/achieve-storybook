import { filter } from "lodash";
import { FilterAction } from "../../../shared/constants/filterHelpers";

export type FilterState = {
  search: string;
};

export type FilterReducerAction = {
  type: FilterAction;
  payload?: any;
};

export const initialState = { search: "" };

export const filterBillingInventoryReducer = (
  state: FilterState,
  action: FilterReducerAction
) => {
  switch (action.type) {
    case FilterAction.SEARCH: {
      return { ...state, search: action.payload };
    }

    default:
      return { ...state };
  }
};

export const searchTable = (searchValue: string, searchData: any[]) => {
  if (searchValue.length < 3) {
    return searchData;
  }

  const searchString = searchValue.toLocaleLowerCase();
  return filter(searchData, (value) => {
    return (
      value.name?.toLocaleLowerCase().includes(searchString) ||
      value.accounName?.toLocaleLowerCase().includes(searchString) ||
      value.purchaseOrderName?.toLocaleLowerCase().includes(searchString)
    );
  });
};

export const searchAndFilter = (state: FilterState, searchData: any[]) => {
  const { search } = state;
  const searchedValues = searchTable(search, searchData);

  return searchedValues;
};
