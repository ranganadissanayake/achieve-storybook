import { FilterAction } from "../../../shared/constants/filterHelpers";
import {
  initialState,
  filterBillingInventoryReducer,
  FilterState,
  searchAndFilter,
} from "./billingFiltersReducer";

describe("filterBillingInventoryReducer", () => {
  it("should handle SEARCH action", () => {
    const state: FilterState = { ...initialState };
    const action = { type: FilterAction.SEARCH, payload: ["search-text"] };
    const newState = filterBillingInventoryReducer(state, action);
    expect(newState.search).toEqual(["search-text"]);
  });

  it("should handle searchAndFilter", () => {
    const newState = searchAndFilter(
      {
        search: "se",
      },
      []
    );
    expect(newState).toEqual([]);
  });
});
