import React from "react";
import { Card, TableV2 } from "@btdigital/nayan-component-library";

import "./index.scss";
import PageWrap from "../../../components/PageWrap";
import TitleBar from "../../../components/TitleBar";
import { generateColumns } from "./utils";
import {
  CustomerPurchaseOrder,
  BillingAccount,
} from "../../../shared/mappers/classes/dto/billingAccount.dto";
import { selectBillingAccounts } from "../../../redux/billingAccountsSlice";
import { useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";
import {
  filterBillingInventoryReducer as filterPurchaseOrdersReducer,
  initialState as searchState,
  searchAndFilter as searchPurchase,
} from "../BillingFilters/billingFiltersReducer";
import PurchaseOrdersFilters from "../BillingFilters";

const PurchaseOrders: React.FC = () => {
  const [searchParams, _] = useSearchParams();
  const billingAccounts = useSelector(selectBillingAccounts);
  const [state, filterDispatch] = React.useReducer(
    filterPurchaseOrdersReducer,
    searchState
  );
  const billingId = searchParams.get("billingId");
  const [billingAccount, setBillingAccount] = React.useState<BillingAccount>();
  const [filteredData, setFiltered] = React.useState<CustomerPurchaseOrder[]>(
    []
  );
  const [purchaseData, setPurchaseData] = React.useState<
    CustomerPurchaseOrder[]
  >([]);

  React.useEffect(() => {
    const mapPuchaseOrders = () => {
      const billing = billingAccounts.find((acc) => acc.id === billingId);

      const purchaseOrders = billing?.customerPurchaseOrder || [];

      setBillingAccount(billing);

      setFiltered(purchaseOrders);
      setPurchaseData(purchaseOrders);
    };
    mapPuchaseOrders();
  }, [billingAccounts, billingId]);

  React.useEffect(() => {
    const searched = searchPurchase(state, purchaseData);
    if (state.search.length > 0) {
      setFiltered(searched);
    }
  }, [state]);

  return (
    <section>
      <PageWrap className="purchase-page" testId="purchase-page">
        <div className="fp-row">
          <div className="col-16 xl:col-8 sm:col-8 md:col-8">
            <TitleBar
              title={`${billingAccount?.name}`}
              wrapperClassName="align"
              subTitle={`Account Number: ${billingAccount?.id}`}
            />
          </div>
        </div>
        <div className="fp-row">
          <div className="col-16 purchase-table">
            <Card data-testid="purchase-card">
              <PurchaseOrdersFilters
                state={state}
                dispatch={filterDispatch}
                filteredData={filteredData ?? []}
              />
              <TableV2
                data={filteredData ?? []}
                columns={generateColumns()}
                enablePagination={true}
                defaultPageSize={10}
                pageSizes={[10, 25, 50, 100]}
                enableFixHeader={true}
                tableMaxHeight="100%"
                tableMaxWidth="1400px"
                noDataMessage={"No data to display"}
              />
            </Card>
          </div>
        </div>
      </PageWrap>
    </section>
  );
};

export default PurchaseOrders;
