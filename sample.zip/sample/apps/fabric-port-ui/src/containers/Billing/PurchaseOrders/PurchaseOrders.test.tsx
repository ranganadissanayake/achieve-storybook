import React from "react";
import { BrowserRouter } from "react-router-dom";
import { render, screen, act } from "@testing-library/react";
import PurchaseOrders from "./index";
import { Provider } from "react-redux";
import store from "../../../redux/store";
import "regenerator-runtime";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useSearchParams: () => [
    new URLSearchParams({ billingId: "0013L00000WLYrAQAX" }),
  ],
}));

describe("PurchaseOrders", () => {
  it("should load purchase orders", async () => {
    await act(() =>
      render(
        <Provider store={store}>
          <BrowserRouter>
            <PurchaseOrders />
          </BrowserRouter>
        </Provider>
      )
    );

    expect(screen.queryByText("BAC-0013L00000WLYrAQAX")).toBeInTheDocument();
  });

  it("should show no data", async () => {
    jest.mock("react-router-dom", () => ({
      ...jest.requireActual("react-router-dom"),
      useSearchParams: () => [new URLSearchParams({ billingId: "" })],
    }));

    await act(() =>
      render(
        <Provider store={store}>
          <BrowserRouter>
            <PurchaseOrders />
          </BrowserRouter>
        </Provider>
      )
    );

    expect(screen.queryByText("No data to display")).toBeInTheDocument();
  });
});
