import { Badge } from "@btdigital/nayan-component-library";
import React from "react";

export const generateColumns = () => [
  {
    header: "Purchase Order Name",
    accessorKey: "purchaseOrderName",
    id: "purchaseOrderName",
  },
  {
    header: "Order Number",
    accessorKey: "purchaseOrderNumber",
    id: "purchaseOrderNumber",
  },
  {
    header: "Order Type",
    accessorKey: "",
    id: "purchaseOrderType",
    cell: ({ row }: { row: any }) => (
      <div className="port-type">
        <Badge
          text={row.original?.purchaseOrderType}
          customStyle="border-fix"
          style="default"
          outline={true}
        />
      </div>
    ),
  },
];
