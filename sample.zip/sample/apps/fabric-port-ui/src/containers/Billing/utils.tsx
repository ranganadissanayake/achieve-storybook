import { Badge, Icon } from "@btdigital/nayan-component-library";
import GFHeading from "../../components/GFHeading";
import Tooltip from "../../components/TooltipV2";

import React from "react";

export const generateColumns = (handleNavigate: (id: string) => void) => [
  {
    header: "Billing Account Name",
    accessorKey: "name",
    id: "accountName",
  },
  {
    header: "Account ID",
    accessorKey: "id",
    id: "accountId",
  },
  {
    accessorKey: "",
    id: "currrency",
    header: () => (
      <div className="billing-currency">
        <GFHeading size="S6" weight="regular">
          Currency
        </GFHeading>
        <Tooltip
          placement="bottom"
          trigger="mouseover"
          content="This is the currency in which your purchases will be billed and invoiced"
        >
          <Icon title="info" color="#5514b4" size="sm" />
        </Tooltip>
      </div>
    ),
    cell: ({ row }: { row: any }) => (
      <div className="port-type">
        <Badge
          text={row.original?.currency}
          customStyle="border-fix"
          style="default"
          outline={true}
        />
      </div>
    ),
  },
  {
    header: "Purchase Orders",
    accessorKey: "purchaseOrder",
    id: "purchaseOrder",
    cell: ({ row }: { row: any }) => (
      <div
        className="billing-action"
        onClick={() => handleNavigate(row?.original.id)}
      >
        <span>View</span>
      </div>
    ),
  },
];
