import React from "react";
import { BrowserRouter } from "react-router-dom";
import { render, screen, act } from "@testing-library/react";
import Billing from "./index";
import { Provider } from "react-redux";
import store from "../../redux/store";
import "regenerator-runtime";
import { useApi } from "../../shared/helpers";

const response = {
  customerID: "29055",
  customerName: "CSA-29055",
  billingAccounts: [
    {
      id: "0013L00000WLYrAQAX",
      name: "BAC-0013L00000WLYrAQAX",
      currency: "USD",
      default: true,
    },
    {
      id: "0015L00000WLYrAQAY",
      name: "EAC-0015L00000WLYrAQAY",
      currency: "GBP",
      default: false,
    },
    {
      id: "0014L00000WLYrAQAZ",
      name: "DAC-0014L00000WLYrAQAZ",
      currency: "LKR",
      default: false,
    },
  ],
};

jest.mock("../../shared/helpers/api", () => ({
  useApi: jest.fn(),
}));

describe("Billing", () => {
  beforeEach(() => {
    jest.useFakeTimers();
    (useApi as jest.Mock).mockReturnValue({
      getBillingAccounts: jest.fn().mockResolvedValue(response),
    });
  });

  it("should load accounts", async () => {
    await act(() =>
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Billing />
          </BrowserRouter>
        </Provider>
      )
    );

    expect(screen.queryByText("BAC-0013L00000WLYrAQAX")).toBeInTheDocument();
  });

  it("should not load unavalilable accounts", async () => {
    await act(() =>
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Billing />
          </BrowserRouter>
        </Provider>
      )
    );

    expect(
      screen.queryByText("test-account-MSP-nov15-23432")
    ).not.toBeInTheDocument();
  });

  it("should show no accounts messabe", async () => {
    await act(() =>
      render(
        <Provider store={store}>
          <BrowserRouter>
            <Billing />
          </BrowserRouter>
        </Provider>
      )
    );

    expect(
      screen.queryByText(
        "It appears you don't have any billing accounts at the moment."
      )
    ).toBeInTheDocument();
  });
});
