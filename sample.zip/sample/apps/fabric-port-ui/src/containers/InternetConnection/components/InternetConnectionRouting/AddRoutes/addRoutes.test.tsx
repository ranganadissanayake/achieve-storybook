import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import AddRoutes from "./index";
import { Provider } from "react-redux";
import store from "../../../../../redux/store";

describe("AddRoutes component", () => {
  const mockGetMetrix = jest.fn();

  beforeEach(() => {
    render(
      <Provider store={store}>
        <AddRoutes titleText="Test title" getMetrix={mockGetMetrix} isIpv4 />
      </Provider>,
    );
  });

  it("renders the title text", () => {
    expect(screen.getByText("Test title")).toBeInTheDocument();
  });

  it('adds a new row when "Add New" button is clicked', () => {
    const addButton = screen.getByRole("button", { name: "Add New" });
    fireEvent.click(addButton);
  });

  it("does not allow more than 5 rows", () => {
    const addButton = screen.getByRole("button", { name: "Add New" });
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
  });

  it('disables "Add New" button when there are already 5 rows', () => {
    const addButton = screen.getByRole("button", { name: "Add New" });
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    expect(addButton).toBeDisabled();
  });

  it('updates the "location" field in the state on user input', () => {
    const locationInput = screen.getByPlaceholderText("1");
    fireEvent.change(locationInput, { target: { value: "London" } });

    const updatedRow = { id: 0, name: "", prefix: "", location: "London" };
    expect(mockGetMetrix).toHaveBeenCalledWith([updatedRow]);
  });

  it("displays error message for duplicate name field", () => {
    const addButton = screen.getByRole("button", { name: "Add New" });
    fireEvent.click(addButton);

    const nameInput1 = screen.getByPlaceholderText("Data Subnet 1");
    fireEvent.change(nameInput1, { target: { value: "Test Name" } });

    const nameInput2 = screen.getByPlaceholderText("Data Subnet 2");
    fireEvent.change(nameInput2, { target: { value: "Test Name" } });
  });
});
