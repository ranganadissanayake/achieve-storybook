import React, { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";

import {
  Label,
  Input,
  Icon,
  Button,
  DropdownInput,
} from "@btdigital/nayan-component-library";

import {
  selectInternetRouting,
  updateInternetRouting,
  updateLevel,
  updateStep,
} from "../../../../../redux/internetSlice";
import { useIpv4FormInput } from "../../../../../shared/hooks";
import {
  INVALID_IPV4_MESSAGE,
  THIS_FIELD_CANNOT_BE_EMPTY,
} from "../../../../../shared/constants";
import Paginator from "../../../../../components/Paginator";
import { metrixTypeDiverse } from "../../../../../shared/types";
import ipRegex from "../../../../../shared/utils/ip-regex";
import { hasCommonName } from "../../../../../containers/IPAddressInventory/utils";
import "./AddRoutesDiverse.scss";

export interface PrefixList {
  id: string;
  value: string;
}

interface IpListField {
  id: number;
  name: string;
  prefix: string;
  prefixLength: string;
  location: string;
  priority: string;
  error?: string;
}

interface IpListEmptyField {
  id: number;
  name: boolean;
  prefix: boolean;
  prefixLength: boolean;
}

export interface AddRoutesDiverseProps {
  titleText?: string;
  colName?: string;
  colPrefix?: string;
  colPrefixLength?: string;
  Location?: string;
  colPrefixPlaceholder?: string;
  isIpv4: boolean;
  description?: string;
  prefixLengthList: PrefixList[];
  colPriority?: string;
  initiateNext?: boolean;
  isBfd?: boolean;
  getMetrix?: (metrixValue: metrixTypeDiverse[]) => void;
  v4Values?: metrixTypeDiverse[];
  v6Values?: metrixTypeDiverse[];
}

const AddRoutesDiverse: React.FC<AddRoutesDiverseProps> = ({
  titleText,
  colName,
  colPrefix,
  colPrefixLength,
  colPriority,
  colPrefixPlaceholder,
  prefixLengthList,
  getMetrix,
  description,
  isIpv4,
  initiateNext,
  isBfd,
  v4Values,
  v6Values
}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [searchParams, _] = useSearchParams();
  const isEdit = searchParams.get("status") === "edit";

  const { metrixValueDiverseState, routingTypeState } = useSelector(
    selectInternetRouting
  );
  const internetRoutingState = useSelector(selectInternetRouting);

  //empty two rows should be show by default
  const IpList: IpListField[] = [
    {
      id: 0,
      name: "",
      prefix: "",
      prefixLength: "",
      location: "",
      priority: "1",
    },
  ];

  const IpListWrapper = { ipV4: IpList, ipV6: IpList };
  const { appendPeriodToInput, hasInvalidIpv4Address } = useIpv4FormInput();

  const [ipListState, setIpListState] = useState(
    routingTypeState === "Static"
      ? isIpv4 && metrixValueDiverseState.ipV4
        ? metrixValueDiverseState.ipV4
        : metrixValueDiverseState.ipV6
        ? metrixValueDiverseState.ipV6
        : []
      : IpListWrapper.ipV4
  );
  const [_fieldIsEmpty, setFieldIsEmpty] = useState<IpListEmptyField[]>([]);

  const dataPerPage = 5;
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [chunkedDataSet, setChunkedDataSet] = useState<metrixTypeDiverse[]>([]);
  const lastIndex = currentPage * dataPerPage;
  const firstIndex = lastIndex - dataPerPage;
  const isHidePaginator = true;

  //creating a empty new row
  const addIpList = (length: number) => {
    setIpListState([
      ...ipListState,
      {
        id: length,
        name: "",
        prefix: "",
        prefixLength: "",
        location: "",
        priority: "1",
      },
    ]);
  };

  const removeIpList = (index: number) => {
    setIpListState((listItem) => listItem.filter((_, idx) => _.id !== index));
  };

  //passing metrix value as a call back for further use
  useEffect(() => {
    if (getMetrix) {
      getMetrix(ipListState);
    }
  }, [ipListState]);

  //check duplicates
  const checkDuplicates = (value: string, field: string) => {
    if (field === "name") {
      return ipListState.some((element) => element.name === value);
    } else if (field === "prefix") {
      return ipListState.some((element) => element.prefix === value);
    }
    return false;
  };

  //capture updates
  const updateFieldChanged = (value: string, index: number, field: string) => {
    if (_fieldIsEmpty.length > index) {
      if (field === "name") {
        _fieldIsEmpty[index].name = false;
      }
      if (field === "prefix") {
        _fieldIsEmpty[index].prefix = false;
      }
      if (field === "prefixLength") {
        _fieldIsEmpty[index].prefixLength = false;
      }
    }

    if (value != "") {
      checkDuplicates(value, field);
    }

    setIpListState((prev: IpListField[]) => {
      return prev.map((item, i) => {
        if (i === index) {
          if (field === "name") {
            return { ...item, name: value };
          } else if (field === "prefix") {
            if (isIpv4) {
              const updated = appendPeriodToInput(value, prev[i].prefix);
              const error = hasInvalidIpv4Address(updated);
              return {
                ...item,
                prefix: updated,
                error: error ? INVALID_IPV4_MESSAGE : undefined,
              };
            } else {
              const error = !ipRegex.v6({ exact: true }).test(value);
              return {
                ...item,
                prefix: value,
                error: error ? INVALID_IPV4_MESSAGE : undefined,
              };
            }
          } else if (field === "prefixLength") {
            return { ...item, prefixLength: value };
          } else if (field === "priority") {
            return { ...item, priority: value };
          } else {
            return { ...item, location: value };
          }
        } else {
          return item;
        }
      });
    });
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const nextPage = () => {
    if (currentPage !== totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const previousPage = () => {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const _navigateNext = React.useCallback( async () => {
    let navigateNext = true;

    setFieldIsEmpty(ipListState.map((field) => {
      return  {
        id: Number(field.id),
        name: field.name === "",
        prefix: field.prefix === "",
        prefixLength: field.prefixLength === "",
      };
    }));

    [...(v4Values || []), ...(v6Values || [])].forEach((field) => {
      const emptyFields = {
        id: field.id,
        name: field.name === "",
        prefix: field.prefix === "",
        prefixLength: field.prefixLength === "",
      };

      const isNameDuplicate =
        field.name !== "" &&
        ipListState.filter((item) => item.name === field.name).length > 1;
      const isPrefixDuplicate =
        field.prefix !== "" &&
        ipListState.filter((item) => item.prefix === field.prefix).length > 1;
      const isHavingSameNamesV4V6 = v4Values && v4Values?.length > 0 && v6Values && v6Values?.length > 0 && hasCommonName(v4Values, v6Values);

      if (
        emptyFields.name ||
        emptyFields.prefix ||
        emptyFields.prefixLength ||
        isNameDuplicate ||
        isPrefixDuplicate ||
        isHavingSameNamesV4V6 ||
        field?.error
      ) {
        navigateNext = false;
      }
    });

    if (navigateNext) {
      dispatch(
        updateInternetRouting({
          ...internetRoutingState,
          routingTypeState: "Static",
          metrixValueDiverseState: { ipV4: v4Values, ipV6: v6Values },
          bfdState: isBfd ? isBfd : false,
        })
      );
      dispatch(updateLevel(4));
      dispatch(updateStep(3));
      navigate(`/internet-connection/summary${isEdit ? "?status=edit" : ""}`);
    }
  }, [ipListState, internetRoutingState, v4Values, v6Values]);

  useEffect(() => {
    setTotalPages(Math.ceil(ipListState.length / dataPerPage));
    setChunkedDataSet(ipListState.slice(firstIndex, lastIndex));
  }, [ipListState, firstIndex, lastIndex]);

  React.useEffect(() => {
    if (initiateNext) {
      _navigateNext();
    }
  }, [initiateNext]);

  const IpV4ListView = chunkedDataSet.map((list: any, index: number) => {
    const isNameDuplicate =
      list.name !== "" &&
      ipListState.filter((item) => item.name === list.name).length > 1;
    const isPrefixDuplicate =
      list.prefix !== "" &&
      ipListState.filter((item) => item.prefix === list.prefix).length > 1;
    const isHavingSameNamesV4V6 = v4Values && v4Values?.length > 0 && v6Values && v6Values?.length > 0 && hasCommonName(v4Values, v6Values);

      const isErrorExist =
      _fieldIsEmpty.find((f) => f.id === list.id)?.name ||
      isNameDuplicate || isHavingSameNamesV4V6 ||
      _fieldIsEmpty.find((f) => f.id === list.id)?.prefix ||
      isPrefixDuplicate ||
      !!list?.error ||
      _fieldIsEmpty.find((f) => f.id === list.id)?.prefixLength;

    return (
      <div className="add-ip-routes-wrapper" key={index}>
        <div className="first-col">
          <Input
            label={index === 0 ? colName : ""}
            name="name"
            className={`ipv4-input ${index > 0 ? "spacing" : ""} ${
              isErrorExist ? "error_space" : ""
            }`}
            placeholder={`Data Subnet ${list.id + 1}`}
            labelSize="sm"
            state={
              _fieldIsEmpty.find((f) => f.id === list.id)?.name ||
              isNameDuplicate || isHavingSameNamesV4V6
                ? "error"
                : "default"
            }
            errorMessageSize="sm"
            showErrorIcon={false}
            onChange={(e: string) => updateFieldChanged(e, index, "name")}
            errorMessage={
              _fieldIsEmpty.find((f) => f.id === list.id)?.name
                ? THIS_FIELD_CANNOT_BE_EMPTY
                : isNameDuplicate
                ? "Values cannot be the same"
                : isHavingSameNamesV4V6
                ? "Please use different names for each"
                : ""
            }
            value={list?.name}
            labelTextStyles="routing_input_label"
          />
        </div>
        <div className="second-col">
          <Input
            label={index === 0 ? colPrefix : ""}
            name="prefix"
            className={`ipv4-input-prefix ${index > 0 ? "spacing" : ""} ${
              isErrorExist ? "error_space" : "default"
            }`}
            placeholder={colPrefixPlaceholder}
            labelSize="sm"
            errorMessageSize="sm"
            showErrorIcon={false}
            onChange={(e: string) => updateFieldChanged(e, index, "prefix")}
            state={
              _fieldIsEmpty.find((f) => f.id === list.id)?.prefix ||
              isPrefixDuplicate ||
              !!list?.error
                ? "error"
                : "default"
            }
            errorMessage={
              _fieldIsEmpty.find((f) => f.id === list.id)?.prefix
                ? THIS_FIELD_CANNOT_BE_EMPTY
                : isPrefixDuplicate
                ? "Values cannot be the same"
                : list?.error || ""
            }
            value={list?.prefix}
            labelTextStyles="routing_input_label"
          />
        </div>
        <div className="third-col">
          <DropdownInput
            label={index === 0 ? colPrefixLength : ""}
            name="prefixLength"
            className={`ipv4-input-prefixLength ${index > 0 ? "spacing" : ""} ${
              isErrorExist ? "error_space" : "default"
            }`}
            placeholder=""
            labelSize="sm"
            state={
              _fieldIsEmpty.find((f) => f.id === list.id)?.prefixLength
                ? "error"
                : "default"
            }
            errorMessageSize="sm"
            options={prefixLengthList}
            showErrorIcon={false}
            onSelect={(e: string) =>
              updateFieldChanged(e, index, "prefixLength")
            }
            errorMessage={
              _fieldIsEmpty.find((f) => f.id === list.id)?.prefixLength
                ? THIS_FIELD_CANNOT_BE_EMPTY
                : ""
            }
            value={list?.prefixLength}
            labelTextStyles="routing_input_label"
          />
        </div>
        <div className="forth-col">
          <Input
            label={index === 0 ? colPriority : ""}
            name="priority"
            className={`ipv4-input ${index > 0 ? "spacing" : ""} ${
              isErrorExist ? "error_space" : "default"
            }`}
            type="number"
            placeholder="1"
            labelSize="sm"
            state={"default"}
            errorMessageSize="sm"
            showErrorIcon={false}
            onChange={(e: string) => updateFieldChanged(e, index, "priority")}
            value={list?.priority}
            labelTextStyles="routing_input_label"
          />
        </div>
        <div className={`icon-col ${isErrorExist ? "error_space" : "default"}`}>
          {index > 0 && (
            <Icon
              title="bin_new"
              showOriginal
              onClick={() => removeIpList(+list.id)}
            />
          )}
        </div>
      </div>
    );
  });

  return (
    <>
      <div className="add-ip-routes">
        <Label text={titleText} size="lg" labelTextStyles="title" />
        <section className="routes-description">{description}</section>
        {IpV4ListView}
        <section className="action-area">
          <div className="add-new-btn">
            <Button
              iconTitle="expand_row"
              label="Add New"
              onPress={() => {
                if (ipListState.length < 5) {
                  addIpList(ipListState.length);
                }
              }}
              variant="outline"
              iconSize="sm"
              iconBefore={true}
              disabled={ipListState.length > 4 ? true : false}
              labelContainerCustomStyle="routing_btn"
            />
          </div>
          <div>
            {!isHidePaginator && (
              <Paginator
                currentPage={currentPage}
                onPageChange={handlePageChange}
                totalPages={totalPages}
                previousPage={previousPage}
                nextPage={nextPage}
              />
            )}
          </div>
        </section>
      </div>
    </>
  );
};

export default AddRoutesDiverse;
