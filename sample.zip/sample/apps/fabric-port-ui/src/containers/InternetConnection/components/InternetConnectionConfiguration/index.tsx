import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useSearchParams } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormProvider, useForm } from "react-hook-form";
import * as yup from "yup";

import {
  Button,
  Card,
  Icon,
  Input,
  Label,
  Modal,
  RangeBar,
  Tile,
  Toggle,
  UsageStackedGraph,
  ErrorMessage,
} from "@btdigital/nayan-component-library";

import InternetConnectionWrapper from "../../../../components/InternetConnectionWrapper";
import {
  dataMapper,
  getInternetServicesAllocationByPortId,
  validateRange,
  validateRangeInclusive,
} from "../../../../shared/utils";
import IPAddressing from "../IPAddressing";
import InternetConnectionRouting from "../InternetConnectionRouting";
import {
  resetInternetSlice,
  selectCurrentLevel,
  selectPortData,
  updateLevel,
  updateStep,
  updateInternetConfigurationData,
  selectInternetConfigurations,
  CreateInternetState,
} from "../../../../redux/internetSlice";
import {
  ConnectedDropdownInput,
  ConnectedInput,
  ConnectedTextarea,
} from "../../../../components/ConnectedFormElements";
import {
  MAX_NUMBER_OF_CHARACTERS,
  OUT_OF_RANGE,
  THIS_FIELD_CANNOT_BE_EMPTY,
  VLAN_ENCAPSULATION_METHODS,
  MIN_PORT_SPEED,
} from "../../../../shared/constants";
import {
  BandwidthType,
  InternetConfigurationData,
  PortInformation,
} from "../../../../shared/types";
import ModifyInLineText from "../../../../components/ModifyInLineText";
import { useApi } from "../../../../shared/helpers";
import images from "../../../../shared/assets";
import { selectInternet } from "../../../../redux/internetSlice";

import "./index.scss";

export enum BackgroundType {
  GRADIENT = "linear-gradient(90deg, #FF7F00 0%, #34A827 6.77%, #34A827 48.44%, #34A827 93.23%, #FF7F00 100%)",
  SUCCESS = "#088003",
  WARNING = "#ffc501",
  DEFAULT = "#5514b4",
  CRITICAL = "#da020f",
}

export const getAssociatedBandwidth = (
  portData: PortInformation,
  rowIndex: number,
) => {
  return Number(
    dataMapper(
      rowIndex === 0 && portData.isPrimaryLAG
        ? portData.primaryLAGMetadata?.lagPortSpeed
        : rowIndex === 1 && portData.isSecondaryLAG
        ? portData.secondaryLAGMetadata?.lagPortSpeed
        : portData.diversePortSubRows[Number(rowIndex)]?.portSpeed,
    ).split(" ")[0],
  );
};

const initialBandwidthData = [
  {
    amount: 0,
    fillColor: "#088003",
    label: "Used",
  },
];

const InternectConnConfigSchema = yup
  .object({
    connectionName: yup
      .string()
      .trim()
      .required(THIS_FIELD_CANNOT_BE_EMPTY)
      .max(30, MAX_NUMBER_OF_CHARACTERS(30)),
    connectionDescription: yup
      .string()
      .trim()
      .required()
      .nullable()
      .max(500, MAX_NUMBER_OF_CHARACTERS(500)),
    vlanEncapsulationMethod: yup.string().required(THIS_FIELD_CANNOT_BE_EMPTY),
    specificVlanId: yup
      .number()
      .required(THIS_FIELD_CANNOT_BE_EMPTY)
      .typeError(THIS_FIELD_CANNOT_BE_EMPTY)
      .nullable()
      .min(1, OUT_OF_RANGE(1, 4094))
      .max(4094, OUT_OF_RANGE(1, 4094)),
    mtu: yup
      .number()
      .required(THIS_FIELD_CANNOT_BE_EMPTY)
      .typeError(THIS_FIELD_CANNOT_BE_EMPTY)
      .nullable()
      .min(1440, OUT_OF_RANGE(1440, 1500))
      .max(1500, OUT_OF_RANGE(1440, 1500)),
  })
  .required();

type InternetConnConfigFormData = yup.InferType<
  typeof InternectConnConfigSchema
>;

const InternetConnectionConfiguration = () => {
  const api = useApi();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [searchParams, _] = useSearchParams();

  const internetDetails: InternetConfigurationData =
    useSelector(selectInternetConfigurations) || {};

  const { editInternetItem }: CreateInternetState = useSelector(selectInternet);

  const _internetEditItem: InternetConfigurationData = {
    ...editInternetItem,
    bandwidthType:
      editInternetItem?.bandwidthType?.toLocaleLowerCase() as BandwidthType,
    connectionName: editInternetItem?.internetName
      ? editInternetItem?.internetName
          .replace("[Primary] - ", "")
          .replace("[Secondary] - ", "")
          .substring(0, 30)
      : "",
    connectionDescription: editInternetItem?.internetDescription ?? "",
    isEnabledPredictiveBandwidth: !!editInternetItem?.isPredictiveMonitoring,
    isOversubscription: !!editInternetItem?.isOversubscription,
    isEnabledUtilisationMonitoring:
      !!editInternetItem?.staticBandwidthConfig?.staticMinBandwidthThreshold,
    isStatic: editInternetItem?.bandwidthType === "static",
    maxCommitBandwidth: dataMapper(
      editInternetItem?.burstableBandwidthConfig?.burstableMaxBandwidth ?? 0,
    ).split(" ")[0],
    minCommitBandwidth: dataMapper(
      editInternetItem?.burstableBandwidthConfig?.burstableMinCommitBandwidth ??
        0,
    ).split(" ")[0],
    maxUtilizationThreshold: `${
      editInternetItem?.staticBandwidthConfig?.staticMaxBandwidthThreshold ?? 0
    }`,
    minUtilizationThreshold: `${
      editInternetItem?.staticBandwidthConfig?.staticMinBandwidthThreshold ?? 0
    }`,
    vlanEncapsulationMethod: "Dot1Q",
    mtuSize: editInternetItem?.mtu ?? 1500,
    vlanId: editInternetItem?.vlanId,
    staticInternetBandwidth: dataMapper(
      editInternetItem?.staticBandwidthConfig?.staticBandwidth ?? 0,
    ).split(" ")[0],
  };

  const _currentLevel = useSelector(selectCurrentLevel);
  const _portData = useSelector(selectPortData);

  const _index = _portData[0].isPrimarySelected ? 0 : 1;

  const _associatedBandwidth = getAssociatedBandwidth(_portData[0], _index);

  const _associatedPortId = React.useMemo(() => {
    return (
      _portData[0].diversePortSubRows[Number(_index)]?.portId ??
      _portData[0].portId
    );
  }, [_portData, _index]);

  const ipAddressingRef = React.useRef<null | HTMLDivElement>(null);
  const routingRef = React.useRef<null | HTMLDivElement>(null);

  const [lastChangedField, setLastChangedField] = useState("");
  const _isModifyJourney = searchParams.get("status") === "edit";
  const _isEdit = internetDetails.connectionName !== "";
  const [_internetDetails, setInternetDetails] =
    React.useState<InternetConfigurationData>(
      _isModifyJourney ? _internetEditItem : internetDetails,
    );

  const internetConnConfigDefaultValues = {
    connectionName: _internetDetails.connectionName,
    connectionDescription:
      _internetDetails.connectionDescription === ""
        ? null
        : _internetDetails.connectionDescription,
    vlanEncapsulationMethod:
      _internetDetails.vlanEncapsulationMethod === ""
        ? VLAN_ENCAPSULATION_METHODS[0]
        : _internetDetails.vlanEncapsulationMethod,
    specificVlanId: _internetDetails.vlanId,
    mtu:
      _internetDetails.mtuSize === undefined || null
        ? 1500
        : _internetDetails.mtuSize,
  };

  const InternetConnConfigFormDataMethods = useForm<InternetConnConfigFormData>(
    {
      resolver: yupResolver(InternectConnConfigSchema),
      defaultValues: internetConnConfigDefaultValues,
      mode: "onChange",
    },
  );

  const [_isVisibleBanner, setIsVisiblebanner] = React.useState(true);
  const [_vlanPillText, setVlanPillText] = React.useState("");
  const [_isVlanIdAvailable, setIsVlanIdAvailable] = React.useState(true);

  const [_internetBandwidth, setInternetBandwidth] = React.useState("");
  const [_minCommitBandwidth, setMinCommitBandwidth] = React.useState("");
  const [_maxCommitBandwidth, setMaxCommitBandwidth] = React.useState("");

  const [_isEnabledUtilisationMonitoring, setIsEnabledUtilisationMonitoring] =
    React.useState(_internetDetails.isEnabledUtilisationMonitoring);
  const [_isUtilisationThresholdValid, setIsUtilisationThresholdValid] =
    React.useState(false);
  const [_isEnabledPredictiveBandwidth, setIsEnabledPredictiveBandwidth] =
    React.useState(false);

  const [_isStatic, setIsStatic] = React.useState(
    _internetDetails.isStatic === undefined ? true : _internetDetails.isStatic,
  );
  const [_isBurstable, setIsBurstable] = React.useState(
    _internetDetails.isStatic === undefined
      ? false
      : !_internetDetails.isStatic,
  );

  const [_bandwidthUsage, setBandwidthUsage] =
    React.useState(initialBandwidthData);

  const _availableBandwidth = React.useMemo(
    () => Number((_associatedBandwidth - _bandwidthUsage[0].amount).toFixed(3)),
    [_associatedBandwidth, _bandwidthUsage],
  );

  const [_minUtilisationThreshold, setMinUtilisationThreshold] = React.useState(
    _internetDetails.minUtilizationThreshold
      ? parseInt(_internetDetails.minUtilizationThreshold)
      : undefined,
  );
  const [_maxUtilisationThreshold, setMaxUtilisationThreshold] = React.useState(
    _internetDetails.maxUtilizationThreshold
      ? parseInt(_internetDetails.maxUtilizationThreshold)
      : undefined,
  );

  const [_vlanEncapMethod, setVlanEncapMethod] = React.useState(
    VLAN_ENCAPSULATION_METHODS[0],
  );

  const [_isMinThresholdEmpty, setIsMinThresholdEmpty] = React.useState(true);
  const [_isMaxThresholdEmpty, setIsMaxThresholdEmpty] = React.useState(true);

  const [_isContinueClicked, setIsContinueClicked] = React.useState(false);
  const [isOversubscription, setIsOversubscription] = React.useState(
    internetDetails?.isOversubscription || false,
  );

  const [_internetBandwidthError, setInternetBandwidthError] =
    React.useState("");
  const [_minCommitBandwidthError, setMinCommitBandwidthError] =
    React.useState("");
  const [_maxCommitBandwidthError, setMaxCommitBandwidthError] =
    React.useState("");
  const [_commitBandwidthError, setCommitBandwidthError] = React.useState("");

  const [_showModal, setShowModal] = React.useState(false);
  const [_initiateStep2NextAction, setInitiateStep2NextAction] =
    React.useState(false);
  const [_initiateStep3NextAction, setInitiateStep3NextAction] =
    React.useState(false);

  const [_availableBrustableBandwidth, setAvailableBrustableBandwidth] =
    React.useState(_associatedBandwidth);

  const getTargetText = () => {
    if (_isBurstable && _minCommitBandwidth) {
      return `${_minCommitBandwidth} Gbps`;
    } else if (_isStatic && _internetBandwidth) {
      return `${_internetBandwidth} Gbps`;
    } else {
      return "-- Gbps";
    }
  };

  const generateBandwidthData = (value: number, max?: number) => {
    if (_isStatic) {
      const selectedLowest = {
        amount: value,
        dashColor: "#088003",
        fillColor: "#E6F4E5",
        label: "Selected (Lowest)",
      };
      const datasetNew = [_bandwidthUsage[0], selectedLowest];
      setBandwidthUsage(datasetNew);
    } else {
      const selectedLowestB = {
        amount: value,
        dashColor: "#088003",
        fillColor: "#E6F4E5",
        label: "Selected (Lowest)",
      };
      const selectedMaxB = {
        amount: max && max > 0 ? max : 0,
        dashColor: "#088003",
        fillColor: "#C4E4BF",
        label: "Selected (Highest)",
      };
      const datasetNew1 = [_bandwidthUsage[0], selectedLowestB, selectedMaxB];
      setBandwidthUsage(datasetNew1);
    }
  };

  const _onModalOk = () => {
    dispatch(updateStep(1));
    dispatch(updateLevel(1));
    if (_isModifyJourney) {
      navigate("/internet-connection/attach-port?status=edit");
    } else {
      dispatch(resetInternetSlice());
      navigate("/internet-connection/attach-port");
    }
    setShowModal(false);
  };

  const _onSubmitStepOne = React.useCallback(
    (formValues: any) => {
      setIsContinueClicked(true);

      const validateStatic = () => {
        const isBandwidthValid =
          !_internetBandwidthError && _internetBandwidth && _isVlanIdAvailable;
        if (_isModifyJourney) return isBandwidthValid;
        return (
          isBandwidthValid &&
          (_isUtilisationThresholdValid || !_isEnabledUtilisationMonitoring)
        );
      };

      if (_currentLevel === 1) {
        if (_isStatic) {
          if (validateStatic()) {
            dispatch(updateLevel(2));
          }
        } else {
          if (
            !_minCommitBandwidthError &&
            _minCommitBandwidth &&
            !_maxCommitBandwidthError &&
            _maxCommitBandwidth &&
            (_isUtilisationThresholdValid ||
              !_isEnabledUtilisationMonitoring) &&
            _isVlanIdAvailable
          ) {
            dispatch(updateLevel(2));
          }
        }
      }

      if (!_internetBandwidthError) {
        dispatch(
          updateInternetConfigurationData({
            bandwidthType: _isStatic ? "static" : "burstable",
            connectionName: formValues.connectionName,
            maxCommitBandwidth: _maxCommitBandwidth,
            isEnabledPredictiveBandwidth: _isEnabledPredictiveBandwidth,
            isEnabledUtilisationMonitoring: _isEnabledUtilisationMonitoring,
            minCommitBandwidth: _minCommitBandwidth,
            staticInternetBandwidth: _internetBandwidth,
            connectionDescription: formValues.connectionDescription,
            minUtilizationThreshold: `${_minUtilisationThreshold}`,
            maxUtilizationThreshold: `${_maxUtilisationThreshold}`,
            vlanId: formValues.specificVlanId,
            mtuSize: formValues.mtu ? formValues.mtu : 1500,
            vlanEncapsulationMethod: formValues.vlanEncapsulationMethod,
            isStatic: _isStatic,
          }),
        );
      }
    },
    [
      _internetBandwidthError,
      _isStatic,
      _internetBandwidth,
      _isEnabledPredictiveBandwidth,
      _isEnabledUtilisationMonitoring,
      _minCommitBandwidth,
      _maxCommitBandwidth,
      _minCommitBandwidthError,
      _maxCommitBandwidthError,
      _isUtilisationThresholdValid,
      _minUtilisationThreshold,
      _maxUtilisationThreshold,
      _isVlanIdAvailable,
      _currentLevel,
    ],
  );

  const handleNext = React.useCallback(() => {
    let bandwidthErrorExist = false;

    if (_isStatic) {
      if (_internetBandwidth === "") {
        setInternetBandwidthError(THIS_FIELD_CANNOT_BE_EMPTY);
        bandwidthErrorExist = true;
      }
    } else {
      if (_minCommitBandwidth === "") {
        setMinCommitBandwidthError(THIS_FIELD_CANNOT_BE_EMPTY);
        bandwidthErrorExist = true;
      }
      if (_maxCommitBandwidth === "") {
        setMaxCommitBandwidthError(THIS_FIELD_CANNOT_BE_EMPTY);
        bandwidthErrorExist = true;
      }
    }

    if (
      _internetBandwidthError ||
      _minCommitBandwidthError ||
      _maxCommitBandwidthError
    ) {
      bandwidthErrorExist = true;
    }

    InternetConnConfigFormDataMethods.handleSubmit(_onSubmitStepOne)();

    if (!bandwidthErrorExist && _currentLevel === 2) {
      setInitiateStep2NextAction(true);
      setTimeout(() => {
        setInitiateStep2NextAction(false);
      }, 500);
    } else if (
      !bandwidthErrorExist &&
      (_currentLevel === 3 || _currentLevel === 4)
    ) {
      if (_isModifyJourney) {
        navigate(
          `/internet-connection/summary${
            _isModifyJourney ? "?status=edit" : ""
          }`,
        );
        return;
      }
      setInitiateStep3NextAction(true);
      setTimeout(() => {
        setInitiateStep3NextAction(false);
      }, 500);
    }
  }, [
    _currentLevel,
    _isStatic,
    _minUtilisationThreshold,
    _maxUtilisationThreshold,
    _minCommitBandwidth,
    _maxCommitBandwidth,
    _internetBandwidth,
    _isVlanIdAvailable,
    _isUtilisationThresholdValid,
    _isEnabledPredictiveBandwidth,
    _isEnabledUtilisationMonitoring,
  ]);

  React.useEffect(() => {
    if (_internetBandwidth && _internetBandwidth !== "0") {
      generateBandwidthData(+_internetBandwidth);
    } else if (_minCommitBandwidth && _maxCommitBandwidth) {
      generateBandwidthData(
        +_minCommitBandwidth,
        +_maxCommitBandwidth - +_minCommitBandwidth,
      );
    }
  }, [_internetBandwidth, _maxCommitBandwidth, _minCommitBandwidth]);

  React.useEffect(() => {
    const getBandwidthInfor = async () => {
      if (_associatedPortId) {
        const portDetailsResponse = await api.getPortDetails(_associatedPortId);
        const isOversubscription =
          portDetailsResponse.primaryPortMetadata.isOversubscription;
        const { totalUsedBandwidth } =
          await getInternetServicesAllocationByPortId(
            _associatedPortId,
            api,
            isOversubscription,
            _internetEditItem.connectionId,
          );

        setIsOversubscription(isOversubscription);
        setBandwidthUsage((prev) => {
          const newArr = [...prev];
          newArr[0] = { ...prev[0], amount: totalUsedBandwidth };
          return newArr;
        });
        setAvailableBrustableBandwidth(
          parseFloat((_associatedBandwidth - totalUsedBandwidth).toFixed(4)),
        );
      }
    };
    getBandwidthInfor();
  }, [_associatedPortId, _index, api]);

  React.useEffect(() => {
    setInternetDetails(
      _isModifyJourney && !_isEdit ? _internetEditItem : internetDetails,
    );
  }, []);

  React.useEffect(() => {
    if (
      _internetDetails.connectionName ||
      _internetDetails.bandwidthType ||
      _internetDetails.connectionDescription ||
      _internetDetails.isEnabledPredictiveBandwidth ||
      _internetDetails.vlanId ||
      _internetDetails.mtuSize ||
      _internetDetails.staticInternetBandwidth ||
      _internetDetails.isEnabledUtilisationMonitoring ||
      _internetDetails.maxCommitBandwidth ||
      _internetDetails.minCommitBandwidth ||
      _internetDetails.maxUtilizationThreshold ||
      _internetDetails.minUtilizationThreshold
    ) {
      setIsBurstable(_internetDetails.bandwidthType === "burstable");
      setIsStatic(_internetDetails.bandwidthType === "static");
      setIsEnabledPredictiveBandwidth(
        _internetDetails.isEnabledPredictiveBandwidth,
      );
      setInternetBandwidth(_internetDetails.staticInternetBandwidth);
      // setInternetBandwidth(
      //   _isModifyJourney && !_isEdit && _internetDetails.associatedPort !== _associatedPortId
      //     ? ""
      //     : _internetDetails.staticInternetBandwidth
      // );

      setIsEnabledUtilisationMonitoring(
        _internetDetails.isEnabledUtilisationMonitoring,
      );
      setMaxCommitBandwidth(
        _isModifyJourney &&
          !_isEdit &&
          _internetDetails.associatedPort !== _associatedPortId
          ? ""
          : _internetDetails.maxCommitBandwidth,
      );
      setMinCommitBandwidth(
        _isModifyJourney &&
          !_isEdit &&
          _internetDetails.associatedPort !== _associatedPortId
          ? ""
          : _internetDetails.minCommitBandwidth,
      );
    }
    setTimeout(() => window.scrollTo(0, 0), 200);
  }, [_associatedPortId, _internetDetails, _isModifyJourney]);

  React.useEffect(() => {
    if (_currentLevel === 2 && ipAddressingRef.current) {
      ipAddressingRef.current.scrollIntoView();
    }
    if (_currentLevel === 3 && routingRef.current) {
      routingRef.current.scrollIntoView();
    }
  }, [_currentLevel, ipAddressingRef, routingRef]);

  React.useEffect(() => {
    if (_vlanEncapMethod !== VLAN_ENCAPSULATION_METHODS[0]) {
      InternetConnConfigFormDataMethods.setValue("specificVlanId", null);
      setIsVlanIdAvailable(true);
      setVlanPillText("");
    } else {
      InternetConnConfigFormDataMethods.setValue("specificVlanId", NaN);
    }
  }, [_vlanEncapMethod]);

  React.useEffect(() => {
    if (_internetDetails.vlanId) {
      InternetConnConfigFormDataMethods.setValue(
        "specificVlanId",
        _internetDetails.vlanId,
      );
    }
  }, [_internetDetails.vlanId]);

  React.useEffect(() => {
    if (!_isEnabledUtilisationMonitoring) {
      setIsUtilisationThresholdValid(false);
      setLastChangedField("");
    }
  }, [_isEnabledUtilisationMonitoring]);

  React.useEffect(() => {
    if (
      internetDetails.isEnabledUtilisationMonitoring &&
      internetDetails.minUtilizationThreshold &&
      internetDetails.maxUtilizationThreshold
    ) {
      setIsUtilisationThresholdValid(true);
    }
  }, []);

  return (
    <>
      <InternetConnectionWrapper
        portsPreview={true}
        selectedPort={true}
        selectedPorts={_portData}
        handleNext={handleNext}
        handleBack={() => setShowModal(true)}
      >
        <FormProvider {...InternetConnConfigFormDataMethods}>
          <div className="fp-container">
            <div className="network-services-config__content-main fp-row">
              <div className="column-one col-16 sm:col-16 md:col-8 mt-16">
                <Card cardStyle="config_card">
                  <div>
                    <Label
                      text="Name & Description"
                      size="lg"
                      containerStyles="config-internet__container"
                      labelTextStyles="title"
                    />
                    <ConnectedInput
                      name="connectionName"
                      label="Connection Name"
                      containerStyles="config-connection-name__input"
                      labelTextStyles="config_field_label"
                      placeholder={MAX_NUMBER_OF_CHARACTERS(30)}
                      labelSize="sm"
                    />

                    <ConnectedTextarea
                      name="connectionDescription"
                      label="Description (optional)"
                      labelSize="sm"
                      placeholder={MAX_NUMBER_OF_CHARACTERS(500)}
                      containerStyles="config-connection-description__text-area"
                      labelTextStyles="config_field_label"
                      rows={8}
                      onChangeSideEffects={(val) => {
                        if (val === "") {
                          InternetConnConfigFormDataMethods.resetField(
                            "connectionDescription",
                          );
                        }
                      }}
                    />
                    <Label
                      text="Bandwidth"
                      size="sm"
                      containerStyles="config-connection-bandwidth__container"
                      labelTextStyles="title config_field_label"
                    />
                    <div className="config-connection-bandwidth__content-wrapper">
                      <Button
                        iconTitle={
                          _isStatic ? "radio_button_icon" : "radio_unchecked"
                        }
                        label="Static"
                        onPress={(v) => {
                          setIsStatic(true);
                          setIsBurstable(false);
                          setIsVisiblebanner(true);
                          setMinCommitBandwidth("");
                          setBandwidthUsage((prev) => [prev[0]]);
                          InternetConnConfigFormDataMethods.setValue(
                            "mtu",
                            1500,
                          );
                        }}
                        variant={_isStatic ? "solid" : "outline"}
                        iconBefore={true}
                        enableOriginalIcon
                        iconSize="sm"
                        iconCustomStyle="radio-button-icon"
                        dataTestId="static_btn"
                        className={`${_isStatic ? "bandwidth-button" : ""}`}
                        disabled={_isModifyJourney}
                      />
                      <Button
                        iconTitle={
                          _isBurstable ? "radio_button_icon" : "radio_unchecked"
                        }
                        label="Burstable"
                        onPress={() => {
                          setIsBurstable(true);
                          setIsStatic(false);
                          setIsVisiblebanner(true);
                          setInternetBandwidth("");
                          setBandwidthUsage((prev) => [prev[0]]);
                          InternetConnConfigFormDataMethods.setValue(
                            "mtu",
                            null,
                          );
                          if (
                            _availableBrustableBandwidth <= MIN_PORT_SPEED &&
                            !isOversubscription
                          ) {
                            setIsEnabledUtilisationMonitoring(false);
                            setIsEnabledPredictiveBandwidth(false);
                            setMinUtilisationThreshold(NaN);
                            setMaxUtilisationThreshold(NaN);
                          }
                        }}
                        variant={_isBurstable ? "solid" : "outline"}
                        iconBefore={true}
                        iconSize="sm"
                        enableOriginalIcon
                        iconCustomStyle="radio-button-icon"
                        dataTestId="burstable_btn"
                        className={`${_isBurstable ? "bandwidth-button" : ""}`}
                        disabled={_isModifyJourney}
                      />
                    </div>
                    {_isModifyJourney && (
                      <ModifyInLineText text="Changing this setting may affect the price on your invoice" />
                    )}
                    {_isVisibleBanner && _isStatic && (
                      <Tile customClassName="config-banner__wrapper">
                        <Icon color="#5514B4" size="sm" title="alert" />
                        <div className="config-banner__content">
                          <h3>Static</h3>
                          <p>
                            A fixed amount of bandwidth with a fixed price. Any
                            excess traffic is policed and dropped.
                          </p>
                        </div>
                        <Icon
                          color="#5514B4"
                          title="cross_new"
                          onClick={() => {
                            setIsVisiblebanner(!_isVisibleBanner);
                          }}
                        />
                      </Tile>
                    )}
                    {_isVisibleBanner &&
                      _isBurstable &&
                      _availableBrustableBandwidth > MIN_PORT_SPEED && (
                        <Tile customClassName="config-banner__wrapper">
                          <Icon color="#5514B4" size="sm" title="alert" />
                          <div className="config-banner__content">
                            <h3>Burstable</h3>
                            <p>
                              Burstable bandwidth has a fixed rate for minimum
                              committed bandwidth and a usage-based price for
                              traffic sent between the minimum and maximum
                              bandwidth. Traffic exceeding the maximum bandwidth
                              rates is dropped.
                            </p>
                          </div>
                          <Icon
                            color="#5514B4"
                            title="cross_new"
                            onClick={() => {
                              setIsVisiblebanner(!_isVisibleBanner);
                            }}
                          />
                        </Tile>
                      )}
                    {_isBurstable &&
                      _availableBrustableBandwidth <= MIN_PORT_SPEED &&
                      !isOversubscription && (
                        <div className="bandwidth-shortage-message mt-8">
                          <img
                            src={images.errorInfoIcon}
                            className="errorInfo-icon"
                          />
                          <ErrorMessage
                            message="Bandwidth shortage: Selected port capped at 1 Mbps.
                        Burstable bandwidth configuration is not supported. 
                        Please review your network settings and consider 
                        upgrading the port capacity for optimal performance."
                            showIcon={false}
                            size="sm"
                          />
                        </div>
                      )}
                    <ConnectedDropdownInput
                      name="vlanEncapsulationMethod"
                      label="VLAN encapsulation method"
                      onChangeSideEffects={(val) => {
                        setVlanEncapMethod(val);
                      }}
                      options={VLAN_ENCAPSULATION_METHODS.map((v) => {
                        return { value: v, id: v };
                      })}
                      state={
                        _isBurstable &&
                        _availableBrustableBandwidth <= MIN_PORT_SPEED &&
                        !isOversubscription
                          ? "disabled"
                          : "default"
                      }
                      containerStyles="config-connection-name__input"
                      labelTextStyles="config_field_label"
                    />
                    {_vlanEncapMethod === VLAN_ENCAPSULATION_METHODS[0] && (
                      <ConnectedInput
                        name="specificVlanId"
                        helper="Select specific VLAN ID, range from 1 to 4094"
                        labelSize="sm"
                        containerStyles="config-connection-name__input"
                        type="integer"
                        placeholder="Input integer between 1 to 4094"
                        onChangeSideEffects={(val) => {
                          const isValValid = validateRange(
                            parseInt(val),
                            0,
                            4095,
                          );
                          setIsVlanIdAvailable(isValValid);
                          setVlanPillText("");
                        }}
                        state={
                          _isBurstable &&
                          _availableBrustableBandwidth <= MIN_PORT_SPEED &&
                          !isOversubscription
                            ? "disabled"
                            : "default"
                        }
                        primaryBadgeBefore
                        primaryBadgeIconShowOriginal={_isVlanIdAvailable}
                        primaryBadgeIcon={
                          _isVlanIdAvailable ? "single_tick" : "cross_new"
                        }
                        primaryBadgeIconColor={
                          _isVlanIdAvailable ? "#088003" : " #DA020F"
                        }
                        primaryBadgeCustomStyle={
                          _isVlanIdAvailable
                            ? "vlan-badge-success"
                            : "vlan-badge-error"
                        }
                        primaryBadgeText={_vlanPillText}
                        primaryBadgeTextStyle={
                          _isVlanIdAvailable
                            ? "vlan-text-success"
                            : "vlan-text-error"
                        }
                      />
                    )}
                    {(_isStatic || _isBurstable) && (
                      <ConnectedInput
                        name="mtu"
                        label="Maximum Transmission Unit (MTU)"
                        type="integer"
                        containerStyles="config-connection-name__input"
                        labelTextStyles="config_field_label"
                        labelSize="sm"
                        placeholder="Permissible values: 1440-1500"
                      />
                    )}
                  </div>
                </Card>
              </div>
              <div className="column-two col-16 sm:col-16 md:col-8 mt-16">
                <Card cardStyle="config_card">
                  <div>
                    <Label
                      text="Bandwidth & Layer 2"
                      size="lg"
                      containerStyles="config-settings__container"
                      labelTextStyles="title"
                    />
                    <UsageStackedGraph
                      graphData={_bandwidthUsage}
                      unitText="Gbps"
                      title="Associated Port Bandwidth"
                      showRemaining
                      totalAmount={_associatedBandwidth}
                    />
                    {_isStatic && (
                      <Input
                        label="Enter Internet Bandwidth (Gbps)"
                        name="internet_bandwidth"
                        labelSize="sm"
                        containerStyles="config-connection-name__input"
                        labelTextStyles="config_field_label"
                        type="float"
                        numberOfDecimalPlaces={3}
                        value={_internetBandwidth}
                        onChange={(value: string) => {
                          const validVal = validateRangeInclusive(
                            Number(value),
                            0.001,
                            _availableBandwidth,
                          );
                          if (value.length < 8) {
                            setInternetBandwidth(value === "0" ? "" : value);
                          }
                          if (
                            !validVal &&
                            value !== "" &&
                            !isOversubscription
                          ) {
                            setInternetBandwidthError(
                              `Out of range (0.001 to ${_availableBandwidth})`,
                            );
                            generateBandwidthData(0);
                          } else {
                            generateBandwidthData(+value);
                            setInternetBandwidthError("");
                          }
                        }}
                        state={_internetBandwidthError ? "error" : "default"}
                        errorMessage={_internetBandwidthError}
                        errorMessageSize="sm"
                        showErrorIcon={false}
                      />
                    )}
                    {_isBurstable && (
                      <div className="burstable_bandwidth__wrapper">
                        <Label
                          text="Enter Internet Bandwidth (Gbps)"
                          size="sm"
                          labelTextStyles="config_field_label"
                        />
                        <div className="burstable_bandwidth__inputs">
                          <Input
                            helper="Min commit bandwidth"
                            name="minCommitBandwidth"
                            value={_minCommitBandwidth}
                            onChange={(value: string) => {
                              const isWithinRange = validateRangeInclusive(
                                Number(value),
                                0.001,
                                _availableBandwidth - 0.001,
                              );

                              const isWithinRangeMax =
                                _maxCommitBandwidth !== ""
                                  ? validateRange(
                                      parseInt(_maxCommitBandwidth),
                                      0,
                                      _associatedBandwidth,
                                    )
                                  : true;

                              const isValueValid =
                                _maxCommitBandwidth === "" ||
                                Number(value) < Number(_maxCommitBandwidth);

                              if (value.length < 8) {
                                setMinCommitBandwidth(
                                  value === "0" ? "" : value,
                                );
                              }
                              if (!isValueValid && value !== "") {
                                setMinCommitBandwidthError(
                                  "Value must be less than max bandwidth",
                                );
                              } else {
                                setMinCommitBandwidthError("");
                              }

                              if (!isWithinRange && value !== "") {
                                setMinCommitBandwidthError(
                                  `Out of range (0.001 to ${(
                                    _availableBandwidth - 0.001
                                  ).toFixed(3)})`,
                                );
                                generateBandwidthData(
                                  0,
                                  parseInt(_maxCommitBandwidth) -
                                    parseInt(value),
                                );
                              } else if (isWithinRangeMax) {
                                generateBandwidthData(
                                  +value,
                                  Number(_maxCommitBandwidth) - Number(value),
                                );
                                setCommitBandwidthError("");
                              }

                              if (
                                _maxCommitBandwidth !== "" &&
                                _maxCommitBandwidthError &&
                                !_maxCommitBandwidthError.includes(
                                  "Out of range",
                                ) &&
                                Number(_maxCommitBandwidth) >
                                  (Number(value) || 0)
                              ) {
                                setMaxCommitBandwidthError("");
                              }
                            }}
                            containerStyles="config-connection-name__input"
                            labelSize="sm"
                            type="float"
                            numberOfDecimalPlaces={3}
                            state={
                              _minCommitBandwidthError || _commitBandwidthError
                                ? "error"
                                : _isBurstable &&
                                  _availableBrustableBandwidth <=
                                    MIN_PORT_SPEED &&
                                  !isOversubscription
                                ? "disabled"
                                : "default"
                            }
                            errorMessage={_minCommitBandwidthError}
                            errorMessageSize="sm"
                            showErrorIcon={false}
                          />
                          <Input
                            helper="Max bandwidth"
                            name="maxCommitBandwith"
                            value={_maxCommitBandwidth}
                            onChange={(value: string) => {
                              const availableBandwidth =
                                _associatedBandwidth -
                                _bandwidthUsage[0].amount -
                                parseInt(
                                  _minCommitBandwidth === ""
                                    ? "0"
                                    : _minCommitBandwidth,
                                );

                              const isWithinRange = validateRangeInclusive(
                                Number(value),
                                0.002,
                                _availableBandwidth,
                              );

                              const isValueValid =
                                _minCommitBandwidth === "" ||
                                Number(value) > Number(_minCommitBandwidth);

                              if (value.length < 8) {
                                setMaxCommitBandwidth(
                                  value === "0" ? "" : value,
                                );
                              }
                              if (!isValueValid && value !== "") {
                                setMaxCommitBandwidthError(
                                  "Value must be greater than min commit",
                                );
                              } else {
                                setMaxCommitBandwidthError("");
                              }

                              if (
                                !isWithinRange &&
                                value !== "" &&
                                !isOversubscription
                              ) {
                                setMaxCommitBandwidthError(
                                  `Out of range (0.002 to ${_availableBandwidth})`,
                                );
                                generateBandwidthData(+_minCommitBandwidth, 0);
                              } else {
                                generateBandwidthData(
                                  +_minCommitBandwidth,
                                  Number(value) - Number(_minCommitBandwidth),
                                );
                                setCommitBandwidthError("");
                              }

                              if (
                                _minCommitBandwidth !== "" &&
                                _minCommitBandwidthError &&
                                !_minCommitBandwidthError.includes(
                                  "Out of range",
                                ) &&
                                Number(_minCommitBandwidth) <
                                  (Number(value) || availableBandwidth)
                              ) {
                                setMinCommitBandwidthError("");
                              }
                            }}
                            containerStyles="config-connection-name__input"
                            labelSize="sm"
                            type="float"
                            numberOfDecimalPlaces={3}
                            state={
                              _maxCommitBandwidthError || _commitBandwidthError
                                ? "error"
                                : _isBurstable &&
                                  _availableBrustableBandwidth <=
                                    MIN_PORT_SPEED &&
                                  !isOversubscription
                                ? "disabled"
                                : "default"
                            }
                            errorMessage={_maxCommitBandwidthError}
                            errorMessageSize="sm"
                            showErrorIcon={false}
                          />
                        </div>
                        {_commitBandwidthError &&
                          _minCommitBandwidthError === "" &&
                          _maxCommitBandwidthError === "" && (
                            <ErrorMessage
                              message={_commitBandwidthError}
                              size="sm"
                              showIcon={false}
                            />
                          )}
                      </div>
                    )}
                    <div className="config-bandwidth-uti-monitoring mb-16">
                      <Label
                        text="Bandwidth Utilisation Monitoring"
                        size="sm"
                        labelTextStyles="config_field_label"
                      />
                      <Toggle
                        checked={_isEnabledUtilisationMonitoring}
                        onChange={() => {
                          setIsEnabledUtilisationMonitoring(
                            !_isEnabledUtilisationMonitoring,
                          );
                        }}
                        disabled={
                          _isModifyJourney ||
                          (_isBurstable &&
                            _availableBrustableBandwidth <= MIN_PORT_SPEED &&
                            !isOversubscription)
                        }
                      />
                    </div>

                    {_isEnabledUtilisationMonitoring && (
                      <Card cardStyle="monitoring-alarm__wrapper">
                        <Label
                          text="Monitoring alarm setting"
                          size="sm"
                          labelTextStyles="config_field_label"
                        />
                        <RangeBar
                          backgroundType={BackgroundType.GRADIENT}
                          customStyle="config-monitoring__rangebar"
                          enableScale
                          defaultMinValue={_minUtilisationThreshold}
                          defaultMaxValue={_maxUtilisationThreshold}
                          errorMinGreaterThanMax={
                            lastChangedField === "min"
                              ? "Value must be less than max threshold"
                              : ""
                          }
                          errorMaxGreaterThanMin={
                            lastChangedField === "max"
                              ? "Value must be greater than min threshold"
                              : ""
                          }
                          customMaxInputStyle="input-text-range-bar"
                          customMinInputStyle="input-text-range-bar"
                          labelMax="Max Utilisation Threshold (%)"
                          labelMin="Min Utilisation Threshold (%)"
                          maxErrorText="Out of Range (1 to 100%)"
                          maxInputRange={[1, 100]}
                          minErrorText="Out of Range (0 to 99%)"
                          minInputRange={[0, 99]}
                          showMaxErrorIcon={false}
                          showMinErrorIcon={false}
                          targetText={getTargetText()}
                          targetTextAlign="center"
                          minPlaceholder={"0-99%"}
                          maxPlaceholder={"1-100%"}
                          keepErrorSpace={true}
                          errorMinIsEmpty={
                            _isEnabledUtilisationMonitoring &&
                            _isMinThresholdEmpty &&
                            _isContinueClicked
                              ? "Min cannot be empty"
                              : ""
                          }
                          errorMaxIsEmpty={
                            _isEnabledUtilisationMonitoring &&
                            _isMaxThresholdEmpty &&
                            _isContinueClicked
                              ? "Max cannot be empty"
                              : ""
                          }
                          onMinChange={(v: number) => {
                            setMinUtilisationThreshold(v);
                            setIsMinThresholdEmpty(false);
                            setLastChangedField("min");
                            if (
                              _maxUtilisationThreshold &&
                              v >= 0 &&
                              v < _maxUtilisationThreshold
                            ) {
                              setIsUtilisationThresholdValid(true);
                            } else {
                              setIsUtilisationThresholdValid(false);
                            }
                          }}
                          onMaxChange={(v: number) => {
                            setMaxUtilisationThreshold(v);
                            setIsMaxThresholdEmpty(false);
                            setLastChangedField("max");
                            if (
                              (_minUtilisationThreshold ||
                                _minUtilisationThreshold === 0) &&
                              v < 101 &&
                              v > _minUtilisationThreshold
                            ) {
                              setIsUtilisationThresholdValid(true);
                            } else {
                              setIsUtilisationThresholdValid(false);
                            }
                          }}
                          disabled={
                            _isModifyJourney ||
                            (_isBurstable &&
                              _availableBrustableBandwidth <= MIN_PORT_SPEED &&
                              !isOversubscription)
                          }
                        />
                        <div className="config-bandwidth-uti-monitoring">
                          <Label
                            text="Predictive Bandwidth Optimisation"
                            size="sm"
                            labelTextStyles="config_field_label"
                          />
                          <Toggle
                            checked={_isEnabledPredictiveBandwidth}
                            onChange={(val) => {
                              setIsEnabledPredictiveBandwidth(val);
                            }}
                            disabled={
                              _isModifyJourney ||
                              (_isBurstable &&
                                _availableBrustableBandwidth <=
                                  MIN_PORT_SPEED &&
                                !isOversubscription)
                            }
                          />
                        </div>
                        {_isEnabledPredictiveBandwidth && (
                          <p className="predictive_bandwidth">
                            This optimisation utilizes the same utilisation
                            threshold settings mentioned above. When enabled, it
                            generates an alert if a threshold is predicted to be
                            exceeded within the next month.
                          </p>
                        )}
                      </Card>
                    )}
                  </div>
                </Card>
              </div>
              {_currentLevel > 1 && (
                <div className="col-16">
                  <div ref={ipAddressingRef} className="ref_holder">
                    <IPAddressing initiateNext={_initiateStep2NextAction} />
                  </div>
                </div>
              )}

              {_currentLevel > 2 && (
                <div className="col-16">
                  <div ref={routingRef} className="ref_holder">
                    <InternetConnectionRouting
                      initiateNext={_initiateStep3NextAction}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </FormProvider>
      </InternetConnectionWrapper>
      <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        topIconSize="md"
        title="Leave without saving changes"
        complementaryMessage="Are you sure you want to leave this page? Your setup information will be lost."
        contentAlign="center"
        actionText="Leave"
        onOk={_onModalOk}
        closeModal={!_showModal}
        onCancel={() => setShowModal(false)}
      />
    </>
  );
};

export default InternetConnectionConfiguration;
