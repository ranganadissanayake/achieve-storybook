import React from "react";
import { BrowserRouter } from "react-router-dom";
import { render, screen, fireEvent } from "@testing-library/react";

import AddRoutesDiverse from "./index";
import { Provider } from "react-redux";
import store from "../../../../../redux/store";
import { IP_V4_ALL_PREFIXES, IP_V6_ALL_PREFIXES } from "../../../../../shared/constants/common";

describe("AppRouteDiverse Component", () => {
  const mockGetMetrix = jest.fn();

  beforeEach(() => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <AddRoutesDiverse
            prefixLengthList={IP_V4_ALL_PREFIXES}
            titleText="Test title"
            getMetrix={mockGetMetrix}
            isIpv4
            colName="Name"
            colPrefix="IPv4 Prefix"
            colPrefixLength="Prefix Length"
            colPriority="Priority"
          />
        </BrowserRouter>
      </Provider>,
    );
  });

  it("renders the title text", () => {
    expect(screen.getByText("Test title")).toBeInTheDocument();
  });

  it("renders the the necessary fields", () => {
    expect(screen.getByText("Name")).toBeInTheDocument();
    expect(screen.getByText("IPv4 Prefix")).toBeInTheDocument();
    expect(screen.getByText("Prefix Length")).toBeInTheDocument();
    expect(screen.getByText("Priority")).toBeInTheDocument();
  });

  it('adds a new row when "Add New" button is clicked', () => {
    const addButton = screen.getByRole("button", { name: "Add New" });
    fireEvent.click(addButton);
  });

  it("does not allow more than 5 rows", () => {
    const addButton = screen.getByRole("button", { name: "Add New" });
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
  });

  it('disables "Add New" button when there are already 5 rows', () => {
    const addButton = screen.getByRole("button", { name: "Add New" });
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    fireEvent.click(addButton);
    expect(addButton).toBeDisabled();
  });
  it('updates the "location" field in the state on user input', () => {
    const locationInput = screen.getByPlaceholderText("1");
    fireEvent.change(locationInput, { target: { value: "London" } });
  });

  it("displays error message for duplicate name field", () => {
    const addButton = screen.getByRole("button", { name: "Add New" });
    fireEvent.click(addButton);

    const nameInput1 = screen.getByPlaceholderText("Data Subnet 1");
    fireEvent.change(nameInput1, { target: { value: "Test Name" } });

    const nameInput2 = screen.getByPlaceholderText("Data Subnet 2");
    fireEvent.change(nameInput2, { target: { value: "Test Name" } });
  });
});

describe("AppRouteDiverse Component for ipv6", () => {
  const mockGetMetrix = jest.fn();

  beforeEach(() => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <AddRoutesDiverse
            prefixLengthList={IP_V6_ALL_PREFIXES}
            titleText="IPv6 Routes"
            getMetrix={mockGetMetrix}
            isIpv4={false}
            colName="Name"
            colPrefix="IPv6 Prefix"
            colPrefixLength="Prefix Length"
            colPrefixPlaceholder="2001:2a56:a321:4563::"
            colPriority="Priority"
            description="Same IP Routes should be provided for both the primary and secondary ports."
            isBfd={true}
          />
        </BrowserRouter>
      </Provider>,
    );
  });

  it("renders the title text", () => {
    expect(screen.getByText("IPv6 Routes")).toBeInTheDocument();
  });

  it("renders the description text", () => {
    expect(screen.getByText("Same IP Routes should be provided for both the primary and secondary ports.")).toBeInTheDocument();
  });
});
