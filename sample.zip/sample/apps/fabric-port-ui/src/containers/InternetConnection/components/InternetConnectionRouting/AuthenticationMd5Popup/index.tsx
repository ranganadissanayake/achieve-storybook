import React, { useEffect, useState } from "react";
import { Label, Input, Button } from "@btdigital/nayan-component-library";
import images from "../../../../../shared/assets";
import "./AuthenticationMd5Popup.scss";
import { usePasswordValidation } from "./hooks/usePasswordValidation";

export interface AuthenticationMd5PopupProps {
  onCancel: () => void;
  onConfirm: (v: string) => void;
  defaultPassword?: string;
}
export type InputType = "default" | "success" | "error" | "disabled";

const AuthenticationMd5Popup: React.FC<AuthenticationMd5PopupProps> = ({
  onConfirm,
  defaultPassword
}) => {
  const [password, setPassword] = useState(defaultPassword ?? "");
  const [showPassword, setShowPassword] = useState(false);
  const [isValidPassword, setIsValidPassword] = useState(false);
  const [_isFocusOnTyping, setIsFocusOnTyping] = useState(false);
  const [_isFocusOnTypingRetype, setIsFocusOnTypingRetype] = useState(false);
  const [_inputNewPasswordState, setInputNewPasswordState] =
    useState<InputType>("default");

  const [passwordRetype, setPasswordRetype] = useState(defaultPassword ?? "");
  const [showPasswordRetype, setShowPasswordRetype] = useState(false);
  const [_isPasswordsMatch, setIsPasswordsMatch] = useState(false);
  const [_inputConfirmPasswordState, setInputConfirmPasswordState] =
    useState<InputType>("disabled");

  const [
    validMinLength,
    validMaxLength,
    hasNumber,
    specialChar,
    upperCase,
    lowerCase,
    firstCharNumber,
  ] = usePasswordValidation({
    password: password,
  });

  // Click on new password input
  const _onChangePassword = (e: string) => {
    setPassword(e);
  };

  // Click on confirm password input
  const _onChangePasswordRetype = (e: string) => {
    setPasswordRetype(e);
  };

  useEffect(() => {
    if (password.toString() === passwordRetype.toString()) {
      setIsPasswordsMatch(true);
      setInputConfirmPasswordState("success");
      setInputNewPasswordState("success");
    } else {
      setIsPasswordsMatch(false);
      setInputConfirmPasswordState("default");
    }
  }, [passwordRetype, password]);

  useEffect(() => {
    if (
      password &&
      validMinLength &&
      validMaxLength &&
      specialChar &&
      hasNumber &&
      lowerCase &&
      upperCase &&
      firstCharNumber &&
      _isPasswordsMatch
    ) {
      setIsValidPassword(true);
    } else {
      setIsValidPassword(false);
    }
  }, [
    firstCharNumber,
    hasNumber,
    lowerCase,
    password,
    specialChar,
    upperCase,
    validMinLength,
    validMaxLength,
    _isPasswordsMatch,
  ]);

  useEffect(() => {
    if (
      password &&
      validMinLength &&
      validMaxLength &&
      specialChar &&
      hasNumber &&
      lowerCase &&
      upperCase &&
      firstCharNumber
    ) {
      setInputConfirmPasswordState("default");
      setInputNewPasswordState("success");
    } else {
      setInputConfirmPasswordState("disabled");
      setInputNewPasswordState("default");
    }
  }, [
    firstCharNumber,
    hasNumber,
    lowerCase,
    password,
    specialChar,
    upperCase,
    validMaxLength,
    validMinLength,
  ]);

  // Click when confirm button
  const _onConfirm = () => {
    if (isValidPassword) {
      onConfirm(password);
      setInputNewPasswordState("success");
      setInputConfirmPasswordState("success");
    } else {
      if (passwordRetype) {
        setInputConfirmPasswordState("error");
      }
      setInputNewPasswordState("error");
    }
  };
  return (
    <>
      <div className="auth-md5__wrapper fp-row">
        <div className="col-16 auth-icon">
          <img src={images.authMd5} alt="authentication-md5" />
        </div>
        <div className="col-16 auth-title">
          <Label text="Enable MD5 Authentication " />
        </div>
        <div className="col-16 auth-md5-input__wrapper">
          <div className="container">
            <Button
              className={`input-action`}
              onPress={() => {
                if (password) {
                  setShowPassword(!showPassword);
                }
              }}
              variant={"white"}
              iconBefore={true}
              enableOriginalIcon={true}
              iconTitle={showPassword ? "eye_close" : "eye_open"}
            />
            <Input
              data-testid="new-password"
              label="New Password"
              name="newPassword"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={_onChangePassword}
              containerStyles="input-password"
              labelSize="sm"
              state={_inputNewPasswordState}
              errorMessage=""
              errorMessageSize="sm"
              showErrorIcon={false}
              helper={_isFocusOnTyping ? `${password.length}/80` : ""}
              maxLength={80}
              onFocus={() => setIsFocusOnTyping(true)}
              onBlur={() => {
                if (!password) {
                  setIsFocusOnTyping(false);
                }
              }}
            />
          </div>
        </div>
        {_isFocusOnTyping && (
          <div className="col-16 auth-md5-input-errors__wrapper">
            <div className="container">
              <Label
                text="Password must have :"
                labelTextStyles="auth-md5-input-errors__main-heading"
              />
              <ul className="errors">
                {password ? (
                  <>
                    {firstCharNumber ? (
                      <li className="error error-primary">
                        <img src={images.tickActive} alt="" className="icon" />
                        <p>First character not a number</p>
                      </li>
                    ) : (
                      <li className="error error-secondary">
                        <img src={images.cross} alt="" className="icon" />
                        <p>First character not a number</p>
                      </li>
                    )}
                    {validMaxLength ? (
                      <li className="error error-primary">
                        <img src={images.tickActive} alt="" className="icon" />
                        <p>Maximum 80 characters</p>
                      </li>
                    ) : (
                      <li className="error error-secondary">
                        <img src={images.cross} alt="" className="icon" />
                        <p>Maximum 80 characters</p>
                      </li>
                    )}
                    {validMinLength ? (
                      <li className="error error-primary">
                        <img src={images.tickActive} alt="" className="icon" />
                        <p>Minimum 4 characters</p>
                      </li>
                    ) : (
                      <li className="error error-secondary">
                        <img src={images.cross} alt="" className="icon" />
                        <p>Minimum 4 characters</p>
                      </li>
                    )}
                    {upperCase ? (
                      <li className="error error-primary">
                        <img src={images.tickActive} alt="" className="icon" />
                        <p>An uppercase character</p>
                      </li>
                    ) : (
                      <li className="error error-secondary">
                        <img src={images.cross} alt="" className="icon" />
                        <p>An uppercase character</p>
                      </li>
                    )}
                    {lowerCase ? (
                      <li className="error error-primary">
                        <img src={images.tickActive} alt="" className="icon" />
                        <p>A lowercase character</p>
                      </li>
                    ) : (
                      <li className="error error-secondary">
                        <img src={images.cross} alt="" className="icon" />
                        <p>A lowercase character</p>
                      </li>
                    )}
                    {hasNumber ? (
                      <li className="error error-primary">
                        <img src={images.tickActive} alt="" className="icon" />
                        <p>A number</p>
                      </li>
                    ) : (
                      <li className="error error-secondary">
                        <img src={images.cross} alt="" className="icon" />
                        <p>A number</p>
                      </li>
                    )}
                    {specialChar ? (
                      <li className="error error-primary">
                        <img src={images.tickActive} alt="" className="icon" />
                        <p>A special character (!@#.$%^&*+=-)</p>
                      </li>
                    ) : (
                      <li className="error error-secondary">
                        <img src={images.cross} alt="" className="icon" />
                        <p>A special character (!@#.$%^&*+=-)</p>
                      </li>
                    )}
                    {_isPasswordsMatch ? (
                      <li className="error error-primary">
                        <img src={images.tickActive} alt="" className="icon" />
                        <p>Passwords must match</p>
                      </li>
                    ) : (
                      <li className="error error-secondary">
                        <img src={images.cross} alt="" className="icon" />
                        <p>Passwords must match</p>
                      </li>
                    )}
                  </>
                ) : (
                  <>
                    <li className="error error-default">
                      <img src={images.tickDiabled} alt="" className="icon" />
                      <p>First character not a number</p>
                    </li>
                    <li className="error error-default">
                      <img src={images.tickDiabled} alt="" className="icon" />
                      <p>Maximum 80 characters</p>
                    </li>
                    <li className="error error-default">
                      <img src={images.tickDiabled} alt="" className="icon" />
                      <p>Minimum 4 characters</p>
                    </li>
                    <li className="error error-default">
                      <img src={images.tickDiabled} alt="" className="icon" />
                      <p>An uppercase character</p>
                    </li>
                    <li className="error error-default">
                      <img src={images.tickDiabled} alt="" className="icon" />
                      <p>A lowercase character</p>
                    </li>
                    <li className="error error-default">
                      <img src={images.tickDiabled} alt="" className="icon" />
                      <p>A number </p>
                    </li>
                    <li className="error error-default">
                      <img src={images.tickDiabled} alt="" className="icon" />
                      <p>A special character (!@#.$%^&*+=-)</p>
                    </li>
                    <li className="error error-default">
                      <img src={images.tickDiabled} alt="" className="icon" />
                      <p>Passwords must match</p>
                    </li>
                  </>
                )}
              </ul>
            </div>
          </div>
        )}
        <div className="col-16 auth-md5-input__wrapper">
          <div className="container confirm-password">
            <Button
              className={`input-action`}
              onPress={() => {
                if (passwordRetype) {
                  setShowPasswordRetype(!showPasswordRetype);
                }
              }}
              variant={"white"}
              iconBefore={true}
              enableOriginalIcon={true}
              iconTitle={showPasswordRetype ? "eye_close" : "eye_open"}
            />
            <Input
              label="Confirm Password"
              name="confirmPassword"
              type={showPasswordRetype ? "text" : "password"}
              value={passwordRetype}
              onChange={_onChangePasswordRetype}
              containerStyles="input-password"
              labelSize="sm"
              maxLength={80}
              state={_inputConfirmPasswordState}
              errorMessage=""
              errorMessageSize="sm"
              showErrorIcon={false}
              helper={
                _isFocusOnTypingRetype ? `${passwordRetype.length}/80` : ""
              }
              onFocus={() => setIsFocusOnTypingRetype(true)}
              onBlur={() => {
                if (!passwordRetype) {
                  setIsFocusOnTypingRetype(false);
                }
              }}
            />
          </div>
        </div>
        <div className="col-16 auth-md5-actions__wrapper">
          <div className="container">
            <Button
              label="Confirm Password"
              variant={"solid"}
              size="large"
              onPress={() => _onConfirm()}
              className="confirm_password"
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default AuthenticationMd5Popup;
