import React from "react";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import user from "@testing-library/user-event";
import configureMockStore from "redux-mock-store";

import InternetConnectionConfiguration from "./index";
import {
  BANDWIDTH_EXCEED_ERROR_MESSAGE,
  billingAccounts,
  internetConfiguration,
  internetConfigurationDiverse,
} from "../../../../shared/constants/internetConnection";
import { useApi } from "../../../../shared/helpers";
import "regenerator-runtime";

const AVAILABLE_BANDWIDTH = 10;

jest.mock("../../../../shared/helpers/api", () => ({
  useApi: jest.fn(),
}));

const mockStore = configureMockStore();

const internetData = [
  {
    name: "Internet-Test19",
    description: "",
    isResilient: false,
    billingAccountId: "SBE202306061740",
    primaryConnection: {
      connectionId: "02i3L00000AskexQAB",
      portId: "02i3L00000AskktQAB",
      VLANID: 2032,
      encapsulation: "dot1q",
      isEnabled: true,
      bandwidthType: "static",
      isBFD: false,
      IPVersion: "ipv4",
      routingType: "bgp",
      routingConfig: {
        bgpConfig: {
          ASNType: "private",
          bgpPeerASN: "65530",
          btRoutesAdvertised: "default-only",
          ipv4Config: {
            bgpPeerAddress: "100.9.8.29",
            ebgpMultihop: "",
            gracefulRestart: false,
            isMD5Authentication: true,
            enableAdvanceBGP: "",
            advancedBGPConfig: false,
          },
        },
      },
      isTelemetryStreamingEnabled: false,
      IPAddressConfiguration: {
        ipv4Config: {
          WANId: "02i3L00000AskBJQAZ",
          LANConfig: [
            {
              LANId: "02i3L00000AskBOQAZ",
            },
          ],
          BTWANAddress: "100.9.8.28",
          CustomerWANAddress: "100.9.8.29",
          isDHCP: true,
        },
      },
      staticBandwidthConfig: {
        staticBandwidth: 3000,
        isStaticBandwidthThreshold: false,
      },
    },
  },
];

const portDetailsData = {
  portName: "LAG",
  isDiverse: true,
  primaryPortMetadata: {
    portId: "02i3L000008KoVdQAK",
    portSpeed: 200000,
    sfpType: "100GBASE-LR4",
    mtu: 1500,
    isOversubscription: false,
    isUtilisationThreshold: true,
    highUtilisationThreshold: 80,
    lowUtilisationThreshold: 10,
    isPredictiveOptimisation: false,
    encapsulation: "unspecified",
    portStatus: "On",
    isEnabled: false,
    description: "",
    isTelemetryStreamingEnabled: false,
    associatedNetworkServices: [
      {
        connectionId: "InternetOnStandardPortPS",
        type: "",
        VLANID: "101",
        bandwidth: "2000",
        name: "",
      },
    ],
    btPopSiteId: "GBLONA039",
    isLAGEnabled: true,
    primaryLAGMetadata: {
      lagPortsCount: 1,
      lagPortSpeed: 200000,
      lagMemberPorts: [
        {
          lagPortId: "G4i3L000008KoVdPKS",
          lagPortStatus: "On",
        },
      ],
    },
  },
  secondaryPortMetadata: {
    portId: "U2i3L000008KoVdLPS",
    portSpeed: 200000,
    sfpType: "100GBASE-LR4",
    mtu: 1500,
    isOversubscription: false,
    isUtilisationThreshold: true,
    highUtilisationThreshold: 80,
    lowUtilisationThreshold: 10,
    isPredictiveOptimisation: false,
    encapsulation: "unspecified",
    portStatus: "On",
    isEnabled: false,
    description: "",
    isTelemetryStreamingEnabled: false,
    associatedNetworkServices: [
      {
        connectionId: "InternetOnStandardPortPS",
        type: "",
        VLANID: "101",
        bandwidth: "2000",
        name: "",
      },
    ],
    btPopSiteId: "GBLONA039",
    isLAGEnabled: true,
    secondaryLAGMetadata: {
      lagPortsCount: 2,
      lagPortSpeed: 200000,
      lagMemberPorts: [
        {
          lagPortId: "G4i3L000008KoVdPPS",
          lagPortStatus: "On",
        },
        {
          lagPortId: "G4i5L000008KoVdPPS",
          lagPortStatus: "On",
        },
      ],
    },
  },
  countryISOCode: "GB",
  portTerm: 12,
  createdBy: {
    dateTime: "2023-11-01T06:42:22.000Z",
  },
};

const portDetails = [
  {
    portName: "PortA_Internet01",
    portId: "02i3L00000AskktQAB",
    portLocation: "United Kingdom",
    resilience: "Diverse",
    secondaryPortName: "",
    secondaryPortLocation: "",
    secondaryResilience: "",
    diversePortSubRows: [
      {
        portId: "02i3L00000AskktQAB",
        portSpeed: 10000,
        portStatus: "active",
        portName: "PortA_Internet01",
      },
    ],
    isPrimarySelected: true,
    isSecondarySelected: false,
    isDiversityChanged: false,
    portDiversity: "",
  },
];

const store = mockStore({
  internet: {
    portDetails,
    internetConfiguration,
    internetConfigurationDiverse,
  },
  billingAccounts,
});

window.HTMLElement.prototype.scrollIntoView = jest.fn();

describe("InternetConnectionConfiguration", () => {
  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getInternetConnectionSearch: jest.fn().mockResolvedValue(internetData),
      getPortDetails: jest.fn().mockResolvedValue(portDetailsData),
      getInternetPricing: jest.fn().mockResolvedValue({
        oneTimePrice: 100,
        recurringMonthlyPrice: 200,
      }),
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("renders without errors", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );
    expect(screen.getByTestId("breadcrumb-content")).toBeInTheDocument();
  });

  test("clicking Next button shows error message when required fields are empty", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    fireEvent.click(screen.getByText("Continue"));
    expect(screen.getByText("Network Services")).toBeInTheDocument();
  });

  test("displays the Unsaved Changes modal when attempting to leave the page", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    fireEvent.click(screen.getAllByText("Leave")[0]);

    const unsavedChangesModal = screen.getAllByText(
      "Leave without saving changes",
    )[0];

    expect(unsavedChangesModal).toBeInTheDocument();
  });

  test("displays an error message when leaving the page without submitting the form", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    fireEvent.click(screen.getAllByText("Leave")[0]);

    fireEvent.click(screen.getAllByText("Cancel")[0]);

    fireEvent.click(screen.getAllByText("Leave")[0]);
  });

  it("submits the form for burstable bandwidth and proceeds to the next step", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    fireEvent.click(screen.getByText("Burstable"));
    const submitButton = screen.getByText("Continue");
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByTestId("breadcrumb-content")).toBeInTheDocument();
    });
  });

  it("displays the necessary card titles", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    expect(screen.getByText("Name & Description")).toBeInTheDocument();
    expect(screen.getByText("Bandwidth & Layer 2")).toBeInTheDocument();
  });

  it("displays the title for the UsageStackedGrpah component", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    expect(screen.getByText("Associated Port Bandwidth")).toBeInTheDocument();
  });

  it("Entering value into Internet Bandwidth field updates UsageGraph total (Static)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const staticButton = screen.getByTestId("static_btn");
    await user.click(staticButton);

    expect(
      screen.getByText("Enter Internet Bandwidth (Gbps)"),
    ).toBeInTheDocument();

    expect(
      screen.getByText(
        `${AVAILABLE_BANDWIDTH}.000 Gbps of ${AVAILABLE_BANDWIDTH} Gbps Available`,
      ),
    ).toBeInTheDocument();

    const _bandwidth = 50;

    const bandwidthInput = screen.getByRole("textbox", {
      name: "Enter Internet Bandwidth (Gbps)",
    });
    user.click(bandwidthInput);
    user.keyboard(`${_bandwidth}`);
    expect(
      screen.getByText(
        `${AVAILABLE_BANDWIDTH}.000 Gbps of ${AVAILABLE_BANDWIDTH} Gbps Available`,
      ),
    ).toBeInTheDocument();
  });

  it("Displays error message when value entered is greater than available bandwidth (Static)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const staticButton = screen.getByTestId("static_btn");
    await user.click(staticButton);

    const bandwidthInput = screen.getByRole("textbox", {
      name: "Enter Internet Bandwidth (Gbps)",
    });

    user.click(bandwidthInput);
    user.keyboard("550");
    expect(
      screen.getByText(`Out of range (0.001 to ${AVAILABLE_BANDWIDTH})`),
    ).toBeInTheDocument();
  });

  it("Displays error message when user enters 0 for available bandwidth (Static)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const staticButton = screen.getByTestId("static_btn");
    await user.click(staticButton);

    const bandwidthInput = screen.getByRole("textbox", {
      name: "Enter Internet Bandwidth (Gbps)",
    });

    user.click(bandwidthInput);
    user.keyboard("0");
    expect(
      screen.getByText(`Out of range (0.001 to ${AVAILABLE_BANDWIDTH})`),
    ).toBeInTheDocument();
  });

  it("Entering and removing value in Internet Bandwidth field does not throw error (Static)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const staticButton = screen.getByTestId("static_btn");
    await user.click(staticButton);

    const bandwidthInput = screen.getByRole("textbox", {
      name: "Enter Internet Bandwidth (Gbps)",
    });
    user.click(bandwidthInput);
    user.keyboard("5");
    user.keyboard("{backspace}");
    expect(
      screen.queryByText(BANDWIDTH_EXCEED_ERROR_MESSAGE),
    ).not.toBeInTheDocument();
  });

  it("Entering value into Internet Bandwidth field updates UsageGraph total (Burstable)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const burstableButton = screen.getByTestId("burstable_btn");
    await user.click(burstableButton);

    expect(
      screen.getByText(
        `${AVAILABLE_BANDWIDTH}.000 Gbps of ${AVAILABLE_BANDWIDTH} Gbps Available`,
      ),
    ).toBeInTheDocument();
    expect(
      screen.getByText("Enter Internet Bandwidth (Gbps)"),
    ).toBeInTheDocument();
    expect(screen.getByText("Min commit bandwidth")).toBeInTheDocument();
    expect(screen.getByText("Max bandwidth")).toBeInTheDocument();

    const _minBandwidth = 25;

    const minBandwidthInput = screen.getByRole("textbox", {
      name: "Min commit bandwidth",
    });
    user.click(minBandwidthInput);
    user.keyboard(`${_minBandwidth}`);
    expect(
      screen.getByText(
        `${AVAILABLE_BANDWIDTH}.000 Gbps of ${AVAILABLE_BANDWIDTH} Gbps Available`,
      ),
    ).toBeInTheDocument();
  });

  it("Entering and removing value in min and max bandwidth fields does not throw error (Burstable)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const burstableButton = screen.getByTestId("burstable_btn");
    await user.click(burstableButton);

    const minBandwidthInput = screen.getByRole("textbox", {
      name: "Min commit bandwidth",
    });
    user.click(minBandwidthInput);
    user.keyboard("5");
    user.keyboard("{backspace}");
    expect(
      screen.queryByText(BANDWIDTH_EXCEED_ERROR_MESSAGE),
    ).not.toBeInTheDocument();

    const maxBandwidthInput = screen.getByRole("textbox", {
      name: "Max bandwidth",
    });
    user.click(maxBandwidthInput);
    user.keyboard("5");
    user.keyboard("{backspace}");
    expect(
      screen.queryByText(BANDWIDTH_EXCEED_ERROR_MESSAGE),
    ).not.toBeInTheDocument();
  });

  it("Displays error message when value entered is greater than available bandwidth (Burstable)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const burstableButton = screen.getByTestId("burstable_btn");
    await user.click(burstableButton);

    const minBandwidthInput = screen.getByRole("textbox", {
      name: "Min commit bandwidth",
    });
    user.click(minBandwidthInput);
    user.keyboard("550");
    expect(
      screen.getByText("Out of range (0.001 to 9.999)"),
    ).toBeInTheDocument();

    const maxBandwidthInput = screen.getByRole("textbox", {
      name: "Max bandwidth",
    });
    user.click(maxBandwidthInput);
    user.keyboard("550");
    expect(screen.getByText("Out of range (0.002 to 10)")).toBeInTheDocument();
  });

  it("Displays error message when user enters 0 for available bandwidth or 0.001 for max (Burstable)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const burstableButton = screen.getByTestId("burstable_btn");
    await user.click(burstableButton);

    const minBandwidthInput = screen.getByRole("textbox", {
      name: "Min commit bandwidth",
    });
    user.click(minBandwidthInput);
    user.keyboard("0");
    expect(
      screen.getByText("Out of range (0.001 to 9.999)"),
    ).toBeInTheDocument();

    const maxBandwidthInput = screen.getByRole("textbox", {
      name: "Max bandwidth",
    });
    user.click(maxBandwidthInput);
    user.keyboard("0");
    expect(screen.getByText("Out of range (0.002 to 10)")).toBeInTheDocument();
    user.keyboard("0.001");
    expect(screen.getByText("Out of range (0.002 to 10)")).toBeInTheDocument();
  });

  it("Displays error message when min Commit is greater than max bandwidth (Burstable)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const burstableButton = screen.getByTestId("burstable_btn");
    await user.click(burstableButton);

    const minBandwidthInput = screen.getByRole("textbox", {
      name: "Min commit bandwidth",
    });
    user.click(minBandwidthInput);
    user.keyboard("3");

    const maxBandwidthInput = screen.getByRole("textbox", {
      name: "Max bandwidth",
    });
    user.click(maxBandwidthInput);
    user.keyboard("2");

    expect(
      screen.getByText("Value must be greater than min commit"),
    ).toBeInTheDocument();
  });

  it("Displays error message when max bandwidth is less than min commit (Burstable)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const burstableButton = screen.getByTestId("burstable_btn");
    await user.click(burstableButton);

    const maxBandwidthInput = screen.getByRole("textbox", {
      name: "Max bandwidth",
    });
    user.click(maxBandwidthInput);
    user.keyboard("2");

    const minBandwidthInput = screen.getByRole("textbox", {
      name: "Min commit bandwidth",
    });
    user.click(minBandwidthInput);
    user.keyboard("3");

    expect(
      screen.getByText("Value must be less than max bandwidth"),
    ).toBeInTheDocument();
  });

  it("Displays error message when user enters excess max first and valid min (Burstable)", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const burstableButton = screen.getByTestId("burstable_btn");
    await user.click(burstableButton);

    const maxBandwidthInput = screen.getByRole("textbox", {
      name: "Max bandwidth",
    });
    user.click(maxBandwidthInput);
    user.keyboard("2000");

    const minBandwidthInput = screen.getByRole("textbox", {
      name: "Min commit bandwidth",
    });
    user.click(minBandwidthInput);
    user.keyboard("5");

    expect(screen.getByText("Out of range (0.002 to 10)")).toBeInTheDocument();
  });

  it("Display 'Monitory alarm setting' on clicking 'Bandwidth Utilisation Monitoring'", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    expect(
      screen.getByText("Bandwidth Utilisation Monitoring"),
    ).toBeInTheDocument();
    const utlisationCheckbox = screen.getAllByRole("checkbox");
    await user.click(utlisationCheckbox[0]);

    expect(
      screen.getByText("Min Utilisation Threshold (%)"),
    ).toBeInTheDocument();
    expect(
      screen.getByText("Max Utilisation Threshold (%)"),
    ).toBeInTheDocument();
    expect(screen.getByPlaceholderText("0-99%")).toBeInTheDocument();
    expect(screen.getByPlaceholderText("1-100%")).toBeInTheDocument();
  });

  it("Makes sure Threshold inputs have null value by default'", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const utlisationCheckbox = screen.getAllByRole("checkbox");
    await user.click(utlisationCheckbox[0]);

    expect(screen.getByPlaceholderText("0-99%")).toHaveValue(null);
    expect(screen.getByPlaceholderText("1-100%")).toHaveValue(null);
  });

  it("Entering out of range values in threshold throws errors'", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const utlisationCheckbox = screen.getAllByRole("checkbox");
    await user.click(utlisationCheckbox[0]);

    const minThreshold = screen.getByPlaceholderText("0-99%");
    await user.click(minThreshold);
    await user.keyboard("100");
    expect(screen.getByText("Out of Range (0 to 99%)")).toBeInTheDocument();

    const maxThreshold = screen.getByPlaceholderText("1-100%");
    await user.click(maxThreshold);
    await user.keyboard("101");
    expect(screen.getByText("Out of Range (1 to 100%)")).toBeInTheDocument();
  });

  it("Entering min greater than max values in threshold throws errors'", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const utlisationCheckbox = screen.getAllByRole("checkbox");
    await user.click(utlisationCheckbox[0]);

    const maxThreshold = screen.getByPlaceholderText("1-100%");
    await user.click(maxThreshold);
    await user.keyboard("50");

    const minThreshold = screen.getByPlaceholderText("0-99%");
    await user.click(minThreshold);
    await user.keyboard("60");

    expect(
      screen.getByText("Value must be less than max threshold"),
    ).toBeInTheDocument();
  });

  it("Clicking continue without entering threshold values displays error messages'", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    screen.debug(undefined, Infinity);

    const utlisationCheckbox = screen.getAllByRole("checkbox");
    await user.click(utlisationCheckbox[0]);

    const connectionName = screen.getByRole("textbox", {
      name: "Connection Name",
    });
    await user.click(connectionName);
    await user.keyboard("Text Name");

    const staticButton = screen.getByTestId("static_btn");
    await user.click(staticButton);

    const vlanIDInput = screen.getByRole("spinbutton", {
      name: "Maximum Transmission Unit (MTU)",
    });
    await user.click(vlanIDInput);
    await user.keyboard("12");

    const bandwidthInput = screen.getByRole("textbox", {
      name: "Enter Internet Bandwidth (Gbps)",
    });
    await user.click(bandwidthInput);
    await user.keyboard("4");

    const submitButton = screen.getByText("Continue");
    await user.click(submitButton);

    setTimeout(async () => {
      expect(
        await screen.findByText("Min cannot be empty"),
      ).toBeInTheDocument();
      expect(await screen.getByText("Max cannot be empty")).toBeInTheDocument();
    }, 500);
  });
});
