import { useState, useEffect } from "react";

export const usePasswordValidation = ({
  password = " ",
  minCharLength = 4,
  maxCharLength = 80,
}) => {
  const [validMinLength, setValidMinLength] = useState(false);
  const [validMaxLength, setValidMaxLength] = useState(false);
  const [hasNumber, setHasNumber] = useState(false);
  const [upperCase, setUpperCase] = useState(false);
  const [lowerCase, setLowerCase] = useState(false);
  const [specialChar, setSpecialChar] = useState(false);
  const [firstCharNumber, setFirstCharNumber] = useState(false);

  useEffect(() => {
    setValidMinLength(password.length >= minCharLength);
    setValidMaxLength(password.length <= maxCharLength);
    setHasNumber(/\d/.test(password));
    setSpecialChar(/[!@#.$%^&*+=-]/.test(password));
    setUpperCase(/^(?=.*[A-Z])/.test(password));
    setLowerCase(/^(?=.*[a-z])/.test(password));
    setFirstCharNumber(/\D/.test(password.charAt(0)));
  }, [password, minCharLength, maxCharLength]);

  return [
    validMinLength,
    validMaxLength,
    hasNumber,
    specialChar,
    upperCase,
    lowerCase,
    firstCharNumber,
  ];
};
