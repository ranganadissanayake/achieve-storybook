import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { Label, Input, Icon, Button } from "@btdigital/nayan-component-library";

import { selectInternetRouting } from "../../../../../redux/internetSlice";
import { useIpv4FormInput } from "../../../../../shared/hooks";
import { INVALID_IPV4_MESSAGE } from "../../../../../shared/constants";

import "./AddRoutes.scss";

export type metrixType = {
  id: number;
  name: string;
  prefix: string;
  location: string;
  error?: string;
};
export interface AddRoutesProps {
  titleText?: string;
  colName?: string;
  colPrefix?: string;
  Location?: string;
  colPrefixPlaceholder?: string;
  isIpv4: boolean;
  getMetrix?: (metrixValue: metrixType[]) => void;
}

const AddRoutes: React.FC<AddRoutesProps> = ({
  titleText,
  colName,
  colPrefix,
  Location,
  colPrefixPlaceholder,
  getMetrix,
  isIpv4,
}) => {
  const { metrixValueState, routingTypeState } = useSelector(
    selectInternetRouting,
  );

  //empty two rows should be show by default
  const IpList = [
    {
      id: 0,
      name: "",
      prefix: "",
      location: "",
    },
  ];

  const { appendPeriodToInput, hasInvalidIpv4Address } = useIpv4FormInput();

  const [ipListState, setIpListState] = useState(
    routingTypeState === "Static" ? metrixValueState : IpList,
  );

  //creating a empty new row
  const addIpList = (length: number) => {
    setIpListState([
      ...ipListState,
      {
        id: length,
        name: "",
        prefix: "",
        location: "",
      },
    ]);
  };

  const removeIpList = (index: number) => {
    setIpListState((listItem) => listItem.filter((_, idx) => idx !== index));
  };

  //passing metrix value as a call back for further use
  useEffect(() => {
    if (getMetrix) {
      getMetrix(ipListState);
    }
  }, [ipListState]);

  //check duplicates
  const checkDuplicates = (value: string, field: string) => {
    if (field === "name") {
      return ipListState.some((element) => element.name === value);
    } else if (field === "prefix") {
      return ipListState.some((element) => element.prefix === value);
    }
    return false;
  };

  //capture updates
  const updateFieldChanged = (value: string, index: number, field: string) => {
    if (value != "") {
      checkDuplicates(value, field);
    }

    setIpListState((prev) => {
      return prev.map((item, i) => {
        if (i === index) {
          if (field === "name") {
            return { ...item, name: value };
          } else if (field === "prefix") {
            if (isIpv4) {
              const updated = appendPeriodToInput(value, prev[i].prefix);
              const error = hasInvalidIpv4Address(updated);
              return {
                ...item,
                prefix: updated,
                error: error ? INVALID_IPV4_MESSAGE : undefined,
              };
            } else {
              return { ...item, prefix: value };
            }
          } else {
            return { ...item, location: value };
          }
        } else {
          return item;
        }
      });
    });
  };

  const IpV4ListView = ipListState.map((list: any, index: number) => {
    const isNameDuplicate =
      list.name !== "" &&
      ipListState.filter((item) => item.name === list.name).length > 1;
    const isPrefixDuplicate =
      list.prefix !== "" &&
      ipListState.filter((item) => item.prefix === list.prefix).length > 1;
    return (
      <div className="add-ip-routes-wrapper" key={index}>
        <div className="first-col">
          <Input
            label={index === 0 ? colName : ""}
            name="name"
            className="ipv4-input"
            placeholder={`Data Subnet ${index + 1}`}
            labelSize="sm"
            state={isNameDuplicate ? "error" : "default"}
            errorMessageSize="sm"
            showErrorIcon={false}
            onChange={(e: string) => updateFieldChanged(e, index, "name")}
            errorMessage={isNameDuplicate ? "Values cannot be the same" : ""}
            value={list?.name}
          />
        </div>
        <div className="second-col">
          <Input
            label={index === 0 ? colPrefix : ""}
            name="IPPrefix"
            className="ipv4-input"
            placeholder={colPrefixPlaceholder}
            labelSize="sm"
            errorMessageSize="sm"
            showErrorIcon={false}
            onChange={(e: string) => updateFieldChanged(e, index, "prefix")}
            state={isPrefixDuplicate || !!list?.error ? "error" : "default"}
            errorMessage={
              isPrefixDuplicate
                ? "Values cannot be the same"
                : list?.error || ""
            }
            value={list?.prefix}
          />
        </div>
        <div className="third-col">
          <Input
            label={index === 0 ? Location : ""}
            name="Location"
            className="ipv4-input"
            placeholder="1"
            labelSize="sm"
            state={"default"}
            errorMessageSize="sm"
            showErrorIcon={false}
            onChange={(e: string) => updateFieldChanged(e, index, "location")}
            value={list?.location}
          />
        </div>
        <div className="icon-col">
          {index > 0 && (
            <Icon title="bin_new" showOriginal onClick={() => removeIpList(index)} />
          )}
        </div>
      </div>
    );
  });

  return (
    <>
      <div className="add-ip-routes">
        <Label text={titleText} size="lg" labelTextStyles="title" />
        {IpV4ListView}
        <div className="add-new-btn">
          <Button
            iconTitle="expand_row"
            label="Add New"
            onPress={() => addIpList(ipListState.length)}
            variant="outline"
            iconSize="sm"
            disabled={ipListState.length > 4}
            iconBefore={true}
          />
        </div>
      </div>
    </>
  );
};

export default AddRoutes;
