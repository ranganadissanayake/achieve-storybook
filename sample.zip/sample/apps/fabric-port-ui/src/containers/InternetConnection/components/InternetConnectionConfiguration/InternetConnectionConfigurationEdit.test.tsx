import React from "react";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { render, screen } from "@testing-library/react";

import InternetConnectionConfiguration from "./index";
import store from "../../../../redux/store";
import { useApi } from "../../../../shared/helpers";
import "regenerator-runtime";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useSearchParams: () => [new URLSearchParams({ status: "edit" })],
}));

jest.mock("../../../../shared/helpers");

describe("Internet Configuration in edit mode", () => {
  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getInternetConnectionSearch: jest.fn().mockResolvedValue({}),
    });
  });

  afterEach(() => {
    jest.clearAllMocks()
  });

  it("Check if in editing mode", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    expect(screen.getByText("Edit")).toBeInTheDocument();
    expect(screen.getByText("Internet Inventory")).toBeInTheDocument();
  });

  it("Disable fields that can not be edited", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <InternetConnectionConfiguration />
        </BrowserRouter>
      </Provider>,
    );

    const vlanEncap = screen.getByRole("textbox", {
      name: "VLAN encapsulation method"
    });

    expect(vlanEncap).not.toBeDisabled();

    const vlanId = screen.getByRole("spinbutton", {
      name: "Select specific VLAN ID, range from 1 to 4094"
    });

    expect(vlanId).not.toBeDisabled();
  });
});