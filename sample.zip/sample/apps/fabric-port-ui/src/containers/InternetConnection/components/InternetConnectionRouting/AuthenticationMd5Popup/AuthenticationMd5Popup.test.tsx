import React from "react";
import { render, fireEvent } from "@testing-library/react";
import AuthenticationMd5Popup, { AuthenticationMd5PopupProps } from "./index";

// populate unit testings for above AuthenticationMd5Popup react component
describe("AuthenticationMd5Popup", () => {
  const onCancelMock = jest.fn();
  const onConfirmMock = jest.fn();
  const defaultProps: AuthenticationMd5PopupProps = {
    onCancel: onCancelMock,
    onConfirm: onConfirmMock,
  };

  it("should be trigger validations", () => {
    const { getByText, getAllByPlaceholderText } = render(
      <AuthenticationMd5Popup {...defaultProps} />,
    );
    fireEvent.focus(getAllByPlaceholderText("")[0]);
    expect(getByText("First character not a number")).toBeInTheDocument();
    expect(getByText("Maximum 80 characters")).toBeInTheDocument();
    expect(getByText("Minimum 4 characters")).toBeInTheDocument();
    expect(getByText("An uppercase character")).toBeInTheDocument();
    expect(getByText("A lowercase character")).toBeInTheDocument();
    expect(getByText("A number")).toBeInTheDocument();
    expect(getByText("A special character (!@#.$%^&*+=-)")).toBeInTheDocument();
    expect(getByText("Password must have :")).toBeInTheDocument();
  });
});