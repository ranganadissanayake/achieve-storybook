import { usePasswordValidation } from "./usePasswordValidation";
import { renderHook } from "@testing-library/react";

describe("usePasswordValidation", () => {
  it("should return correct validation states for valid password", () => {
    const password = "Abc@123";
    const { result } = renderHook(() => usePasswordValidation({ password }));
    const [
      validMinLength,
      validMaxLength,
      hasNumber,
      specialChar,
      upperCase,
      lowerCase,
      firstCharNumber,
    ] = result.current;

    expect(validMinLength).toBe(true);
    expect(validMaxLength).toBe(true);
    expect(hasNumber).toBe(true);
    expect(specialChar).toBe(true);
    expect(upperCase).toBe(true);
    expect(lowerCase).toBe(true);
    expect(firstCharNumber).toBe(true);
  });

  it("should return initial validation states as false", () => {
    const password = " ";
    const { result } = renderHook(() => usePasswordValidation({ password }));
    const [
      validMinLength,
      validMaxLength,
      hasNumber,
      specialChar,
      upperCase,
      lowerCase,
      firstCharNumber,
    ] = result.current;

    expect(validMinLength).toBe(false);
    expect(validMaxLength).toBe(true);
    expect(hasNumber).toBe(false);
    expect(specialChar).toBe(false);
    expect(upperCase).toBe(false);
    expect(lowerCase).toBe(false);
    expect(firstCharNumber).toBe(true);
  });
  it("should return if first character is number as falsy", () => {
    const password = "1";
    const { result } = renderHook(() => usePasswordValidation({ password }));
    const [firstCharNumber] = result.current;
    expect(firstCharNumber).toBe(false);
  });
});
