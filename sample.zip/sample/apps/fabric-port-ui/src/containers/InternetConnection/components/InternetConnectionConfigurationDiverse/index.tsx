import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate, useSearchParams } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormProvider, useForm } from "react-hook-form";
import * as yup from "yup";

import {
  Button,
  Card,
  ErrorMessage,
  Icon,
  Input,
  Label,
  Modal,
  RangeBar,
  Tile,
  Toggle,
  UsageStackedGraph,
} from "@btdigital/nayan-component-library";

import {
  resetInternetSlice,
  selectPortData,
  updateLevel,
  updateStep,
  selectCurrentLevel,
  updateInternetConfigurationDiverseData,
  selectInternetConfigurationsDiverse,
  selectInternetEditItem,
  selectInternetEditId,
} from "../../../../redux/internetSlice";
import InternetConnectionWrapper from "../../../../components/InternetConnectionWrapper";
import {
  ConnectedDropdownInput,
  ConnectedInput,
  ConnectedTextarea,
} from "../../../../components/ConnectedFormElements";
import {
  getInternetServicesAllocationByPortId,
  validateRange,
  validateRangeInclusive,
} from "../../../../shared/utils";
import {
  MAX_NUMBER_OF_CHARACTERS,
  OUT_OF_RANGE,
  THIS_FIELD_CANNOT_BE_EMPTY,
  VLAN_ENCAPSULATION_METHODS,
  MIN_PORT_SPEED,
} from "../../../../shared/constants";
import IPAddressing from "../IPAddressing";
import InternetConnectionRouting from "../InternetConnectionRouting";
import {
  BandwidthType,
  InternetConfigurationDiverseData,
} from "../../../../shared/types";
import ModifyInLineText from "../../../../components/ModifyInLineText";
import { useApi } from "../../../../shared/helpers";
import images from "../../../../shared/assets";
import { getAssociatedBandwidth } from "../InternetConnectionConfiguration";
import loadingSpinner from '../../../../shared/assets/gifs/loading-spinner-black-20.gif'

import "../InternetConnectionConfiguration/index.scss";
import "./index.scss";

export enum BackgroundType {
  GRADIENT = "linear-gradient(90deg, #FF7F00 0%, #34A827 6.77%, #34A827 48.44%, #34A827 93.23%, #FF7F00 100%)",
  SUCCESS = "#088003",
  WARNING = "#ffc501",
  DEFAULT = "#5514b4",
  CRITICAL = "#da020f",
}

const initialBandwidthData = [
  {
    amount: 0,
    fillColor: "#088003",
    label: "Used",
  },
];

const InternetConnConfigDiverseSchema = yup
  .object({
    connectionName: yup
      .string()
      .trim()
      .required(THIS_FIELD_CANNOT_BE_EMPTY)
      .max(30, MAX_NUMBER_OF_CHARACTERS(30)),
    connectionDescriptionPrimary: yup
      .string()
      .trim()
      .required()
      .nullable()
      .max(500, MAX_NUMBER_OF_CHARACTERS(500)),
    connectionDescriptionSecondary: yup
      .string()
      .trim()
      .required()
      .nullable()
      .max(500, MAX_NUMBER_OF_CHARACTERS(500)),
    vlanEncapsulationMethodPrimary: yup
      .string()
      .required(THIS_FIELD_CANNOT_BE_EMPTY),
    vlanEncapsulationMethodSecondary: yup
      .string()
      .required(THIS_FIELD_CANNOT_BE_EMPTY),
    specificVlanIdPrimary: yup
      .number()
      .required(THIS_FIELD_CANNOT_BE_EMPTY)
      .typeError(THIS_FIELD_CANNOT_BE_EMPTY)
      .nullable()
      .min(1, OUT_OF_RANGE(1, 4094))
      .max(4094, OUT_OF_RANGE(1, 4094)),
    specificVlanIdSecondary: yup
      .number()
      .required(THIS_FIELD_CANNOT_BE_EMPTY)
      .typeError(THIS_FIELD_CANNOT_BE_EMPTY)
      .nullable()
      .min(1, OUT_OF_RANGE(1, 4094))
      .max(4094, OUT_OF_RANGE(1, 4094)),
    mtuPrimary: yup
      .number()
      .required(THIS_FIELD_CANNOT_BE_EMPTY)
      .typeError(THIS_FIELD_CANNOT_BE_EMPTY)
      .nullable()
      .min(1440, OUT_OF_RANGE(1440, 1500))
      .max(1500, OUT_OF_RANGE(1440, 1500)),
    mtuSecondary: yup
      .number()
      .required(THIS_FIELD_CANNOT_BE_EMPTY)
      .typeError(THIS_FIELD_CANNOT_BE_EMPTY)
      .nullable()
      .min(1440, OUT_OF_RANGE(1440, 1500))
      .max(1500, OUT_OF_RANGE(1440, 1500)),
  })
  .required();

type InternetConnConfigDiverseFormData = yup.InferType<
  typeof InternetConnConfigDiverseSchema
>;

const InternetConnectionConfigurationDiverse = () => {
  const api = useApi();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [searchParams, _] = useSearchParams();
  const _isModifyJourney = searchParams.get("status") === "edit";

  const internetDiverseDetails =
    useSelector(selectInternetConfigurationsDiverse) || {};
  const [lastChangedField, setLastChangedField] = useState("");
  const _currentLevel = useSelector(selectCurrentLevel);
  const _portData = useSelector(selectPortData);
  const editInternetItem = useSelector(selectInternetEditItem);
  const _internetEditId = useSelector(selectInternetEditId);

  const _associatedBandwidthPrimary = getAssociatedBandwidth(_portData[0], 0);
  const _associatedBandwidthSecondary = getAssociatedBandwidth(_portData[0], 1);

  const _isEdit = React.useMemo(() => !!_internetEditId, [_internetEditId]);

  const configureInternetRef = React.useRef<null | HTMLDivElement>(null);
  const ipAddressingRef = React.useRef<null | HTMLDivElement>(null);
  const routingRef = React.useRef<null | HTMLDivElement>(null);

  const _internetDiverseEditItem: InternetConfigurationDiverseData = {
    ...internetDiverseDetails,
    bandwidthType:
      editInternetItem?.bandwidthType?.toLocaleLowerCase() as BandwidthType,
    connectionName: editInternetItem?.internetName ?? "",
    staticInternetBandwidthPrimary:
      editInternetItem &&
      editInternetItem.subRows &&
      editInternetItem?.subRows[0]?.bandwidth
        ? editInternetItem?.subRows[0]?.bandwidth
        : "",
    staticInternetBandwidthSecondary:
      editInternetItem &&
      editInternetItem.subRows &&
      editInternetItem?.subRows[1]?.bandwidth
        ? editInternetItem?.subRows[1]?.bandwidth
        : "",
    maxCommitBandwidthPrimary:
      editInternetItem &&
      editInternetItem.subRows &&
      editInternetItem?.subRows[0]?.maxCommitBandwidth
        ? editInternetItem?.subRows[0]?.maxCommitBandwidth
        : "",
    minCommitBandwidthPrimary:
      editInternetItem &&
      editInternetItem.subRows &&
      editInternetItem?.subRows[0]?.minCommitBandwidth
        ? editInternetItem?.subRows[0]?.minCommitBandwidth
        : "",
    maxCommitBandwidthSecondary:
      editInternetItem &&
      editInternetItem.subRows &&
      editInternetItem?.subRows[1]?.maxCommitBandwidth
        ? editInternetItem?.subRows[1]?.maxCommitBandwidth
        : "",
    minCommitBandwidthSecondary:
      editInternetItem &&
      editInternetItem.subRows &&
      editInternetItem?.subRows[1]?.minCommitBandwidth
        ? editInternetItem?.subRows[1]?.minCommitBandwidth
        : "",
    isEnabledUtilisationMonitoringPrimary: false,
    isEnabledUtilisationMonitoringSecondary: false,
    vlanEncapsulationMethodPrimary: "Dot1Q",
    vlanEncapsulationMethodSecondary: "Dot1Q",
    vlanIdPrimary:
      editInternetItem &&
      editInternetItem.subRows &&
      editInternetItem?.subRows[0]?.vlanId
        ? (editInternetItem?.subRows[0]?.vlanId as number)
        : null,
    vlanIdSecondary:
      editInternetItem &&
      editInternetItem.subRows &&
      editInternetItem?.subRows[1]?.vlanId
        ? (editInternetItem?.subRows[1]?.vlanId as number)
        : null,
  };

  const [_internetDiverseDetails, setInternetDiverseDetails] =
    React.useState<InternetConfigurationDiverseData>(
      _isModifyJourney && !_isEdit
        ? _internetDiverseEditItem
        : internetDiverseDetails
    );

  const internetConnConfigDiverseDefaultValues = {
    connectionName: _internetDiverseDetails.connectionName,
    connectionDescriptionPrimary:
      _internetDiverseDetails.connectionDescriptionPrimary === ""
        ? null
        : _internetDiverseDetails.connectionDescriptionPrimary,
    connectionDescriptionSecondary:
      _internetDiverseDetails.connectionDescriptionSecondary === ""
        ? null
        : _internetDiverseDetails.connectionDescriptionSecondary,
    vlanEncapsulationMethodPrimary:
      _internetDiverseDetails.vlanEncapsulationMethodPrimary === ""
        ? VLAN_ENCAPSULATION_METHODS[0]
        : _internetDiverseDetails.vlanEncapsulationMethodPrimary,
    vlanEncapsulationMethodSecondary:
      _internetDiverseDetails.vlanEncapsulationMethodSecondary === ""
        ? VLAN_ENCAPSULATION_METHODS[0]
        : _internetDiverseDetails.vlanEncapsulationMethodSecondary,
    specificVlanIdPrimary: _internetDiverseDetails.vlanIdPrimary,
    specificVlanIdSecondary: _internetDiverseDetails.vlanIdSecondary,
    mtuPrimary:
      _internetDiverseDetails.mtuSizePrimary === undefined || null
        ? 1500
        : _internetDiverseDetails.mtuSizePrimary,
    mtuSecondary:
      _internetDiverseDetails.mtuSizeSecondary === undefined || null
        ? 1500
        : _internetDiverseDetails.mtuSizeSecondary,
  };

  React.useEffect(() => {
    setInternetDiverseDetails(
      _isModifyJourney && !_isEdit
        ? _internetDiverseEditItem
        : internetDiverseDetails
    );
  }, [_isModifyJourney, _isEdit]);

  const InternetConnConfigDiverseFormDataMethods =
    useForm<InternetConnConfigDiverseFormData>({
      resolver: yupResolver(InternetConnConfigDiverseSchema),
      defaultValues: internetConnConfigDiverseDefaultValues,
      mode: "onChange",
    });

  const [_isVisibleBanner, setIsVisiblebanner] = React.useState(true);
  const [_vlanPrimaryPillText, setVlanPrimaryPillText] = React.useState("");
  const [_vlanSecondaryPillText, setVlanSecondaryPillText] = React.useState("");
  const [_isVlanIdPrimaryAvailable, setIsVlanIdPrimaryAvailable] =
    React.useState(true);
  const [_isVlanIdSecondaryAvailable, setIsVlanIdSecondaryAvailable] =
    React.useState(true);

  const [_internetBandwidthPrimary, setInternetBandwidthPrimary] =
    React.useState("");
  const [_internetBandwidthSecondary, setInternetBandwidthSecondary] =
    React.useState("");
  const [_minCommitBandwidthPrimary, setMinCommitBandwidthPrimary] =
    React.useState("");
  const [_minCommitBandwidthSecondary, setMinCommitBandwidthSecondary] =
    React.useState("");
  const [_maxCommitBandwidthPrimary, setMaxCommitBandwidthPrimary] =
    React.useState("");
  const [_maxCommitBandwidthSecondary, setMaxCommitBandwidthSecondary] =
    React.useState("");

  const [
    _isEnabledUtilisationMonitoringPrimary,
    setIsEnabledUtilisationMonitoringPrimary,
  ] = React.useState(
    _internetDiverseDetails.isEnabledUtilisationMonitoringPrimary
  );
  const [
    _isEnabledUtilisationMonitoringSecondary,
    setIsEnabledUtilisationMonitoringSecondary,
  ] = React.useState(
    _internetDiverseDetails.isEnabledUtilisationMonitoringSecondary
  );
  const [
    _isUtilisationThresholdValidPrimary,
    setIsUtilisationThresholdValidPrimary,
  ] = React.useState(false);
  const [
    _isUtilisationThresholdValidSecondary,
    setIsUtilisationThresholdValidSecondary,
  ] = React.useState(false);
  const [
    _isEnabledPredictiveBandwidthPrimary,
    setIsEnabledPredictiveBandwidthPrimary,
  ] = React.useState(false);
  const [
    _isEnabledPredictiveBandwidthSecondary,
    setIsEnabledPredictiveBandwidthSecondary,
  ] = React.useState(false);

  const [_isStatic, setIsStatic] = React.useState(
    _internetDiverseDetails.isStatic === undefined
      ? true
      : _internetDiverseDetails.isStatic
  );
  const [_isBurstable, setIsBurstable] = React.useState(
    _internetDiverseDetails.isStatic === undefined
      ? false
      : !_internetDiverseDetails.isStatic
  );

  const [_bandwidthUsagePrimary, setBandwidthUsagePrimary] =
    React.useState(initialBandwidthData);
  const [_bandwidthUsageSecondary, setBandwidthUsageSecondary] =
    React.useState(initialBandwidthData);

  const _availableBandwidthPrimary = React.useMemo(
    () =>
      Number(
        (
          _associatedBandwidthPrimary - _bandwidthUsagePrimary[0].amount
        ).toFixed(3)
      ),
    [_associatedBandwidthPrimary, _bandwidthUsagePrimary]
  );

  const _availableBandwidthSecondary = React.useMemo(
    () =>
      Number(
        (
          _associatedBandwidthSecondary - _bandwidthUsageSecondary[0].amount
        ).toFixed(3)
      ),
    [_associatedBandwidthSecondary, _bandwidthUsageSecondary]
  );

  const [_minUtilisationThresholdPrimary, setMinUtilisationThresholdPrimary] =
    React.useState(
      internetDiverseDetails.minUtilizationThresholdPrimary
        ? parseInt(internetDiverseDetails.minUtilizationThresholdPrimary)
        : undefined
    );
  const [
    _minUtilisationThresholdSecondary,
    setMinUtilisationThresholdSecondary,
  ] = React.useState(
    internetDiverseDetails.minUtilizationThresholdSecondary
      ? parseInt(internetDiverseDetails.minUtilizationThresholdPrimary)
      : undefined
  );
  const [_maxUtilisationThresholdPrimary, setMaxUtilisationThresholdPrimary] =
    React.useState(
      internetDiverseDetails.maxUtilizationThresholdPrimary
        ? parseInt(internetDiverseDetails.maxUtilizationThresholdPrimary)
        : undefined
    );
  const [
    _maxUtilisationThresholdSecondary,
    setMaxUtilisationThresholdSecondary,
  ] = React.useState(
    internetDiverseDetails.maxUtilizationThresholdSecondary
      ? parseInt(internetDiverseDetails.maxUtilizationThresholdPrimary)
      : undefined
  );
  const [_vlanEncapMethodPrimary, setVlanEncapMethodPrimary] = React.useState(
    VLAN_ENCAPSULATION_METHODS[0]
  );
  const [_vlanEncapMethodSecondary, setVlanEncapMethodSecondary] =
    React.useState(VLAN_ENCAPSULATION_METHODS[0]);

  const [_isMinThresholdEmptyPrimary, setIsMinThresholdEmptyPrimary] =
    React.useState(true);
  const [_isMinThresholdEmptySecondary, setIsMinThresholdEmptySecondary] =
    React.useState(true);
  const [_isMaxThresholdEmptyPrimary, setIsMaxThresholdEmptyPrimary] =
    React.useState(true);
  const [_isMaxThresholdEmptySecondary, setIsMaxThresholdEmptySecondary] =
    React.useState(true);

  const [_isContinueClicked, setIsContinueClicked] = React.useState(false);

  const [_internetBandwidthErrorPrimary, setInternetBandwidthErrorPrimary] =
    React.useState("");
  const [_internetBandwidthErrorSecondary, setInternetBandwidthErrorSecondary] =
    React.useState("");
  const [_minCommitBandwidthErrorPrimary, setMinCommitBandwidthErrorPrimary] =
    React.useState("");
  const [
    _minCommitBandwidthErrorSecondary,
    setMinCommitBandwidthErrorSecondary,
  ] = React.useState("");
  const [_maxCommitBandwidthErrorPrimary, setMaxCommitBandwidthErrorPrimary] =
    React.useState("");
  const [
    _maxCommitBandwidthErrorSecondary,
    setMaxCommitBandwidthErrorSecondary,
  ] = React.useState("");
  const [_commitBandwidthErrorPrimary, setCommitBandwidthErrorPrimary] =
    React.useState("");
  const [_commitBandwidthErrorSecondary, setCommitBandwidthErrorSecondary] =
    React.useState("");

  const [_showModal, setShowModal] = React.useState(false);
  const [scrollToTop, setScollToTop] = React.useState(false);

  const [_initiateStep2NextAction, setInitiateStep2NextAction] =
    React.useState(false);
  const [_initiateStep3NextAction, setInitiateStep3NextAction] =
    React.useState(false);

  const [_availablePrimaryBandwidth, setAvailablePrimaryBandwidth] = React.useState(_associatedBandwidthPrimary);
  const [_availableSecondaryBandwidth, setAvailableSecondaryBandwidth] = React.useState(_associatedBandwidthSecondary);
  const [isOversubscriptionPrimary, setIsOversubscriptionPrimary] =
    React.useState(_internetDiverseDetails?.isOversubscriptionPrimary || false);

  const [isOversubscriptionSecondary, setIsOversubscriptionSecondary] =
    React.useState(
      _internetDiverseDetails?.isOversubscriptionSecondary || false
    );

  const getTargetText = (
    internetBandwidth: string,
    _minCommitBandwidth: string
  ) => {
    if (_isBurstable && _minCommitBandwidth) {
      return `${_minCommitBandwidth} Gbps`;
    } else if (_isStatic && internetBandwidth) {
      return `${internetBandwidth} Gbps`;
    } else {
      return "-- Gbps";
    }
  };

  const generateBandwidthData = (
    value: number,
    portType: "primary" | "secondary",
    max?: number
  ) => {
    if (_isStatic) {
      const selectedLowest = {
        amount: value,
        dashColor: "#088003",
        fillColor: "#E6F4E5",
        label: "Selected (Lowest)",
      };
      if (portType === "primary") {
        const datasetNew = [_bandwidthUsagePrimary[0], selectedLowest];
        setBandwidthUsagePrimary(datasetNew);
      } else {
        const datasetNew = [_bandwidthUsageSecondary[0], selectedLowest];
        setBandwidthUsageSecondary(datasetNew);
      }
    } else {
      const selectedLowestB = {
        amount: value,
        dashColor: "#088003",
        fillColor: "#E6F4E5",
        label: "Selected (Lowest)",
      };
      const selectedMaxB = {
        amount: max && max > 0 ? max : 0,
        dashColor: "#088003",
        fillColor: "#C4E4BF",
        label: "Selected (Highest)",
      };
      if (portType === "primary") {
        const datasetNew1 = [
          _bandwidthUsagePrimary[0],
          selectedLowestB,
          selectedMaxB,
        ];
        setBandwidthUsagePrimary(datasetNew1);
      } else {
        const datasetNew1 = [
          _bandwidthUsageSecondary[0],
          selectedLowestB,
          selectedMaxB,
        ];
        setBandwidthUsageSecondary(datasetNew1);
      }
    }
  };

  const _onModalOk = () => {
    dispatch(updateStep(1));
    dispatch(updateLevel(1));
    if (_isModifyJourney) {
      navigate("/internet-connection/attach-port?status=edit");
    } else {
      dispatch(resetInternetSlice());
      navigate("/internet-connection/attach-port");
    }
    setShowModal(false);
  };

  const _isBurstableBandwidthShortage = () => {
    return _isBurstable && ((_availablePrimaryBandwidth <= MIN_PORT_SPEED && !isOversubscriptionPrimary) || (_availableSecondaryBandwidth <= MIN_PORT_SPEED && !isOversubscriptionSecondary ))
  }

  const _onSubmitStepOne = React.useCallback(
    (formValues: any) => {
      setIsContinueClicked(true);

      const validateStatic = () => {
        const isBandwidthValid =
          !_internetBandwidthErrorPrimary &&
          !_internetBandwidthErrorSecondary &&
          _internetBandwidthPrimary &&
          _internetBandwidthSecondary &&
          _isVlanIdPrimaryAvailable &&
          _isVlanIdSecondaryAvailable;
        if (_isModifyJourney) return isBandwidthValid;
        return (
          isBandwidthValid &&
          (_isUtilisationThresholdValidPrimary ||
            !_isEnabledUtilisationMonitoringPrimary) &&
          (_isUtilisationThresholdValidSecondary ||
            !_isEnabledUtilisationMonitoringSecondary)
        );
      };

      if (_currentLevel === 1) {
        if (_isStatic) {
          if (validateStatic()) {
            dispatch(updateLevel(2));
          }
        } else {
          if (
            !_minCommitBandwidthErrorPrimary &&
            !_minCommitBandwidthErrorSecondary &&
            _minCommitBandwidthPrimary &&
            _minCommitBandwidthSecondary &&
            !_maxCommitBandwidthErrorPrimary &&
            !_maxCommitBandwidthErrorSecondary &&
            _maxCommitBandwidthPrimary &&
            _maxCommitBandwidthSecondary &&
            (_isUtilisationThresholdValidPrimary ||
              !_isEnabledUtilisationMonitoringPrimary) &&
            (_isUtilisationThresholdValidSecondary ||
              !_isEnabledUtilisationMonitoringSecondary) &&
            _isVlanIdPrimaryAvailable &&
            _isVlanIdSecondaryAvailable
          ) {
            dispatch(updateLevel(2));
          }
        }
      }

      if (
        !_internetBandwidthErrorPrimary &&
        !_internetBandwidthErrorSecondary
      ) {
        dispatch(
          updateInternetConfigurationDiverseData({
            bandwidthType: _isStatic ? "static" : "burstable",
            connectionName: formValues.connectionName,
            isEnabledPredictiveBandwidthPrimary:
              _isEnabledPredictiveBandwidthPrimary,
            isEnabledPredictiveBandwidthSecondary:
              _isEnabledPredictiveBandwidthSecondary,
            isEnabledUtilisationMonitoringPrimary:
              _isEnabledUtilisationMonitoringPrimary,
            isEnabledUtilisationMonitoringSecondary:
              _isEnabledUtilisationMonitoringSecondary,
            minCommitBandwidthPrimary: _minCommitBandwidthPrimary,
            minCommitBandwidthSecondary: _minCommitBandwidthSecondary,
            maxCommitBandwidthPrimary: _maxCommitBandwidthPrimary,
            maxCommitBandwidthSecondary: _maxCommitBandwidthSecondary,
            staticInternetBandwidthPrimary: _internetBandwidthPrimary,
            staticInternetBandwidthSecondary: _internetBandwidthSecondary,
            connectionDescriptionPrimary:
              formValues.connectionDescriptionPrimary,
            connectionDescriptionSecondary:
              formValues.connectionDescriptionSecondary,
            minUtilizationThresholdPrimary: `${_minUtilisationThresholdPrimary}`,
            minUtilizationThresholdSecondary: `${_minUtilisationThresholdSecondary}`,
            maxUtilizationThresholdPrimary: `${_maxUtilisationThresholdPrimary}`,
            maxUtilizationThresholdSecondary: `${_maxUtilisationThresholdSecondary}`,
            vlanIdPrimary: formValues.specificVlanIdPrimary,
            vlanIdSecondary: formValues.specificVlanIdSecondary,
            mtuSizePrimary: formValues.mtuPrimary ? formValues.mtuPrimary : 1500,
            mtuSizeSecondary: formValues.mtuSecondary ? formValues.mtuSecondary : 1500,
            vlanEncapsulationMethodPrimary:
              formValues.vlanEncapsulationMethodPrimary,
            vlanEncapsulationMethodSecondary:
              formValues.vlanEncapsulationMethodSecondary,
            isStatic: _isStatic,
          })
        );
      }
    },
    [
      _internetBandwidthErrorPrimary,
      _internetBandwidthErrorSecondary,
      _isStatic,
      _internetBandwidthPrimary,
      _internetBandwidthSecondary,
      _isEnabledPredictiveBandwidthPrimary,
      _isEnabledPredictiveBandwidthSecondary,
      _isEnabledUtilisationMonitoringPrimary,
      _isEnabledUtilisationMonitoringSecondary,
      _minCommitBandwidthPrimary,
      _minCommitBandwidthSecondary,
      _maxCommitBandwidthPrimary,
      _maxCommitBandwidthSecondary,
      _minCommitBandwidthErrorPrimary,
      _minCommitBandwidthErrorSecondary,
      _maxCommitBandwidthErrorPrimary,
      _maxCommitBandwidthErrorSecondary,
      _isUtilisationThresholdValidPrimary,
      _isUtilisationThresholdValidSecondary,
      _minUtilisationThresholdPrimary,
      _minUtilisationThresholdSecondary,
      _maxUtilisationThresholdPrimary,
      _maxUtilisationThresholdSecondary,
      _isVlanIdPrimaryAvailable,
      _isVlanIdSecondaryAvailable,
      _currentLevel
    ]
  );

  const handleNext = React.useCallback(() => {
    let bandwidthErrorExist = false;

    if (_isStatic) {
      if (_internetBandwidthPrimary === "") {
        setInternetBandwidthErrorPrimary(THIS_FIELD_CANNOT_BE_EMPTY);
        bandwidthErrorExist = true;
      }
      if (_internetBandwidthSecondary === "") {
        setInternetBandwidthErrorSecondary(THIS_FIELD_CANNOT_BE_EMPTY);
        bandwidthErrorExist = true;
      }
    } else {
      if (_minCommitBandwidthPrimary === "") {
        setMinCommitBandwidthErrorPrimary(THIS_FIELD_CANNOT_BE_EMPTY);
        bandwidthErrorExist = true;
      }
      if (_minCommitBandwidthSecondary === "") {
        setMinCommitBandwidthErrorSecondary(THIS_FIELD_CANNOT_BE_EMPTY);
        bandwidthErrorExist = true;
      }
      if (_maxCommitBandwidthPrimary === "") {
        setMaxCommitBandwidthErrorPrimary(THIS_FIELD_CANNOT_BE_EMPTY);
        bandwidthErrorExist = true;
      }
      if (_maxCommitBandwidthSecondary === "") {
        setMaxCommitBandwidthErrorSecondary(THIS_FIELD_CANNOT_BE_EMPTY);
        bandwidthErrorExist = true;
      }
    }

    InternetConnConfigDiverseFormDataMethods.handleSubmit(_onSubmitStepOne)();
    setScollToTop(true);

    if (!bandwidthErrorExist && _currentLevel === 2) {
      setInitiateStep2NextAction(true);
      setTimeout(() => {
        setInitiateStep2NextAction(false);
      }, 500);
    } else if (
      !bandwidthErrorExist &&
      (_currentLevel === 3 || _currentLevel === 4)
    ) {
      if (_isModifyJourney) {
        navigate(
          `/internet-connection/summary${
            _isModifyJourney ? "?status=edit" : ""
          }`
        );
        return;
      }
      setInitiateStep3NextAction(true);
      setTimeout(() => {
        setInitiateStep3NextAction(false);
      }, 500);
    }
  }, [
    _currentLevel,
    _isStatic,
    _minUtilisationThresholdPrimary,
    _minUtilisationThresholdSecondary,
    _maxUtilisationThresholdPrimary,
    _maxUtilisationThresholdSecondary,
    _minCommitBandwidthPrimary,
    _minCommitBandwidthSecondary,
    _maxCommitBandwidthPrimary,
    _maxCommitBandwidthSecondary,
    _internetBandwidthPrimary,
    _internetBandwidthSecondary,
    _isUtilisationThresholdValidPrimary,
    _isUtilisationThresholdValidSecondary,
    _isEnabledPredictiveBandwidthPrimary,
    _isEnabledPredictiveBandwidthSecondary,
    _isEnabledUtilisationMonitoringPrimary,
    _isEnabledUtilisationMonitoringSecondary,
    _isVlanIdPrimaryAvailable,
    _isVlanIdSecondaryAvailable,
  ]);

  React.useEffect(() => {
    const getBandwidthInfor = async () => {
      let isOversubscription: boolean = false;
      if (_portData[0].serviceId) {
        const portDetailsResponse = await api.getPortDetails(
          _portData[0].serviceId
        );
        isOversubscription =
          portDetailsResponse.primaryPortMetadata.isOversubscription;
        const { totalUsedBandwidth: totalUsedBandwidthPrimary } =
          await getInternetServicesAllocationByPortId(
            _portData[0].serviceId,
            api,
            isOversubscription
          );
        setIsOversubscriptionPrimary(isOversubscription);

        setBandwidthUsagePrimary((prev) => {
          const newArr = [...prev];
          newArr[0] = { ...prev[0], amount: totalUsedBandwidthPrimary };
          return newArr;
        });
        setAvailablePrimaryBandwidth(parseFloat((_associatedBandwidthPrimary - totalUsedBandwidthPrimary).toFixed(4)));
      }
      if (
        _portData[0].diversePortSubRows[1] &&
        _portData[0].diversePortSubRows[1].portId
      ) {
        const portDetailsResponse = await api.getPortDetails(
          _portData[0].diversePortSubRows[1].portId
        );
        isOversubscription =
          portDetailsResponse.primaryPortMetadata.isOversubscription;
        const { totalUsedBandwidth: totalUsedBandwidthSecondary } =
          await getInternetServicesAllocationByPortId(
            _portData[0].diversePortSubRows[1].portId,
            api,
            isOversubscription
          );
        setIsOversubscriptionSecondary(isOversubscription);
        setBandwidthUsageSecondary((prev) => {
          const newArr = [...prev];
          newArr[0] = { ...prev[0], amount: totalUsedBandwidthSecondary };
          return newArr;
        });
        setAvailableSecondaryBandwidth(parseFloat((_associatedBandwidthSecondary - totalUsedBandwidthSecondary).toFixed(4)));
      }
    };

    getBandwidthInfor();
  }, [_portData]);

  React.useEffect(() => {
    if (_currentLevel === 2 && ipAddressingRef.current) {
      ipAddressingRef.current.scrollIntoView();
    }
    if (_currentLevel === 3 && routingRef.current) {
      routingRef.current.scrollIntoView();
    }
  }, [_currentLevel, ipAddressingRef, routingRef]);

  React.useEffect(() => {
    if (
      _internetDiverseDetails.bandwidthType ||
      _internetDiverseDetails.isEnabledPredictiveBandwidthPrimary ||
      _internetDiverseDetails.isEnabledPredictiveBandwidthSecondary ||
      _internetDiverseDetails.isEnabledUtilisationMonitoringPrimary ||
      _internetDiverseDetails.isEnabledUtilisationMonitoringSecondary ||
      _internetDiverseDetails.minCommitBandwidthPrimary ||
      _internetDiverseDetails.minCommitBandwidthSecondary ||
      _internetDiverseDetails.maxCommitBandwidthPrimary ||
      _internetDiverseDetails.maxCommitBandwidthSecondary ||
      _internetDiverseDetails.maxUtilizationThresholdPrimary ||
      _internetDiverseDetails.maxUtilizationThresholdSecondary ||
      _internetDiverseDetails.minUtilizationThresholdPrimary ||
      _internetDiverseDetails.minUtilizationThresholdSecondary
    ) {
      setIsBurstable(_internetDiverseDetails.bandwidthType === "burstable");
      setIsStatic(_internetDiverseDetails.bandwidthType === "static");
      setIsEnabledPredictiveBandwidthPrimary(
        _internetDiverseDetails.isEnabledPredictiveBandwidthPrimary
      );
      setIsEnabledPredictiveBandwidthSecondary(
        _internetDiverseDetails.isEnabledPredictiveBandwidthSecondary
      );
      setInternetBandwidthPrimary(
        _internetDiverseDetails.staticInternetBandwidthPrimary
      );
      setInternetBandwidthSecondary(
        _internetDiverseDetails.staticInternetBandwidthSecondary
      );
      setMinCommitBandwidthPrimary(
        _internetDiverseDetails.minCommitBandwidthPrimary
      );
      setMinCommitBandwidthSecondary(
        _internetDiverseDetails.minCommitBandwidthSecondary
      );
      setMaxCommitBandwidthPrimary(
        _internetDiverseDetails.maxCommitBandwidthPrimary
      );
      setMaxCommitBandwidthSecondary(
        _internetDiverseDetails.maxCommitBandwidthSecondary
      );
      setIsEnabledUtilisationMonitoringPrimary(
        _internetDiverseDetails.isEnabledUtilisationMonitoringPrimary
      );
      setIsEnabledUtilisationMonitoringSecondary(
        _internetDiverseDetails.isEnabledUtilisationMonitoringSecondary
      );
      setMinCommitBandwidthPrimary(
        _internetDiverseDetails.minCommitBandwidthPrimary
      );
      setMinCommitBandwidthSecondary(
        _internetDiverseDetails.minCommitBandwidthSecondary
      );
      setMaxCommitBandwidthPrimary(
        _internetDiverseDetails.maxCommitBandwidthPrimary
      );
      setMaxCommitBandwidthSecondary(
        _internetDiverseDetails.maxCommitBandwidthSecondary
      );
    }
    setTimeout(() => window.scrollTo(0, 0), 200);
  }, []);

  React.useEffect(() => {
    if (_currentLevel === 1 && scrollToTop && configureInternetRef.current) {
      configureInternetRef.current.scrollIntoView();
      setScollToTop(false);
    }
  }, [_currentLevel, configureInternetRef, scrollToTop]);

  React.useEffect(() => {
    if (!_isEnabledUtilisationMonitoringPrimary) {
      setIsUtilisationThresholdValidPrimary(true);
    } else {
      setIsUtilisationThresholdValidPrimary(false);
    }
  }, [_isEnabledUtilisationMonitoringPrimary]);

  React.useEffect(() => {
    if (!_isEnabledUtilisationMonitoringSecondary) {
      setIsUtilisationThresholdValidSecondary(true);
    } else {
      setIsUtilisationThresholdValidSecondary(false);
    }
  }, [_isEnabledUtilisationMonitoringSecondary]);

  React.useEffect(() => {
    if (_vlanEncapMethodPrimary !== VLAN_ENCAPSULATION_METHODS[0]) {
      InternetConnConfigDiverseFormDataMethods.setValue(
        "specificVlanIdPrimary",
        null
      );
      setIsVlanIdPrimaryAvailable(true);
      setVlanPrimaryPillText("");
    } else if (_vlanEncapMethodPrimary === VLAN_ENCAPSULATION_METHODS[0]) {
      InternetConnConfigDiverseFormDataMethods.setValue(
        "specificVlanIdPrimary",
        NaN
      );
    }
  }, [_vlanEncapMethodPrimary]);

  React.useEffect(() => {
    if (_vlanEncapMethodSecondary !== VLAN_ENCAPSULATION_METHODS[0]) {
      InternetConnConfigDiverseFormDataMethods.setValue(
        "specificVlanIdSecondary",
        null
      );
      setIsVlanIdSecondaryAvailable(true);
      setVlanSecondaryPillText("");
    } else if (_vlanEncapMethodSecondary === VLAN_ENCAPSULATION_METHODS[0]) {
      InternetConnConfigDiverseFormDataMethods.setValue(
        "specificVlanIdSecondary",
        NaN
      );
    }
  }, [_vlanEncapMethodSecondary]);

  React.useEffect(() => {
    if (_internetDiverseDetails.vlanIdPrimary) {
      InternetConnConfigDiverseFormDataMethods.setValue(
        "specificVlanIdPrimary",
        _internetDiverseDetails.vlanIdPrimary
      );
    }
    if (_internetDiverseDetails.vlanIdSecondary) {
      InternetConnConfigDiverseFormDataMethods.setValue(
        "specificVlanIdSecondary",
        _internetDiverseDetails.vlanIdSecondary
      );
    }
  }, []);

  React.useEffect(() => {
    if (!_isEnabledUtilisationMonitoringPrimary) {
      setLastChangedField("");
    }
    if (!_isEnabledUtilisationMonitoringSecondary) {
      setLastChangedField("");
    }
  }, [
    _isEnabledUtilisationMonitoringPrimary,
    _isEnabledUtilisationMonitoringSecondary,
  ]);

  React.useEffect(() => {
    if (
      internetDiverseDetails.isEnabledUtilisationMonitoringPrimary &&
      internetDiverseDetails.minUtilizationThresholdPrimary &&
      internetDiverseDetails.maxUtilizationThresholdPrimary
    ) {
      setIsUtilisationThresholdValidPrimary(true);
    }
    if (
      internetDiverseDetails.isEnabledUtilisationMonitoringSecondary &&
      internetDiverseDetails.minUtilizationThresholdSecondary &&
      internetDiverseDetails.maxUtilizationThresholdSecondary
    ) {
      setIsUtilisationThresholdValidSecondary(true);
    }
  }, []);

  return (
    <>
      <div ref={configureInternetRef}></div>
      <InternetConnectionWrapper
        portsPreview={true}
        selectedPort={true}
        selectedPorts={_portData}
        handleNext={handleNext}
        handleBack={() => setShowModal(true)}
      >
        <FormProvider {...InternetConnConfigDiverseFormDataMethods}>
          <div className="fp-container">
            <div className="network-services-config__content-main config_diverse fp-row">
              <div className="column_both col-16">
                <Card>
                  <Label
                    text="Name & Description"
                    size="lg"
                    containerStyles="config-internet__container"
                    labelTextStyles="title"
                  />
                  <div className="diverse_row fp-row">
                    <div className="col-16 md:col-8">
                      <ConnectedInput
                        name="connectionName"
                        label="Connection Name"
                        containerStyles="config-connection-name__input"
                        labelTextStyles="config_field_label"
                        className="column_one"
                        placeholder="Up to 30 characters"
                        labelSize="sm"
                      />
                    </div>
                    <div className="col-16 md:col-8">{}</div>
                    <div className="col-16 md:col-8">
                      <div className="diverse_column_content column_one">
                        <Label
                          text="Primary Connection"
                          labelTextStyles="port_type"
                          size="sm"
                        />
                        <ConnectedTextarea
                          name="connectionDescriptionPrimary"
                          label="Description (optional)"
                          labelSize="sm"
                          placeholder="Up to 500 characters"
                          containerStyles="config-connection-description__text-area column_one"
                          labelTextStyles="config_field_label"
                          rows={6}
                          onChangeSideEffects={(val) => {
                            if (val === "") {
                              InternetConnConfigDiverseFormDataMethods.resetField(
                                "connectionDescriptionPrimary"
                              );
                            }
                          }}
                        />
                      </div>
                    </div>
                    <div className="col-16 md:col-8">
                      <div className="diverse_column_content column_two">
                        <Label
                          text="Secondary Connection"
                          labelTextStyles="port_type"
                          size="sm"
                        />
                        <ConnectedTextarea
                          name="connectionDescriptionSecondary"
                          label="Description (optional)"
                          labelSize="sm"
                          placeholder="Up to 500 characters"
                          containerStyles="config-connection-description__text-area"
                          labelTextStyles="config_field_label"
                          rows={6}
                          onChangeSideEffects={(val) => {
                            if (val === "") {
                              InternetConnConfigDiverseFormDataMethods.resetField(
                                "connectionDescriptionSecondary"
                              );
                            }
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </Card>
                <div className="mt-16">
                  <Card>
                    <Label
                      text="Bandwidth & Layer 2"
                      size="lg"
                      containerStyles="config-internet__container"
                      labelTextStyles="title"
                    />
                    <div className="diverse_row fp-row">
                      <div className="col-16 md:col-8">
                        <div className="column_one">
                          <Label
                            text="Bandwidth"
                            size="sm"
                            containerStyles="config-connection-bandwidth__container"
                            labelTextStyles="title config_field_label"
                          />
                          <div className="config-connection-bandwidth__content-wrapper">
                            <Button
                              iconTitle={
                                _isStatic ? "radio_button_icon" : "radio_unchecked"
                              }
                              label="Static"
                              onPress={() => {
                                setIsStatic(true);
                                setIsBurstable(false);
                                setIsVisiblebanner(true);
                                setMinCommitBandwidthPrimary("");
                                setMinCommitBandwidthSecondary("");
                                setBandwidthUsagePrimary((prev) => [prev[0]]);
                                setBandwidthUsageSecondary((prev) => [prev[0]]);
                                InternetConnConfigDiverseFormDataMethods.setValue(
                                  "mtuPrimary",
                                  1500
                                );
                                InternetConnConfigDiverseFormDataMethods.setValue(
                                  "mtuSecondary",
                                  1500
                                );
                              }}
                              variant={_isStatic ? "solid" : "outline"}
                              iconBefore={true}
                              iconSize="sm"
                              dataTestId="static_btn"
                              enableOriginalIcon
                              iconCustomStyle="radio-button-icon"
                            />
                            <Button
                              iconTitle={
                                _isBurstable
                                  ? "radio_button_icon"
                                  : "radio_unchecked"
                              }
                              label="Burstable"
                              onPress={() => {
                                setIsBurstable(true);
                                setIsStatic(false);
                                setIsVisiblebanner(true);
                                setInternetBandwidthPrimary("");
                                setInternetBandwidthSecondary("");
                                setBandwidthUsagePrimary((prev) => [prev[0]]);
                                setBandwidthUsageSecondary((prev) => [prev[0]]);
                                InternetConnConfigDiverseFormDataMethods.setValue(
                                  "mtuPrimary",
                                  null
                                );
                                InternetConnConfigDiverseFormDataMethods.setValue(
                                  "mtuSecondary",
                                  null
                                );
                                if((_availablePrimaryBandwidth <= MIN_PORT_SPEED || _availableSecondaryBandwidth <= MIN_PORT_SPEED)){
                                  setIsEnabledUtilisationMonitoringPrimary(false);
                                  setIsEnabledPredictiveBandwidthSecondary(false);
                                  setMaxUtilisationThresholdPrimary(NaN);
                                  setMaxUtilisationThresholdSecondary(NaN);
                                  setMinUtilisationThresholdPrimary(NaN);
                                  setMinUtilisationThresholdSecondary(NaN);
                                  setIsEnabledPredictiveBandwidthPrimary(false);
                                  setIsEnabledUtilisationMonitoringSecondary(false);
                                }
                              }}
                              variant={_isBurstable ? "solid" : "outline"}
                              iconBefore={true}
                              iconSize="sm"
                              dataTestId="burstable_btn"
                              enableOriginalIcon
                              iconCustomStyle="radio-button-icon"
                            />
                          </div>
                          {_isModifyJourney && (
                            <ModifyInLineText text="Changing this setting may affect the price on your invoice" />
                          )}
                          {_isVisibleBanner && _isStatic && (
                            <Tile customClassName="config-banner__wrapper">
                              <Icon color="#5514B4" size="sm" title="alert" />
                              <div className="config-banner__content">
                                <h3>Static</h3>
                                <p>
                                  A fixed amount of bandwidth with a fixed
                                  price. Any excess traffic is policed and
                                  dropped.
                                </p>
                              </div>
                              <Icon
                                color="#5514B4"
                                title="cross_new"
                                onClick={() => {
                                  setIsVisiblebanner(!_isVisibleBanner);
                                }}
                              />
                            </Tile>
                          )}
                          {_isVisibleBanner && _isBurstable && (_availablePrimaryBandwidth > MIN_PORT_SPEED && _availableSecondaryBandwidth > MIN_PORT_SPEED) && (
                            <Tile customClassName="config-banner__wrapper">
                              <Icon color="#5514B4" size="sm" title="alert" />
                              <div className="config-banner__content">
                                <h3>Burstable</h3>
                                <p>
                                  Burstable bandwidth has a fixed rate for
                                  minimum committed bandwidth and a usage-based
                                  price for traffic sent between the minimum and
                                  maximum bandwidth. Traffic exceeding the
                                  maximum bandwidth rates is dropped.
                                </p>
                              </div>
                              <Icon
                                color="#5514B4"
                                title="cross_new"
                                onClick={() => {
                                  setIsVisiblebanner(!_isVisibleBanner);
                                }}
                              />
                            </Tile>
                          )}

                          {_isBurstableBandwidthShortage() &&
                          <div className="bandwidth-shortage-message mt-8">
                            <img src={images.errorInfoIcon} className="errorInfo-icon"/>
                            <ErrorMessage
                              message="Bandwidth shortage: Selected port capped at 1 Mbps.
                            Burstable bandwidth configuration is not supported. 
                            Please review your network settings and consider 
                            upgrading the port capacity for optimal performance."
                              showIcon={false}
                              size="sm"
                            />
                          </div>
                          }
                        </div>
                      </div>

                      <div className="col-16 md:col-8">{}</div>

                      <div className="col-16 md:col-8">
                        <div className="diverse_column_content column_one settings">
                          <Label
                            text="Primary Connection"
                            labelTextStyles="port_type"
                            size="sm"
                          />
                          <UsageStackedGraph
                            graphData={_bandwidthUsagePrimary}
                            unitText="Gbps"
                            title="Associated Port Bandwidth"
                            showRemaining
                            totalAmount={_associatedBandwidthPrimary}
                          />
                          {_isStatic && (
                            <Input
                              label="Enter Internet Bandwidth (Gbps)"
                              name="internetBandwithPrimary"
                              labelSize="sm"
                              containerStyles="config-connection-name__input"
                              labelTextStyles="config_field_label"
                              type="float"
                              numberOfDecimalPlaces={3}
                              value={_internetBandwidthPrimary}
                              onChange={(value: string) => {
                                const validVal = validateRangeInclusive(
                                  Number(value),
                                  0.001,
                                  _availableBandwidthPrimary
                                );
                                if (value.length < 8) {
                                  setInternetBandwidthPrimary(
                                    value === "0" ? "" : value
                                  );
                                }
                                if (
                                  !validVal &&
                                  value !== "" &&
                                  !isOversubscriptionPrimary
                                ) {
                                  setInternetBandwidthErrorPrimary(
                                    `Out of range (0.001 to ${_availableBandwidthPrimary})`
                                  );
                                  generateBandwidthData(0, "primary");
                                } else {
                                  generateBandwidthData(+value, "primary");
                                  setInternetBandwidthErrorPrimary("");
                                }
                              }}
                              state={_internetBandwidthErrorPrimary ? "error" : "default"}
                              errorMessage={_internetBandwidthErrorPrimary}
                              errorMessageSize="sm"
                              showErrorIcon={false}
                              assetSrc={loadingSpinner}
                            />
                          )}
                          {_isBurstable && (
                            <div className="burstable_bandwidth__wrapper">
                              <Label
                                text="Enter Internet Bandwidth (Gbps)"
                                size="sm"
                                labelTextStyles="config_field_label"
                              />
                              <div className="burstable_bandwidth__inputs">
                                <Input
                                  helper="Min commit bandwidth"
                                  name="minCommitPrimary"
                                  value={_minCommitBandwidthPrimary}
                                  onChange={(value: string) => {
                                    const isWithinRange =
                                      validateRangeInclusive(
                                        Number(value),
                                        0.001,
                                        _availableBandwidthPrimary - 0.001
                                      );

                                    const isWithinRangeMax =
                                      _maxCommitBandwidthPrimary !== ""
                                        ? validateRange(
                                            parseInt(
                                              _maxCommitBandwidthPrimary
                                            ),
                                            0,
                                            _associatedBandwidthPrimary
                                          )
                                        : true;

                                    const isValueValid =
                                      _maxCommitBandwidthPrimary === "" ||
                                      Number(value) <
                                        Number(_maxCommitBandwidthPrimary);

                                    if (value.length < 8) {
                                      setMinCommitBandwidthPrimary(
                                        value === "0" ? "" : value
                                      );
                                    }

                                    if (!isValueValid && value !== "") {
                                      setMinCommitBandwidthErrorPrimary(
                                        "Value must be less than max bandwidth"
                                      );
                                    } else {
                                      setMinCommitBandwidthErrorPrimary("");
                                    }

                                    if (!isWithinRange && value !== "") {
                                      setMinCommitBandwidthErrorPrimary(
                                        `Out of range (0.001 to ${(
                                          _availableBandwidthPrimary - 0.001
                                        ).toFixed(3)})`
                                      );
                                      generateBandwidthData(
                                        0,
                                        "primary",
                                        parseInt(_maxCommitBandwidthPrimary) -
                                          parseInt(value)
                                      );
                                    } else if (isWithinRangeMax) {
                                      generateBandwidthData(
                                        +value,
                                        "primary",
                                        Number(_maxCommitBandwidthPrimary) -
                                          Number(value)
                                      );
                                      setCommitBandwidthErrorPrimary("");
                                    }

                                    if (
                                      _maxCommitBandwidthPrimary !== "" &&
                                      _maxCommitBandwidthErrorPrimary &&
                                      !_maxCommitBandwidthErrorPrimary.includes(
                                        "Out of range"
                                      ) &&
                                      Number(_maxCommitBandwidthPrimary) >
                                        (Number(value) || 0)
                                    ) {
                                      setMaxCommitBandwidthErrorPrimary("");
                                    }
                                  }}
                                  containerStyles="config-connection-name__input"
                                  labelSize="sm"
                                  type="float"
                                  numberOfDecimalPlaces={3}
                                  state={
                                    _minCommitBandwidthErrorPrimary ||
                                    _commitBandwidthErrorPrimary
                                      ? "error" : _isBurstableBandwidthShortage() ? "disabled"  : "default"
                                  }
                                  errorMessage={_minCommitBandwidthErrorPrimary}
                                  errorMessageSize="sm"
                                  showErrorIcon={false}
                                  assetSrc={loadingSpinner}
                                />
                                <Input
                                  helper="Max bandwidth"
                                  name="maxCommitPrimary"
                                  value={_maxCommitBandwidthPrimary}
                                  onChange={(value: string) => {
                                    const availableBandwidth =
                                      _associatedBandwidthPrimary -
                                      _bandwidthUsagePrimary[0].amount -
                                      parseInt(
                                        _minCommitBandwidthPrimary === ""
                                          ? "0"
                                          : _minCommitBandwidthPrimary
                                      );

                                    const isWithinRange =
                                      validateRangeInclusive(
                                        Number(value),
                                        0.002,
                                        _availableBandwidthPrimary
                                      );

                                    const isValueValid =
                                      _minCommitBandwidthPrimary === "" ||
                                      Number(value) >
                                        Number(_minCommitBandwidthPrimary);

                                    if (value.length < 8) {
                                      setMaxCommitBandwidthPrimary(
                                        value === "0" ? "" : value
                                      );
                                    }

                                    if (!isValueValid && value !== "") {
                                      setMaxCommitBandwidthErrorPrimary(
                                        "Value must be greater than min commit"
                                      );
                                    } else {
                                      setMaxCommitBandwidthErrorPrimary("");
                                    }

                                    if (
                                      !isWithinRange &&
                                      value !== "" &&
                                      !isOversubscriptionPrimary
                                    ) {
                                      setMaxCommitBandwidthErrorPrimary(
                                        `Out of range (0.002 to ${_availableBandwidthPrimary})`
                                      );
                                      generateBandwidthData(
                                        +_minCommitBandwidthPrimary,
                                        "primary",
                                        0
                                      );
                                    } else {
                                      generateBandwidthData(
                                        +_minCommitBandwidthPrimary,
                                        "primary",
                                        Number(value) -
                                          Number(_minCommitBandwidthPrimary)
                                      );
                                      setCommitBandwidthErrorPrimary("");
                                    }

                                    if (
                                      _minCommitBandwidthPrimary !== "" &&
                                      _minCommitBandwidthErrorPrimary &&
                                      !_minCommitBandwidthErrorPrimary.includes(
                                        "Out of range"
                                      ) &&
                                      Number(_minCommitBandwidthPrimary) <
                                        (Number(value) || availableBandwidth)
                                    ) {
                                      setMinCommitBandwidthErrorPrimary("");
                                    }
                                  }}
                                  containerStyles="config-connection-name__input"
                                  labelSize="sm"
                                  type="float"
                                  numberOfDecimalPlaces={3}
                                  state={
                                    _maxCommitBandwidthErrorPrimary ||
                                    _commitBandwidthErrorPrimary
                                      ? "error" : _isBurstableBandwidthShortage() ? "disabled" : "default"
                                  }
                                  errorMessage={_maxCommitBandwidthErrorPrimary}
                                  errorMessageSize="sm"
                                  showErrorIcon={false}
                                  assetSrc={loadingSpinner}
                                />
                              </div>
                              {_commitBandwidthErrorPrimary &&
                                _minCommitBandwidthErrorPrimary === "" &&
                                _maxCommitBandwidthErrorPrimary === "" && (
                                  <ErrorMessage
                                    message={_commitBandwidthErrorPrimary}
                                    size="sm"
                                    showIcon={false}
                                  />
                                )}
                            </div>
                          )}

                          <div className="config-bandwidth-uti-monitoring mb-16">
                            <Label
                              text="Bandwidth Utilisation Monitoring"
                              size="sm"
                              labelTextStyles="config_field_label"
                            />
                            <Toggle
                              checked={_isEnabledUtilisationMonitoringPrimary}
                              onChange={() => {
                                setIsEnabledUtilisationMonitoringPrimary(
                                  !_isEnabledUtilisationMonitoringPrimary
                                );
                              }}
                              disabled={_isBurstableBandwidthShortage()}
                            />
                          </div>
                          {_isEnabledUtilisationMonitoringPrimary && (
                            <Card cardStyle="monitoring-alarm__wrapper">
                              <Label
                                text="Monitoring alarm setting"
                                labelTextStyles="config_field_label"
                                size="sm"
                              />
                              <RangeBar
                                backgroundType={BackgroundType.GRADIENT}
                                customStyle="config-monitoring__rangebar"
                                enableScale
                                defaultMinValue={
                                  _minUtilisationThresholdPrimary
                                }
                                defaultMaxValue={
                                  _maxUtilisationThresholdPrimary
                                }
                                errorMinGreaterThanMax={
                                  lastChangedField === "min"
                                    ? "Value must be less than max threshold"
                                    : ""
                                }
                                errorMaxGreaterThanMin={
                                  lastChangedField === "max"
                                    ? "Value must be greater than min threshold"
                                    : ""
                                }
                                customMaxInputStyle="input-text-range-bar"
                                customMinInputStyle="input-text-range-bar"
                                labelMax="Max Utilisation Threshold (%)"
                                labelMin="Min Utilisation Threshold (%)"
                                maxErrorText="Out of Range (1 to 100%)"
                                maxInputRange={[1, 100]}
                                minErrorText="Out of Range (0 to 99%)"
                                minInputRange={[0, 99]}
                                showMaxErrorIcon={false}
                                showMinErrorIcon={false}
                                targetText={getTargetText(
                                  _internetBandwidthPrimary,
                                  _minCommitBandwidthPrimary
                                )}
                                targetTextAlign="center"
                                minPlaceholder={"0-99%"}
                                maxPlaceholder={"1-100%"}
                                keepErrorSpace={true}
                                errorMinIsEmpty={
                                  _isEnabledUtilisationMonitoringPrimary &&
                                  _isMinThresholdEmptyPrimary &&
                                  _isContinueClicked
                                    ? "Min cannot be empty"
                                    : ""
                                }
                                errorMaxIsEmpty={
                                  _isEnabledUtilisationMonitoringPrimary &&
                                  _isMaxThresholdEmptyPrimary &&
                                  _isContinueClicked
                                    ? "Max cannot be empty"
                                    : ""
                                }
                                onMinChange={(v: number) => {
                                  setMinUtilisationThresholdPrimary(v);
                                  setIsMinThresholdEmptyPrimary(false);
                                  setLastChangedField("min");
                                  if (
                                    _maxUtilisationThresholdPrimary &&
                                    v >= 0 &&
                                    v < _maxUtilisationThresholdPrimary
                                  ) {
                                    setIsUtilisationThresholdValidPrimary(true);
                                  } else {
                                    setIsUtilisationThresholdValidPrimary(
                                      false
                                    );
                                  }
                                }}
                                onMaxChange={(v: number) => {
                                  setMaxUtilisationThresholdPrimary(v);
                                  setIsMaxThresholdEmptyPrimary(false);
                                  setLastChangedField("max");
                                  if (
                                    (_minUtilisationThresholdPrimary ||
                                      _minUtilisationThresholdPrimary === 0) &&
                                    v < 101 &&
                                    v > _minUtilisationThresholdPrimary
                                  ) {
                                    setIsUtilisationThresholdValidPrimary(true);
                                  } else {
                                    setIsUtilisationThresholdValidPrimary(
                                      false
                                    );
                                  }
                                }}
                              />
                              <div className="config-bandwidth-uti-monitoring">
                                <Label
                                  text="Predictive Bandwidth Optimisation"
                                  size="sm"
                                  labelTextStyles="config_field_label"
                                />
                                <Toggle
                                  checked={_isEnabledPredictiveBandwidthPrimary}
                                  onChange={(val) => {
                                    setIsEnabledPredictiveBandwidthPrimary(val);
                                  }}
                                  disabled={_isBurstableBandwidthShortage()}
                                />
                              </div>
                              {_isEnabledPredictiveBandwidthPrimary && (
                                <p className="predictive_bandwidth">
                                  This optimisation utilizes the same
                                  utilisation threshold settings mentioned
                                  above. When enabled, it generates an alert if
                                  a threshold is predicted to be exceeded within
                                  the next month.
                                </p>
                              )}
                            </Card>
                          )}

                          <ConnectedDropdownInput
                            name="vlanEncapsulationMethodPrimary"
                            label="VLAN encapsulation method"
                            onChangeSideEffects={(val) => {
                              setVlanEncapMethodPrimary(val);
                            }}
                            options={VLAN_ENCAPSULATION_METHODS.map((v) => {
                              return { value: v, id: v };
                            })}
                            containerStyles="config-connection-name__input encap_method"
                            labelTextStyles="config_field_label"
                            state={_isBurstableBandwidthShortage() ? 'disabled': 'default'}
                          />

                          {_vlanEncapMethodPrimary ===
                            VLAN_ENCAPSULATION_METHODS[0] && (
                            <ConnectedInput
                              name="specificVlanIdPrimary"
                              helper="Select specific VLAN ID, range from 1 to 4094"
                              labelSize="sm"
                              containerStyles="config-connection-name__input"
                              type="integer"
                              placeholder="Input integer between 1 to 4094"
                              onChangeSideEffects={(val) => {
                                const isValValid = validateRange(
                                  parseInt(val),
                                  0,
                                  4095
                                );
                                setIsVlanIdPrimaryAvailable(isValValid);
                                setVlanPrimaryPillText("");
                              }}
                              primaryBadgeBefore
                              primaryBadgeIconShowOriginal={
                                _isVlanIdPrimaryAvailable
                              }
                              primaryBadgeIcon={
                                _isVlanIdPrimaryAvailable
                                  ? "single_tick"
                                  : "cross_new"
                              }
                              primaryBadgeIconColor={
                                _isVlanIdPrimaryAvailable
                                  ? "#088003"
                                  : " #DA020F"
                              }
                              primaryBadgeCustomStyle={
                                _isVlanIdPrimaryAvailable
                                  ? "vlan-badge-success"
                                  : "vlan-badge-error"
                              }
                              primaryBadgeText={_vlanPrimaryPillText}
                              primaryBadgeTextStyle={
                                _isVlanIdPrimaryAvailable
                                  ? "vlan-text-success"
                                  : "vlan-text-error"
                              }
                              state={_isBurstableBandwidthShortage() ? 'disabled': 'default'}
                            />
                          )}

                          {(_isStatic || _isBurstable) && (
                            <ConnectedInput
                              name="mtuPrimary"
                              label="Maximum Transmission Unit (MTU)"
                              type="integer"
                              containerStyles="config-connection-name__input"
                              labelTextStyles="config_field_label"
                              labelSize="sm"
                              placeholder="Permissible values: 1440-1500"
                            />
                          )}
                        </div>
                      </div>

                      <div className="col-16 md:col-8">
                        <div className="diverse_column_content column_two settings">
                          <Label
                            text="Secondary Connection"
                            labelTextStyles="port_type"
                            size="sm"
                          />
                          <UsageStackedGraph
                            graphData={_bandwidthUsageSecondary}
                            unitText="Gbps"
                            title="Associated Port Bandwidth"
                            showRemaining
                            totalAmount={_associatedBandwidthSecondary}
                          />
                          {_isStatic && (
                            <Input
                              label="Enter Internet Bandwidth (Gbps)"
                              name="internetBandwithSecondary"
                              labelSize="sm"
                              containerStyles="config-connection-name__input"
                              labelTextStyles="config_field_label"
                              type="float"
                              numberOfDecimalPlaces={3}
                              value={_internetBandwidthSecondary}
                              onChange={(value: string) => {
                                const validVal = validateRangeInclusive(
                                  Number(value),
                                  0.001,
                                  _availableBandwidthSecondary
                                );
                                if (value.length < 8) {
                                  setInternetBandwidthSecondary(
                                    value === "0" ? "" : value
                                  );
                                }
                                if (
                                  !validVal &&
                                  value !== "" &&
                                  !isOversubscriptionSecondary
                                ) {
                                  setInternetBandwidthErrorSecondary(
                                    `Out of range (0.001 to ${_availableBandwidthSecondary})`
                                  );
                                  generateBandwidthData(0, "secondary");
                                } else {
                                  generateBandwidthData(+value, "secondary");
                                  setInternetBandwidthErrorSecondary("");
                                }
                              }}
                              state={
                                _internetBandwidthErrorSecondary
                                  ? "error" : "default"
                              }
                              errorMessage={_internetBandwidthErrorSecondary}
                              errorMessageSize="sm"
                              showErrorIcon={false}
                              assetSrc={loadingSpinner}
                            />
                          )}
                          {_isBurstable && (
                            <div className="burstable_bandwidth__wrapper">
                              <Label
                                text="Enter Internet Bandwidth (Gbps)"
                                size="sm"
                                labelTextStyles="config_field_label"
                              />
                              <div className="burstable_bandwidth__inputs">
                                <Input
                                  helper="Min commit bandwidth"
                                  name="minCommitSecondary"
                                  value={_minCommitBandwidthSecondary}
                                  onChange={(value: string) => {
                                    const isWithinRange =
                                      validateRangeInclusive(
                                        Number(value),
                                        0.001,
                                        _availableBandwidthSecondary - 0.001
                                      );

                                    const isWithinRangeMax =
                                      _maxCommitBandwidthSecondary !== ""
                                        ? validateRange(
                                            parseInt(
                                              _maxCommitBandwidthSecondary
                                            ),
                                            0,
                                            _associatedBandwidthSecondary
                                          )
                                        : true;

                                    const isValueValid =
                                      _maxCommitBandwidthSecondary === "" ||
                                      Number(value) <
                                        Number(_maxCommitBandwidthSecondary);

                                    if (value.length < 8) {
                                      setMinCommitBandwidthSecondary(
                                        value === "0" ? "" : value
                                      );
                                    }

                                    if (!isValueValid && value !== "") {
                                      setMinCommitBandwidthErrorSecondary(
                                        "Value must be less than max bandwidth"
                                      );
                                    } else {
                                      setMinCommitBandwidthErrorSecondary("");
                                    }
                                    if (!isWithinRange && value !== "") {
                                      setMinCommitBandwidthErrorSecondary(
                                        `Out of range (0.001 to ${(
                                          _availableBandwidthSecondary - 0.001
                                        ).toFixed(3)})`
                                      );
                                      generateBandwidthData(
                                        0,
                                        "secondary",
                                        parseInt(_maxCommitBandwidthSecondary) -
                                          parseInt(value)
                                      );
                                    } else if (isWithinRangeMax) {
                                      generateBandwidthData(
                                        +value,
                                        "secondary",
                                        Number(_maxCommitBandwidthSecondary) -
                                          Number(value)
                                      );
                                      setCommitBandwidthErrorSecondary("");
                                    }

                                    if (
                                      _maxCommitBandwidthSecondary !== "" &&
                                      _maxCommitBandwidthErrorSecondary &&
                                      !_maxCommitBandwidthErrorSecondary.includes(
                                        "Out of range"
                                      ) &&
                                      Number(_maxCommitBandwidthSecondary) >
                                        (Number(value) || 0)
                                    ) {
                                      setMaxCommitBandwidthErrorSecondary("");
                                    }
                                  }}
                                  containerStyles="config-connection-name__input"
                                  labelSize="sm"
                                  type="float"
                                  numberOfDecimalPlaces={3}
                                  state={
                                    _minCommitBandwidthErrorSecondary ||
                                    _commitBandwidthErrorSecondary
                                      ? "error" : _isBurstableBandwidthShortage() ? "disabled" : "default"
                                  }
                                  errorMessage={
                                    _minCommitBandwidthErrorSecondary
                                  }
                                  errorMessageSize="sm"
                                  showErrorIcon={false}
                                  assetSrc={loadingSpinner}
                                />
                                <Input
                                  helper="Max bandwidth"
                                  name="maxCommitSecondary"
                                  value={_maxCommitBandwidthSecondary}
                                  onChange={(value: string) => {
                                    const availableBandwidth =
                                      _associatedBandwidthSecondary -
                                      _bandwidthUsageSecondary[0].amount -
                                      parseInt(
                                        _minCommitBandwidthSecondary === ""
                                          ? "0"
                                          : _minCommitBandwidthSecondary
                                      );

                                    const isWithinRange =
                                      validateRangeInclusive(
                                        Number(value),
                                        0.002,
                                        _availableBandwidthSecondary
                                      );

                                    const isValueValid =
                                      _minCommitBandwidthSecondary === "" ||
                                      Number(value) >
                                        Number(_minCommitBandwidthSecondary);

                                    if (value.length < 8) {
                                      setMaxCommitBandwidthSecondary(
                                        value === "0" ? "" : value
                                      );
                                    }

                                    if (!isValueValid && value !== "") {
                                      setMaxCommitBandwidthErrorSecondary(
                                        "Value must be greater than min commit"
                                      );
                                    } else {
                                      setMaxCommitBandwidthErrorSecondary("");
                                    }

                                    if (
                                      !isWithinRange &&
                                      value !== "" &&
                                      !isOversubscriptionSecondary
                                    ) {
                                      setMaxCommitBandwidthErrorSecondary(
                                        `Out of range (0.002 to ${_availableBandwidthSecondary})`
                                      );
                                      generateBandwidthData(
                                        +_minCommitBandwidthSecondary,
                                        "secondary",
                                        0
                                      );
                                    } else {
                                      generateBandwidthData(
                                        +_minCommitBandwidthSecondary,
                                        "secondary",
                                        Number(value) -
                                          Number(_minCommitBandwidthSecondary)
                                      );
                                      setCommitBandwidthErrorSecondary("");
                                    }

                                    if (
                                      _minCommitBandwidthSecondary !== "" &&
                                      _minCommitBandwidthErrorSecondary &&
                                      !_minCommitBandwidthErrorSecondary.includes(
                                        "Out of range"
                                      ) &&
                                      Number(_minCommitBandwidthSecondary) <
                                        (Number(value) || availableBandwidth)
                                    ) {
                                      setMinCommitBandwidthErrorSecondary("");
                                    }
                                  }}
                                  containerStyles="config-connection-name__input"
                                  labelSize="sm"
                                  type="float"
                                  numberOfDecimalPlaces={3}
                                  state={
                                    _maxCommitBandwidthErrorSecondary ||
                                    _commitBandwidthErrorSecondary
                                      ? "error" : _isBurstableBandwidthShortage() ? "disabled" : "default"
                                  }
                                  errorMessage={
                                    _maxCommitBandwidthErrorSecondary
                                  }
                                  errorMessageSize="sm"
                                  showErrorIcon={false}
                                  assetSrc={loadingSpinner}
                                />
                              </div>
                              {_commitBandwidthErrorSecondary &&
                                _minCommitBandwidthErrorSecondary === "" &&
                                _maxCommitBandwidthErrorSecondary === "" && (
                                  <ErrorMessage
                                    message={_commitBandwidthErrorSecondary}
                                    size="sm"
                                    showIcon={false}
                                  />
                                )}
                            </div>
                          )}

                          <div className="config-bandwidth-uti-monitoring mb-16">
                            <Label
                              text="Bandwidth Utilisation Monitoring"
                              size="sm"
                              labelTextStyles="config_field_label"
                            />
                            <Toggle
                              checked={_isEnabledUtilisationMonitoringSecondary}
                              onChange={() => {
                                setIsEnabledUtilisationMonitoringSecondary(
                                  !_isEnabledUtilisationMonitoringSecondary
                                );
                              }}
                              disabled={_isBurstableBandwidthShortage()}
                            />
                          </div>
                          {_isEnabledUtilisationMonitoringSecondary && (
                            <Card cardStyle="monitoring-alarm__wrapper">
                              <Label
                                text="Monitoring alarm setting"
                                size="sm"
                                labelTextStyles="config_field_label"
                              />
                              <RangeBar
                                backgroundType={BackgroundType.GRADIENT}
                                customStyle="config-monitoring__rangebar"
                                enableScale
                                defaultMinValue={
                                  _minUtilisationThresholdSecondary
                                }
                                defaultMaxValue={
                                  _maxUtilisationThresholdSecondary
                                }
                                errorMinGreaterThanMax={
                                  lastChangedField === "min"
                                    ? "Value must be less than max threshold"
                                    : ""
                                }
                                errorMaxGreaterThanMin={
                                  lastChangedField === "max"
                                    ? "Value must be greater than min threshold"
                                    : ""
                                }
                                customMaxInputStyle="input-text-range-bar"
                                customMinInputStyle="input-text-range-bar"
                                labelMax="Max Utilisation Threshold (%)"
                                labelMin="Min Utilisation Threshold (%)"
                                maxErrorText="Out of Range (1 to 100%)"
                                maxInputRange={[1, 100]}
                                minErrorText="Out of Range (0 to 99%)"
                                minInputRange={[0, 99]}
                                showMaxErrorIcon={false}
                                showMinErrorIcon={false}
                                targetText={getTargetText(
                                  _internetBandwidthSecondary,
                                  _minCommitBandwidthSecondary
                                )}
                                targetTextAlign="center"
                                minPlaceholder={"0-99%"}
                                maxPlaceholder={"1-100%"}
                                keepErrorSpace={true}
                                errorMinIsEmpty={
                                  _isEnabledUtilisationMonitoringSecondary &&
                                  _isMinThresholdEmptySecondary &&
                                  _isContinueClicked
                                    ? "Min cannot be empty"
                                    : ""
                                }
                                errorMaxIsEmpty={
                                  _isEnabledUtilisationMonitoringSecondary &&
                                  _isMaxThresholdEmptySecondary &&
                                  _isContinueClicked
                                    ? "Max cannot be empty"
                                    : ""
                                }
                                onMinChange={(v: number) => {
                                  setMinUtilisationThresholdSecondary(v);
                                  setIsMinThresholdEmptySecondary(false);
                                  setLastChangedField("min");
                                  if (
                                    _maxUtilisationThresholdSecondary &&
                                    v >= 0 &&
                                    v < _maxUtilisationThresholdSecondary
                                  ) {
                                    setIsUtilisationThresholdValidSecondary(
                                      true
                                    );
                                  } else {
                                    setIsUtilisationThresholdValidSecondary(
                                      false
                                    );
                                  }
                                }}
                                onMaxChange={(v: number) => {
                                  setMaxUtilisationThresholdSecondary(v);
                                  setIsMaxThresholdEmptySecondary(false);
                                  setLastChangedField("max");
                                  if (
                                    (_minUtilisationThresholdSecondary ||
                                      _minUtilisationThresholdSecondary ===
                                        0) &&
                                    v < 101 &&
                                    v > _minUtilisationThresholdSecondary
                                  ) {
                                    setIsUtilisationThresholdValidSecondary(
                                      true
                                    );
                                  } else {
                                    setIsUtilisationThresholdValidSecondary(
                                      false
                                    );
                                  }
                                }}
                              />
                              <div className="config-bandwidth-uti-monitoring">
                                <Label
                                  text="Predictive Bandwidth Optimisation"
                                  size="sm"
                                  labelTextStyles="config_field_label"
                                />
                                <Toggle
                                  checked={
                                    _isEnabledPredictiveBandwidthSecondary
                                  }
                                  onChange={(val) => {
                                    setIsEnabledPredictiveBandwidthSecondary(
                                      val
                                    );
                                  }}
                                />
                              </div>
                              {_isEnabledPredictiveBandwidthSecondary && (
                                <p className="predictive_bandwidth">
                                  This optimisation utilizes the same
                                  utilisation threshold settings mentioned
                                  above. When enabled, it generates an alert if
                                  a threshold is predicted to be exceeded within
                                  the next month.
                                </p>
                              )}
                            </Card>
                          )}

                          <ConnectedDropdownInput
                            name="vlanEncapsulationMethodSecondary"
                            label="VLAN encapsulation method"
                            onChangeSideEffects={(val) => {
                              setVlanEncapMethodSecondary(val);
                            }}
                            options={VLAN_ENCAPSULATION_METHODS.map((v) => {
                              return { value: v, id: v };
                            })}
                            containerStyles="config-connection-name__input encap_method"
                            labelTextStyles="config_field_label"
                            state={_isBurstableBandwidthShortage() ? 'disabled' : 'default'}
                          />

                          {_vlanEncapMethodSecondary ===
                            VLAN_ENCAPSULATION_METHODS[0] && (
                            <ConnectedInput
                              name="specificVlanIdSecondary"
                              helper="Select specific VLAN ID, range from 1 to 4094"
                              labelSize="sm"
                              containerStyles="config-connection-name__input"
                              type="integer"
                              placeholder="Input integer between 1 to 4094"
                              onChangeSideEffects={(val) => {
                                const isValValid = validateRange(
                                  parseInt(val),
                                  0,
                                  4095
                                );
                                setIsVlanIdSecondaryAvailable(isValValid);
                                setVlanSecondaryPillText("");
                              }}
                              primaryBadgeBefore
                              primaryBadgeIconShowOriginal={
                                _isVlanIdSecondaryAvailable
                              }
                              primaryBadgeIcon={
                                _isVlanIdSecondaryAvailable
                                  ? "single_tick"
                                  : "cross_new"
                              }
                              primaryBadgeIconColor={
                                _isVlanIdSecondaryAvailable
                                  ? "#088003"
                                  : " #DA020F"
                              }
                              primaryBadgeCustomStyle={
                                _isVlanIdSecondaryAvailable
                                  ? "vlan-badge-success"
                                  : "vlan-badge-error"
                              }
                              primaryBadgeText={_vlanSecondaryPillText}
                              primaryBadgeTextStyle={
                                _isVlanIdSecondaryAvailable
                                  ? "vlan-text-success"
                                  : "vlan-text-error"
                              }
                              state={_isBurstableBandwidthShortage() ? 'disabled' : 'default'}
                            />
                          )}
                          {(_isStatic || _isBurstable) && (
                            <ConnectedInput
                              name="mtuSecondary"
                              label="Maximum Transmission Unit (MTU)"
                              type="integer"
                              containerStyles="config-connection-name__input"
                              labelTextStyles="config_field_label"
                              labelSize="sm"
                              placeholder="Permissible values: 1440-1500"
                            />
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>
            </div>

            {_currentLevel > 1 && (
              <div>
                <div ref={ipAddressingRef} className="ref_holder">
                  <IPAddressing initiateNext={_initiateStep2NextAction} />
                </div>
              </div>
            )}

            {_currentLevel > 2 && (
              <div className="mt-16">
                <div ref={routingRef} className="ref_holder">
                  <InternetConnectionRouting
                    initiateNext={_initiateStep3NextAction}
                    journeyType="diverse"
                  />
                </div>
              </div>
            )}
          </div>
        </FormProvider>
      </InternetConnectionWrapper>
      <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        topIconSize="md"
        title="Leave without saving changes"
        complementaryMessage="Are you sure you want to leave this page? Your setup information will be lost."
        contentAlign="center"
        actionText="Leave"
        onOk={_onModalOk}
        closeModal={!_showModal}
        onCancel={() => setShowModal(false)}
      />
    </>
  );
};

export default InternetConnectionConfigurationDiverse;
