import React from "react";
import { render, screen } from "@testing-library/react";
import CreatePortSelection from "./index";
import { BrowserRouter } from "react-router-dom";

describe("CreatePortSelection", () => {
  it("should render", () => {
    render(
      <BrowserRouter>
        <CreatePortSelection />
      </BrowserRouter>,
    );
    expect(screen.getByTestId("port-container")).toBeInTheDocument();
  });
});
