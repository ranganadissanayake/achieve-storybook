import React from "react";
import { useNavigate } from "react-router-dom";
import { Button, Label } from "@btdigital/nayan-component-library";

import PortTypeCard from "../../components/PortTypeCard";
import customerPortIcon from "../../shared/assets/images/svg/customer_port.svg";
import couldPortIcon from "../../shared/assets/images/svg/cloud_port.svg";
import PageWrap from "../../components/PageWrap";

import "./CreatePortSelection.scss";
import TagDataLayerService from "../../shared/services/TagDatalayer.service";

const CreatePortSelection = () => {
  const navigate = useNavigate();

  return (
    <PageWrap className="port-container " testId="port-container">
      <div className="port-cards-heading">
        <Label
          size="lg"
          text="Create a new Port"
          labelTextStyles="port-heading"
        />
        <label className="port-sub-heading">
          Visit{" "}
          <a className="sub-heading-link">BT Global Fabric knowledge centre</a>{" "}
          for more information on port configuration
        </label>
      </div>

      <div
        className="port-cards-content fp-row"
        data-testid="port-card-container "
      >
        <div className="col-16 xl:col-5 sm:col-8 md:col-8 lg:col-5 mb-16">
          <PortTypeCard
            mainImage={customerPortIcon}
            mainTitle="Customer Port"
            description="Deploy a port with connectivity into a total of 700 Data centre locations globally."
            subtitle="Time to Deploy"
            subItems={["Immediate deploy"]}
            actionButton={
              <Button
                label="Create"
                variant="gradient"
                fullWidth={true}
                className="port-selection-button"
                onPress={() => {
                  TagDataLayerService.pushCtaData("Create - Customer Port");
                  navigate("/customer-ports");
                }}
              />
            }
          />
        </div>
        <div className="col-16 xl:col-5 sm:col-8 md:col-8 lg:col-5 mb-16">
          <PortTypeCard
            mainImage={couldPortIcon}
            mainTitle="Cloud Port"
            description="Deploy a port only connection within a BT PoP Data centre Location."
            subtitle="Time to Deploy"
            subItems={["Immediate deploy"]}
            actionButton={
              <Button
                label="Create"
                variant="gradient"
                fullWidth={true}
                className="port-selection-button"
                onPress={() => {
                  TagDataLayerService.pushCtaData("Create - Cloud Port");
                  TagDataLayerService.pushPageData("Create Cloud Port", "Choose your Cloud Provider");
                  navigate("/cloud-ports/choose-a-provider");
                }}
              />
            }
          />
        </div>
      </div>
    </PageWrap>
  );
};

export default CreatePortSelection;
