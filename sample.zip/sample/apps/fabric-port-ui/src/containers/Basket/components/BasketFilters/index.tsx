import {
  Button,
  DropdownDatePicker,
  DropdownGroup,
} from "@btdigital/nayan-component-library";
import React from "react";
import { getTypeOptions } from "../../../../shared/constants/portInventory";

export interface BasketFiltersProps {
  data: any;
  filteredItemsCount: number;
  typeFilters: string[];
  dateFilters: string[];
  clearFilters: () => void;
  setTypeFilters: (value: string[]) => void;
  setDateFilters: (value: string[]) => void;
}

const BasketFilters: React.FC<BasketFiltersProps> = ({
  data,
  typeFilters,
  filteredItemsCount,
  dateFilters,
  clearFilters,
  setTypeFilters,
  setDateFilters,
}) => {
  return (
    <div className="filter-actions">
      <DropdownGroup
        options={getTypeOptions(data)}
        label="Type"
        type="checkbox"
        defaultValue={typeFilters}
        selectSideEffects={(value: any) => {
          setTypeFilters(value as string[]);
        }}
      />
      <DropdownDatePicker
        label="Date added"
        defaultValue={dateFilters}
        selectSideEffects={(value: any) => {
          setDateFilters(value as string[]);
        }}
      />
      {filteredItemsCount > 0 && (
        <Button
          label="Clear all"
          variant="link"
          onPress={() => {
            clearFilters();
          }}
        />
      )}
    </div>
  );
};

export default BasketFilters;
