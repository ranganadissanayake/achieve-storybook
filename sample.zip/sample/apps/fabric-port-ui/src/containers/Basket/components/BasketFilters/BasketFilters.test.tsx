import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import BasketFilters, { BasketFiltersProps } from "./index";

describe("BasketFilters", () => {
  const data = [
    { id: 1, name: "Type A" },
    { id: 2, name: "Type B" },
    { id: 3, name: "Type C" },
  ];

  const typeFilters = ["Type A", "Type B"];
  const dateFilters = ["Type A", "Type B"];
  const filteredItemsCount = 5;
  const clearFiltersMock = jest.fn();
  const setTypeFiltersMock = jest.fn();
  const setDateFiltersMock = jest.fn();

  afterEach(() => {
    clearFiltersMock.mockClear();
    setTypeFiltersMock.mockClear();
    setDateFiltersMock.mockClear();
  });

  const renderComponent = (props: Partial<BasketFiltersProps> = {}) => {
    const defaultProps: BasketFiltersProps = {
      data,
      filteredItemsCount,
      typeFilters,
      dateFilters,
      clearFilters: clearFiltersMock,
      setTypeFilters: setTypeFiltersMock,
      setDateFilters: setDateFiltersMock,
    };

    return render(<BasketFilters {...defaultProps} {...props} />);
  };

  it("renders without errors", () => {
    renderComponent();
  });

  it("calls the clearFilters function when the clear button is clicked", () => {
    renderComponent();
    fireEvent.click(screen.getByText("Clear all"));
    expect(clearFiltersMock).toHaveBeenCalledTimes(1);
  });
});
