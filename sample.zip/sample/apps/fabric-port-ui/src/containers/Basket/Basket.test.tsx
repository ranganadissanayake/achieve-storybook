import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import Basket from "./index";
import { BrowserRouter } from "react-router-dom";
import "regenerator-runtime";
import { Provider } from "react-redux";
import store from "../../redux/store";

describe("test Basket component", () => {
  test("renders the Basket component", async () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <Basket />
        </BrowserRouter>
      </Provider>,
    );

    expect(screen.getByTestId("basket")).toBeInTheDocument();
  });
  test("displays the BasketFilters component", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <Basket />
        </BrowserRouter>
      </Provider>,
    );

    expect(screen.getByText("Order selected")).toBeInTheDocument();
  });
  test("clears the selectedTableData when the 'Order selected' button is clicked", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <Basket />
        </BrowserRouter>
      </Provider>,
    );
    const orderSelectedButton = screen.getByText("Order selected");
    fireEvent.click(orderSelectedButton);
  });
});
