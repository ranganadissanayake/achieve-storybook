import React from "react";
import { render, screen } from "@testing-library/react";
import BasketSummary, { BasketSummaryProps } from "./index";

const mockBasketItems = [
  {
    id: 1,
    name: "Item 1",
    monthlyPrice: 10,
    oneOffPayment: 20,
  },
  {
    id: 2,
    name: "Item 2",
    monthlyPrice: 15,
    oneOffPayment: 30,
  },
];

const mockDeployAction = jest.fn();

const setup = (props: Partial<BasketSummaryProps> = {}) => {
  const defaultProps: BasketSummaryProps = {
    selectedBasketItems: mockBasketItems as any,
    deployAction: mockDeployAction,
  };
  const mergedProps = { ...defaultProps, ...props };
  return render(<BasketSummary {...mergedProps} />);
};

describe("BasketSummary", () => {
  test("renders the correct basket data", () => {
    setup();

    const basketTitle = screen.getByText("Basket");
    const itemCount = screen.getByText("Order selected");

    expect(basketTitle).toBeInTheDocument();
    expect(itemCount).toBeInTheDocument();
  });
});
