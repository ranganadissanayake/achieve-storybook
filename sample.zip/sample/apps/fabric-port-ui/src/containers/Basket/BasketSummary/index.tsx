import React, { useEffect, useState } from "react";
import { Card, Badge, Button } from "@btdigital/nayan-component-library";
import { Basket } from "../../../shared/types/index";

import "./basketSummary.scss";

export interface BasketSummaryProps {
  selectedBasketItems?: [];
  deployAction?: () => void;
}

export interface BasketData {
  totalRecurring: string;
  totalNonRecurring: string;
  amountToPay: string;
}

const BasketSummary: React.FC<BasketSummaryProps> = ({
  selectedBasketItems,
  deployAction,
}) => {
  const [totalRecurring, setTotalRecurring] = useState<number>(0);
  const [totalNonRecurring, setTotalNonRecurring] = useState<number>(0);

  let itemTotalRecurring: number;
  let itemTotalNonRecurring: number;

  useEffect(() => {
    if (selectedBasketItems?.length) {
      itemTotalRecurring = 0;
      itemTotalNonRecurring = 0;

      setTotalRecurring(0);
      setTotalNonRecurring(0);

      selectedBasketItems.map((item: Basket) => {
        itemTotalRecurring = itemTotalRecurring + item.monthlyPrice;
        itemTotalNonRecurring = itemTotalNonRecurring + item.oneOffPayment;
      });

      setTotalRecurring(itemTotalRecurring);
      setTotalNonRecurring(itemTotalNonRecurring);
    } else {
      setTotalRecurring(0);
      setTotalNonRecurring(0);
    }
  }, [selectedBasketItems]);

  return (
    <section className="basket-summary">
      <div className="fp-container">
        <Card>
          <div className="fp-row pl-20 pr-20">
            <div className="left-wrap col-16 sm:col-8 md:col-8 lg:col-8 xl:col-8">
              <div className="basket-data-wrap">
                <div className="data-title">
                  <span>Basket</span>
                </div>
                <div className="data-count">
                  {" "}
                  <Badge
                    style="default-light"
                    customStyle="badge-icon"
                    text={
                      selectedBasketItems?.length &&
                      selectedBasketItems?.length > 1
                        ? `${selectedBasketItems?.length} Items`
                        : `${selectedBasketItems?.length} Item`
                    }
                  />
                </div>
              </div>
              <div className="basket-data-wrap">
                <div className="data-title">Total Recurring (MRC)</div>
                <div className="data-count">
                  <b> {`£${totalRecurring.toLocaleString()}`}</b>/{" "}
                  <span className="month-text">month</span>{" "}
                </div>
              </div>
              <div className="basket-data-wrap">
                <div className="data-title">Total Non-Recurring (NRC)</div>
                <div className="data-count">
                  <b>{`£${totalNonRecurring.toLocaleString()}`}</b>
                </div>
              </div>
            </div>
            <div className="right-wrap col-16 sm:col-8 md:col-8 lg:col-8 xl:col-8">
              <div className="order-section">
                <div className="amount">
                  <div className="amount-text">
                    <b>Amount to Pay</b>
                  </div>
                  <div className="amount-value">
                    <b>{`£${(
                      totalRecurring + totalNonRecurring
                    ).toLocaleString()}`}</b>
                  </div>
                </div>
                <div className="order-selected">
                  <Button
                    onPress={deployAction}
                    label="Order selected"
                    variant="gradient"
                    size="medium"
                    className="order-btn"
                    disabled={selectedBasketItems?.length ? false : true}
                  />
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default BasketSummary;
