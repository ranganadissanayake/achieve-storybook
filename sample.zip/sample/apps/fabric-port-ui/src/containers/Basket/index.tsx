import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";

import dayjs from "dayjs";
import {
  Table,
  Card,
  Modal,
} from "@btdigital/nayan-component-library";

import { updateBasket, updateCount } from "../../redux/basketSlice";
import dots from "../../shared/assets/images/svg/dots-vertical.svg";
import BasketSummary from "./BasketSummary";
import { updateIsDeploymentRequestEnabled } from "../../redux/portOnlySlice";
import ContextDropDown from "../../components/ContextDropdown";
import { RowDataInterfacePortIn } from "shared/types";
import BasketFilters from "./components/BasketFilters";

import "./Basket.scss";

export interface BasketProps { }

interface RowDataInterface {
  getToggleRowExpandedProps: any;
  isExpanded: boolean;
  id: number;
}

export interface ColumnDataInterface {
  logoURL: string;
  portName: string;
  type: string;
  primaryPortSpeed: string;
  secondaryPortSpeed: string;
  oneOffPayment: number;
  monthlyPrice: number;
  discount?: number;
  timeToDeploy?: string;
}

const Basket: React.FC<BasketProps> = (props: BasketProps) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [threeDotsStatus, setThreeDotsStatus] = React.useState(false);

  const [_showDeleteModal, setShowDeleteModal] = React.useState(false);

  const [showFilterBar, setShowFilterBar] = React.useState(false);
  const [typeFilters, setTypeFilters] = React.useState<string[]>([]);
  const [dateFilters, setDateFilters] = React.useState<string[]>([]);
  const [selectedIdForDeletion, setSelectedIdForDeletion] =
    useState<string>("");
  let tableData: any[] = [];

  React.useEffect(() => {
    if (localStorage.portsData) {
      tableData = JSON.parse(localStorage.portsData);
    }
  }, []);

  const getTableDataFromLocalStorage = () => {
    if (localStorage.portsData) {
      return JSON.parse(localStorage.portsData);
    } else {
      return [];
    }
  }

  const [prepTableData, setPrepTableData] = useState(tableData);
  const [selectedTableData, setSelectedTableData] = useState<any>([]);
  //set some sample data to local storage
  localStorage.setItem("cartData", JSON.stringify(prepTableData));

  const onSelectMulitiRows = (values: []) => {
    if (values.length !== 0) {
      setSelectedTableData(values);
    } else {
      setSelectedTableData(prepTableData);
    }
  };

  useEffect(() => {
    setSelectedTableData(prepTableData);
  }, [prepTableData]);

  const handleFilters = () => {
    const filters: any = {};
    if (typeFilters.length > 0) {
      filters["type"] = typeFilters;
    }

    return prepTableData.filter(function (item: any) {
      if (
        dateFilters.length > 0 &&
        dayjs(item?.lastAdded).isAfter(dateFilters[0]?.split(" - ")[0]) !==
        dayjs(item?.lastAdded).isBefore(dateFilters[0]?.split(" - ")[1])
      ) {
        return false;
      }
      for (const key in filters) {
        if (item[key] === undefined || !filters[key]?.includes(item[key])) {
          return false;
        }
      }
      return true;
    });
  };

  React.useEffect(() => {
    if (typeFilters.length > 0 || dateFilters.length > 0) {
      setPrepTableData(handleFilters());
    } else {
      setPrepTableData(getTableDataFromLocalStorage());
    }
  }, [typeFilters, dateFilters]);

  //sample column data with custom columns
  const tableColumns = [
    {
      // Make custom cell that can render components inside
      Header: "Item Name",
      accessor: "portName",
      id: "portName",
    },
    {
      // Make custom cell that can render components inside
      Header: "Type",
      id: "type",
      accessor: "type",
    },
    {
      Header: "Date Added",
      accessor: "lastAdded",
    },
    {
      Header: "Time to Deploy",
      accessor: "timeToDeploy",
      minWidth: 200,
    },
    {
      Header: "Recurring (MRC)",
      accessor: "monthlyPrice",
      Cell: ({
        row,
        data,
      }: {
        row: RowDataInterface;
        data: ColumnDataInterface[];
      }) => <div>{`£${data[row.id].monthlyPrice.toLocaleString()}`}</div>,
    },
    {
      Header: "Non-Recurring (NRC)",
      accessor: "oneOffPayment",
      Cell: ({
        row,
        data,
      }: {
        row: RowDataInterface;
        data: ColumnDataInterface[];
      }) => <div>{`£${data[row.id].oneOffPayment.toLocaleString()}`}</div>,
    },
    {
      Header: () => <span className="total-col">Total</span>,
      accessor: "total",
      Cell: ({
        row,
        data,
      }: {
        row: RowDataInterface;
        data: ColumnDataInterface[];
      }) => (
        <div className="total-col">
          <b>{`£${(
            data[row.id].monthlyPrice + data[row.id].oneOffPayment
          ).toLocaleString()}`}</b>
        </div>
      ),
    },
    {
      Header: "",
      accessor: "action",
      Cell: ({ row }: { row: RowDataInterfacePortIn }) => (
        <div
          className="dots-container"
          onMouseEnter={hidePreviousContextMenu}
          onMouseLeave={() => setThreeDotsStatus(false)}
        >
          <div
            className={`dots ${threeDotsStatus ? "show" : ""}`}
            onClick={(event) => toggleBasketPortActions(event)}
          >
            <img
              className="three-dots"
              style={{ width: "20px", height: "20px" }}
              src={dots}
            />
          </div>
          <div className={`context`} id="dots-actions">
            <ContextDropDown
              dropItems={[
                {
                  id: "delete",
                  label: "Delete",
                  onClick: () =>
                    deleteRow(
                      row.original.uuid ? row.original.uuid : row.id.toString(),
                    ),
                  icon: "bin",
                },
              ]}
            />
          </div>
        </div>
      ),
      sticky: "right",
      width: 20,
    },
  ];

  const toggleBasketPortActions = (event: any) => {
    event.stopPropagation();
    const contextMenu = event.currentTarget.nextElementSibling;
    contextMenu?.classList.toggle("show");
  };

  const hideCurrentContextMenu = () => {
    const currentContext = document.querySelector(".context.show");
    currentContext?.classList.remove("show");
  };

  const hidePreviousContextMenu = (event: any) => {
    const dotContainerClasses = ["dots-container", "dots", "three-dots"];
    if (dotContainerClasses.includes(event.target.classList[0])) {
      const openContexts = event.currentTarget
        .closest("table")
        .querySelectorAll(".context.show");
      openContexts.forEach((element: any) => {
        if (element !== event.currentTarget) {
          element.classList.remove("show");
        }
      });
    }
  };

  // Deleting row and update the local storage service basket data
  const deleteRow = (id: string) => {
    setSelectedIdForDeletion(id);
    setShowDeleteModal(true);
  };

  const deployAll = () => {
    const selectedPortIds = selectedTableData.map((item: any) => {
      return item.uuid;
    });
    const filteredBasketPortsData = prepTableData.filter((item: any) => {
      if (!selectedPortIds.includes(item.uuid)) {
        return item;
      }
    });
    localStorage.setItem("portsData", JSON.stringify(filteredBasketPortsData));
    setPrepTableData(filteredBasketPortsData);
    dispatch(updateCount(filteredBasketPortsData.length));
    dispatch(updateBasket(filteredBasketPortsData));
    dispatch(updateIsDeploymentRequestEnabled(true));
    switch (selectedTableData[0]?.type) {
      case "Data Centre Connection":
        navigate("/port-b-deployment", {
          state: {
            isDeployAllRequest: true,
            portName: selectedTableData[0]?.portName,
          },
        });
        break;
      case "IP VPN":
        navigate("/ip-vpn-deployment", {
          state: {
            isDeployAllRequest: true,
            IpVpnName: selectedTableData[0]?.portName,
          },
        });
        break;
      case "Cloud Port":
        navigate("/cloud-ports/deployment",
          {
            state: {
              portName: selectedTableData[0]?.portName
            }
          });
        break;
      case "Internet":
        navigate("/internet-deployment",
          {
            state: {
              internetId: selectedTableData[0]?.uuid,
              connectionNameRoute: selectedTableData[0]?.portName
            }
          });
        break;
      default:
        navigate("/port-a-deployment", {
          state: {
            isDeployAllRequest: true,
            selectedPortName: selectedTableData[0]?.portName,
          },
        });
        break;
    }
  };

  const editRow = (id: string) => {
    alert("Editing row :" + id);
  };

  const onDeletePort = (id: string) => {
    setPrepTableData((prepTableData) =>
      prepTableData.filter((data) => data.uuid !== id)

    );
    setShowDeleteModal(false);
    localStorage.setItem("portsData", JSON.stringify(prepTableData.filter((data) => data.uuid !== id)));
  };
  const filteredItemsCount = [...typeFilters, ...dateFilters].length;

  const clearAll = () => {
    setDateFilters([]);
    setTypeFilters([]);
  };

  React.useEffect(() => {
    dispatch(updateCount(prepTableData.length));
  }, [prepTableData]);

  return (
    <section
      className="standard_container_basket"
      onClick={hideCurrentContextMenu}
    >
      <main className="standard_content" data-testid="basket">
        <BasketSummary
          deployAction={deployAll}
          selectedBasketItems={selectedTableData}
        ></BasketSummary>
        <div className="fp-container">
          <div className="fp-row">
            <div className="col-16">
              <Card data-testid="port-type-card">
                <Table
                  tableData={prepTableData}
                  tableColumn={tableColumns}
                  enablePagination={true}
                  enableSorting={true}
                  visibleColumnLimit={8}
                  enableFilters={true}
                  maxColumnCount={12}
                  editItem={editRow}
                  selectMulitiRows
                  onSelectMulitiRows={onSelectMulitiRows}
                  showAdvanceFilter={true}
                  showFilterBar={showFilterBar}
                  setShowFilterBar={(showFilter) => {
                    setShowFilterBar(showFilter);
                  }}
                  searchPlaceholder={"Search"}
                  buttonIconBefore={true}
                  filteredOptions={
                    filteredItemsCount ? filteredItemsCount : undefined
                  }
                  FilterBar={
                    <BasketFilters
                      data={prepTableData}
                      filteredItemsCount={filteredItemsCount}
                      typeFilters={typeFilters}
                      dateFilters={dateFilters}
                      setDateFilters={setDateFilters}
                      setTypeFilters={setTypeFilters}
                      clearFilters={clearAll}
                    />
                  }
                />
              </Card>
            </div>
          </div>
        </div>
        <div className="fp-container">
          <div className="fp-row">
            <div className="actions actions__bottom col-16">
              <div />
            </div>
          </div>
        </div>
      </main>
      {_showDeleteModal && (
        <Modal
          topIcon="info"
          topIconStyle="critical"
          size="md"
          topIconSize="md"
          title="Are you sure you want to delete?"
          message="This item will be deleted immediately. You can't undo this action."
          contentAlign="center"
          actionText="Delete"
          onOk={() => onDeletePort(selectedIdForDeletion)}
          closeModal={!_showDeleteModal}
          onCancel={() => setShowDeleteModal(false)}
          outsideClose={true}
        />
      )}
    </section>
  );
};

export default Basket;
