import React from "react";
import { render } from "@testing-library/react";
import "regenerator-runtime";
import CloudMainHeader from ".";

describe("CloudMainHeader", () => {
  it("renders without errors", () => {
    const { container } = render(<CloudMainHeader />);
    expect(container.getElementsByClassName("cloud-main-header")).toBeTruthy();
  });
});
