import React from "react";
import { BrowserRouter } from "react-router-dom";
import { render, screen } from "@testing-library/react";
import CloudPortConfigWrapper from "./index";
import { Provider } from "react-redux";

import "regenerator-runtime";
import store from "../../../../redux/store";

describe("Cloud Port Configuration Wrapper", () => {
  it("Renders the wapper component", () => {
    render(
      <Provider store={store}>
      <BrowserRouter>
        <CloudPortConfigWrapper />
      </BrowserRouter>
      </Provider>
    );
    expect(screen.getByTestId("cloud_port_config_wrapper")).toBeInTheDocument();
  });
});
