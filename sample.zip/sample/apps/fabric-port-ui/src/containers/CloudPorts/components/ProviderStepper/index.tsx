import React from "react";
import images from "../../../../shared/assets";
import { Card } from "@btdigital/nayan-component-library";
import "./ProviderStepper.scss";

export interface ProviderStepperProps {
  id: number;
  providerName: string;
  providerNameShorthand?: string;
}
const ProviderStepper: React.FC<ProviderStepperProps> = ({
  id,
  providerName,
  providerNameShorthand,
}) => {
  return (
    <>
      <div
        className="provider-stepper-outside-wrapper"
        data-testid="provider-stepper"
      >
        <Card key={id} cardStyle="provider-stepper-card">
          <div className="provider-stepper_wrapper fp-row">
            <section className="step-wrapper col-16 sm:col-8 md:col-8 lg:col-4">
              <div className="main-img-title">
                <h2>STEP 1</h2>
                <img src={images.usersPlus} alt="" srcSet="" />
              </div>
              <div className="step-content">
                <h3 data-testid="shorthand">
                  Prep from{" "}
                  {providerNameShorthand ? providerNameShorthand : providerName}
                </h3>
                <p>
                  Retrieve your <strong>Paring Key</strong> from the{" "}
                  <strong>{providerName} Platform.</strong>
                </p>
              </div>
            </section>

            <section className="step-wrapper col-16 sm:col-8 md:col-8 lg:col-4">
              <div className="main-img-title">
                <h2>STEP 2</h2>
                <img src={images.settings} alt="" srcSet="" />
              </div>
              <div className="step-content">
                <h3>Configure a Cloud Port (Group)</h3>
                <p className="step-2-desc">
                  Validate your{" "}
                  {providerNameShorthand ? providerNameShorthand : providerName}{" "}
                  Pairing Key then fill out the screens (upload a letter of
                  authority if you select a Dedicated connection).
                </p>
                <a>How to configure a Cloud Port &gt;</a>
              </div>
            </section>

            <section className="step-wrapper col-16 sm:col-8 md:col-8 lg:col-4">
              <div className="main-img-title">
                <h2>STEP 3</h2>
                <img src={images.verified} alt="" srcSet="" />
              </div>
              <div className="step-content">
                <h3>
                  Accept Connection in{" "}
                  {providerNameShorthand ? providerNameShorthand : providerName}
                </h3>
                <p className="step-3-desc">
                  Accept the hosted connection in{" "}
                  <strong>{providerName} Platform.</strong>{" "}
                </p>
                <a>Read More &gt;</a>
              </div>
            </section>

            <section className="navigation-section col-16 sm:col-8 md:col-8 lg:col-4">
              <h2>Next</h2>
              <Card cardStyle="navigation-card">
                <h4>You're ready to connect!</h4>
                <div className="content">
                  <p>
                    View how to connect your network service to your BT Cloud
                    Port
                  </p>
                  <img src={images.navigateNext} alt="" srcSet="" />
                </div>
              </Card>
            </section>
          </div>
        </Card>
      </div>
    </>
  );
};

export default ProviderStepper;
