import { Card, Icon, Label } from '@btdigital/nayan-component-library';
import React from 'react';
import './CloudPortCard.scss';


export type CloudPortCardProps = {
    title: string;
    imagePaths?: string[];
    titleBadge?: React.ReactElement;
    bulletPoints: (string | React.ReactElement)[];
    customCardClass?: string;
}

const CloudPortCard: React.FC<CloudPortCardProps> = ({
    title,
    imagePaths = [],
    titleBadge,
    bulletPoints,
    customCardClass
}) => {
    return (
        <Card
            cardStyle={`cloud-port-group-card ${customCardClass}`}>
            <div
                className="images-wrapper"
                data-testid="cloud-port-card-images">
                {
                    imagePaths.map(path => (
                        <img src={path} alt="cloudLightning" key={path} />
                    ))
                }
            </div>
            <div
                className="title-wrapper"
                data-testid="cloud-port-card-title">
                <Label text={title} />
                {titleBadge}
            </div>
            <ul className="bullet-points">
                {
                    bulletPoints.map((bulletPoint, i) => (
                        <li
                            key={`${i} - 1`}
                            data-testid="bullet-point">
                            <div className="bullet-point">
                                <div className="tick-wrapper">
                                    <Icon
                                        size="sm"
                                        title="tick_new"
                                        showOriginal
                                    />
                                </div>
                                {
                                    React.isValidElement(bulletPoint)
                                        ? bulletPoint
                                        : (<span
                                            className="bullet-point-label-span">
                                            {bulletPoint}
                                        </span>)
                                }
                            </div>
                        </li>
                    ))
                }
            </ul>
        </Card >
    )
}

export default CloudPortCard;
