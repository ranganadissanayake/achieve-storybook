import React from "react";
import { useNavigate } from "react-router-dom";
import { Icon, Label, Toggle } from "@btdigital/nayan-component-library";

import "./AddNewCloudPort.scss";
import TagDataLayerService from "../../../../shared/services/TagDatalayer.service";

const AddNewCloudPort: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="add-new-cloud-port" data-testid="add-new-cloud-port">
      <div className="add-new-cloudport-container">
        <div
          className="left-content"
          onClick={() => {
            TagDataLayerService.pushCtaData("Add a New Cloud Port");
            TagDataLayerService.pushPageData("Create Cloud Port", "Validate Pairing Key");
            navigate("/cloud-ports/validate-pairing-key")
          }}
        >
          <Icon title="plus_new" color="#5514B4" showOriginal />
          <Label
            text="Add a New Cloud Port"
            labelTextStyles="add-new-port-label"
            containerStyles="add-new-port-container"
          />
        </div>
        <div className="right-content">
          <Label
            text="Enable Cloud Port group?"
            labelTextStyles="enable-port-group-label"
            containerStyles="enable-port-group-container"
          />
          <Toggle size="md" checked={false} showText={false} />
        </div>
      </div>
    </div>
  );
};

export default AddNewCloudPort;
