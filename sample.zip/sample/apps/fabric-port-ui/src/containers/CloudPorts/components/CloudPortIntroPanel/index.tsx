import { Badge } from '@btdigital/nayan-component-library';
import React from 'react';
import IntroPanel from '../../../../components/IntroPanel';
import images from '../../../../shared/assets';
import {
  CLOUD_PORT_CLOUD_GROUP_BULLETS
} from '../../../../shared/constants';
import CloudPortCard from '../CloudPortCard';
import './CloudPortIntroPanel.scss';

const CloudPortIntroPanel: React.FC = () => {
  return (
    <IntroPanel
      header="Introducing Cloud Ports & Cloud Port Groups"
      showCloseIcon
      showReadMoreButton
      showDontShowAgainButton
      onClose={() => { }}
    >
      <div className="child-space">
        <CloudPortCard
          title="Single Cloud Port"
          imagePaths={[images.cloudLightning]}
          bulletPoints={[
            (<span
              className="bullet-point-label-span"
              key="key1">Single or multiple Partner VLAN attachments connected to the <b>same</b> Edge Availability Domain in the same or multiple locations
            </span>
            ),
            "Customers may desire this for development, non-production or short-lived environment scenarios"
          ]}
          customCardClass="left-card"
        />
        <CloudPortCard
          title="Cloud Port Group"
          imagePaths={[images.cloudLightning, images.cloudLightning]}
          titleBadge={<Badge text="Recommended" customStyle="recommended-badge" />}
          bulletPoints={[(
            <span
              className="bullet-point-label-span"
              key="key1">Two Partner VLAN attachments connected to <b>different</b> Edge Availability Domains in the same location / city
            </span>
          ),
          ...CLOUD_PORT_CLOUD_GROUP_BULLETS]}
          customCardClass="right-card"
        />
      </div>
    </IntroPanel>
  )
}

export default CloudPortIntroPanel;
