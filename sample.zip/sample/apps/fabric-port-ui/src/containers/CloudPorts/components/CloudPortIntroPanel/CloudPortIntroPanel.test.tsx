import React from "react";
import { render } from "@testing-library/react";
import CloudPortIntroPanel from ".";

describe("CloudPortIntroPanel", () => {
    it("renders without errors", () => {
        render(
            <CloudPortIntroPanel />
        )
    });
});