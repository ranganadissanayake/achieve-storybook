import React from "react";
import "./style.scss";
import { Badge, Card } from "@btdigital/nayan-component-library";

export interface ProviderCardProps {
  id: number;
  imageUrl: string;
  providerName: string;
  moreDetails?: string;
  badgeText?: string;
  isProviderSelected?: boolean;
  onclick: (id: string) => void;
}
const ProviderCard: React.FC<ProviderCardProps> = ({
  id,
  imageUrl,
  providerName,
  moreDetails,
  badgeText,
  isProviderSelected,
  onclick,
}) => {
  return (
    <>
      <div
        onClick={() => onclick(providerName)}
        className="provider-card-outside-wrapper"
        data-testid="provider-card"
      >
        <Card
          key={id}
          cardStyle={`provider-card-wrapper ${
            isProviderSelected ? "selected" : ""
          }`}
        >
          <section className="header">
            <img src={imageUrl} alt="" srcSet="" className="header-img" />
            {badgeText && <Badge customStyle="new-badge" text={badgeText} />}
          </section>
          <section
            className={`content ${
              isProviderSelected ? "selected-content" : ""
            }`}
          >
            <h3>{providerName}</h3>
            {moreDetails && <p>{moreDetails}</p>}
          </section>
        </Card>
      </div>
    </>
  );
};

export default ProviderCard;
