import React from "react";
import { render, screen } from "@testing-library/react";
import "regenerator-runtime";
import ProviderStepper from ".";

describe("ProviderStepper", () => {
  it("renders without errors", () => {
    render(<ProviderStepper id={0} providerName={"GCP"} />);
    const providerStepper = screen.getByTestId("provider-stepper");
    expect(providerStepper).toBeInTheDocument();
  });
  it("renders shorthand format", () => {
    render(<ProviderStepper id={0} providerName={"Google Cloud"} providerNameShorthand="gcp"/>);
    const providerStepper = screen.getByTestId("shorthand");
    expect(providerStepper).toBeInTheDocument();
  });
});
