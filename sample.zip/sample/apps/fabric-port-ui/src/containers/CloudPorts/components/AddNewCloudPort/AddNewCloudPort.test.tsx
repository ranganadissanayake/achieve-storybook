import React from "react";
import { render, fireEvent } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";

import AddNewCloudPort from ".";

describe("AddNewCloudPort", () => {
  it("renders without errors", () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <AddNewCloudPort />
      </BrowserRouter>
    );
    expect(getByTestId("add-new-cloud-port")).toBeInTheDocument();
  });

  it("should able to click on Add a New Cloud Port", () => {
    const { getByTestId, getByText } = render(
      <BrowserRouter>
        <AddNewCloudPort />
      </BrowserRouter>
    );
    fireEvent.click(getByText("Add a New Cloud Port"));
    expect(getByTestId("add-new-cloud-port")).toBeInTheDocument();
  });
});
