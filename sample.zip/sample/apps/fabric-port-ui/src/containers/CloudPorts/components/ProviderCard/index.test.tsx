import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import "regenerator-runtime";
import ProviderCard from ".";

describe("ProviderCard", () => {
  it("renders without errors", () => {
    render(
      <ProviderCard
        id={0}
        imageUrl={"./gcp.svg"}
        providerName={"GCP"}
        onclick={jest.fn()}
      />
    );
    const providerCard = screen.getByTestId("provider-card");
    expect(providerCard).toBeInTheDocument();
  });

  it("renders with badge", () => {
    render(
      <ProviderCard
        id={0}
        imageUrl={"./gcp.svg"}
        providerName={"GCP"}
        onclick={jest.fn()}
        badgeText="New"
      />
    );
    const providerCard = screen.getByText("New");
    expect(providerCard).toBeInTheDocument();
  });
  it("renders with badge", () => {
    const { container } = render(
      <ProviderCard
        id={0}
        imageUrl={"./gcp.svg"}
        providerName={"GCP"}
        onclick={jest.fn()}
        badgeText="New"
        isProviderSelected={true}
      />
    );
    expect(container.getElementsByClassName("selected-content")).toBeTruthy();
  });
  it("trigger onclick ", async () => {
    const onClick = jest.fn();
    render(
      <ProviderCard
        id={0}
        imageUrl={"./gcp.svg"}
        providerName={"GCP"}
        onclick={onClick}
      />
    );
    const providerCard = screen.getByTestId("provider-card");
    fireEvent.click(providerCard);
    expect(onClick).toHaveBeenCalled()
  });
});
