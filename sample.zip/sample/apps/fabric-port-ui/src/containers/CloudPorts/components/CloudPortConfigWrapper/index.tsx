import React from "react";
import { useNavigate } from "react-router-dom";

import { Button, Crumb, Modal } from "@btdigital/nayan-component-library";
import PageWrap from "../../../../components/PageWrap";

import "./CloudPortConfigWrapper.scss";
import { useDispatch } from "react-redux";
import { resetSlice } from "../../../../redux/cloudPortSlice";

export interface CloudPortConfigWrapperProps extends React.PropsWithChildren {
  className?: string;
  currentStep?: number;
  showButtons?: boolean;
  handleNext?: VoidFunction;
  handleBack?: VoidFunction;
}

const CloudPortConfigWrapper: React.FC<CloudPortConfigWrapperProps> = ({
  currentStep = 1,
  className = "",
  children,
  showButtons = true,
  handleNext,
  handleBack,
}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [_showModal, setShowModal] = React.useState(false);

  const _onModalOk = () => {
    dispatch(resetSlice());
    navigate("/create-new-port");
    setShowModal(false);
  };

  const handleBreadcrumbRouting = (): Crumb[] => {
    const breadcrumbItems: Crumb[] = [
      {
        name: "Create Connection",
        onClick: () => {
          setShowModal(true);
        },
      },
      {
        name: "Create a Cloud Port",
      },
    ];

    return breadcrumbItems;
  };

  return (
    <section className="config_wrapper_container">
      <PageWrap
        className={className}
        steps={[
          "Validate GCP Pairing Key",
          "Choose Location",
          "Configuration",
          "Summary",
        ]}
        handleBreadcrumbRouting={handleBreadcrumbRouting}
        currentStep={currentStep}
        testId="cloud_port_config_wrapper"
      >
        {children}
        {showButtons && (
          <div className="buttons_container">
            <Button
              label="Back"
              variant="link"
              onPress={handleBack}
              dataTestId="back_btn"
              className="btn"
            />
            <Button
              label="Continue"
              variant="gradient"
              onPress={handleNext}
              dataTestId="continue_btn"
            />
          </div>
        )}
      </PageWrap>
      <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        topIconSize="md"
        title="Leave without saving changes"
        complementaryMessage="Are you sure you want to leave this page? Your setup information will be lost."
        contentAlign="center"
        actionText="Leave"
        onOk={_onModalOk}
        closeModal={!_showModal}
        onCancel={() => setShowModal(false)}
      />
    </section>
  );
};

export default CloudPortConfigWrapper;
