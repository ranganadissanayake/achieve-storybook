import { render } from "@testing-library/react";
import CloudPortCard from ".";
import React from "react";
import images from '../../../../shared/assets';


describe("CloudPortCard", () => {
    it("renders without errors", () => {
        const { getByTestId, getAllByRole } = render(
            <CloudPortCard
                title="Test Title"
                bulletPoints={["Test bullet"]}
                imagePaths={[images.cloudLightning]}
            />
        );
        expect(getAllByRole("img").length).toBeGreaterThan(0);
        expect(getByTestId("cloud-port-card-title").textContent).toBe("Test Title");
    });

    it("should renders title of the card with Test Title", () => {
        const { getByTestId } = render(
            <CloudPortCard
                title="Test Title"
                bulletPoints={["Test bullet"]}
                imagePaths={[images.cloudLightning]}
            />
        );
        expect(getByTestId("cloud-port-card-title").textContent).toBe("Test Title");
    });

    it("should not render images if no image path supplied", () => {
        const { queryAllByAltText } = render(
            <CloudPortCard
                title="Test Title"
                bulletPoints={["Test bullet"]}
            />
        );
        expect(queryAllByAltText("cloudLightning").length).toBe(0);
    });

    it("should render bullet points", () => {
        const { getAllByTestId } = render(
            <CloudPortCard
                title="Test Title"
                bulletPoints={["Test bullet"]}
                imagePaths={[images.cloudLightning]}
            />
        );
        expect(getAllByTestId("bullet-point").length).toBeGreaterThan(0);
    });
});