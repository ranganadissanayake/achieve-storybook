import React from "react";
import "./CloudMainHeader.scss";
import { Label } from "@btdigital/nayan-component-library";

const CloudMainHeader: React.FC = () => {
  return (
    <Label
      data-testid="main-header-cloud"
      containerStyles="cloud-main-header"
      text="Choose your Cloud Provider"
      helperTextStyles="cloud-main-header-helper"
      helper="BT Cloud Ports will provide private connectivity to Hyperscaler Private Clouds Providers and Wider BT Portfolio."
    />
  );
};

export default CloudMainHeader;
