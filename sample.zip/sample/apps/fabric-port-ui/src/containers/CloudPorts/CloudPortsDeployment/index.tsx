import { Button, useToast } from "@btdigital/nayan-component-library";
import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import DeploymentStatusCard from "./../../../components/DeploymentStatusCard";
import PageWrap from "./../../../components/PageWrap";
import images from "./../../../shared/assets";
import { BT_NOTIFICATIONS, TOAST_TIMEOUT } from "./../../../shared/constants";
import { buildNotification } from "./../../../shared/constants/toastBuilder";
import useLocalStorage from "./../../../shared/hooks/useLocalStorage";
import { DeploymentStatus } from "./../../../shared/types";
import "./CloudPortsDeployment.scss";
import TagDataLayerService from "./../../../shared/services/TagDatalayer.service";

const CloudPortDeployment = () => {
  const navigate = useNavigate();
  const toast = useToast();
  const { state } = useLocation();
  const { portName = "" } = state;

  const [deploymentStatus] = useState<DeploymentStatus>(
    DeploymentStatus.awaited
  );

  const [notificationStorage, setNotificationStorage] = useLocalStorage(BT_NOTIFICATIONS, []);

  const makeApiRequest = React.useCallback(async () => {
    // TODO: handle API call in a different story
    const deployInternetNotification = buildNotification(
      {
        type: "info",
        title: "Cloud Port is being deployed",
        description: (
          <p className="content">
            <b>
              {portName}
            </b>{" "}
            is being deployed and will take approximately 5 minutes
          </p>
        ),
      },
      "Cloudport"
    );
    toast.addToast(deployInternetNotification.view(), {
      position: "top",
      timeout: TOAST_TIMEOUT,
      deleteSideEffect: () => {
        deployInternetNotification.save({
          notificationStorage,
          setNotificationStorage,
        });
      },
    });
    setTimeout(() => {
      const deployInternetSuccessNotification = buildNotification(
        {
          type: "success",
          title: "Cloud Port has been successfully deployed",
          description: (
            <p className="content">
              <b>
                {portName}
              </b>{" "}
              was successfully deployed
            </p>
          ),
        },
        "Cloudport"
      );
      toast.addToast(deployInternetSuccessNotification.view(), {
        position: "top",
        timeout: TOAST_TIMEOUT,
        deleteSideEffect: () => {
          deployInternetNotification.save({
            notificationStorage,
            setNotificationStorage,
          });
        },
      });
    }, 30000);
  }, []);

  React.useEffect(() => {
    makeApiRequest();

  }, []);

  const _onBackToHome = () => {
    TagDataLayerService.pushCtaData("Back to Dashboard");
    TagDataLayerService.pushPageData("Dashboard");
    navigate("/");
  };

  const renderCurrentStatus = React.useCallback(() => {
    switch (deploymentStatus) {
      case DeploymentStatus.failed:
        return (
          <DeploymentStatusCard
            statusImageURL={images.portADeploymentFailed}
            imageWidth="64px"
            imageHeight="64px"
            containerClassName="failed-container"
            title="Sorry, we can't connect your port :("
            description={[]}
            leftButtonTitle="Try Again"
            leftButtonClassName="try-again-button"
            rightButtonTitle="Save it to basket"
            rightButtonClassName="save-it-button"
            rightButtonClick={()=>{}}
          />
        );
      case DeploymentStatus.awaited:
        return (
          <DeploymentStatusCard
            statusImageURL={images.cloudPort}
            imageWidth="80px"
            imageHeight="80px"
            containerClassName="awaited-container"
            title="We're working on your request :)"
            description={[
              "We will be in touch as soon as deployment is completed.",
              "You can now leave this page",
            ]}
            leftButtonTitle="Assign it to a Group"
            leftButtonClassName="assign-it-to-group"
            leftButtonClick={() => TagDataLayerService.pushCtaData("Assign it to a Group")}
            rightButtonTitle="View in Cloud Port Inventory"
            rightButtonClassName="view-port-button"
            rightButtonClick={() => {
              TagDataLayerService.pushCtaData("View in Cloud Port Inventory");
              TagDataLayerService.pushPageData("Cloud Port Inventory");
              navigate("/cloud-port-inventory")
            }}
          />
        );
      default:
        return null;
    }
  }, [deploymentStatus]);

  return (
    <PageWrap
      className="cloudport-deployment-container"
      testId="cloudport-deployment-container"
    >
      <div className="fp-row deployment-screen-wrapper">
        <div className="col-16">
          <div className="deployment-status-container">
            <div>{renderCurrentStatus()}</div>
            <div className="back-to-dash">
              <Button
                variant="link"
                label="Back to Dashboard"
                iconBefore={true}
                className="back-to-home-button"
                iconTitle="previous_arrow"
                onPress={_onBackToHome}
              />
            </div>
          </div>
        </div>
      </div>
    </PageWrap>
  );
};

export default CloudPortDeployment;
