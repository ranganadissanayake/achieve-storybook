import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { BrowserRouter as Router } from "react-router-dom";
import React from "react";
import CloudPortDeployment from ".";
import { Provider } from "react-redux";
import store from "../../../redux/store";

const mockNavigate = jest.fn();
jest.mock("react-router-dom", () => ({
    ...jest.requireActual("react-router-dom"),
    useNavigate: () => mockNavigate,
    useLocation: () => ({
        state: { portName: "Sample port" }
    })
}));



describe("CloudPortDeployment", () => {
    test("renders the DeploymentAwaited component", () => {
        render(
            <Provider store={store}>
                <Router>
                    <CloudPortDeployment />
                </Router>
            </Provider>
        );
        expect(screen.getByTestId("cloudport-deployment-container")).toBeInTheDocument();
    });

    it("navigates to home page when 'Back to home' button is clicked", async () => {
        const { findAllByText } = render(
            <Provider store={store}>
                <Router>
                    <CloudPortDeployment />
                </Router>
            </Provider>
        );
        const link = await findAllByText("Back to Dashboard");
        fireEvent.click(link[0]);
        await waitFor(() => {
            expect(mockNavigate).toHaveBeenCalledTimes(1)
        });
    });
});