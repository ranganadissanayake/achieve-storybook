import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import "regenerator-runtime";
import ChooseAProvider from ".";

describe("ChooseAProvider", () => {
  it("renders without errors", () => {
    const { container } = render(
      <BrowserRouter>
        <ChooseAProvider />
      </BrowserRouter>
    );
    expect(
      container.getElementsByClassName("choose-a-provider-wrapper")
    ).toBeTruthy();
  });

  it("trigger handleProviderClick ", async () => {
    render(
      <BrowserRouter>
        <ChooseAProvider />
      </BrowserRouter>
    );
    const providers = screen.getByText("Google Cloud");
    fireEvent.click(providers);
  });

  it("trigger handle back button ", async () => {
    render(
      <BrowserRouter>
        <ChooseAProvider />
      </BrowserRouter>
    );
    const back = screen.getByTestId("back_btn");
    fireEvent.click(back);
  });

  it("trigger handle back button ", async () => {
    render(
      <BrowserRouter>
        <ChooseAProvider />
      </BrowserRouter>
    );
    const continueButton = screen.getByTestId("continue_button");
    fireEvent.click(continueButton);
  });
});
