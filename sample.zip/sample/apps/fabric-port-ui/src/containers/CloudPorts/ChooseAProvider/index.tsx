import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@btdigital/nayan-component-library";

import ProviderCard, { ProviderCardProps } from "../components/ProviderCard";
import CloudMainHeader from "../components/CloudMainHeader";
import ProviderStepper from "../components/ProviderStepper";
import { PROVIDERS_SET, PROVIDER_CONFIG } from "../../../shared/constants";

import "./ChooseAProvider.scss";
import TagDataLayerService from "../../../shared/services/TagDatalayer.service";

export interface ChooseAProviderProps { }

const ChooseAProvider: React.FC<ChooseAProviderProps> = () => {
  const navigate = useNavigate();

  const [selectedProviderId, setSelectedProviderId] = React.useState<number>(1);

  const handleProviderClick = (provider: ProviderCardProps) => {
    setSelectedProviderId(provider.id);
  };
  return (
    <>
      <div className="fp-container choose-a-provider-wrapper">
        <div className="fp-row">
          <div className="col-16">
            <CloudMainHeader />
          </div>
        </div>
        <div className="fp-row">
          {PROVIDERS_SET.map((provider) => (
            <div
              className="col-16 sm:col-8 md:col-8 lg:col-4"
              key={provider.id}
            >
              <ProviderCard
                id={provider.id}
                imageUrl={provider.imageUrl}
                providerName={provider.providerName} //TODO: add prop for bold number
                moreDetails={provider.moreDetails}
                badgeText={provider.badgeText}
                isProviderSelected={selectedProviderId === provider.id}
                onclick={() => handleProviderClick(provider)}
              />
            </div>
          ))}
        </div>
        <div className="fp-row">
          {PROVIDER_CONFIG.map(
            (config) =>
              config.id === selectedProviderId && (
                <div className="col-16" key={config.id}>
                  <ProviderStepper
                    key={config.id}
                    id={config.id}
                    providerName={config.providerName}
                    providerNameShorthand={config.providerNameShorthand}
                  />
                </div>
              )
          )}
        </div>
        <div className="fp-row action-area">
          <div className="button-row">
            <Button
              label="Back"
              variant="link"
              dataTestId="back_btn"
              onPress={() => {
                TagDataLayerService.pushCtaData("Back");
                TagDataLayerService.pushPageData("Create a new Port");
                navigate("/create-new-port")
              }}
              className="back-button"
            />
            <Button
              label="Continue"
              variant="gradient"
              dataTestId="continue_button"
              onPress={
                () => {
                  TagDataLayerService.pushCtaData("Continue");
                  TagDataLayerService.pushPageData("Create Cloud Port", "Cloud Port Configuration");
                  navigate("/cloud-ports/configuration")
                }}
              className="next-button"
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default ChooseAProvider;
