import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import * as router from "react-router";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import ValidatePairingKey from "./index";
import store from "../../../redux/store";
import { AppProvider } from "../../../context/AppContext";
import { ApiProvider } from "../../../shared/helpers";

const navigate = jest.fn();

jest.mock("../../../authConfig", () => ({
  getAccessToken: jest.fn(),
}));

describe("CreateNewIpWrapper", () => {
  beforeEach(() => {
    jest.spyOn(router, "useNavigate").mockImplementation(() => navigate);

    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider>
            <AppProvider>
              <ValidatePairingKey />
            </AppProvider>
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );
  });

  it("renders component title", () => {
    expect(screen.getByText("Validate Pairing Key")).toBeInTheDocument();
  });

  it("renders google cloud logo", () => {
    expect(screen.getByAltText("Google Cloud")).toBeInTheDocument();
  });

  it("renders input componet", () => {
    expect(screen.getByText("Google Partner Pairing Key")).toBeInTheDocument();
    expect(
      screen.getByText(
        "E.g. 7e51371e-72a3-40b5-b844-2e3efefaee59/us-central1/2"
      )
    ).toBeInTheDocument();
  });

  it("renders need help card", () => {
    expect(screen.getByText("Need Help?")).toBeInTheDocument();
  });
  it("handles input with an invalid pairing key", async () => {
    const input = screen.getByPlaceholderText(
      "00000000-0000-0000-0000-000000000000/region/0"
    );

    fireEvent.change(input, { target: { value: "invalid_key" } });
    fireEvent.blur(input);

    expect(screen.getByAltText("Loading")).toBeInTheDocument();
  });

  it("handles back click", () => {
    const backBtn = screen.getByText("Back");
    fireEvent.click(backBtn);
  });

  test("shows the popup when click on navigation", async () => {
    const input = screen.getByPlaceholderText(
      "00000000-0000-0000-0000-000000000000/region/0"
    );
    fireEvent.change(input, { target: { value: "test" } });
    fireEvent.blur(input);
    await new Promise((r) => setTimeout(r, 3000));
    const continueBtn = screen.getByText("Continue");
    fireEvent.click(continueBtn);
    setTimeout(() => {
      expect(navigate).toHaveBeenCalledWith("/cloud-ports/select-location");
    }, 100);
  });

  test("shows the popup when click on navigation", () => {
    fireEvent.click(screen.getByText("Create Connection"));
    expect(screen.getByText("Leave without saving changes")).toBeVisible();
  });

  test("should show error if continue without key", async () => {
    const input = screen.getByPlaceholderText(
      "00000000-0000-0000-0000-000000000000/region/0"
    );
    fireEvent.change(input, { target: { value: "" } });
    fireEvent.blur(input);
    await new Promise((r) => setTimeout(r, 3000));
    const continueBtn = screen.getByText("Continue");
    fireEvent.click(continueBtn);
    expect(
      screen.getByText("Please input a pairing key to proceed")
    ).toBeVisible();
  });

  test("should not show error if valid key", () => {
    const input = screen.getByPlaceholderText(
      "00000000-0000-0000-0000-000000000000/region/0"
    );
    fireEvent.change(input, { target: { value: "test" } });
    fireEvent.blur(input);

    setTimeout(() => {
      expect(screen.getByText("Invalid Service Key")).not.toBeVisible();
    }, 5000);
  });

  it("handles input with an invalid pairing key", async () => {
    const input = screen.getByPlaceholderText(
      "00000000-0000-0000-0000-000000000000/region/0"
    );

    fireEvent.change(input, { target: { value: "wrong" } });
    fireEvent.blur(input);
    await new Promise((r) => setTimeout(r, 2000));
    setTimeout(() => {
      expect(screen.getByText("Invalid Service Key")).toBeInTheDocument();
    }, 10000);
  });

  test("shows the popup when click on navigation or try to cancel", async () => {
    const mockcancelNavigation = jest.fn();
    const mockShowModal = jest.fn();
    jest.mock("../../../shared/hooks/useDetectNavigationChange", () => ({
      useDetectNavigationChange: jest.fn(() => [
        true,
        jest.fn(),
        mockcancelNavigation,
      ]),
    }));

    jest.mock("../../../shared/hooks/useAppContext", () => ({
      useAppContext: () =>
        jest.fn(() => ({
          showModal: mockShowModal,
        })),
    }));

    const input = screen.getByPlaceholderText(
      "00000000-0000-0000-0000-000000000000/region/0"
    );

    fireEvent.change(input, { target: { value: "test" } });
    fireEvent.blur(input);
    await new Promise((r) => setTimeout(r, 2000));

    fireEvent.click(screen.getByText("Create Connection"));
    expect(screen.getByTestId("modal")).not.toHaveClass("close");
  });
});
