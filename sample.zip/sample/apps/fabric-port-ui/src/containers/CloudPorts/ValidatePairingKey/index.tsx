import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import { Card, Icon, Input, Label } from "@btdigital/nayan-component-library";

import CloudPortConfigWrapper from "../components/CloudPortConfigWrapper";
import images from "../../../shared/assets";
import {
  selectPairingKey,
  updatePairingKey,
} from "../../../redux/cloudPortSlice";

import "./ValidatePairingKey.scss";
import TagDataLayerService from "../../../shared/services/TagDatalayer.service";
import useAppContext from "../../../shared/hooks/useAppContext";
import useDetectNavigationChange from "../../../shared/hooks/useDetectNavigationChange";

const ValidatePairingKey = () => {
  const navigate = useNavigate();
  const _dispatch = useDispatch();

  const pairingKey = useSelector(selectPairingKey);

  const [_pairingKey, setPairingKey] = React.useState(pairingKey ?? "");
  const [_verifying, setVeriflying] = React.useState(false);
  const [_isValidKey, setIsValidKey] = React.useState(pairingKey !== "");
  const [_isInvalidKey, setIsInvalidKey] = React.useState(false);
  const [_displayError, setDisplayError] = React.useState(false);
  const [showModalTrigger, setShowModalTrigger] = React.useState(false);
  const [_canContinue,setCanContinue] = React.useState(false);

  const [showPrompt, confirmNavigation, cancelNavigation] =
    useDetectNavigationChange(showModalTrigger);

  const { showModal } = useAppContext();

  const handleShowModal = () => {
    showModal({
      onOk: confirmNavigation,
      onCancel: cancelNavigation,
    });
  };

  useEffect(() => {
    if (showPrompt) {
      handleShowModal();
    }
  }, [showPrompt, confirmNavigation, cancelNavigation]);

  useEffect(()=>{
    if(_canContinue){
      navigate("/cloud-ports/select-location");
    }
  },[_canContinue])

  const _onNextClick = () => {
    if (_isValidKey) {
      setShowModalTrigger(false);
      _dispatch(updatePairingKey(_pairingKey));
      TagDataLayerService.pushCtaData("Continue");
      TagDataLayerService.pushPageData("Create Cloud Port", "Choose Location");
      setCanContinue(true)
    } else if (_pairingKey === "") {
      setDisplayError(true);
    }
  };

  const showModalPopup = () => {
    setShowModalTrigger(true);
  };

  const _onBackClick = () => {
    _dispatch(updatePairingKey(_pairingKey));
    TagDataLayerService.pushCtaData("Back");
    TagDataLayerService.pushPageData(
      "Create Cloud Port",
      "Cloud Port Configuration"
    );
    navigate("/cloud-ports/configuration");
  };

  const _onBlur = () => {
    if (_pairingKey !== "") {
      showModalPopup();
      setVeriflying(true);
    }
  };

  const _resetStates = () => {
    setIsValidKey(false);
    setIsInvalidKey(false);
    setDisplayError(false);
  };

  React.useEffect(() => {
    let timer: NodeJS.Timeout;
    if (_pairingKey !== "" && _verifying) {
      timer = setTimeout(() => {
        if (_pairingKey === "wrong") {
          setIsInvalidKey(true);
        } else {
          setIsValidKey(true);
        }
        setVeriflying(false);
      }, 2000);
    } else if (_pairingKey === "") {
      setIsValidKey(false);
    }

    return () => clearTimeout(timer);
  }, [_pairingKey, _verifying]);

  return (
    <CloudPortConfigWrapper
      currentStep={1}
      handleNext={_onNextClick}
      handleBack={_onBackClick}
    >
      <section className="cloud_port_container">
        <Label text="Validate Pairing Key" containerStyles="title_container" />

        <main className="fp-row cloud_port_main">
          <div className="col-16 xl:col-8 sm:col-8 md:col-8 mb-32">
            <Card width="100%" cardStyle="pairing_key_card google_cloud_card">
              <img
                src={images.googleCloud}
                alt="Google Cloud"
                srcSet=""
                width="262"
                height="60"
                className="google_cloud_img"
              />
              <div className="pairing_key_input">
                <div className="loader_container">
                  {_verifying && (
                    <img
                      src={images.loader}
                      alt="Loading"
                      srcSet=""
                      style={{ width: "32px", height: "32px" }}
                      className="loader"
                    />
                  )}
                  <Input
                    label="Google Partner Pairing Key"
                    labelSize="sm"
                    placeholder="00000000-0000-0000-0000-000000000000/region/0"
                    onChange={(val) => {
                      setPairingKey(val);
                      _resetStates();
                    }}
                    onBlur={_onBlur}
                    state={
                      _verifying
                        ? "disabled"
                        : _displayError || _isInvalidKey
                        ? "error"
                        : "default"
                    }
                    errorMessage={
                      _displayError
                        ? "Please input a pairing key to proceed"
                        : "Invalid Service Key"
                    }
                    errorMessageSize="sm"
                    showErrorIcon={false}
                    value={pairingKey}
                  />
                </div>
                <div className="input_helper">
                  {_isValidKey && <Icon title="tick_alt_2px" color="#088003" />}
                  <Label
                    size="sm"
                    labelTextStyles="labet_text"
                    helper={
                      _verifying
                        ? "Verifying Service Key"
                        : _isValidKey
                        ? "Valid Service Key"
                        : _isInvalidKey || _displayError
                        ? ""
                        : "E.g. 7e51371e-72a3-40b5-b844-2e3efefaee59/us-central1/2"
                    }
                    helperTextStyles={`input_example ${
                      _verifying ? "verifying" : _isValidKey ? "valid_key" : ""
                    }`}
                  />
                </div>
              </div>
            </Card>
          </div>

          <div className="col-16 xl:col-8 sm:col-8 md:col-8 mb-32">
            <Card
              width="100%"
              cardStyle="pairing_key_card google_cloud_card help_card"
            >
              <Label text="Need Help?" labelTextStyles="need_help" />
              <label className="help_description">
                Learn more about how to connect Google Cloud from our BT Global
                Fabric <a className="help_link">HelpHub</a>.
              </label>
              <div className="help_items">
                <div className="help_item">
                  <img
                    src={images.location}
                    alt="location"
                    srcSet=""
                    width="32"
                    height="32"
                    color="#000000"
                  />
                  {/* <Icon title="location" size="lg" /> */}
                  <label className="item_title">
                    <span className="digit">220</span> Locations
                  </label>
                  <Label
                    helper="Select from 220 global Google data centres"
                    size="xs"
                    helperTextStyles="item_description"
                  />
                  <label className="help_cta">View all locations</label>
                </div>

                <div className="help_item">
                  <img
                    src={images.scale}
                    alt="scale"
                    srcSet=""
                    width="32"
                    height="32"
                    color="#000000"
                  />
                  {/* <Icon title="location" size="lg" /> */}
                  <label className="item_title">
                    <span className="digit">3</span> Resilience Type
                  </label>
                  <Label
                    helper="GCP resilience is not mandatory"
                    size="xs"
                    helperTextStyles="item_description"
                  />
                  <label className="help_cta">More info</label>
                </div>
                <div className="help_item">
                  <img
                    src={images.speedometer}
                    alt="speedmeter"
                    srcSet=""
                    width="32"
                    height="32"
                    color="#000000"
                  />
                  {/* <Icon title="location" size="lg" /> */}
                  <label className="item_title">
                    <span className="digit">50</span> Gbps
                  </label>
                  <Label
                    helper="GCP supports up to 50 Gbps speed"
                    size="xs"
                    helperTextStyles="item_description"
                  />
                  <label className="help_cta">More info</label>
                </div>
              </div>
            </Card>
          </div>
        </main>
      </section>
    </CloudPortConfigWrapper>
  );
};

export default ValidatePairingKey;
