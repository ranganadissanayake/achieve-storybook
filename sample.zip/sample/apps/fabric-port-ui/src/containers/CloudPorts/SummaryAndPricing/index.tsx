import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import dayjs from "dayjs";

import {
  Badge,
  Button,
  Card,
  Divider,
  Icon,
  Label,
} from "@btdigital/nayan-component-library";

import CloudPortConfigWrapper from "../components/CloudPortConfigWrapper";
import {
  resetSlice,
  selectCloudPortConfig,
  selectCloudPortLocation,
} from "../../../redux/cloudPortSlice";
import { updateCount } from "../../../redux/basketSlice";
import { dataMapper } from "../../../shared/utils";
import { Basket } from "../../../shared/types";
import logo1 from "../../../shared/assets/images/client-logo-1.png";
import images from "../../../shared/assets";
import TagDataLayerService from "../../../shared/services/TagDatalayer.service";
import GFLoader from "../../../components/GFLoader";
import GFTerms from "../../../components/GFTerms";

import "../../CreatePortOnly/CreatePortOnly.scss";
import "../ValidatePairingKey/ValidatePairingKey.scss";
import "./SummaryAndPricing.scss";

const SummaryAndPricing = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { state } = useLocation();
  const { isMapSelection } = state;

  const locationData = useSelector(selectCloudPortLocation);
  const configData = useSelector(selectCloudPortConfig);

  const [_addedToBasket, setAddedToBasket] = React.useState(false);
  const [_showPricing, setShowPricing] = React.useState(false);
  const [_showAdvancedSettings, setShowAdvancedSettings] = React.useState(false);

  const handleCheckboxChange = () => {
    setIsCheckboxChecked(true);
  };

  const _addToBasket = () => {
    TagDataLayerService.pushCtaData("Add to Basket");
    const portData = {
      uuid: uuidv4(),
      portName: configData.portName,
      country: locationData.country,
      lastAdded: dayjs(Date.now()).format("DD/MM/YYYY"),
      portSpeed: configData.portSpeed,
      logoURL: logo1,
      monthlyPrice: Number("00.00"),
      oneOffPayment: Number("00.00"),
      type: "Cloud Port",
      location: locationData.location,
      timeToDeploy: "Immediate deploy",
    };

    let ports: Basket[] = [];
    if (localStorage.portsData) {
      ports = JSON.parse(localStorage.portsData);
    }

    ports = [...ports, portData];
    localStorage.portsData = JSON.stringify(ports);
    dispatch(updateCount(ports.length));
    setAddedToBasket(true);
  };

  const _deployPort = () => {
    if (isCheckboxChecked) {
      const portName = configData.portName;
      dispatch(resetSlice());
      TagDataLayerService.pushCtaData("Order");
      TagDataLayerService.pushPageData("Create Cloud Port", "Cloud Port deployment");
      navigate("/cloud-ports/deployment", { state: { portName: portName } });
    }
  };

  const loader = (
    <img
      src={images.loader}
      alt="Loading"
      srcSet=""
      width="32"
      height="32"
      className="loader"
    />
  );

  React.useEffect(() => {
    setTimeout(() => {
      setShowPricing(true);
    }, 4000);
  }, []);

  const _onNavigateToBasket = () => {
    dispatch(resetSlice());
    navigate("/basket");
  };
  const [isCheckboxChecked, setIsCheckboxChecked] = useState(false);

  return (
    <CloudPortConfigWrapper
      currentStep={4}
      showButtons={false}
      className="cloud_port_container summary_container summary_and_pricing_container"
    >
      {
        !_showPricing ?
          (
            <GFLoader />
          )
          :
          (
      <main
        className="fp-row summary_content cloud_port_main summary_and_pricing_content"
        data-testId="summary_and_pricing"
      >
        <div className="col-16 xl:col-8 sm:col-8 md:col-8 mb-32">
          <Card width="100%" height="100%">
            <div className="card_header summary_alignment">
              <Label text="Summary" />
              <Button
                onPress={() => {
                  TagDataLayerService.pushCtaData("Edit");
                  TagDataLayerService.pushPageData("Create Cloud Port", "Specify your site and required speed");
                  navigate("/cloud-ports/single-gcp-config", { state: { isMapSelection: isMapSelection } })
                }}
                label="Edit"
                variant="link"
                className="edit_button summary_btn"
                dataTestId="edit_btn"
              />
            </div>
            <Divider margin="xxl" className="summary_divider" />
            <div className="summary_alignment">
              <Label
                text="Cloud Port"
                size="sm"
                labelTextStyles="summary_subtitle"
              />
              <Badge text="Non Diverse" customStyle="complete-badge" />
            </div>
            <section className="summary_details">
              <div className="summary_alignment">
                <label className="summary_text_key">Name</label>
                <label className="summary_text_value">
                  {configData.portName}
                </label>
              </div>
              <div className="summary_alignment">
                <label className="summary_text_key">
                  Cloud Service Provider
                </label>
                <label className="summary_text_value">
                  Google Cloud Platform
                </label>
              </div>
              <div className="summary_alignment">
                <label className="summary_text_key">Country</label>
                <label className="summary_text_value">
                  {locationData.country}
                </label>
              </div>
              <div className="summary_alignment">
                <label className="summary_text_key">Metro</label>
                <label className="summary_text_value">
                  {locationData.metro}
                </label>
              </div>
              <div className="summary_alignment">
                <label className="summary_text_key">Location</label>
                <label className="summary_text_value">
                  {locationData.location}
                </label>
              </div>
              <div className="summary_alignment">
                <label className="summary_text_key">Zone</label>
                <label className="summary_text_value">
                  {locationData.zone}
                </label>
              </div>
              <div className="summary_alignment">
                <label className="summary_text_key">Speed</label>
                <label className="summary_text_value">
                  {dataMapper(configData.portSpeed.toString() || 0)}
                </label>
              </div>
              <div className="summary_alignment">
                <Button
                  className="advanced_settings"
                  iconSize="sm"
                  iconTitle={_showAdvancedSettings ? "chevron_up_2px" : "chevron_down_2px"}
                  label="Advanced Settings"
                  onPress={() => setShowAdvancedSettings((prev) => !prev)}
                  variant="link"
                  dataTestId="advanced_setting_btn"
                />
              </div>
              {
                _showAdvancedSettings && 
                <div className="summary_alignment">
                  <label className="summary_text_key">Standard MTU</label>
                  <label className="summary_text_value">{configData.mtuSize}</label>
                </div>
              }
            </section>
          </Card>
        </div>
        <div className="col-16 xl:col-8 sm:col-8 md:col-8 mb-32">
          <Card width="100%" height="100%">
            <div className="card_header summary_alignment">
              <Label text="Price" />
              <span className="item_number">1 item</span>
            </div>
            <Divider margin="xxl" className="summary_divider" />
            <Label text="Port" size="sm" />
            <section className="summary_details">
              <div className="summary_alignment price_item">
                <label className="summary_text_value price_text_key">
                  {configData.portName}
                </label>
                {_showPricing ? (
                  <label className="price_text_value">
                    {`£00.00`}/<span className="price_text_unit">month</span>
                  </label>
                ) : (
                  loader
                )}
              </div>
              <div className="summary_alignment price_item">
                <label className="cloud_price_badge price_item">
                  Shared Cloud Ports are free of charge
                </label>
              </div>
              <Label text="Total" size="sm" />
              <div className="summary_alignment price_item">
                <label className="summary_text_value price_text_key">
                  Recurring (MRC)
                </label>
                {_showPricing ? (
                  <label className="price_text_value price_colored">
                    {`£00.00`}/<span className="price_text_unit">month</span>
                  </label>
                ) : (
                  loader
                )}
              </div>
              <div className="summary_alignment price_item">
                <label className="summary_text_value price_text_key">
                  Non-Recurring (NRC)
                </label>
                {_showPricing ? (
                  <label className="price_text_value price_colored">
                    {`£00.00`}
                  </label>
                ) : (
                  loader
                )}
              </div>
              <GFTerms onAccepted={handleCheckboxChange}/>
              <div className="summary_alignment">
                <Button
                  label="Add to Basket"
                  onPress={_addToBasket}
                  variant="outline"
                  fullWidth
                  size="large"
                  className="deploy_btn summary_btn"
                  dataTestId="add_to_basket_btn"
                />
                <Button
                  label="Order"
                  onPress={_deployPort}
                  variant="gradient"
                  fullWidth
                  size="large"
                  className={`summary_btn ${isCheckboxChecked ? '' : 'btn-disabled'}`}
                  dataTestId="deploy_btn"
                  disabled={!isCheckboxChecked}
                />
              </div>
              {_addedToBasket && (
                <div className="deploy_to_basket">
                  <div className="success_message">
                    <Icon title="tick_variant" inverse className="tick_icon" />
                    <span className="summary_text_key">
                      Port added to basket successfully
                    </span>
                  </div>
                  <Button
                    label="View in Basket"
                    variant="link"
                    size="medium"
                    className="view_in_basket_btn summary_btn"
                    dataTestId="view_in_basket_btn"
                    onPress={_onNavigateToBasket}
                  />
                </div>
              )}
            </section>
          </Card>
        </div>
      </main>
          )
      }
    </CloudPortConfigWrapper>
  );
};

export default SummaryAndPricing;
