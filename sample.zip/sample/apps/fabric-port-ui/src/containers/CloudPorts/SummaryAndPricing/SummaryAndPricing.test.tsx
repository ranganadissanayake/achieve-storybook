import React from "react";
import { render, screen } from "@testing-library/react";
import { Provider } from "react-redux";
import { MemoryRouter } from "react-router-dom";

import SummaryAndPricing from "./index";
import store from "../../../redux/store";
import { ApiProvider } from "../../../shared/helpers";

describe("Summary component", () => {
  beforeEach(() => {
    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={[{ state: { isMapSelection: true } }]}>
          <ApiProvider>
            <SummaryAndPricing />
          </ApiProvider>
        </MemoryRouter>
      </Provider>
    );
  });

  it("Renders page titles", async() => {
    expect(await screen.findAllByText("Summary")).toHaveLength(1);
  });

});

describe("Summary Component 2", () => {
  test("Renders add to basket successful message on clicking add to basket button", async() => {
    const {  } = render(
      <Provider store={store}>
        <MemoryRouter initialEntries={[{ state: { isMapSelection: true } }]}>
          <ApiProvider>
            <SummaryAndPricing />
          </ApiProvider>
        </MemoryRouter>
      </Provider>
    );

  });
});
