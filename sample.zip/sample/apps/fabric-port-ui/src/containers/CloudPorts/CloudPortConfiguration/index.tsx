import React from "react";
import "./CloudPortConfiguration.scss";
import TitleBar from "../../../components/TitleBar";
import AddNewCloudPort from "../components/AddNewCloudPort";
import CloudPortIntroPanel from "../components/CloudPortIntroPanel";
import { Button } from "@btdigital/nayan-component-library";
import { useNavigate } from "react-router-dom";
import TagDataLayerService from "../../../shared/services/TagDatalayer.service"

const CloudPortConfiguration = () => {
  const navigate = useNavigate();

  return (
    <div
      className="fp-container cloudports-config-container"
      data-testid="cloudports-configuration"
    >
      <div className="header-wrapper">
        <TitleBar
          title="Cloud Port Configuration"
          titleTextClassName="configuration-title"
        />
      </div>
      <div className="add-new-cloud-port-wrapper">
        <AddNewCloudPort />
      </div>
      <div>
        <CloudPortIntroPanel />
      </div>
      <div className="fp-row action-area">
          <div className="button-row">
            <Button
              label="Back"
              variant="link"
              dataTestId="back_btn"
              onPress={() => {
                TagDataLayerService.pushCtaData("Back");
                TagDataLayerService.pushPageData("Create Cloud Port", "Choose your Cloud Provider");
                navigate("/cloud-ports/choose-a-provider")
              } }
              className="back-button"
            />
          </div>
        </div>
    </div>
  );
};

export default CloudPortConfiguration;
