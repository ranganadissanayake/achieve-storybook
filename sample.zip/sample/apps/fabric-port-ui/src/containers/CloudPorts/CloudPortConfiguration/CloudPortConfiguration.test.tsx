import React from "react";
import { fireEvent, render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";

import CloudPortConfiguration from ".";

describe("CloudPortConfiguration", () => {
  it("renders without errors", () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <CloudPortConfiguration />
      </BrowserRouter>
    );
    expect(getByTestId("cloudports-configuration")).toBeInTheDocument();
  });

  it("should able to go to back", () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <CloudPortConfiguration />
      </BrowserRouter>
    );
    fireEvent.click(getByTestId("back_btn"));
    expect(getByTestId("cloudports-configuration")).toBeInTheDocument();
  });
});
