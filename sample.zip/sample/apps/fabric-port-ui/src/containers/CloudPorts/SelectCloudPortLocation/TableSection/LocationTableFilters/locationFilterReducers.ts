import { searchTable } from "../../../../../shared/constants/locationTable";

export enum FilterAction {
  SEARCH = "SEARCH",
  FILTER_COUNTRY = "FILTER_COUNTRY",
  FILTER_METRO = "FILTER_METRO",
  FILTER_ZONE = "FILTER_ZONE",
  CLEAR_ALL = "CLEAR_ALL",
}

export type FilterState = {
  search: string;
  country?: string[];
  metro?: string[];
  zone?: string[];
};

export type FilterReducerAction = {
  type: FilterAction;
  payload?: any;
};

export const initialState = { search: "" };

export const filterLocationReducer = (
  state: FilterState,
  action: FilterReducerAction
) => {
  switch (action.type) {
    case FilterAction.FILTER_COUNTRY: {
      return {
        ...state,
        country: action.payload,
      };
    }
    case FilterAction.FILTER_METRO: {
      return { ...state, metro: action.payload };
    }
    case FilterAction.FILTER_ZONE: {
      return { ...state, zone: action.payload };
    }
    case FilterAction.SEARCH: {
      return { ...state, search: action.payload };
    }
    case FilterAction.CLEAR_ALL: {
      return { ...initialState };
    }
  }
};

export const searchAndFilter = (state: FilterState) => {
  const { country, zone, metro, search } = state;
  const searchedValues = searchTable(search);

  return searchedValues.filter((item) => {
    const filters: any = {};

    if (country && country.length > 0) {
      filters["country"] = country;
    }
    if (zone && zone.length > 0) {
      filters["zone"] = zone;
    }

    if (metro && metro.length > 0) {
      filters["metro"] = metro;
    }
    for (const key in filters) {
      if (item[key] === undefined || !filters[key]?.includes(item[key])) {
        return false;
      }
    }
    return true;
  });
};
