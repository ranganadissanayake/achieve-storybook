import {
  FilterAction,
  cloudPortReducer,
  mapFilteredData,
} from "./cloudPortReducer";

describe("cloudPortReducer", () => {
  it("should handle FILTER_COUNTRY action", () => {
    const initialState = {
      type: "cloud-port",
      mapData: {
        focus: { lat: 41.87194, lng: 12.56738 },
        data: [],
      },
      zoom: 3,
    };

    const action = {
      type: FilterAction.FILTER_COUNTRY,
      payload: {
        lat: 45.0,
        lng: 15.0,
        data: [{ lat: 45.0, lng: 15.0, count: 5 }],
      },
    };

    const newState = cloudPortReducer(initialState, action);

    expect(newState.type).toBe("cloud-port");
    expect(newState.showInfoWindow).toBe(false);
    expect(newState.mapData.focus.lat).toBe(45.0);
    expect(newState.mapData.focus.lng).toBe(15.0);
    expect(newState.mapData.data.length).toBe(1);
  });
});

describe("mapFilteredData", () => {
  it("should map data correctly", () => {
    const input = {
      lat: 45.0,
      lng: 15.0,
      count: 5,
    };

    const result = mapFilteredData(input);

    expect(result.position.lat).toBe(45.0);
    expect(result.position.lng).toBe(15.0);
  });
});
