import {
  Button,
  DropdownInputMultiSelect,
  Input,
} from "@btdigital/nayan-component-library";
import React, { useState } from "react";
import {
  getLocationCountries,
  getLocationMetro,
  getLocationZone,
} from "../../../../../shared/constants/locationTable";
import { FilterAction, FilterState } from "./locationFilterReducers";

type LocationFiltersProps = { state: FilterState; dispatch: any };
const LocationFilters: React.FC<LocationFiltersProps> = ({
  state,
  dispatch,
}) => {
  const [showFilterBar, setShowFilterBar] = useState(false);

  function clearFilters(): void {
    dispatch({
      type: FilterAction.CLEAR_ALL,
    });
  }

  const filteredOptions = [
    ...(state.country || []),
    ...(state.metro || []),
    ...(state.zone || []),
  ].length;

  return (
    <React.Fragment>
      <div className="fp-row filter-row">
        <Input
          value={state.search}
          onChange={(value) => {
            dispatch({
              type: FilterAction.SEARCH,
              payload: value,
            });
          }}
          name="searchInput"
          iconName="search"
          placeholder="Search"
          className="filter-input"
          size="sm"
          iconSize="sm"
        />
        <Button
          label="Filter"
          className="filter-button"
          iconTitle="filter"
          variant={showFilterBar || filteredOptions ? "solid" : "outline"}
          onPress={() => {
            setShowFilterBar && setShowFilterBar(!showFilterBar);
          }}
          primaryBadgeText={
            filteredOptions > 0 ? filteredOptions.toString() : undefined
          }
          primaryBadgeVariant="default-light"
          iconBefore={true}
          isFontHeadline={false}
        />
      </div>
      {showFilterBar && (
        <div className="fp-row filter-row">
          <DropdownInputMultiSelect
            type="text"
            name="Country"
            placeholder="Country"
            className="filter-input"
            showFlag={false}
            onlySelectedValue={false}
            options={getLocationCountries()}
            defaultValue="Country"
            defaultSelectedValues={state.country}
            getSelectedValues={(value) => {
              dispatch({
                type: FilterAction.FILTER_COUNTRY,
                payload: value,
              });
            }}
          />
          <DropdownInputMultiSelect
            type="text"
            name="Metro"
            placeholder="Metro"
            className="filter-input"
            showFlag={false}
            onlySelectedValue={false}
            options={getLocationMetro()}
            defaultValue="Metro"
            defaultSelectedValues={state.metro}
            getSelectedValues={(value) => {
              dispatch({
                type: FilterAction.FILTER_METRO,
                payload: value,
              });
            }}
          />
          <DropdownInputMultiSelect
            type="text"
            name="Zone"
            placeholder="Zone"
            className="filter-input"
            showFlag={false}
            onlySelectedValue={false}
            options={getLocationZone()}
            defaultValue="Zone"
            defaultSelectedValues={state.zone}
            getSelectedValues={(value) => {
              dispatch({
                type: FilterAction.FILTER_ZONE,
                payload: value,
              });
            }}
          />
          {filteredOptions > 0 && (
            <Button
              label="Clear all"
              variant="link"
              onPress={() => clearFilters()}
            />
          )}
        </div>
      )}
    </React.Fragment>
  );
};

export default LocationFilters;
