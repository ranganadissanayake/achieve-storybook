import React from "react";
import { render, fireEvent } from "@testing-library/react";
import LocationFilters from "./index";

const mockDispatch = jest.fn();

const mockState = {
  search: "",
  country: [],
  metro: [],
  zone: [],
  portLocationTableData: "",
};

jest.mock("../../../../../shared/constants/locationTable", () => ({
  getLocationCountries: () => ["Country1", "Country2"],
  getLocationMetro: () => ["Metro1", "Metro2"],
  getLocationZone: () => ["Zone1", "Zone2"],
}));

describe("LocationFilters", () => {
  it("renders without crashing", () => {
    render(<LocationFilters state={mockState} dispatch={mockDispatch} />);
  });

  it("calls dispatch with correct action when search input changes", () => {
    const { getByPlaceholderText } = render(
      <LocationFilters state={mockState} dispatch={mockDispatch} />
    );
    const searchInput = getByPlaceholderText("Search");
    fireEvent.change(searchInput, { target: { value: "New Search" } });
    expect(mockDispatch).toHaveBeenCalledWith({
      type: "SEARCH",
      payload: "New Search",
    });
  });

  it("calls setShowFilterBar when filter button is clicked", () => {
    const { getByText } = render(
      <LocationFilters state={mockState} dispatch={mockDispatch} />
    );
    const filterButton = getByText("Filter");
    fireEvent.click(filterButton);
    expect(mockDispatch).toHaveBeenCalledTimes(7);
  });
});
