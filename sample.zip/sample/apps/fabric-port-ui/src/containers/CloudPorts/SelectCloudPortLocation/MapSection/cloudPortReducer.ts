import { MOCK_CLOUD_PORT_COUNTRY_LIST } from "../../../../shared/constants";

export enum FilterAction {
  FILTER_COUNTRY = "FILTER_COUNTRY",
  FILTER_METRO = "FILTER_METRO",
  FILTER_LOCATION = "FILTER_LOCATION",
}

export const initialState = {
  type: "cloud-port",
  mapData: {
    focus: {
      lat: 41.87194,
      lng: 12.56738,
    },
    data: [
      ...MOCK_CLOUD_PORT_COUNTRY_LIST.map((c) => ({
        position: { lat: c.lat, lng: c.lng },
        label: c.count,
        type: "city",
      })),
    ],
  },
  zoom: 3,
};

export interface DropdownAction {
  type: FilterAction;
  payload: any;
}

export interface CloudPortLocationState {
  type: string;
  mapData: {
    focus: { lat: number; lng: number };
    data: any;
  };
  zoom: number;
  showInfoWindow?: boolean;
}

export const cloudPortReducer = (
  state: CloudPortLocationState,
  action: DropdownAction
) => {
  const { lat, lng, data } = action.payload;
  switch (action.type) {
    case FilterAction.FILTER_COUNTRY:
      return {
        ...state,
        type: "cloud-port",
        showInfoWindow: false,
        mapData: {
          focus: { lat, lng },
          data: data,
        },
        zoom: data.length > 1 ? 5 : 6,
      };
    case FilterAction.FILTER_METRO:
      return {
        ...state,
        type: "cloud-port",
        showInfoWindow: false,
        mapData: {
          focus: { lat, lng },
          data: data,
        },
        zoom: 11,
      };
    case FilterAction.FILTER_LOCATION:
      return {
        ...state,
        type: "cloud-port",
        zoom: 14,
        showInfoWindow: true,
        mapData: {
          focus: { lat, lng },
          data: [
            {
              position: { lat: lat, lng: lng },
              name: data.value,
              value: data.value,
            },
          ],
        },
      };
    default:
      return state;
  }
};

export const mapFilteredData = (data: any) => ({
  position: {
    lat: data.lat,
    lng: data.lng,
  },
  label: data.count,
});
