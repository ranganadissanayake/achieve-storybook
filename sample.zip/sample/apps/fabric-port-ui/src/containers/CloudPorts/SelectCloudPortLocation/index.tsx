import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";

import {
  Breadcrumb,
  Crumb,
  Label,
  ProgressStepper,
  Icon,
} from "@btdigital/nayan-component-library";

import ButtonsTab from "../../../components/ButtonsTab";
import MapSection, { SelectMapSaveFormHandle } from "./MapSection";
import TableSection, { LocationTableSaveFormHandle } from "./TableSection";
import { resetSlice } from "../../../redux/cloudPortSlice";
import { useDispatch } from "react-redux";
import useAppContext from "../../../shared/hooks/useAppContext";
import useDetectNavigationChange from "../../../shared/hooks/useDetectNavigationChange";

import "./SelectCloudPortLocation.scss";

enum TABS {
  map = "Map",
  table = "Table",
}

const buttonList = [TABS.map, TABS.table];

const SelectCloudPortLocation = () => {
  const _dispatch = useDispatch();
  const { state } = useLocation();
  const { isMapSelection } = state || { isMapSelection: true };

  const [viewMode, setViewMode] = React.useState<string>(
    isMapSelection ? TABS.map : TABS.table
  );
  const [_showModal, setShowModal] = React.useState(true);

  const _mapRef = React.useRef<SelectMapSaveFormHandle>(null);
  const _tableRef = React.useRef<LocationTableSaveFormHandle>(null);
  const [showPrompt, confirmNavigation, cancelNavigation] =
    useDetectNavigationChange(_showModal);

  const { showModal } = useAppContext();

  const defaultCrumbs: Crumb[] = [
    {
      name: "Create Connection",
      onClick: () => {
        setShowModal(true);
      },
    },
    {
      name: "Create a Cloud Port",
    },
  ];

  const handleBreadcrumbRouting = (): Crumb[] => {
    const breadcrumbItems = defaultCrumbs;
    const updatedBreadcrumb: Crumb[] = [];
    breadcrumbItems.forEach((crumb) => {
      if (!updatedBreadcrumb.some((item) => item.name === crumb.name)) {
        updatedBreadcrumb.push(crumb);
      }
    });
    return updatedBreadcrumb;
  };

  const _handleShowModal = (val: boolean) => {
    setShowModal(val);
  };

  const renderTabs = () => {
    switch (viewMode) {
      case TABS.map:
        return <MapSection ref={_mapRef} setShowModal={_handleShowModal} />;
      case TABS.table:
        return <TableSection ref={_tableRef} />;
      default:
        return <React.Fragment />;
    }
  };

  const handleShowModal = () => {
    showModal({
      onOk: _onModalOk,
      onCancel: cancelNavigation,
    });
  };

  useEffect(() => {
    if (showPrompt) {
      handleShowModal();
    }
  }, [showPrompt, confirmNavigation, cancelNavigation]);

  const _onModalOk = () => {
    _dispatch(resetSlice());
    confirmNavigation();
  };

  const _onTabChange = (label: string) => {
    if (_tableRef && _tableRef.current) {
      _tableRef.current.saveTempData();
    }

    if (_mapRef && _mapRef.current) {
      _mapRef.current.saveTempData();
    }
    setViewMode(label);
  };

  return (
    <>
      <div
        className="cloud-ports-wrapper fp-container"
        data-testid="select-cloud-port-location"
      >
        <header data-testid="" className="top_panel">
          <Breadcrumb
            crumbs={handleBreadcrumbRouting()}
            separator={<Icon title="chevron_right" size="sm" />}
          />
          <ProgressStepper
            steps={[
              "Validate GCP Pairing Key",
              "Choose Location",
              "Configuration",
              "Summary",
            ]}
            currentStep={2}
            type="stepper"
            className="progress_stepper"
          />
        </header>
        <div className="fp-row">
          <div className="title-wrapper">
            <div className="left-content">
              <Label text="Choose Location" containerStyles="choose-location" />
            </div>
            <div className="right-content" data-testid="map-table-toggle">
              <ButtonsTab
                buttonTextList={buttonList}
                onChangeButton={_onTabChange}
                activeIndex={buttonList.indexOf(viewMode as TABS)}
              />
            </div>
          </div>

          <div className="cloud-ports-wrapper--content">{renderTabs()}</div>
        </div>
      </div>
    </>
  );
};

export default SelectCloudPortLocation;
