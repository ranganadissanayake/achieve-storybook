import React from "react";
import { render, fireEvent} from "@testing-library/react";
import LocationTable from "./index";
import store from "../../../../redux/store";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";

describe("LocationTable Component Rendering", () => {
  it("renders without errors", () => {
    const { getByText, getByTestId } = render(
      <Provider store={store}>
        <BrowserRouter>
          <LocationTable />
        </BrowserRouter>
      </Provider>
    );

    const backButton = getByTestId("back_btn");
    const continueButton = getByTestId("continue_btn");
    const regionHeader = getByText("Region served");
    const locationNameHeader = getByText("Location name");
    expect(backButton).toBeInTheDocument();
    expect(continueButton).toBeInTheDocument();
    expect(regionHeader).toBeInTheDocument();
    expect(locationNameHeader).toBeInTheDocument();
  });

  it("shows an error modal when 'Continue' is clicked without selecting a location", () => {
    const { getByTestId, getByText } = render(
      <Provider store={store}>
        <BrowserRouter>
          <LocationTable />
        </BrowserRouter>
      </Provider>
    );

    const continueButton = getByTestId("continue_btn");
    fireEvent.click(continueButton);

    const errorModalTitle = getByText("You haven't selected a location");
    const errorModalMessage = getByText("You cannot continue without selecting location");
    expect(errorModalTitle).toBeInTheDocument();
    expect(errorModalMessage).toBeInTheDocument();
  });


  it("navigates to a different route when the 'Back' button is clicked", () => {
    const { getByText } = render(
      <Provider store={store}>
        <BrowserRouter>
          <LocationTable />
        </BrowserRouter>
      </Provider>
    );

    const backButton = getByText("Back");

    fireEvent.click(backButton);
  });
});
