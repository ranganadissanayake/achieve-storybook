import {
  Button,
  Card,
  Modal,
  TableV2,
} from "@btdigital/nayan-component-library";
import React, { forwardRef, useEffect, useReducer, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  selectPortLocationTableData,
  updatePortLocationTableData,
  updatePortLocationTableSelection
} from "../../../../redux/cloudPortSlice";
import images from "../../../../shared/assets";
import { LOCATION_DATA_DEMO } from "../../../../shared/constants/locationTable";
import "./LocationTable.scss";
import LocationTableFilters from "./LocationTableFilters";
import {
  filterLocationReducer,
  initialState,
  searchAndFilter,
} from "./LocationTableFilters/locationFilterReducers";
import { isNil } from "lodash";
import {
  MOCK_CLOUD_PORT_METRO_LIST
} from "../../../../shared/constants";

const LOCATION_COLUMNS = [
  {
    id: "region",
    header: () => (
      <div className="region-header">
        <span>Region served</span>
        <img
          src={images.infoIcon}
          alt="info-icon"
          className="info-icon-tooltip"
        />
      </div>
    ),
    accessorKey: "region",
    cell: ({ row }: { row: any }) => (
      <div className="region-field">
        <img src={images.tickActive} alt={"Region"} width={20} />
        <span>{row.original.region}</span>
        <span>({row.original.country})</span>
      </div>
    ),
  },
  {
    id: "metro",
    header: "Metropolitan area",
    accessorKey: "metro",
  },
  {
    id: "location",
    header: "Location name",
    accessorKey: "location",
  },
  {
    id: "facilityProvider",
    header: "Facility provider",
    accessorKey: "facilityProvider",
    cell: ({ row }: { row: any }) => (
      <div className="facility-field">
        <span>{row.original.facilityProvider}</span>
      </div>
    ),
  },
  {
    id: "zone",
    header: "Zone",
    accessorKey: "zone",
    cell: ({ row }: { row: any }) => {
      const { zone } = row.original;
      return (
        <div className="zone-field">
          <span className={zone.split(" ")[1] === "1" ? "zone-1" : "zone-2"}>
            {zone}
          </span>
        </div>
      );
    },
  },
];

export type LocationTableProps = {};

export type LocationTableSaveFormHandle = {
  saveTempData: () => void;
};


const LocationTable = forwardRef<
  LocationTableSaveFormHandle,
  LocationTableProps
>(({ }: LocationTableProps, ref) => {
  const _dispatch = useDispatch();

  const navigate = useNavigate();
  const { location } = useSelector(selectPortLocationTableData);
  const [selectedValue, setSelectedValue] = useState<string>(location ?? "");
  const [tableData, setTableData] = useState(LOCATION_DATA_DEMO);
  const [state, dispatch] = useReducer(filterLocationReducer, initialState);
  const [showUnSelected, setUnShowSelected] = useState(false);

  const columns = [
    {
      id: "facility-provider",
      cell: ({ row }: { row: any }) => (
        <>
          <input
            type="radio"
            id={row.original.location}
            defaultChecked={row.original.location === selectedValue}
            onChange={handleChildButtonClick}
            checked={row.original.location === selectedValue}
            value={row.original.location}
          />
        </>
      )
    },
    ...LOCATION_COLUMNS]

  const handleChildButtonClick = (event: any) => {
    setSelectedValue(event.currentTarget.value);
  };

  const handleNext = () => {
    if (!selectedValue) {
      setUnShowSelected(true);
      return;
    }
    const row = LOCATION_DATA_DEMO.filter(a => a.location === selectedValue)[0];
    const metroInfo = MOCK_CLOUD_PORT_METRO_LIST.filter((l) => l.city === row.metro)[0];
    const locationCoordinates = metroInfo.location.filter((l) => l.id === selectedValue)[0];
    _dispatch(
      updatePortLocationTableData({
        country: row.country,
        location: row.location,
        metro: row.metro,
        zone: row.zone,
        mapProps: {
          showInfoWindow: true,
          type: "cloud-port",
          zoom: 13,
          mapData: {
            focus: {
              lat: locationCoordinates.lat,
              lng: locationCoordinates.lng
            },
            data: [
              {
                position: {
                  lat: locationCoordinates.lat,
                  lng: locationCoordinates.lng
                },
                name: row.location,
                value: row.location
              }
            ]
          }
        }
      })
    );
    navigate("/cloud-ports/single-gcp-config", { state: { isMapSelection: false } });
  };

  useEffect(() => {
    const searched = searchAndFilter(state);
    setTableData(searched);
  }, [state]);

  React.useImperativeHandle(ref, () => ({
    saveTempData() {
      if (!isNil(selectedValue)) {
        _dispatch(updatePortLocationTableSelection(selectedValue));
      }
    }
  }));

  return (
    <React.Fragment>
      <div className="fp-row location-table">
        <div className="col-16 p-0">
          <Card>
            <LocationTableFilters state={state} dispatch={dispatch} />
            <TableV2
              data={tableData}
              columns={columns}
              enablePagination={true}
              defaultPageSize={10}
              pageSizes={[10, 25, 50, 100]}
            />
          </Card>
        </div>
      </div>
      <div className="location-table-actions-section">
        <Button
          label="Back"
          variant="link"
          dataTestId="back_btn"
          onPress={() => navigate("/cloud-ports/validate-pairing-key")}
        />
        <Button
          label="Continue"
          variant="gradient"
          dataTestId="continue_btn"
          onPress={handleNext}
        />
      </div>
      {showUnSelected && (
        <Modal
          topIcon="cloud_desktop"
          topIconStyle="critical"
          size="md"
          title="You haven't selected a location"
          complementaryMessage="You cannot continue without selecting location"
          contentAlign="center"
          hideButtons={true}
          onCancel={() => setUnShowSelected(false)}
          closeModal={!showUnSelected}
        />
      )}
    </React.Fragment>
  );
});
export default LocationTable;
