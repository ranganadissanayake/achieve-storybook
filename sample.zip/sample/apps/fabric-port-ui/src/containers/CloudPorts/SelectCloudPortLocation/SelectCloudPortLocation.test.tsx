import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import { Provider } from "react-redux";
import "regenerator-runtime";
import { fireEvent, render,screen } from "@testing-library/react";
import SelectCloudPortLocation from ".";
import store from "../../../redux/store";

jest.mock("@btdigital/nayan-component-library", () => {
  const lib = jest.requireActual("@btdigital/nayan-component-library");
  return {
    ...lib,
    Map: ({ t }) => <>{t}</>,
  };
});

describe("SelectCloudPortLocation", () => {
  test("should renders SelectCloudPortLocation component", () => {
    const { getByTestId, getAllByTestId } = render(
      <Provider store={store}>
        <Router>
          <SelectCloudPortLocation />
        </Router>
      </Provider>
    );
    expect(getByTestId("select-cloud-port-location")).toBeInTheDocument();
    expect(getByTestId("map-table-toggle")).toBeInTheDocument();
    expect(getByTestId("map-container")).toBeInTheDocument();
    expect(getAllByTestId("dropdown").length).toBe(3);
  });

  test("should navigate to pair key page on click back button", () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <Router>
          <SelectCloudPortLocation />
        </Router>
      </Provider>
    );

    fireEvent.click(getByTestId("back_btn"));
    expect(window.location.pathname).toContain(
      "/cloud-ports/validate-pairing-key"
    );
  });

  test("should not able to navigate to next page if form is empty", () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <Router>
          <SelectCloudPortLocation />
        </Router>
      </Provider>
    );

    fireEvent.click(getByTestId("continue_btn"));
    expect(getByTestId("select-cloud-port-location")).toBeInTheDocument();
  });

  test("should not able to navigate to next page if form is empty", () => {
    const { getByTestId, getAllByTestId, getByText } = render(
      <Provider store={store}>
        <Router>
          <SelectCloudPortLocation />
        </Router>
      </Provider>
    );

    fireEvent.click(getAllByTestId("dropdown")[0]);
    fireEvent.click(getByText("Finland"));

    fireEvent.click(getAllByTestId("dropdown")[1]);
    fireEvent.click(getByText("Helsinki"));

    fireEvent.click(getAllByTestId("dropdown")[2]);
    fireEvent.click(getByText("hem-zone1-7098"));

    fireEvent.click(getByText("Zone A"));
    fireEvent.click(getByText("Zone B"));

    expect(getByTestId("select-cloud-port-location")).toBeInTheDocument();
  });

  test("should render MapSection when viewMode is 'Map'", () => {
    render(
      <Provider store={store}>
        <Router>
          <SelectCloudPortLocation />
        </Router>
      </Provider>
    );

    fireEvent.click(screen.getByText("Map"));
    expect(screen.getByTestId("map-container")).toBeInTheDocument();
  });
  test("should render TableSection when viewMode is 'Table'", () => {
    render(
      <Provider store={store}>
        <Router>
          <SelectCloudPortLocation />
        </Router>
      </Provider>
    );
  
    fireEvent.click(screen.getByText("Table"));
    
  });
  

});
