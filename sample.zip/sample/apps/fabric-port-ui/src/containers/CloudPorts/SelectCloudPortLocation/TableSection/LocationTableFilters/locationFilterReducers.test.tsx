import {
  FilterAction,
  filterLocationReducer,
  FilterState,
  initialState,
  searchAndFilter,
} from './locationFilterReducers';

describe('filterLocationReducer', () => {
  it('should handle FILTER_COUNTRY action', () => {
    const state: FilterState = { ...initialState };
    const action = { type: FilterAction.FILTER_COUNTRY, payload: ['Country1', 'Country2'] };
    const newState = filterLocationReducer(state, action);
    expect(newState.country).toEqual(['Country1', 'Country2']);
  });

  it('should handle FILTER_METRO action', () => {
    const state: FilterState = { ...initialState };
    const action = { type: FilterAction.FILTER_METRO, payload: ['Metro1', 'Metro2'] };
    const newState = filterLocationReducer(state, action);
    expect(newState.metro).toEqual(['Metro1', 'Metro2']);
  });

  it('should handle FILTER_ZONE action', () => {
    const state: FilterState = { ...initialState };
    const action = { type: FilterAction.FILTER_ZONE, payload: ['Zone1', 'Zone2'] };
    const newState = filterLocationReducer(state, action);
    expect(newState.zone).toEqual(['Zone1', 'Zone2']);
  });

  it('should handle SEARCH action', () => {
    const state: FilterState = { ...initialState };
    const action = { type: FilterAction.SEARCH, payload: 'New Search' };
    const newState = filterLocationReducer(state, action);
    expect(newState.search).toEqual('New Search');
  });

  it('should handle CLEAR_ALL action', () => {
    const state: FilterState = { search: 'Search', country: ['Country1'] };
    const action = { type: FilterAction.CLEAR_ALL };
    const newState = filterLocationReducer(state, action);
    expect(newState).toEqual(initialState);
  });
});

describe('searchAndFilter', () => {
  it('should return all items when no filters are applied', () => {
    const state: FilterState = { ...initialState };
    const filteredData = searchAndFilter(state);
    expect(filteredData);
  });

  it('should filter by country', () => {
    const state: FilterState = { ...initialState, country: ['Country1'] };
    const filteredData = searchAndFilter(state);
    expect(filteredData);
  });

  it('should filter by metro', () => {
    const state: FilterState = { ...initialState, metro: ['Metro2'] };
    const filteredData = searchAndFilter(state);
    expect(filteredData);
  });

  it('should filter by zone', () => {
    const state: FilterState = { ...initialState, zone: ['Zone3'] };
    const filteredData = searchAndFilter(state);
    expect(filteredData);
  });
});
