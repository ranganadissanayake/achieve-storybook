import { isNil } from "lodash";
import React, { forwardRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import {
  Button,
  Card,
  DropdownInput,
  Label,
  Map,
} from "@btdigital/nayan-component-library";
import {
  selectCloudPortLocation,
  updatePortLocation,
} from "../../../../redux/cloudPortSlice";
import {
  MOCK_CLOUD_PORT_COUNTRY_LIST,
  MOCK_CLOUD_PORT_METRO_LIST,
} from "../../../../shared/constants";
import { getCountryOptions } from "../../../../shared/constants/portInventory";
import {
  FilterAction,
  cloudPortReducer,
  initialState,
  mapFilteredData,
} from "./cloudPortReducer";

import { MapProps } from "../../../../shared/types";
import "./SelectCloudPortLocation.scss";
import TagDataLayerService from "../../../../shared/services/TagDatalayer.service";
import Tooltip from "../../../../components/TooltipV2";
import { FlagMap } from "../../../../shared/assets/images/flags";

export type SelectCloudPortLocationProps = {
  setShowModal: (val: boolean) => void;
};

export type SelectMapSaveFormHandle = {
  saveTempData: () => void;
};

const MapSection = forwardRef<
  SelectMapSaveFormHandle,
  SelectCloudPortLocationProps
>(({setShowModal}: SelectCloudPortLocationProps, ref) => {
  const navigate = useNavigate();
  const _dispatch = useDispatch();

  const locationData = useSelector(selectCloudPortLocation);
  const [country, setCountry] = React.useState<string>(
    locationData.country ?? ""
  );
  const [metro, setMetro] = React.useState<string>("");
  const [metroList, setMetroList] = React.useState<any[]>([
    { id: "", value: "" },
  ]);
  const [location, setLocation] = React.useState<string>("");
  const [locationList, setLocationList] = React.useState<any[]>([
    { id: "", value: "" },
  ]);
  const [zone, setZone] = React.useState<string>(locationData.zone ?? "");
  const [state, dispatch] = React.useReducer(cloudPortReducer, initialState);
  const [_refresh, setRefresh] = React.useState(false);
  const [formErrors, setFormErrors] = React.useState({
    country: false,
    metro: false,
    location: false,
    zone: false,
  });

  React.useEffect(() => {
    setShowModal(false);
  }, []);

  React.useEffect(() => {
    if (country !== "") {
      setFormErrors((prev) => ({ ...prev, country: false }));
      const selectedCountry = MOCK_CLOUD_PORT_COUNTRY_LIST.find(
        (a) => a.countryIsoCode === country
      );
      if (!isNil(selectedCountry)) {
        dispatch({
          type: FilterAction.FILTER_COUNTRY,
          payload: {
            lat: selectedCountry.lat,
            lng: selectedCountry.lng,
            data: selectedCountry.city.map(mapFilteredData),
          },
        });

        setMetroList(selectedCountry?.city ?? []);
        setMetro("");
        setLocation("");
        setLocationList([]);
      }
    }
  }, [country]);

  React.useEffect(() => {
    if (metro !== "") {
      setFormErrors((prev) => ({ ...prev, metro: false }));
      const selectedMetro = MOCK_CLOUD_PORT_METRO_LIST.find(
        (m) => m.id === metro
      );
      if (!isNil(selectedMetro)) {
        dispatch({
          type: FilterAction.FILTER_METRO,
          payload: {
            lat: selectedMetro.lat,
            lng: selectedMetro.lng,
            data: selectedMetro.location.map(mapFilteredData),
          },
        });
        setLocation("");
        setLocationList(selectedMetro.location);
      }
    }
  }, [metro]);

  React.useEffect(() => {
    if (location !== "") {
      setFormErrors((prev) => ({ ...prev, location: false }));
      const selectedLocation = locationList.find((a) => a.id === location);
      if (!isNil(selectedLocation)) {
        dispatch({
          type: FilterAction.FILTER_LOCATION,
          payload: {
            lat: selectedLocation?.lat,
            lng: selectedLocation?.lng,
            data: selectedLocation,
          },
        });
      }
    }
  }, [location]);

  const onNextClicked = () => {
    const countrySelected = country !== "";
    const metroSelected = metro !== "";
    const locationSelected = location !== "";
    const zoneSelected = zone !== "";
    let selectedMetro;
    setFormErrors({
      country: !countrySelected,
      metro: !metroSelected,
      location: !locationSelected,
      zone: !zoneSelected,
    });
    if (countrySelected && metroSelected && locationSelected && zoneSelected) {
      selectedMetro = MOCK_CLOUD_PORT_METRO_LIST.find((m) => m.id === metro);

      _dispatch(
        updatePortLocation({
          country,
          metro: selectedMetro ? selectedMetro?.city ?? "" : "",
          location:
            selectedMetro && selectedMetro?.location
              ? selectedMetro?.location?.find((l) => l.id === location)
                  ?.value ?? ""
              : "",
          zone,
          mapProps: state as MapProps,
        })
      );
      TagDataLayerService.pushCtaData("Continue");
      TagDataLayerService.pushPageData(
        "Create Cloud Port",
        "Specify your site and required speed"
      );
      navigate("/cloud-ports/single-gcp-config", {
        state: { isMapSelection: true },
      });
    }
  };

  const renderMap = React.useMemo(() => {
    return _refresh ? (
      <Map
        mapType={state.type}
        zoom={state.zoom}
        coordinate={{
          ...state.mapData,
          showInfoWindow: state.showInfoWindow,
        }}
      />
    ) : (
      <></>
    );
  }, [state, _refresh]);

  React.useEffect(() => {
    const oldMetro = MOCK_CLOUD_PORT_METRO_LIST.find(
      (m) => m.city === locationData.metro
    );
    setMetro(oldMetro?.id ?? "");
    setLocation(
      oldMetro?.location?.find((l) => l.value === locationData.location)?.id ??
        ""
    );
  }, [locationData, country, _refresh]);

  React.useEffect(() => {
    setTimeout(() => {
      setRefresh(true);
    }, 1000);
  }, []);

  const _onBackClick = (doNavigateBack?: boolean) => {
    const selectedMetro = MOCK_CLOUD_PORT_METRO_LIST.find(
      (m) => m.id === metro
    );
    _dispatch(
      updatePortLocation({
        country,
        metro: selectedMetro ? selectedMetro?.city ?? "" : "",
        location:
          selectedMetro && selectedMetro?.location
            ? selectedMetro?.location?.find((l) => l.id === location)?.value ??
              ""
            : "",
        zone,
        mapProps: state as MapProps,
      })
    );
    if (doNavigateBack) {
      TagDataLayerService.pushCtaData("Back");
      TagDataLayerService.pushPageData(
        "Create Cloud Port",
        "Validate Pairing Key"
      );
      navigate("/cloud-ports/validate-pairing-key");
    }
  };

  React.useImperativeHandle(ref, () => ({
    saveTempData() {
      _onBackClick();
    },
  }));

  return (
    <React.Fragment>
      <div className="location-selection" data-testid="map-section">
        <Card
          width="50%"
          data-testid="location-wrapper"
          cardStyle="config_card"
        >
          <div className="card-content-wrapper-location">
            <div className="location-header">
              <Label text="Your Location" size="lg"></Label>
            </div>
            <div>
              <div className="location-subheading">
                Please select the location of your connection
              </div>
              <div className="form-row">
                <DropdownInput
                  className="country-flag"
                  label="Country"
                  name="country"
                  options={getCountryOptions(MOCK_CLOUD_PORT_COUNTRY_LIST)}
                  placeholder="Search Country"
                  onSelect={(val) => setCountry(val)}
                  showErrorIcon={false}
                  size="sm"
                  allowSearch={true}
                  value={country}
                  errorMessageSize="sm"
                  state={formErrors.country ? "error" : "default"}
                  errorMessage={
                    formErrors.country ? "Please select a country" : ""
                  }
                  showAsset
                  assetMap={FlagMap}
                />
              </div>
              <div className="form-row">
                <Tooltip
                  content={
                    country !== ""
                      ? ""
                      : "Please select country before selecting the metro"
                  }
                  placement="bottom"
                >
                  <DropdownInput
                    label="Metro"
                    name="location-city"
                    placeholder="Search Metro"
                    onSelect={(val) => setMetro(val)}
                    options={metroList}
                    value={metro}
                    showErrorIcon={false}
                    errorMessageSize="sm"
                    state={
                      formErrors.metro
                        ? "error"
                        : country === ""
                        ? "disabled"
                        : "default"
                    }
                    errorMessage={
                      formErrors.metro ? "Please select a metro" : ""
                    }
                  />
                </Tooltip>
              </div>
              <div className="form-row">
                <Tooltip
                  content={
                    metro !== ""
                      ? ""
                      : "Please select metro before selecting the location"
                  }
                  placement="bottom"
                >
                  <DropdownInput
                    label="Location"
                    name="location-provider"
                    placeholder="Search Location"
                    onSelect={(val) => setLocation(val)}
                    options={locationList}
                    value={location}
                    showErrorIcon={false}
                    errorMessageSize="sm"
                    state={
                      formErrors.location
                        ? "error"
                        : metro === ""
                        ? "disabled"
                        : "default"
                    }
                    errorMessage={
                      formErrors.location ? "Please select a location" : ""
                    }
                  />
                </Tooltip>
              </div>
              <div className="form-row">
                <div className="zone-button-wrapper">
                  <div className="action-title">
                    <span className="zone-label">Zone</span>
                  </div>
                  <div className="action-items">
                    <div className="buttons-section">
                      <Button
                        label="Zone A"
                        iconBefore
                        className="btn-action"
                        size="medium"
                        iconSize="sm"
                        onPress={() => {
                          setZone("Zone A");
                          setFormErrors((prev) => ({ ...prev, zone: false }));
                        }}
                        iconTitle={
                          zone === "Zone A"
                            ? "radio_checked"
                            : "radio_unchecked"
                        }
                        variant={zone === "Zone A" ? "solid" : "outline"}
                        disabled={location === ""}
                      />
                      <Button
                        label="Zone B"
                        iconBefore
                        iconTitle={
                          zone === "Zone B"
                            ? "radio_checked"
                            : "radio_unchecked"
                        }
                        className="btn-action"
                        size="medium"
                        iconSize="sm"
                        onPress={() => {
                          setZone("Zone B");
                          setFormErrors((prev) => ({ ...prev, zone: false }));
                        }}
                        variant={zone === "Zone B" ? "solid" : "outline"}
                        disabled={location === ""}
                      />
                    </div>
                    <div className="error-messages">
                      {formErrors.zone && (
                        <Label
                          text="Please select a zone"
                          labelTextStyles="error_message"
                        />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>

        <div
          className="col-16 xl:col-8 sm:col-8 md:col-8 map-section"
          data-testid="map-container"
          onClick={onNextClicked}
        >
          {renderMap}
        </div>
      </div>
      <div className="actions-section">
        <Button
          label="Back"
          variant="link"
          dataTestId="back_btn"
          onPress={() => _onBackClick(true)}
        />
        <Button
          label="Continue"
          variant="gradient"
          dataTestId="continue_btn"
          onPress={onNextClicked}
        />
      </div>
    </React.Fragment>
  );
});

export default MapSection;
