import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import { Provider } from "react-redux";

import { fireEvent, render } from "@testing-library/react";
import MapSection from ".";
import store from "../../../../redux/store";
import { act } from "react-dom/test-utils";

jest.mock("@btdigital/nayan-component-library", () => {
    const lib = jest.requireActual("@btdigital/nayan-component-library");
    return {
        ...lib,
        Map: ({ t }) => <>{t}</>,
    };
});

describe("MapSection", () => {
    beforeAll(() => {
        window.localStorage.setItem("cloudPort-tempdata-map", JSON.stringify({
            country: "Austria",
            metro: "Vienna",
            location: "vie-zone1-67",
            zone: "Zone A",
            mapProps: {}
        }));
        jest.useFakeTimers();
    });

    afterAll(() => {
        window.localStorage.removeItem("cloudPort-tempdata-map");
        jest.useRealTimers();
    });

    const setShowModal = jest.fn();

    test("should renders MapSection component", () => {
        const { getByTestId, getByText } = render(
            <Provider store={store}>
                <Router>
                    <MapSection setShowModal={setShowModal} />
                </Router>
            </Provider>
        );
        act(() => {
            jest.runAllTimers();
        });
        expect(getByTestId("map-section")).toBeInTheDocument();
        expect(getByText("Your Location")).toBeInTheDocument();
        expect(getByText("Please select the location of your connection")).toBeInTheDocument();
    });

    test("should able go back", () => {
        const { getByTestId } = render(
            <Provider store={store}>
                <Router>
                    <MapSection setShowModal={setShowModal} />
                </Router>
            </Provider>
        );

        act(() => {
            jest.runAllTimers();
        });

        fireEvent.click(getByTestId("back_btn"));
      //  expect(getByTestId("map-section")).not.toBeInTheDocument();
    });

    test("should able next", () => {
        const { getByTestId } = render(
            <Provider store={store}>
                <Router>
                    <MapSection setShowModal={setShowModal} />
                </Router>
            </Provider>
        );

        act(() => {
            jest.runAllTimers();
        });

        fireEvent.click(getByTestId("continue_btn"));
      //  expect(getByTestId("map-section")).not.toBeInTheDocument();
    });
});
