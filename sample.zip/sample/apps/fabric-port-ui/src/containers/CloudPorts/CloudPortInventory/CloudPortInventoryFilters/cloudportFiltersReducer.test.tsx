import {
    FilterAction,
    initialState,
    filterCloudInventoryReducer,
    FilterState,
    searchAndFilter
} from "./cloudportFiltersReducer";


describe('filterCloudInventoryReducer', () => {

    it('should handle FILTER_COUNTRY action', () => {
        const state: FilterState = { ...initialState };
        const action = { type: FilterAction.FILTER_COUNTRY, payload: ['Country1', 'Country2'] };
        const newState = filterCloudInventoryReducer(state, action);
        expect(newState.country).toEqual(['Country1', 'Country2']);
    });

    it('should handle FILTER_METRO action', () => {
        const state: FilterState = { ...initialState };
        const action = { type: FilterAction.FILTER_METRO, payload: ['Metro1', 'Metro2'] };
        const newState = filterCloudInventoryReducer(state, action);
        expect(newState.metro).toEqual(['Metro1', 'Metro2']);
    });

    it('should handle FILTER_SPEEd action', () => {
        const state: FilterState = { ...initialState };
        const action = { type: FilterAction.FILTER_SPEED, payload: ['20Gpbs'] };
        const newState = filterCloudInventoryReducer(state, action);
        expect(newState.speed).toEqual(['20Gpbs']);
    });

    it('should handle SEARCH action', () => {
        const state: FilterState = { ...initialState };
        const action = { type: FilterAction.SEARCH, payload: ['search-text'] };
        const newState = filterCloudInventoryReducer(state, action);
        expect(newState.search).toEqual(['search-text']);
    });

    it('should handle CLEAR_ALL action', () => {
        const state: FilterState = { ...initialState };
        const action = { type: FilterAction.CLEAR_ALL };
        const newState = filterCloudInventoryReducer(state, action);
        expect(newState).toEqual({ "search": "" });
    });


    it('should handle searchAndFilter', () => {
        const newState = searchAndFilter({
            country: ["country-a"],
            search: "se",
            metro: ["metro"],
            speed: ["100"]
        });
        expect(newState).toEqual([]);
    });
})