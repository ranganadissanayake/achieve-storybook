import React, { useEffect, useReducer, useState } from "react";
import {
  Badge,
  Button,
  Card,
  Icon,
  TableV2,
} from "@btdigital/nayan-component-library";

import { capitalize, dataMapper } from "../../../shared/utils";

import portInventory from "../../../shared/assets/images/svg/portInventory.svg";

import "./index.scss";
import PageWrap from "../../../components/PageWrap";
import TitleBar from "../../../components/TitleBar";
import deleted from "../../../shared/assets/images/svg/deleted.svg";
import deploying from "../../../shared/assets/images/svg/deploying-new.svg";
import disabled from "../../../shared/assets/images/svg/disabled.svg";
import CloudInventoryFilters from "./CloudPortInventoryFilters";
import {
  filterCloudInventoryReducer,
  initialState,
  searchAndFilter,
} from "./CloudPortInventoryFilters/cloudportFiltersReducer";
import { PORT_DATA_DEMO } from "../../../shared/constants/cloudPortInventory";
import { useNavigate } from "react-router-dom";
import Tooltip from "../../../components/TooltipV2";

const StatusIcon = ({ row }: { row: any }) => {
  let status = row.original.status || "up";

  if (row.getCanExpand()) {
    const allStatus = row.original.subRows.map((subRow) => subRow.status);
    status = allStatus.includes("deploying") ? "deploying" : status;
    status = allStatus.includes("deleting") ? "deleting" : status;
    status = allStatus.includes("down") ? "unknown" : status;
  }

  return (
    <div>
      <Tooltip
        content={
          row.getCanExpand()
            ? `1 port is ${status === "unknown" ? "Down" : capitalize(status)}`
            : capitalize(status)
        }
        placement="top"
      >
        <div>{handlestatus(status)}</div>
      </Tooltip>
    </div>
  );
};

const handlestatus = (status: string) => {
  switch (status) {
    case "up":
      return <Icon size="md" title="tick_variant" inverse color="#088003" />;
    case "deploying":
      return <img style={{ width: "20px", height: "20px" }} src={deploying} />;
    case "down":
      return <Icon title="cross" inverse color="#DA020F" />;
    case "unknown":
      return <Icon title="alert" inverse color="#DA020F" />;
    case "disabled":
      return (
        <img
          style={{ width: "20px", height: "20px" }}
          className="disable-icon"
          src={disabled}
        />
      );
    case "deleting":
      return <img style={{ width: "22px", height: "22px" }} src={deleted} />;
    default:
      return <Icon size="md" title="tick_variant" inverse color="#088003" />;
  }
};

const tableColumns = [
  {
    header: "Port Name",
    accessorKey: "portName",
    id: "portName",
    sticky: "left",
  },
  {
    header: "Status",
    accessorKey: "status",
    id: "status",
    cell: ({ row }: { row: any }) =>
      StatusIcon({
        row,
      }),
  },
  {
    header: "Cloud Provider",
    accessorKey: "providerName",
    cell: ({ row }: { row: any }) => (
      <div className="provider-section">
        {row.original?.providerLogo && (
          <img alt="logo" src={row.original?.providerLogo} />
        )}
        <span>{row.original?.providerName}</span>
      </div>
    ),
  },
  {
    header: "Country",
    accessorKey: "country",
    cell: ({ row }: { row: any }) => {
      return (
        <div className="text">
          {row.getCanExpand()
            ? `${row.original?.subRows?.length} linked ports available`
            : row.original?.country}
        </div>
      );
    },
  },
  {
    header: "Metropolitan Area",
    accessorKey: "metro",
  },
  {
    header: "Location Name",
    accessorKey: "location",
  },
  {
    header: "Speed",
    accessorKey: "portSpeed",
    cell: ({ row }: { row: any }) => (
      <div className="portspeed-container">
        <div className="text">
          {!row.original?.subRows && dataMapper(row.original?.portSpeed)}
        </div>
      </div>
    ),
  },
  {
    header: "Port ID",
    accessorKey: "portId",
  },
  {
    header: "Resilience",
    accessorKey: "resilience",
    cell: ({ row }: { row: any }) => (
      <div className="port-type">
        <Badge text={row.original?.resilience} style="disabled-inverse" />
        {row.original?.childNo && (
          <div className="diverse-item">
            <span>{row.original?.childNo}</span>
          </div>
        )}
      </div>
    ),
  },
  {
    header: "Created",
    accessorKey: "createdAt",
  },
];

const CloudPortInventory: React.FC = () => {
  const [tableData, setTableData] = useState(PORT_DATA_DEMO);

  const [state, dispatch] = useReducer(
    filterCloudInventoryReducer,
    initialState
  );

  useEffect(() => {
    const searched = searchAndFilter(state);
    setTableData(searched);
  }, [state]);

  const navigate = useNavigate();

  return (
    <PageWrap className="cloud-port-inventory" testId="port-inventory">
      <div className="fp-row">
        <div className="col-16 xl:col-8 sm:col-8 md:col-8">
          <TitleBar
            imageUrl={portInventory}
            title="Cloud Port Inventory"
            wrapperClassName="align"
          />
        </div>
        <div className="col-16 xl:col-8 sm:col-8 md:col-8 top-actions align-end">
          <Button
            label="Create New Port"
            variant="outline"
            iconTitle="expand_row"
            iconBefore={true}
            size="medium"
            className="create"
            isFontHeadline={false}
            onPress={() => {
              navigate("/cloud-ports/choose-a-provider");
            }}
          />
        </div>
      </div>
      <div className="fp-row">
        <div className="col-16 cloud-port-table">
          <Card data-testid="port-type-card">
            <CloudInventoryFilters state={state} dispatch={dispatch} />
            <TableV2
              data={tableData}
              columns={tableColumns}
              enablePagination={true}
              defaultPageSize={10}
              pageSizes={[10, 25, 50, 100]}
              enableStickyColumn={true}
              enableCanExpand={true}
              tableMaxHeight="900px"
              tableMaxWidth="1400px"
            />
          </Card>
        </div>
      </div>
    </PageWrap>
  );
};

export default CloudPortInventory;
