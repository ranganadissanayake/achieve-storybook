import {
  Button,
  DropdownGroup,
  DropdownInputMultiSelect,
  Input,
} from "@btdigital/nayan-component-library";
import React, { useState } from "react";

import { FilterAction, FilterState } from "./cloudportFiltersReducer";
import {
  getCountryOptions,
  getMetroOptions,
} from "../../../../shared/constants/cloudPortInventory";

type CloudInventoryFiltersProps = { state: FilterState; dispatch: any };
const CloudInventoryFilters: React.FC<CloudInventoryFiltersProps> = ({
  state,
  dispatch,
}) => {
  const [showFilterBar, setShowFilterBar] = useState(false);

  function clearFilters(): void {
    dispatch({
      type: FilterAction.CLEAR_ALL,
    });
  }

  const filteredOptions = [
    ...(state.country || []),
    ...(state.metro || []),
    ...(state.speed || []),
  ].length;

  return (
    <React.Fragment>
      <div className="fp-row filter-row">
        <Input
          value={state.search}
          onChange={(value) => {
            dispatch({
              type: FilterAction.SEARCH,
              payload: value,
            });
          }}
          name="searchInput"
          iconName="search"
          placeholder="Search"
          className="filter-input"
          size="sm"
          iconSize="sm"
        />
        <Button
          label="Filter"
          className="filter-button"
          iconTitle="filter"
          variant={showFilterBar || filteredOptions ? "solid" : "outline"}
          onPress={() => {
            setShowFilterBar && setShowFilterBar(!showFilterBar);
          }}
          primaryBadgeText={
            filteredOptions > 0 ? filteredOptions.toString() : undefined
          }
          primaryBadgeVariant="default-light"
          iconBefore={true}
          isFontHeadline={false}
        />
      </div>
      {showFilterBar && (
        <div className="fp-row filter-row">
          <DropdownInputMultiSelect
            type="text"
            name="Country"
            placeholder="Country"
            className="filter-input"
            showFlag={false}
            onlySelectedValue={false}
            options={getCountryOptions()}
            defaultValue="Country"
            defaultSelectedValues={state.country}
            getSelectedValues={(value) => {
              dispatch({
                type: FilterAction.FILTER_COUNTRY,
                payload: value,
              });
            }}
          />
          <DropdownInputMultiSelect
            type="text"
            name="Metro"
            placeholder="Metro"
            className="filter-input"
            showFlag={false}
            onlySelectedValue={false}
            options={getMetroOptions()}
            defaultValue="Metro"
            defaultSelectedValues={state.metro}
            getSelectedValues={(value) => {
              dispatch({
                type: FilterAction.FILTER_METRO,
                payload: value,
              });
            }}
          />
          <DropdownGroup
            rangeDefault={{ min: 0, max: 100 }}
            range={{ min: 0, max: 100 }}
            label="Speed"
            type="range"
            defaultValue={state.speed}
            selectSideEffects={(value: any) => {
              dispatch({
                type: FilterAction.FILTER_SPEED,
                payload: value,
              });
            }}
            rangeButton={true}
            leftValidationRangebar={"Min speed cannot exceed max speed"}
            rightValidationRangebar={"Max speed cannot be less than min speed"}
            unitTextRangebar="Gbps"
          />
          {filteredOptions > 0 && (
            <Button
              label="Clear all"
              variant="link"
              onPress={() => clearFilters()}
            />
          )}
        </div>
      )}
    </React.Fragment>
  );
};

export default CloudInventoryFilters;
