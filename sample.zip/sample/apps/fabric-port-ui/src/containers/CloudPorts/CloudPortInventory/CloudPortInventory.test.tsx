import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";

import CloudPortInventory from "./index";

jest.mock("react-router-dom");

describe("CloudPortInventory Component", () => {
  it("renders without crashing", () => {
    render(<CloudPortInventory />);
    expect(screen.getByTestId("port-inventory")).toBeInTheDocument();
  });

  it("navigates when 'Create New Port' button is clicked", () => {
    const navigateMock = jest.fn();
    jest
      .spyOn(require("react-router-dom"), "useNavigate")
      .mockReturnValue(navigateMock);

    render(<CloudPortInventory />);

    const createButton = screen.getByText("Create New Port");
    fireEvent.click(createButton);
    expect(navigateMock).toHaveBeenCalledWith("/cloud-ports/choose-a-provider");
  });
});
