import React from "react";
import { render, fireEvent } from "@testing-library/react";
import CloudInventoryFilters from "./index";

const mockDispatch = jest.fn();
const mockState = {
  search: "",
  country: [],
  metro: [],
  speed: [],
};

describe("CloudInventoryFilters", () => {
  it("renders without crashing", () => {
    render(<CloudInventoryFilters state={mockState} dispatch={mockDispatch} />);
  });

  it("calls dispatch with correct action when search input changes", () => {
    const { getByPlaceholderText } = render(
      <CloudInventoryFilters state={mockState} dispatch={mockDispatch} />
    );
    const searchInput = getByPlaceholderText("Search");
    fireEvent.change(searchInput, { target: { value: "New Search" } });
    expect(mockDispatch).toHaveBeenCalledWith({
      type: "SEARCH",
      payload: "New Search",
    });
  });

  it("calls setShowFilterBar when filter button is clicked", () => {
    const { getByText } = render(
      <CloudInventoryFilters state={mockState} dispatch={mockDispatch} />
    );
    const filterButton = getByText("Filter");
    fireEvent.click(filterButton);
    expect(mockDispatch).toHaveBeenCalledTimes(5);
  });
});
