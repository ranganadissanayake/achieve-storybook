import { PORT_DATA_DEMO, searchTable } from "../../../../shared/constants/cloudPortInventory";

export enum FilterAction {
  SEARCH = "SEARCH",
  FILTER_COUNTRY = "FILTER_COUNTRY",
  FILTER_METRO = "FILTER_METRO",
  FILTER_SPEED = "FILTER_SPEED",
  CLEAR_ALL = "CLEAR_ALL",
}

export type FilterState = {
  search: string;
  country?: string[];
  metro?: string[];
  speed?: string[];
};

export type FilterReducerAction = {
  type: FilterAction;
  payload?: any;
};

export const initialState = { search: "" };

export const filterCloudInventoryReducer = (
  state: FilterState,
  action: FilterReducerAction
) => {
  switch (action.type) {
    case FilterAction.FILTER_COUNTRY: {
      return {
        ...state,
        country: action.payload,
      };
    }
    case FilterAction.FILTER_METRO: {
      return { ...state, metro: action.payload };
    }
    case FilterAction.FILTER_SPEED: {
      return { ...state, speed: action.payload };
    }
    case FilterAction.SEARCH: {
      return { ...state, search: action.payload };
    }
    case FilterAction.CLEAR_ALL: {
      return { ...initialState };
    }
  }
};

export const searchAndFilter = (state: FilterState): typeof PORT_DATA_DEMO => {
  const { country, speed, metro, search } = state;
  const searchedValues = searchTable(search);

  return searchedValues.filter((item) => {
    const filters: any = {};

    if (country && country.length > 0) {
      filters["country"] = country;
    }
    if (speed && speed.length > 0) {
      filters["portSpeed"] = speed;
    }

    if (metro && metro.length > 0) {
      filters["metro"] = metro;
    }
    for (const key in filters) {
      if (item[key] === undefined || !filters[key]?.includes(item[key])) {
        return false;
      }
    }
    return true;
  });
};
