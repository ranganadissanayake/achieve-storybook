import React from "react";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormProvider, useForm } from "react-hook-form";
import { useSelector, useDispatch } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import * as yup from "yup";

import {
  Button,
  Card,
  Checkbox,
  DropdownInput,
  Icon,
  Label,
  Map,
} from "@btdigital/nayan-component-library";

import CloudPortConfigWrapper from "../components/CloudPortConfigWrapper";
import {
  CLOUD_PORT_SPEED_OPTIONS,
  MAX_NUMBER_OF_CHARACTERS,
  THIS_FIELD_CANNOT_BE_EMPTY,
} from "../../../shared/constants";
import {
  ConnectedDropdownInput,
  ConnectedInput,
  ConnectedTextarea,
} from "../../../components/ConnectedFormElements";
import { CloudPortConfigData } from "../../../shared/types";
import {
  selectCloudPortConfig,
  selectCloudPortLocation,
  selectPortLocationTableData,
  updatePortConfig,
} from "../../../redux/cloudPortSlice";

import "./SingleGCPConfig.scss";
import TagDataLayerService from "../../../shared/services/TagDatalayer.service";
import Tooltip from "../../../components/TooltipV2";
import { FlagMap } from "../../../shared/assets/images/flags";

const SingleGCPConfigSchema = yup
  .object({
    portName: yup
      .string()
      .trim()
      .required(THIS_FIELD_CANNOT_BE_EMPTY)
      .max(30, MAX_NUMBER_OF_CHARACTERS(30)),
    portDescription: yup
      .string()
      .trim()
      .required()
      .nullable()
      .max(500, MAX_NUMBER_OF_CHARACTERS(500)),
    portSpeed: yup.string().required(THIS_FIELD_CANNOT_BE_EMPTY),
    mtuSize: yup.string().required(THIS_FIELD_CANNOT_BE_EMPTY),
  })
  .required();

type SingleGCPConfigFormData = yup.InferType<typeof SingleGCPConfigSchema>;

const SingleGCPConfig = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const configData = useSelector(selectCloudPortConfig);
  const { state } = useLocation();
  const { isMapSelection } = state;

  const singleGCPConfigDefaultValues = {
    portName: configData.portName,
    portDescription: configData.portDescription,
    portSpeed:
      configData.portSpeed !== ""
        ? configData.portSpeed
        : `${CLOUD_PORT_SPEED_OPTIONS[0].id}`,
    mtuSize: configData.mtuSize,
  };

  const SingleGCPConfigFormDataMethods = useForm<SingleGCPConfigFormData>({
    resolver: yupResolver(SingleGCPConfigSchema),
    defaultValues: singleGCPConfigDefaultValues,
    mode: "onChange",
  });

  const locationDataMap = useSelector(selectCloudPortLocation);
  const portLocationDataTable = useSelector(selectPortLocationTableData);

  const locationData = isMapSelection ? locationDataMap : portLocationDataTable;

  const [_showSelected, setShowSelected] = React.useState(false);
  const [_refresh, setRefresh] = React.useState(false);
  const [_isCheckedMtu, setIsCheckedMtu] = React.useState(configData.isCheckedMtu);
  const [_isPortSpeedEmpty, setIsPortSpeedEmpty] = React.useState(false);

  const _onSubmit = React.useCallback(
    (formValues: any) => {
      const portConfigData: CloudPortConfigData = {
        ...formValues,
        isCheckedMtu: _isCheckedMtu,
      };
      dispatch(updatePortConfig(portConfigData));
      TagDataLayerService.pushCtaData("Continue");
      TagDataLayerService.pushPageData("Create Cloud Port", "Summary");
      navigate("/cloud-ports/summary-and-pricing", {
        state: { isMapSelection: isMapSelection },
      });
    },
    [dispatch, navigate, _isCheckedMtu]
  );

  const _onNextClick = React.useCallback(() => {
    SingleGCPConfigFormDataMethods.handleSubmit(_onSubmit)();
  }, [SingleGCPConfigFormDataMethods, _onSubmit]);

  const _onBackClick = React.useCallback(() => {
    const formValues = SingleGCPConfigFormDataMethods.getValues();

    if (formValues) {
      const portConfigData: CloudPortConfigData = {
        ...formValues,
        isCheckedMtu: _isCheckedMtu,
      };
      dispatch(updatePortConfig(portConfigData));
    }

    TagDataLayerService.pushCtaData("Back");
    TagDataLayerService.pushPageData("Create Cloud Port", "Select Location");
    navigate("/cloud-ports/select-location", { state: { isMapSelection } });
  }, [navigate, _isCheckedMtu]);

  const renderMap = React.useMemo(() => {
    return _refresh ? (
      <Map
        mapType={locationData.mapProps.type}
        zoom={locationData.mapProps.zoom}
        coordinate={{
          ...locationData.mapProps.mapData,
          showInfoWindow: locationData.mapProps.showInfoWindow,
        }}
      />
    ) : (
      <></>
    );
  }, [locationData, _refresh]);

  React.useEffect(() => {
    setTimeout(() => {
      setRefresh(true);
    }, 1000);
  }, []);

  return (
    <CloudPortConfigWrapper
      currentStep={3}
      handleNext={_onNextClick}
      handleBack={_onBackClick}
      className="single_gcp_config_container cloud_port_container"
    >
      <Label
        text="Specify your site and required speed"
        containerStyles="title_container"
        size="lg"
      />
      <main className="fp-row gcp_main_content" data-testId="single_gcp_config">
        <div className="col-16 xl:col-8 sm:col-8 md:col-8 mb-24 config_section">
          <Card width="100%" cardStyle="location_card">
            <div className="location_title">
              <Label text="Your location" size="lg" />
              <div className="right_content">
                <span className="selected_badge">Selected</span>
                <Icon
                  title={_showSelected ? "chevron_up" : "chevron_down"}
                  size="sm"
                  onClick={() => setShowSelected((prev) => !prev)}
                  className="more_icon"
                />
              </div>
            </div>

            {_showSelected && (
              <div className="location_body">
                <DropdownInput
                  label="Country"
                  name="country"
                  options={[]}
                  placeholder="Select"
                  showErrorIcon={false}
                  size="sm"
                  allowSearch={true}
                  labelSize="sm"
                  state="disabled"
                  value={locationData.country}
                  showAsset
                  assetMap={FlagMap}
                />
                <DropdownInput
                  label="Metro"
                  name="location-city"
                  placeholder="Select"
                  options={[]}
                  showErrorIcon={false}
                  errorMessageSize="sm"
                  labelSize="sm"
                  state="disabled"
                  value={locationData.metro}
                />
                <DropdownInput
                  label="Location"
                  name="location-provider"
                  placeholder="Search Port"
                  showErrorIcon={false}
                  errorMessageSize="sm"
                  options={[]}
                  labelSize="sm"
                  state="disabled"
                  value={locationData.location}
                />
                <div className="zone-button-wrapper">
                  <div className="action-title">
                    <Label text="Zone" size="sm" />
                    <Tooltip content="Zone tooltip">
                      <Icon
                        size="sm"
                        color="#5514B4"
                        title="alert"
                        className="zone_alert_icon"
                      />
                    </Tooltip>
                  </div>
                  <div className="action-items">
                    <Button
                      label="Zone A"
                      iconBefore
                      className="btn-action"
                      size="medium"
                      iconSize="sm"
                      iconTitle={
                        locationData.zone === "Zone A"
                          ? "radio_checked"
                          : "radio_unchecked"
                      }
                      variant={
                        locationData.zone === "Zone A" ? "solid" : "outline"
                      }
                      disabled={locationData.zone !== "Zone A"}
                    />
                    <Button
                      label="Zone B"
                      iconBefore
                      className="btn-action"
                      size="medium"
                      iconSize="sm"
                      iconTitle={
                        locationData.zone === "Zone B"
                          ? "radio_checked"
                          : "radio_unchecked"
                      }
                      variant={
                        locationData.zone === "Zone B" ? "solid" : "outline"
                      }
                      disabled={locationData.zone !== "Zone B"}
                    />
                  </div>
                </div>
              </div>
            )}
          </Card>

          <FormProvider {...SingleGCPConfigFormDataMethods}>
            <Card width="100%" cardStyle="config_port_card">
              <Label text="Configure Port" containerStyles="config_title" />
              <ConnectedInput
                name="portName"
                label="Port Name"
                containerStyles="config-connection-name__input"
                labelTextStyles="config_label"
                placeholder={MAX_NUMBER_OF_CHARACTERS(30)}
                labelSize="sm"
              />
              <ConnectedTextarea
                name="portDescription"
                label="Port Description (optional)"
                labelSize="sm"
                placeholder={MAX_NUMBER_OF_CHARACTERS(500)}
                containerStyles="config-connection-description__text-area"
                labelTextStyles="config_label"
                rows={8}
                onChangeSideEffects={(val) => {
                  if (val === "") {
                    SingleGCPConfigFormDataMethods.resetField(
                      "portDescription"
                    );
                  }
                }}
              />
              <ConnectedDropdownInput
                name="portSpeed"
                label="Port Speed"
                placeholder="Search Port Speed"
                labelTextStyles="config_label"
                options={CLOUD_PORT_SPEED_OPTIONS.map((a) => ({
                  id: a.id.toString(),
                  value: a.value,
                }))}
                onChangeSideEffects={(text: string) =>
                  setIsPortSpeedEmpty(text === "")
                }
              />
              <div
                className={`checkbox_container ${
                  _isPortSpeedEmpty ? "spacing" : ""
                }`}
              >
                <Checkbox
                  helperText=""
                  id="mtu"
                  name="Default MTU"
                  size="default"
                  state="default"
                  isCheckedDefault={_isCheckedMtu}
                  onSelect={() => setIsCheckedMtu((prev) => !prev)}
                />
                <Tooltip
                  content="Default MTU is 1440 by Google but 1500 is also supported.  Google recommends that a 1500 MTU is only used when the VPCs within GCP are also set to 1500. GCP VPCs also default to an MTU of 1460 but can be set to 1500"
                  placement="right"
                >
                  <div>
                    <Icon
                      size="sm"
                      color="#5514B4"
                      title="alert"
                      className="zone_alert_icon"
                    />
                  </div>
                </Tooltip>
              </div>
              {!_isCheckedMtu && (
                <ConnectedDropdownInput
                  name="mtuSize"
                  label="MTU Size"
                  labelTextStyles="config_label"
                  options={[
                    {
                      id: "1440",
                      value: "1440",
                    },
                    {
                      id: "1500",
                      value: "1500",
                    },
                  ]}
                  containerStyles="config-connection-name__input"
                />
              )}
            </Card>
          </FormProvider>
        </div>
        <div className="col-16 xl:col-8 sm:col-8 md:col-8 mb-24">
          <div className="map_container" data-testId="map">
            {renderMap}
          </div>
        </div>
      </main>
    </CloudPortConfigWrapper>
  );
};

export default SingleGCPConfig;
