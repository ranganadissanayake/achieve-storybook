import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { Provider } from "react-redux";

import SingleGCPConfig from "./index";
import store from "../../../redux/store";
import "regenerator-runtime";

describe("SingleGCPConfig", () => {
  beforeEach(() => {
    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={[{ state: { isMapSelection: true } }]}>
          <SingleGCPConfig />
        </MemoryRouter>
      </Provider >
    );
  });

  it("renders the single GCP Config component", () => {
    expect(
      screen.getByText("Specify your site and required speed")
    ).toBeInTheDocument();
    expect(screen.getByText("Your location")).toBeInTheDocument();
    expect(screen.getByText("Configure Port")).toBeInTheDocument();
  });

  it("renders the map", () => {
    expect(screen.getByTestId("map")).toBeInTheDocument();
  });
});

describe("SingleGCPConfig 2", () => {
  test("should not able to navigate to next page if form is empty", () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <MemoryRouter initialEntries={[{ state: { isMapSelection: true } }]}>
          <SingleGCPConfig />
        </MemoryRouter>
      </Provider >
    );

    fireEvent.click(getByTestId("continue_btn"));
    expect(getByTestId("single_gcp_config")).toBeInTheDocument();
  });

  it("navigates to the previous page when the 'Back' button is clicked", () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <MemoryRouter initialEntries={[{ state: { isMapSelection: true } }]}>
          <SingleGCPConfig />
        </MemoryRouter>
      </Provider>
    );

    fireEvent.click(getByTestId("back_btn"));

    expect(window.location.pathname).toBe("/");
  });

  it("submits the form with valid data", async () => {
    const { getByLabelText, getByTestId } = render(
      <Provider store={store}>
        <MemoryRouter initialEntries={[{ state: { isMapSelection: true } }]}>
          <SingleGCPConfig />
        </MemoryRouter>
      </Provider >
    );

    fireEvent.change(getByLabelText("Port Name"), { target: { value: "Test Port" } });
    fireEvent.change(getByLabelText("Port Description (optional)"), { target: { value: "Test Description" } });
    fireEvent.change(getByLabelText("Port Speed"), { target: { value: "1000" } });
    fireEvent.click(getByLabelText("Default MTU"));

    fireEvent.click(getByTestId("continue_btn"));
  });
});
