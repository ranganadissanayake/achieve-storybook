import { useState, useEffect } from "react";
import { useApi } from "../../../shared/helpers";
import { TopNDataResponseDTO } from "../../../shared/mappers/classes/dto/topN.dto";
import { topNRequestDTO } from "../../../shared/mappers/services/topN.service";
import { TopNEntity } from "../../../shared/mappers/classes/entity/topN.entity";

type ITopNResponse = {
  data: TopNDataResponseDTO | null;
  loading: boolean;
  error: string | null;
};

export const useFetchTopNData = (requestBody: TopNEntity): ITopNResponse => {
  // State to hold the fetched data
  const [data, setData] = useState<TopNDataResponseDTO | null>(null);
  // State to indicate loading status
  const [loading, setLoading] = useState<boolean>(true);
  // State to hold error message
  const [error, setError] = useState<string | null>(null);

  const api = useApi();

  useEffect(() => {
    const fetchData = () => {
      api
        .getTopNData(topNRequestDTO(requestBody))
        .then((response) => {
          setData(response);
        })
        .catch((error) => setError(error))
        .finally(() => setLoading(false));
    };

    fetchData();
  }, [
    requestBody.timePeriod,
    requestBody.resourceType,
    requestBody.telemetryType,
    api
  ]); // Dependency array, re-run effect when URL changes

  return { data, loading, error };
};
