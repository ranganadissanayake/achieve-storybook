import { useState, useEffect } from "react";
import { useApi } from "../../../shared/helpers";
import { TopNDataBandwidthResponseDTO } from "../../../shared/mappers/classes/dto/topN.dto";
import { topNRequestDTO } from "../../../shared/mappers/services/topN.service";
import { TopNEntity } from "../../../shared/mappers/classes/entity/topN.entity";

type ITopNResponse = {
  data: TopNDataBandwidthResponseDTO | null;
  loading: boolean;
  error: string | null;
};

export const useFetchTopNBandwidthData = (
  requestBody: TopNEntity,
): ITopNResponse => {
  // State to hold the fetched data
  const [data, setData] = useState<TopNDataBandwidthResponseDTO | null>(null);
  // State to indicate loading status
  const [loading, setLoading] = useState<boolean>(true);
  // State to hold error message
  const [error, setError] = useState<string | null>(null);

  const api = useApi();

  useEffect(() => {
    const fetchData = () => {
      api
        .getTopNDataBandwidth(topNRequestDTO(requestBody))
        .then((response) => {
          setData(response);
        })
        .catch((error) => setError(error))
        .finally(() => setLoading(false));
    };

    fetchData();
  }, [
    requestBody.timePeriod,
    requestBody.resourceType,
    requestBody.telemetryType,
    api
  ]);

  return { data, loading, error };
};
