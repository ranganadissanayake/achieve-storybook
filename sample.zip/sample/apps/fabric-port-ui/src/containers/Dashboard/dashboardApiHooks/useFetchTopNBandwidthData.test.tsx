import { renderHook, act } from "@testing-library/react";
import { useFetchTopNBandwidthData } from "./useFetchTopNBandwidthData";
import { useApi } from "../../../shared/helpers/api";
import { topNMockBandwidthData } from "../../../shared/constants/dashboard";

jest.mock("../../../shared/helpers/api", () => ({
  ...jest.requireActual("../../../shared/helpers/api"),
  useApi: jest.fn(),
}));
describe("useFetchTopNBandwidthData", () => {
  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getTopNDataBandwidth: jest.fn().mockResolvedValue(topNMockBandwidthData),
    });
  });
  it("should return data", async () => {
    const { result } = renderHook(() =>
      useFetchTopNBandwidthData({
        resourceType: "customerPorts",
        timePeriod: "past4Hours",
        telemetryType: "allocatedBandwidth",
      })
    );
    expect(result.current.loading).toBe(true);
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });
    expect(result.current.error).toBe(null);
    expect(result.current.data).toEqual(topNMockBandwidthData);
    expect(result.current.data).toBeDefined();
  });
});
