import { renderHook, act } from "@testing-library/react";
import { useFetchTopNData } from "./useFetchTopNData";
import { useApi } from "../../../shared/helpers/api";
import { topNMockData } from "../../../shared/constants/dashboard";

jest.mock("../../../shared/helpers/api", () => ({
  ...jest.requireActual("../../../shared/helpers/api"),
  useApi: jest.fn(),
}));
describe("useFetchTopNData", () => {
  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getTopNData: jest.fn().mockResolvedValue(topNMockData),
    });
  });
  it("should return data", async () => {
    const { result } = renderHook(() =>
      useFetchTopNData({
        resourceType: "allPorts",
        telemetryType: "inboundUtilisation",
        timePeriod: "past4Hours",
      }),
    );
    expect(result.current.loading).toBe(true);
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });
    expect(result.current.error).toBe(null);
    expect(result.current.data).toEqual(topNMockData);
    expect(result.current.data).toBeDefined();
  });
});
