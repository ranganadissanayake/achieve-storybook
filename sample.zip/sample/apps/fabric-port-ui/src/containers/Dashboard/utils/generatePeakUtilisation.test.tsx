import {
  generatePeakUtilisation,
  PeakUtilisationData,
} from "./peackUtilisationGraphData";
import dayjs from "dayjs";

describe("generatePeakUtilisation", () => {
  const rawData: PeakUtilisationData[] = [
    { portName: "Port1", received: 50, transmitted: 60 },
    { portName: "Port2", received: 30, transmitted: 40 },
  ];

  it("generates peak utilisation data correctly", () => {
    const { data, options, labels } = generatePeakUtilisation(rawData);

    expect(data).toBeDefined();
    expect(options).toBeDefined();
    expect(labels).toBeDefined();

    expect(data.labels).toEqual(["Port1", "Port2"]);
    expect(options.indexAxis).toBe("y");
    expect(options.responsive).toBe(true);

    const footerResult = options.plugins.tooltip.callbacks.footer();
    const expectedFooter = `        ${dayjs().format("DD MMM YY, hh:mm A")}`;
    expect(footerResult).toBe(expectedFooter);
  });

  it("generates peak utilisation scales correctly", () => {
    const { options } = generatePeakUtilisation(rawData);

    const xScale = options.scales.x;

    expect(xScale.min).toBe(0);
    expect(xScale.max).toBe(100);
    expect(xScale.border.display).toBe(false);

    xScale.ticks.callback(50);
    expect(xScale.ticks.stepSize).toBe(1);
    expect(xScale.ticks.maxTicksLimit).toBe(6);

    const yTicks = {
      callback: jest.fn(),
      font: { size: 12, weight: "bold", family: "BT Curve Headline" },
    };

    expect(yTicks.font.size).toBe(12);
    expect(yTicks.font.weight).toBe("bold");
    expect(yTicks.font.family).toBe("BT Curve Headline");
  });

  it("generates peak utilisation tooltip title and label correctly", () => {
    const { options } = generatePeakUtilisation(rawData);

    const context: any = {
      dataset: {
        data: rawData[0].received,
      },
      raw: 50,
    };

    expect(options.plugins.tooltip.callbacks.title()).toBe("");

    expect(
      options.plugins.tooltip.callbacks.label(context),
    ).toMatchInlineSnapshot(`"  TX (Transmitted)                      50%"`);
  });

  it("generates peak utilisation tooltip title, label, and labelPointStyle correctly", () => {
    const { options } = generatePeakUtilisation(rawData);

    const transmittedContext: any = {
      dataset: {
        data: rawData[0].transmitted,
      },
    };

    expect(
      options.plugins.tooltip.callbacks.labelPointStyle(transmittedContext),
    ).toEqual({
      pointStyle: expect.any(Object),
      rotation: 0,
    });

    const receivedContext: any = {
      dataset: {
        data: rawData[0].received,
      },
    };

    expect(
      options.plugins.tooltip.callbacks.labelPointStyle(receivedContext),
    ).toEqual({
      pointStyle: expect.any(Object),
      rotation: 0,
    });
  });

  it("generates peak utilisation ticks callback correctly", () => {
    const { options } = generatePeakUtilisation(rawData);

    expect(options.scales.y.ticks.callback(0)).toBe("Port1...");
    expect(options.scales.y.ticks.callback(1)).toBe("Port2...");
  });
});
