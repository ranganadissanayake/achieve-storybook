import { TooltipItem } from "chart.js";
import dayjs from "dayjs";

import rxReceived from "../../../shared/assets/images/svg/rx-received.svg";
import txTransmitted from "../../../shared/assets/images/svg/tx-transmitted.svg";
import { ResourceData, TopNDataBandwidthResponseDTO } from "../../../shared/mappers/classes/dto/topN.dto";
import { DataStackChart } from "../components/TopFivePortsByBandwidth";

export interface PeakUtilisationData {
  portName: string;
  received: number;
  transmitted: number;
}

export const generatePeakUtilisation = (rawData: PeakUtilisationData[]) => {
  const labels = rawData?.map(({ portName }) => portName);
  const transmittedData = rawData?.map(({ transmitted }) => transmitted);
  const recievedData = rawData?.map(({ received }) => received);

  const data = {
    labels: labels,
    datasets: [
      {
        data: recievedData,
        backgroundColor: "#1ec8e6",
        barThickness: 14,
      },
      {
        data: transmittedData,
        backgroundColor: "#712dc2",
        barThickness: 14,
      },
    ],
  };

  const rx_image = new Image();
  rx_image.src = rxReceived;
  rx_image.width = 15;
  const tx_image = new Image();
  tx_image.src = txTransmitted;
  tx_image.width = 15;

  const options = {
    indexAxis: "y" as const,
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: "rgb(42, 28, 74, 1)",
        cornerRadius: 8,
        displayColors: true,
        usePointStyle: true,
        bodyColor: "#fff",
        bodyFont: {
          family: "BT Curve Headline",
          weight: "500",
          size: 12,
        },
        footerColor: "#c8c8c8",
        footerFont: {
          family: "BT Curve",
          weight: "400",
          size: 12,
        },
        callbacks: {
          title: () => "",
          label: (context: TooltipItem<"bar">) => {
            if (context.dataset.data === recievedData) {
              return `  RX (Received)                         ${context.raw}%`;
            } else {
              return `  TX (Transmitted)                      ${context.raw}%`;
            }
          },
          labelPointStyle: (context: TooltipItem<"bar">) => {
            return {
              pointStyle:
                context.dataset.data === recievedData ? rx_image : tx_image,
              rotation: 0,
            };
          },
          footer: () => {
            return `        ${dayjs().format("DD MMM YY, hh:mm A")}`;
          },
        },
      },
    },
    elements: {
      bar: {
        borderWidth: 2,
        borderColor: "#fff",
        borderRadius: 4,
      },
    },
    scales: {
      x: {
        ticks: {
          callback: function (value: string | number) {
            return `${value}%`;
          },
          stepSize: 1,
          maxTicksLimit: 6,
        },
        min: 0,
        max: 100,
        border: {
          display: false,
        },
      },
      y: {
        ticks: {
          callback: function (value: string | number) {
            return labels[Number(value)].substring(0, 17) + "...";
          },
          font: {
            size: 12,
            weight: "bold",
            family: "BT Curve Headline",
          },
          color: "transparent",
        },
        grid: {
          display: false,
        },
      },
    },
  };

  return { data, options, labels };
};

export const utilizationChartMapper = (
  rxData: ResourceData[],
  txData: ResourceData[]
): PeakUtilisationData[] => {
  return rxData.map((rxData, index) => {
    return {
      portName: rxData.resourceName ?? "",
      received: +rxData.value,
      transmitted: +txData[index].value,
    };
  });
};

export const transformAPIDataToDataStackChart = (
  apiData: TopNDataBandwidthResponseDTO,
): DataStackChart => {
  const labels: string[] = [];
  const datasets: DataStackChart["datasets"] = [];

  apiData.result.forEach((apiResource, index) => {
    labels.push(apiResource.resourceName);

    const dataset = {
      label: "",
      data: [] as number[],
      backgroundColor: getBackgroundColor(index),
      barThickness: 10,
    };
    apiResource.breakdown.forEach((breakdownItem) => {
      dataset.label = breakdownItem.resourceName;
      dataset.data.push(breakdownItem.value);
    });

    datasets.push(dataset);
  });
  generateDataArrays(datasets);
  return { labels, datasets };
}

export const generateDataArrays = (
  input: DataStackChart["datasets"],
): number[][] => {
  const maxDataLength = Math.max(...input.map((item) => item.data.length));
  input.map((item) => {
    while (item.data.length < maxDataLength) {
      item.data.push(0);
    }
  });

  const dataArrays: number[][] = Array.from(
    { length: maxDataLength },
    () => [],
  );

  input.map((item) => {
    item.data.map((value: number, index: string | number) => {
      dataArrays[index].push(value);
    });
  });

  input.map((item, index) => {
    item.data = dataArrays[index];
  });

  return dataArrays;
};

// Helper function to generate different background colors
export const getBackgroundColor = (index: number): string => {
  const colors = [
    "#0134AA",
    "#044ED4",
    "#0066FF",
    "#76A3F8",
    "#BFD3FA",
    "#BFD3FA",
    "#eeeeee",
  ];
  return colors[index % colors.length];
};