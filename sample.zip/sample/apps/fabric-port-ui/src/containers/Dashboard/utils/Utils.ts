export interface IndicatorData {
  deviceId: number;
  ids: number[];
  objectId: number;
  pluginId: number;
}
export type TimeRange =
  | "5 minutes"
  | "30 minutes"
  | "60 minutes"
  | "24 hours"
  | "1 week";

export const baseUrl = "http://13.40.38.154/api/v2";

export const PERFORMANCE_METRIC_URL = `${baseUrl}/reports/attachments/performance-metrics/run?skipNullPoints=true&graphWidth=800`;

export const myHeaders = new Headers();
myHeaders.append("Content-Type", "application/json");
myHeaders.append(
  "X-AUTH-TOKEN",
  "eyJhbGciOiJIUzUxMiJ9eyJpc3MiOiJncmFmYW5hIn0DYdE9Iu143YyC2DRXTZpRCIYfGGsDd7l-mszJfkokhV1xOBNyLO4R9sImsvxs-yrLrn8L1BWRQNbFDN0CeQ-OA"
);

export const getRequestOptions = (
  { deviceId, ids, objectId, pluginId }: IndicatorData,
  _timeRange: TimeRange = "24 hours"
) => {
  const raw = JSON.stringify({
    name: "string",
    resources: [
      {
        indicators: [
          {
            deviceId,
            ids,
            objectId,
            pluginId,
          },
        ],
      },
    ],
    settings: {
      rawData: {
        csv: {
          expandTimeseries: true,
          formatTimestamp: true,
        },
        dataAggregation: {
          aggregationType: "auto",
          aggregationUnits: "second",
          aggregationValue: 0,
          useAggregation: true,
        },
        rawData: {
          fitTimeSpanTo: "second",
          percentiles: 0,
          projectionTime: 0,
          reduceData: true,
          standardDeviation: 0,
          timeOverTimeOnly: true,
          timeOverTimeType: "none",
          timeOverTimeUnits: "second",
          timeOverTimeValue: 0,
          trend: "none",
          trendType: "linear",
          useBaseline: true,
          usePercentiles: true,
          useTimeOverTime: true,
        },
        units: {
          percentage: true,
          preferredUnits: "bits",
        },
        workHours: {
          customWorkhours: [
            {
              days: ["monday"],
              startHour: 0,
              startMin: 0,
              endHour: 0,
              endMin: 0,
            },
          ],
          type: "none",
          workHoursGroupId: 0,
        },
      },
      sourceFields: {
        fields: ["string"],
        sort: [["string"]],
      },
    },
    time: {
      ranges: {
        type: "RelativePeriod",
        start: `Past ${_timeRange}`,
        end: null,
        options: null,
      },
      timezone: "UTC",
    },
  });

  const requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: raw,
  };

  return requestOptions;
};

export const rand = (min = 0, max = 100) => {
  const difference = max - min;
  let rand = Math.random();
  rand = rand * difference;
  rand = rand + min;

  return Number(rand.toFixed(1));
};

export const shuffle = (array: any[]) => {
  let currentIndex = array.length,
    randomIndex;

  while (currentIndex > 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;

    [array[parseInt(`${currentIndex}`)], array[parseInt(`${randomIndex}`)]] = [
      array[parseInt(`${randomIndex}`)],
      array[parseInt(`${currentIndex}`)],
    ];
  }

  return array;
};

export const timeXAxys = () => {
  var x = 10; //minutes interval
  var times: string[] = []; // time array
  var tt = 0; // start time
  var ap = ["AM", "PM"]; // AM-PM

  //loop to increment the time and push results in array
  for (var i = 0; tt < 1 * 60; i++) {
    var hh = Math.floor(tt / 60); // getting hours of day in 0-24 format
    var mm = tt % 60; // getting minutes of the hour in 0-55 format
    times[i] =
      ("0" + (hh % 12)).slice(-2) +
      ":" +
      ("0" + mm).slice(-2) +
      ap[Math.floor(hh / 12)]; // pushing data in array in [00:00 - 12:00 AM/PM format]
    tt = tt + x;
  }

  return times;
};

export const getRandomNumbers = (min: number, max: number) => {
  var result: number[] = [];
  for (var i = 0; i < 10; i++) {
    result[i] = Math.floor(Math.random() * (max - min + 1) + min) + 1;
  }

  return result;
};

export const formatSpeed = (value?: string) => {
  return value ? `${parseFloat(value).toLocaleString()} Mbps` : "";
};
export const convertGbpsToMbps = (value: string) => {
  return value
    ? (parseFloat(value.replace(" Gbps", "")) * 1000).toString()
    : "";
};
export const GbpsToMbps = (value: string) => {
  return Number(value.replace(/ Gbps/g, "")) * 1000 + " Mbps";
};