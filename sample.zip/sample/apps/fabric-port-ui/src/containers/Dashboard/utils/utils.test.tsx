import {
  convertGbpsToMbps,
  formatSpeed,
  getRandomNumbers,
  getRequestOptions,
  rand,
  shuffle,
  timeXAxys,
} from "./Utils";

describe("getRequestOptions", () => {
  const indicatorData = {
    deviceId: 1,
    ids: [2],
    objectId: 3,
    pluginId: 4,
  };

  it("generates request options correctly", () => {
    const requestOptions = getRequestOptions(indicatorData, "24 hours");
    expect(requestOptions.method).toBe("POST");
  });
});

describe("rand", () => {
  it("generates a random number within the specified range", () => {
    const result = rand(1, 10);
    expect(result).toBeGreaterThanOrEqual(1);
    expect(result).toBeLessThanOrEqual(10);
  });
});

describe("shuffle", () => {
  it("shuffles an array", () => {
    const inputArray = [1, 2, 3, 4, 5];
    const shuffledArray = shuffle([...inputArray]);
    expect(shuffledArray).not.toBe(inputArray);
  });
});

describe("timeXAxys", () => {
  it("generates an array of time values", () => {
    const times = timeXAxys();
    expect(times).toHaveLength(6);
  });
});

describe("getRandomNumbers", () => {
  it("generates an array of random numbers within the specified range", () => {
    const min = 1;
    const max = 10;
    const result = getRandomNumbers(min, max);
    expect(result).toHaveLength(10);
    result.forEach((num) => {
      expect(num).toBeGreaterThanOrEqual(min);
    });
  });
});

describe("formatSpeed", () => {
  it("format port speeds in port c", () => {
    const result = formatSpeed("2000");
    expect(result).toBe("2,000 Mbps");
  });
  it("format port speeds for undefined in port c", () => {
    const result = formatSpeed();
    expect(result).toBe("");
  });
});
describe("convertGbpsToMbps", () => {
  it("convert Gbps to Mbps", () => {
    const result = convertGbpsToMbps("3.2 Gbps");
    expect(result).toBe("3200");
  });
  it("convert Gbps to Mbps for empty string", () => {
    const result = convertGbpsToMbps("");
    expect(result).toBe("");
  });
});
