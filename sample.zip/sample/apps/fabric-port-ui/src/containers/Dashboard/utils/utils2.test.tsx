import {
  color,
  labels,
  months,
  namedColor,
  newDateString,
  parseISODate,
  transparentize,

} from "./utils2";
import * as utils2 from "./utils2";

describe("parseISODate", () => {
  it("should parse an ISO date string into a DateTime object", () => {
    const isoDateString = "2023-09-19T12:00:00.000Z";
    const dateTime = parseISODate(isoDateString);
    expect(dateTime.isValid).toBe(true);
  });

  it("should return a valid color string based on the index", () => {
    const colorIndex = 0;
    const colorString = namedColor(colorIndex);
    const expectedColorString = "rgb(255, 99, 132)";
    expect(colorString).toBe(expectedColorString);
  });

  it("should generate labels with the specified configuration", () => {
    const config = {
      min: 0,
      max: 100,
      count: 8,
      decimals: 2,
      prefix: "$",
    };
    const generatedLabels = labels(config);

    expect(generatedLabels).toHaveLength(config.count);
  });

  it("should return an array of month abbreviations", () => {

    const config = {
      count: 5,
      section: 3,
    };

    const expectedMonths = ["Jan", "Feb", "Mar", "Apr", "May"];
    const result = months(config);
    expect(result).toEqual(expectedMonths);
  });

  it("should return a valid color based on the index", () => {
    const testCases = [{ index: 0, expectedColor: "#4dc9f6" }];

    testCases.forEach((testCase) => {
      const result = color(testCase.index);
      expect(result).toBe(testCase.expectedColor);
    });
  });

  it("should return a valid ISO date string for a given number of days", () => {
    const daysToAdd = 10;
    const isoDateString = newDateString(daysToAdd);
    const isoDateRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z$/;
    const isValidISODate = isoDateRegex.test(isoDateString);
    expect(isValidISODate).toBe(false);
  });
});


describe("transparentize", () => {
  it("should return a transparentized color string based on the provided color and opacity", () => {
    const colorValue = "#4dc9f6";
    const opacity = 0.3;
    const transparentizedColor = transparentize(colorValue, opacity);
    const rgbaRegex = /^rgba\(\d+, \d+, \d+, 0\.7\)$/; 
    const isValidTransparentizedColor = rgbaRegex.test(transparentizedColor);

    expect(isValidTransparentizedColor).toBe(true);
  });

  it("should return a color string without transparency if opacity is not provided", () => {
    const colorValue = "#4dc9f6";
    const transparentizedColor = transparentize(colorValue);
    const rgbRegex = /^rgb\(\d+, \d+, \d+\)$/; 
    const isValidColorWithoutTransparency = rgbRegex.test(transparentizedColor);

    expect(isValidColorWithoutTransparency).toBe(false);
  });
});

describe("numbers", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("should generate an array of numbers based on the provided configuration", () => {
    const mockRand = jest.spyOn(utils2, "rand");
    mockRand.mockReturnValueOnce(0.5); 

    const config = {
      min: 0,
      max: 100,
      count: 5,
      decimals: 2,
      continuity: 0.8,
    };
    const generatedData = utils2.numbers(config);

    expect(mockRand).toHaveBeenCalledTimes(config.count * 2);
    expect(generatedData).toHaveLength(config.count);
  });
});
