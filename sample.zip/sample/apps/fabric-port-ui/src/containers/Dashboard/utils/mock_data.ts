export const MOCK_PORTS_DATA = [
  {
    portName: "Natwest London Cl",
    received: 78,
    transmitted: 57,
  },
  {
    portName: "LD3 Park Royal Da",
    received: 64,
    transmitted: 17,
  },
  {
    portName: "LD2 Slough Data C",
    received: 42,
    transmitted: 59,
  },
  {
    portName: "Google DC 102 Sanf",
    received: 48,
    transmitted: 18,
  },
  {
    portName: "FGH 898 Singapore",
    received: 18,
    transmitted: 16,
  },
];

export const MOCK_INTERNET_CONNECTION_DATA = [
  {
    portName: "DC Metro Web",
    received: 98,
    transmitted: 10,
  },
  {
    portName: "Natwest Net Connect",
    received: 50,
    transmitted: 15,
  },
  {
    portName: "Warsaw Web Link",
    received: 40,
    transmitted: 8,
  },
  {
    portName: "Google DC 102Am...",
    received: 3,
    transmitted: 30,
  },
  {
    portName: "Cloud Virtu Link",
    received: 17,
    transmitted: 3,
  },
];

export const MOCK_IP_VPN_CONNECTION_DATA = [
  {
    portName: "DC MetroEquinix P...",
    received: 6,
    transmitted: 58,
  },
  {
    portName: "Natwest Factory li",
    received: 45,
    transmitted: 2,
  },
  {
    portName: "Warsaw Web Link",
    received: 43,
    transmitted: 6,
  },
  {
    portName: "DC MetroRadiantLi...",
    received: 28,
    transmitted: 4,
  },
  {
    portName: "Google DC 1North E...",
    received: 18,
    transmitted: 16,
  },
];