import React, { useCallback, useEffect, useState } from "react";
import "./Dashboard.scss";
import Header from "./components/Header";
import NetworkMapWidget from "./components/NetworkMapWidget";
import QuickLinks from "./components/QuickLinks";
import IncidentManagement from "./components/IncidentManagement";
import { alertContentList } from "../../shared/constants";
import AlertsList from "../../components/AlertsList";
import TotalAlerts from "../../components/TotalAlerts";
import NoPorts from "./components/NoPorts";
import Spotlight from "./components/Spotlight";
import { AlertTileProps } from "../../components/AlertTile";
import useAppContext from "../../shared/hooks/useAppContext";
import TopFivePortsByBandwidth, { DataStackChart } from "./components/TopFivePortsByBandwidth";
import PeakUtilisation from "./components/PeakUtilisation";
import { MOCK_IP_VPN_CONNECTION_DATA } from "./utils/mock_data";
import { useFetchTopNData } from "../../../src/containers/Dashboard/dashboardApiHooks/useFetchTopNData";
import {
  PeakUtilisationData,
  transformAPIDataToDataStackChart,
  utilizationChartMapper,
} from "./utils/peackUtilisationGraphData";
import { TimePeriod } from "../../shared/mappers/classes/dto/topN.dto";
import { useFetchTopNBandwidthData } from "./dashboardApiHooks/useFetchTopNBandwidthData";

const Dashboard: React.FC = () => {
  const hasPorts = true;
  const hasPortsLocal = true;
  const { searchItems, loadingDashboard } = useAppContext();
  const [alertListContent, setAlertList] =
    React.useState<AlertTileProps[]>(alertContentList);

  // port utilization chart
  const [selectedTimePortUtilization, setSelectedTimePortUtilization] =
    useState<TimePeriod>("past4Hours");
  const { data: rxDataPort } = useFetchTopNData({
    resourceType: "allPorts",
    telemetryType: "inboundUtilisation",
    timePeriod: selectedTimePortUtilization,
  });
  const { data: txDataPort } = useFetchTopNData({
    resourceType: "allPorts",
    telemetryType: "outboundUtilisation",
    timePeriod: selectedTimePortUtilization,
  });
  const [portsUtilizationData, setPortsUtilizationData] = useState<
    PeakUtilisationData[] | null
  >(null);

  // internet utilization chart
  const [selectedTimeInternetUtilization, setSelectedTimeInternetUtilization] =
    useState<TimePeriod>("past4Hours");
  const { data: rxDataInternet } = useFetchTopNData({
    resourceType: "internetConnection",
    telemetryType: "inboundUtilisation",
    timePeriod: selectedTimeInternetUtilization,
  });
  const { data: txDataInternet } = useFetchTopNData({
    resourceType: "internetConnection",
    telemetryType: "outboundUtilisation",
    timePeriod: selectedTimeInternetUtilization,
  });
  const [internetUtilizationData, setInternetUtilizationData] = useState<
    PeakUtilisationData[] | null
  >(null);

  // bandwidth allocation
  const { data: bandwidthAllocationData } = useFetchTopNBandwidthData({
    resourceType: "customerPorts",
    telemetryType: "allocatedBandwidth",
  });
  const [portBandwidthData, setportBandwidthData] =
    useState<DataStackChart | null>(null);

  React.useEffect(() => {
    setAlertList((prev: any) => {
      return prev.map((val: AlertTileProps) => {
        if (val.subHeading === "Total ports" && searchItems.ports.totalItems) {
          val.mainHeading = searchItems.ports.totalItems.toString();
        }
        if (val.subHeading === "Network services" && searchItems.internet.totalItems) {
          val.mainHeading = searchItems.internet.totalItems.toString();
        }
        return val;
      });
    });
  }, [searchItems]);

  //for port utilization
  useEffect(() => {
    if (txDataPort && rxDataPort) {
      setPortsUtilizationData(
        utilizationChartMapper(rxDataPort.result, txDataPort.result),
      );
    }
  }, [txDataPort, rxDataPort]);

  //for internet utilization
  useEffect(() => {
    if (txDataInternet && rxDataInternet) {
      setInternetUtilizationData(
        utilizationChartMapper(rxDataInternet.result, txDataInternet.result),
      );
    }
  }, [txDataInternet, rxDataInternet]);

  useEffect(() => {
    if (bandwidthAllocationData) {
      setportBandwidthData(
        transformAPIDataToDataStackChart(bandwidthAllocationData),
      );
    }
  }, [bandwidthAllocationData]);

  //on chnage port chart time period
  const onSelectPortDateFilter = useCallback(
    (date: TimePeriod) => {
      setSelectedTimePortUtilization(date);
    },
    [selectedTimePortUtilization]
  );

  //on chnage internet chart time period
  const onSelectInternetDateFilter = useCallback(
    (date: TimePeriod) => {
      setSelectedTimeInternetUtilization(date);
    },
    [selectedTimeInternetUtilization]
  );

  return (
    <div className="dashboard-holder pb-32" data-testid="dashboard">
      <div className="fp-container-wide">
        <div className="dashboard-container">
          <Header />
          {hasPorts || hasPortsLocal ? (
            <>
              <section className="highligh-widgets mb-16">
                <div className="fp-row">
                  <div className="total-ports-wrp col-8">
                    <AlertsList
                      alertsList={alertListContent}
                      loading={loadingDashboard}
                    />
                  </div>
                  <div className="notifications-wrp col-8">
                    <TotalAlerts loading={loadingDashboard} />
                  </div>
                </div>
              </section>

              <section className="network-map-wrp mb-16">
                <div className="fp-row">
                  <div className="col-16">
                    <NetworkMapWidget />
                  </div>
                </div>
              </section>

              <section className="top-five-wrp">
                <div className="fp-row">
                  <div className="top-5-ports-wrp col-16 md:col-8 mb-16">
                    <TopFivePortsByBandwidth
                      data={portBandwidthData ?? { datasets: [], labels: [] }}
                    />
                  </div>
                  <div className="top-5-ports-peak-wrp col-16 md:col-8 mb-16">
                    <PeakUtilisation
                      title="Top 5 Ports by Peak utilisation"
                      subTitle="Most heavily used ports, ranked by their peak utilisation"
                      rawData={portsUtilizationData ?? []}
                      ctaText="View all ports"
                      ctaLink="/port-inventory"
                      onSelectDate={onSelectPortDateFilter}
                      selectedValue={selectedTimePortUtilization}
                    />
                  </div>
                  <div className="top-5-internet-wrp col-16 md:col-8 mb-16">
                    <PeakUtilisation
                      title="Top 5 Internet Connections by Peak utilisation"
                      subTitle="Most heavily used internet connections, ranked by their peak utilisation"
                      rawData={internetUtilizationData ?? []}
                      ctaText="View all internet connections"
                      ctaLink="/internet-connection"
                      onSelectDate={onSelectInternetDateFilter}
                      selectedValue={selectedTimeInternetUtilization}
                    />
                  </div>
                  <div className="top-5-vpn-wrp col-16 md:col-8 mb-16">
                    <PeakUtilisation
                      title="Top 5 IP VPN Connections by Peak utilisation"
                      subTitle="Most heavily used IP VPN connections, ranked by their peak utilisation"
                      rawData={MOCK_IP_VPN_CONNECTION_DATA}
                      ctaText="View all IP VPN connections"
                      ctaLink="/network-services/ip-vpn-inventory"
                    />
                  </div>
                </div>
              </section>

              <section
                id="incident-management"
                className="incident-management-wrp mb-16"
              >
                <IncidentManagement />
              </section>
            </>
          ) : (
            <section className="network-map-wrp mb-16">
              <div className="fp-row">
                <div className="col-16">
                  <NoPorts />
                </div>
              </div>
            </section>
          )}

          <section className="spotlight-quick-links-wrp mb-16">
            <div className="fp-row">
              <div className="spotlight-wrp col-16 md:col-8 mb-16 md:mb-0">
                <Spotlight />
              </div>
              <div className="quick-links col-16 md:col-8">
                <QuickLinks />
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
