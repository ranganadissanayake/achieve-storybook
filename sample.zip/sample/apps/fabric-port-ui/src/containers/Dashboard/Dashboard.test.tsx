import React from "react";
import { render } from "@testing-library/react";
import Dashboard from ".";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import store from "../../redux/store";
import { useApi } from "../../shared/helpers";
import { useFetchTopNData } from "../../../src/containers/Dashboard/dashboardApiHooks/useFetchTopNData";
import { useFetchTopNBandwidthData }  from "../../../src/containers/Dashboard/dashboardApiHooks/useFetchTopNBandwidthData";
import { topNMockBandwidthData, topNMockData } from "../../shared/constants/dashboard";

jest.mock("../../shared/helpers");
jest.mock(
  "../../../src/containers/Dashboard/dashboardApiHooks/useFetchTopNData",
  () => ({
    ...jest.requireActual(
      "../../../src/containers/Dashboard/dashboardApiHooks/useFetchTopNData",
    ),
    useFetchTopNData: jest.fn(),
  })
);
jest.mock(
  "../../../src/containers/Dashboard/dashboardApiHooks/useFetchTopNBandwidthData",
  () => ({
    ...jest.requireActual(
      "../../../src/containers/Dashboard/dashboardApiHooks/useFetchTopNBandwidthData",
    ),
    useFetchTopNBandwidthData: jest.fn(),
  })
);

const mockResponse = {
  result: [
    {
      id: "BTC0067294",
      category: "Change",
      priority: "1 - Critical",
      state: "Open",
      product: "",
      shortDescription: "Short description for Component testing Case creation",
      opened: "2024-01-24 10:09:33",
      installed_base_item: "Prisma-BT CORE CUSTOMER",
      service_offering: "",
      sys_id: "8ea4ccf71b3f795057f521f6b04bcbf5",
      sold_product: "Prisma-BT CORE CUSTOMER",
      proactive: "false",
      product_instance_id: "",
    },
    {
      id: "BTC0067111",
      category: "Change",
      priority: "1 - Critical",
      state: "Open",
      product: "",
      shortDescription: "Short description for Component testing Case creation",
      opened: "2024-01-22 09:23:32",
      installed_base_item: "Prisma-BT CORE CUSTOMER",
      service_offering: "",
      sys_id: "58f6e18f97b3fd50ce3e76ae2153af72",
      sold_product: "Prisma-BT CORE CUSTOMER",
      proactive: "false",
      product_instance_id: "",
    },
  ],
};

const internetData = [
  {
    name: "Example 1a",
    description:
      "Non-Resilient IPv4 only with 100Mbps static bandwidth, no threshold monitoring and static routing.",
    isResilient: false,
    primaryConnection: {
      portId: "0013L0001k0QAD",
      connectionId: "0013L0001O76E",
      VLANID: 200,
      encapsulation: "untagged",
      isEnabled: true,
      connectionStatus: "disabled",
      bandwidthType: "static",
      staticBandwidthConfig: {
        staticBandwidth: 100,
        isStaticBandwidthThreshold: false,
      },
      isPredictiveMonitoring: false,
      isBFD: true,
      IPVersion: "ipv4",
      IPAddressConfiguration: {
        ipv4Config: {
          WANId: "0013L000k6HER",
          BTWANAddress: "166.49.170.60/31",
          CustomerWANAddress: "166.49.170.61/31",
          isDHCP: false,
          LANConfig: [
            {
              LANId: "0013L000k6GAD",
            },
          ],
        },
      },
      routingType: "static",
      routingConfig: {
        ipv4StaticConfig: {
          staticConfig: {
            staticRouteCollection: [
              {
                prefix: "212.127.15.64",
                prefixLength: 27,
                priority: 200,
              },
            ],
          },
        },
      },
    },
  }
];

describe("Dashboard Component", () => {
  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getGlobalSupportCases: jest.fn().mockResolvedValue(mockResponse),
      getInternetConnectionSearch: jest.fn().mockResolvedValue(internetData),
      deleteInternetConnection: jest.fn().mockResolvedValue({
        id: "971112a0-bda7-11ed-8c27-29dc5ccad45f",
        message: "Request processed successfully",
        state: "acknowledged"
      }),
    });
    (useFetchTopNData as jest.Mock).mockReturnValue({
      loading: false,
      data: topNMockData,
      error: null,
    });
    (useFetchTopNBandwidthData as jest.Mock).mockReturnValue({
      loading: false,
      data: topNMockBandwidthData,
      error: null,
    });

  });
  it("renders Dashboard component correctly", () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <BrowserRouter>
          <Dashboard />
        </BrowserRouter>
      </Provider>,
    );
    const dashboard = getByTestId("dashboard");
    expect(dashboard).toBeInTheDocument();
  });
});
