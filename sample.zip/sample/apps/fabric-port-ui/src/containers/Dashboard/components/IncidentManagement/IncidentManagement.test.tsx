import React from "react";
import { render, screen, fireEvent, act } from "@testing-library/react";
import IncidentManagement from "./";
import { useApi } from "../../../../shared/helpers";
import { AppProvider } from "../../../../context/AppContext";
import { portsWithAllStatus } from "../../../../shared/constants/portInventory";
import { mockIpAddressResponse } from "../../../../shared/constants/IPAddressInventory";
import { internetTestData } from "../../../../shared/constants/internetConnection";
import { mockUserProfile } from "../../../../shared/constants";

jest.mock("../../../../shared/helpers/api", () => ({
  useApi: jest.fn(),
}));

jest.mock("../../../../authConfig", () => ({
  getAccessToken: jest.fn().mockResolvedValue({}),
}));

jest.mock("react-redux", () => ({
  useDispatch: () => jest.fn(),
}));

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useLocation: () => ({
    pathname: "/mock/path",
  }),
}));

const mockResponse = {
  result: [
    {
      id: "BTC0067294",
      category: "Change",
      priority: "1 - Critical",
      state: "Open",
      product: "",
      shortDescription: "Short description for Component testing Case creation",
      opened: "2024-01-24 10:09:33",
      installed_base_item: "Prisma-BT CORE CUSTOMER",
      service_offering: "",
      sys_id: "8ea4ccf71b3f795057f521f6b04bcbf5",
      sold_product: "Prisma-BT CORE CUSTOMER",
      proactive: "false",
      product_instance_id: "",
    },
    {
      id: "BTC0067111",
      category: "Change",
      priority: "1 - Critical",
      state: "Open",
      product: "",
      shortDescription: "Short description for Component testing Case creation",
      opened: "2024-01-22 09:23:32",
      installed_base_item: "Prisma-BT CORE CUSTOMER",
      service_offering: "",
      sys_id: "58f6e18f97b3fd50ce3e76ae2153af72",
      sold_product: "Prisma-BT CORE CUSTOMER",
      proactive: "false",
      product_instance_id: "",
    },
  ],
};

describe("Incident Management", () => {
  beforeAll(() => {
    window.open = jest.fn();
  });

  beforeEach(() => {
    (useApi as jest.Mock).mockReturnValue({
      getGlobalSupportCases: jest.fn().mockResolvedValue(mockResponse),
      portSearch: jest.fn().mockResolvedValue(portsWithAllStatus),
      getIpAddressSearch: jest.fn().mockResolvedValue(mockIpAddressResponse),
      getUserProfile: jest.fn().mockResolvedValue(mockUserProfile),
      getInternetConnectionSearch: jest
        .fn()
        .mockResolvedValue(internetTestData),
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("renders the IncidentManagement component correctly", async () => {
    await act(async () => render(<IncidentManagement />));
    const widget = screen.getByTestId("IncidentManagement");
    expect(widget).toBeInTheDocument();
  });

  it("renders the report issue button", async () => {
    await act(async () => render(<IncidentManagement />));
    const btn = screen.getByRole("button", { name: "Raise a case" });
    expect(btn).toBeInTheDocument();
  });

  it("renders the view all incidents button", async () => {
    await act(async () => render(<IncidentManagement />));
    const btn = screen.getByRole("button", { name: "View all Cases" });
    expect(btn).toBeInTheDocument();
    act(() => {
      fireEvent.click(btn);
    });
    expect(window.open).toHaveBeenCalled();
  });

  it("hides priority column after clicking on resolved", async () => {
    await act(async () =>
      render(
        <AppProvider>
          <IncidentManagement />
        </AppProvider>
      )
    );
    const resolved = screen.getAllByText("Closed")[0];
    fireEvent.click(resolved);
    expect(
      screen.queryByRole("cell", { name: "Priority" })
    ).not.toBeInTheDocument();
  });

  it("show priority column after clicking on inprogresss", async () => {
    await act(async () =>
      render(
        <AppProvider>
          <IncidentManagement />
        </AppProvider>
      )
    );
    const resolved = screen.getAllByText("Closed")[0];
    fireEvent.click(resolved);
    const inProgress = screen.getAllByText("Open")[0];
    fireEvent.click(inProgress);
    expect(
      screen.queryByRole("cell", { name: "Priority" })
    ).toBeInTheDocument();
  });

  it("renders the view all incidents button", async () => {
    await act(async () =>
      render(
        <AppProvider>
          <IncidentManagement />
        </AppProvider>
      )
    );
    const btn = screen.getByRole("button", { name: "View all Cases" });
    expect(btn).toBeInTheDocument();
    act(() => {
      fireEvent.click(btn);
    });
    expect(window.open).toHaveBeenCalled();
  });
});
