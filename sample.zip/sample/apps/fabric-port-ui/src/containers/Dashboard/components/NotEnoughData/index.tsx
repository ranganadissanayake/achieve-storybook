import React from "react";
import notEnoughData from "../../../../shared/assets/images/svg/not-enough-data.svg";

import "./NotEnoughData.scss";

interface NotEnoughDataProps {}

const NotEnoughData: React.FC<NotEnoughDataProps> = () => {
  return (
    <section className="no_data" data-testid="not_enough_data">
      <div className="no_data_content">
        <img
          src={notEnoughData}
          alt="Not Enough Data"
          className="not_enough_data_icon"
        />
        <label className="not_enough_data_text">
          Not enough data to report this metric
        </label>
      </div>
    </section>
  );
};

export default NotEnoughData;
