import React from "react";

import "./AlertTile.scss";
import { Card } from "@btdigital/nayan-component-library";
import GFHeading from "../../../../components/GFHeading";

export interface AlertTileProps {
  iconName: string;
  mainHeading: string;
  subHeading: string;
}

const AlertTile: React.FC<AlertTileProps> = ({
  iconName,
  mainHeading,
  subHeading,
}) => {
  return (
    <>
      <section className="alert-tile-wrapper">
        <Card>
          <section className="alert-tile-icon">
            <img src={iconName} alt={iconName + "-image"} />
          </section>
          <ul className="main-content-wrapper">
            <GFHeading size="S3" text={mainHeading} weight="regular" />
            <GFHeading
              size="S6"
              weight="light"
              className="sub-heading"
              text={subHeading}
            />
          </ul>
        </Card>
      </section>
    </>
  );
};

export default AlertTile;
