import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

import { Map, Button } from "@btdigital/nayan-component-library";

import CardBlock from "../../../../components/CardBlock";
import GFHeading from "../../../../components/GFHeading";
import { PORTS } from "../../../../shared/constants/map";
import SeletonLoader from "../../../../components/SeletonLoader";
import useAppContext from "../../../../shared/hooks/useAppContext";
import Filter from "./Filter";
import images from "../../../../shared/assets";
import { selectCurrentUser } from "../../../../redux/userProfileSlice";

import "./NetworkMapWidget.scss";

const NetworkMapWidget = () => {
  const { loadingDashboard } = useAppContext();
  const navigate = useNavigate();
  const { organisation } = useSelector(selectCurrentUser);

  const [toggleFilter, setToggleFilter] = useState(false);

  const [portStatus, setPortStatus] = useState<"up" | "down" | "disabled">();

  const mapProps = {
    focus: {
      lat: 32.386095015731556,
      lng: -31.156612392918582,
    },
    data: portStatus
      ? PORTS.filter(
          (site) => site.portStatus === portStatus && portStatus
        ).map((port) => {
          return {
            portId: port.portId,
            serviceId: port.serviceId,
            position: port.position,
            label: `${port.numberOfPorts ?? ""}`,
            type: "city",
            status: port.portStatus,
            number: port.numberOfPorts ?? 1,
            needAttention: port.needAttention ?? 0,
            name: port.portName,
            speed: port.speed,
            provider: port.providerName,
            logo: port.providerLogo,
            portStatus: port.portStatus ?? {
              up: port.numberOfPorts ?? 1,
              warning: 0,
              critical: 0,
            },
          };
        })
      : PORTS.map((port) => {
          return {
            portId: port.portId,
            serviceId: port.serviceId,
            position: port.position,
            label: `${port.numberOfPorts ?? ""}`,
            type: "city",
            status: port.portStatus,
            number: port.numberOfPorts ?? 1,
            needAttention: port.needAttention ?? 0,
            name: port.portName,
            speed: port.portSpeed,
            provider: port.providerName,
            logo: port.providerLogo,
            portStatus: port.groupedPortStatus ?? {
              up: port.numberOfPorts ?? 1,
              warning: 0,
              critical: 0,
            },
          };
        }),
    showInfoWindow: false,
  };

  const handleOnclickFilter = () => {
    setToggleFilter(!toggleFilter);
  };

  const _onMoreDetailsClicked = (portId: string) => {
    const portData = PORTS.find((port) => port.portId === portId);

    navigate(
      `${
        portData?.numberOfPorts && portData?.numberOfPorts > 1
          ? "/port-inventory"
          : portData?.portStatus === "up"
          ? "/port-inventory/detail"
          : "/notifications/port"
      }`,
      {
        state: { rowData: portData },
      }
    );
  };
  const onChageFilterUp = () => {
    setPortStatus("up");
  };
  const onChageFilterDown = () => {
    setPortStatus("down");
  };
  const onChageFilterDisabled = () => {
    setPortStatus("disabled");
  };

  return (
    <div
      className="widget-content network-map-widget"
      data-testid="network-map-widget"
    >
      <CardBlock className="custom-card">
        <CardBlock.Head className="pt-8 pb-8 pr-16 pl-16 mb-2">
          <GFHeading
            size="S5"
            text={
              organisation?.orgName
                ? `${organisation?.orgName} Network Map`
                : "Network Map"
            }
            weight="regular"
          />
        </CardBlock.Head>
        <CardBlock.Body>
          {loadingDashboard ? (
            <SeletonLoader layout={"mapView"} className="skeleton_mapArea" />
          ) : (
            !loadingDashboard && (
              <>
                <Map
                  mapType="network"
                  zoom={2.3}
                  coordinate={mapProps}
                  handleMoreDetails={_onMoreDetailsClicked}
                />
                {portStatus && (
                  <img
                    src={images.blueDot}
                    alt=""
                    srcSet=""
                    className="filter-enabled"
                  />
                )}
                <Button
                  onPress={handleOnclickFilter}
                  variant="white"
                  enableOriginalIcon
                  iconTitle={
                    toggleFilter ? "filter_default" : "filter_disabled"
                  }
                  className={`filter_btn ${
                    toggleFilter ? "enabled_filter" : "default_filter"
                  }`}
                />
              </>
            )
          )}
        </CardBlock.Body>
      </CardBlock>
      <Filter
        isToggle={toggleFilter}
        onClose={handleOnclickFilter}
        filterOption={portStatus}
        onChangeFilterUp={onChageFilterUp}
        onChangeFilterDown={onChageFilterDown}
        onChangeFilterDisabled={onChageFilterDisabled}
      />
    </div>
  );
};
export default NetworkMapWidget;
