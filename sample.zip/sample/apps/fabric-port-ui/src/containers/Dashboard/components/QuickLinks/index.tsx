import React from "react";

import { IconName } from "@btdigital/nayan-component-library";

import QuickLink from "./QuickLink";
import GFHeading from "../../../../components/GFHeading";
import CardBlock from "../../../../components/CardBlock";

import "./QuickLinks.scss";
import SeletonLoader from "../../../../components/SeletonLoader";
import useAppContext from "../../../../shared/hooks/useAppContext";

const QUICKLINKS: QuickLinkType[] = [
  {
    title: "Getting Started with Global Fabric",
    body: "Comprehensive how-to guides, tutorials, and a knowledge base are available to help you begin with the utmost ease.",
    icon: "idea",
  },
  {
    title: "API Documentation",
    body: "Our API Docs are a vital reference with all the info you need to integrate.",
    icon: "json",
  },
  {
    title: "Help Centre",
    body: "Got questions? We’ve got answers! Find the information you need within our Help Centre.",
    icon: "help",
  },
  {
    title: "Getting Started with Global Fabric",
    body: "Comprehensive how-to guides, tutorials, and a knowledge base are available to help you begin with the utmost ease.",
    icon: "idea",
  },
  {
    title: "API Documentation",
    body: "Our API Docs are a vital reference with all the info you need to integrate.",
    icon: "json",
  },
  {
    title: "Help Centre",
    body: "Got questions? We’ve got answers! Find the information you need within our Help Centre.",
    icon: "help",
  },
];

interface QuickLinkType {
  title: string;
  body: string;
  icon: IconName;
}

interface QuickLinksProps {}

const QuickLinks: React.FC<QuickLinksProps> = () => {
  const { loadingDashboard } = useAppContext();
  const [_quickLinks, setQuickLinks] = React.useState<QuickLinkType[]>([]);
  React.useEffect(() => {
    if(loadingDashboard===false) {
      setQuickLinks(QUICKLINKS);
    }
  }, [loadingDashboard]);

  return (
    <div className="quick_links" data-testid="quick_links">
      <CardBlock className="quick_links_card">
        <CardBlock.Head enableHeaderBorder className="pt-8 pl-16 pr-16">
          <GFHeading size="S5" text="Quick Links" weight="regular" />
        </CardBlock.Head>
        <CardBlock.Body className="cardBlock-body">
          <main className="quick_link_body pl-16 pb-16">
            {_quickLinks.length > 0 && !loadingDashboard
              ? _quickLinks.map(({ title, body, icon }) => (
                  <QuickLink
                    key={title}
                    title={title}
                    text={body}
                    icon={icon}
                  />
                ))
              : Array.from(Array(10).keys()).map((val, i) => (
                <SeletonLoader key={i} layout={"rowViewWide"} numberOfRows={val}/>
                ))}
          </main>
        </CardBlock.Body>
      </CardBlock>
    </div>
  );
};

export default QuickLinks;
