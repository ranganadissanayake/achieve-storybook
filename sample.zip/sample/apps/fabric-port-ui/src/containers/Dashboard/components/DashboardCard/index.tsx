import React from "react";

import { Card, Icon, Label } from "@btdigital/nayan-component-library";
import dots from "../../../../shared/assets/images/svg/dots-vertical.svg";

import "./DashboardCard.scss";

interface DashboardCardProps {
  title: string;
  tabs?: string[];
  children?: React.ReactNode;
  dashboardStyles?: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  children,
  dashboardStyles = "",
  tabs = [],
}) => {
  return (
    <Card cardStyle={`dashboard_card ${dashboardStyles}`}>
      <header className="dashboard_card_header">
        <div className="dashboard_title">
          <Icon title="chevron_down_2px" size="sm" />
          <Label text={title} />
        </div>
        <div>
          <img
            className="three-dots"
            style={{ width: "20px", height: "20px" }}
            src={dots}
            alt="context-icon"
          />
        </div>
      </header>
      <section
        className={`dashboard_card_body ${tabs.length === 0 ? "no_tabs" : ""}`}
      >
        {tabs.length > 0 && (
          <ul className="tab_nav">
            {tabs.map((tab, index) => (
              <li className={`${index === 0 ? "active" : ""}`} key={tab}>
                {tab}
              </li>
            ))}
          </ul>
        )}

        {children}
      </section>
    </Card>
  );
};

export default DashboardCard;
