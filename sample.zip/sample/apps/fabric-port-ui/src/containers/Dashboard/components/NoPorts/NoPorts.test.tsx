import React from "react";
import { render, screen } from "@testing-library/react";
import NoPort from "./index";

jest.mock("react-router-dom", () => ({
  useNavigate: jest.fn(),
}));

describe("No Port Compoent", () => {
  it("render the component with buttons and labels", () => {
    render(<NoPort />);
    expect(screen.getByText("Create your first port")).toBeInTheDocument();
    expect(screen.getByText("Know more")).toBeInTheDocument();
    expect(screen.getByText("Create Port")).toBeInTheDocument();
  });
});
