import React from "react";
import { render, screen } from "@testing-library/react";
import Spotlight from "./index";

describe("Spotlight", () => {
  beforeEach(() => {
    render(<Spotlight title="Link Tile" text="Link Text" imgUrl="idea" />);
  });

  it("renders the Spotlight component", () => {
    expect(screen.getByTestId("spotlight")).toBeInTheDocument();
  });

  it("renders the with correct title and body text", () => {
    expect(screen.getByText("Link Tile")).toBeInTheDocument();
    expect(screen.getByText("Link Text")).toBeInTheDocument();
  });

  it("renders the Spotlight img", () => {
    expect(screen.getByTestId("spotlight-img")).toBeInTheDocument();
  });
});
