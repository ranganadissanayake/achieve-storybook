import React from "react";

import { Button, Label } from "@btdigital/nayan-component-library";

import "./Spotlight.scss";

interface SpotlightProps {
  title: string;
  text: string;
  imgUrl: string;
}

const Spotlight: React.FC<SpotlightProps> = ({ title, text, imgUrl }) => {
  return (
    <section className="spotlight" data-testid="spotlight">
      <div className="image_wrapper">
        <img
          data-testid="spotlight-img"
          src={imgUrl}
          className="spotlight_icon"
        />
      </div>
      <div className="spotlight_content">
        <Label
          text={title}
          size="xs"
          helperTextStyles="spotlight_text"
          helper={text}
        />
        <Button
          className="spotlight_btn"
          variant="link"
          enableOriginalIcon={true}
          iconSize="sm"
          iconTitle="chevron_right"
        />
      </div>
    </section>
  );
};

export default Spotlight;
