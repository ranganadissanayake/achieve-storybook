import React from "react";
import { render, screen } from "@testing-library/react";
import user from "@testing-library/user-event";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";

import store from "../../../../redux/store";
import { ApiProvider } from "../../../../shared/helpers/api";
import { MOCK_PORTS_DATA } from "../../../../containers/Dashboard/utils/mock_data";
import PeakUtilisation from "./";

describe("PeakUtilisation", () => {
  beforeEach(() => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <ApiProvider>
            <PeakUtilisation
              title="Top 5 Ports by Peak utilisation"
              subTitle="Most heavily used ports, ranked by their peak utilisation"
              rawData={MOCK_PORTS_DATA}
              ctaText="View all ports"
              ctaLink="/port-inventory"
            />
          </ApiProvider>
        </BrowserRouter>
      </Provider>
    );
  });

  it("renders the PeakUtilisation component correctly", () => {
    const widget = screen.getByTestId("peak_utilisation");
    expect(widget).toBeInTheDocument();
  });

  it("renders the correct component title", () => {
    const title = screen.getByText("Top 5 Ports by Peak utilisation");
    expect(title).toBeInTheDocument();
  });

  it("renders the correct component sub-title", () => {
    const subTitle = screen.getByText(
      "Most heavily used ports, ranked by their peak utilisation"
    );
    expect(subTitle).toBeInTheDocument();
  });

  it("renders the date dropdown", () => {
    const dateDropdown = screen.getByPlaceholderText("Today");
    expect(dateDropdown).toBeInTheDocument();
    expect(screen.getByText("Today")).toBeInTheDocument();
  });

  it("clicking on dropdown displays other options", () => {
    const dateDropdown = screen.getByPlaceholderText("Today");
    user.click(dateDropdown);
    expect(screen.getByText("Yesterday")).toBeInTheDocument();
    expect(screen.getByText("Last week")).toBeInTheDocument();
    expect(screen.getByText("Last month")).toBeInTheDocument();
  });

  it("renders the graph labels", () => {
    setTimeout(()=>{const graphLabels = screen.getByTestId("graph_labels");
    expect(graphLabels).toBeInTheDocument();},5001);
  });

  it("renders the correct map key content", () => {
    setTimeout(()=>{const rx = screen.getByText("RX (Received)");
    expect(rx).toBeInTheDocument();
    const rxIcon = screen.getByAltText("rx");
    expect(rxIcon).toBeInTheDocument();

    const tx = screen.getByText("TX (Transmitted)");
    expect(tx).toBeInTheDocument();
    const txIcon = screen.getByAltText("tx");
    expect(txIcon).toBeInTheDocument();},5001);
  });

  it("renders the view all button with correct text", () => {
    const button = screen.getByTestId("view_all_btn");
    expect(button).toBeInTheDocument();
    const ctaText = screen.getByText("View all ports");
    expect(ctaText).toBeInTheDocument();
  });

  it("renders the peak utilisation graph", () => {
    setTimeout(()=>{const peakGraph = screen.getByTestId("peack_graph");
    expect(peakGraph).toBeInTheDocument();},5001);
  });

  it("clicking the view all button navigates to the required link", () => {
    const button = screen.getByRole("button", { name: /View all ports/i });
    user.click(button);

    setTimeout(() => {
      expect(window.location.pathname).toBe("/port-inventory");
    }, 500);
  });
});
