import React from "react";
import { render, screen } from "@testing-library/react";
import Spotlight from "./index";

describe("Spotlight", () => {
  beforeEach(() => {
    render(<Spotlight />);
  });

  it("renders the quick links component", () => {
    expect(screen.getByTestId("spotlights")).toBeInTheDocument();
  });

  it("renders the with correct title of the component", () => {
    expect(screen.getByText("Spotlight")).toBeInTheDocument();
  });
});
