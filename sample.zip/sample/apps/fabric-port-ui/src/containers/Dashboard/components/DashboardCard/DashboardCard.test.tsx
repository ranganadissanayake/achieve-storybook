import React from "react";
import { render, screen } from "@testing-library/react";
import DashboardCard from "./";

describe("DashboardCard component", () => {
  it("renders component with given title", () => {
    render(<DashboardCard title="Dashboard Card" />);

    expect(screen.getByText("Dashboard Card")).toBeInTheDocument();
  });
  it("renders component with given tabs", () => {
    render(<DashboardCard title="Dashboard Card" tabs={["Tab 1", "Tab 2"]} />);

    expect(screen.getByText("Tab 1")).toBeInTheDocument();
    expect(screen.getByText("Tab 2")).toBeInTheDocument();
  });
});
