import React from "react";
import { render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import NetworkMapWidget from "./index";
import store from "../../../../redux/store";

jest.mock("@btdigital/nayan-component-library", () => {
  return {
    Map: ({}) => {
      return (
        <div data-testid="map-component">
          <p>Map Component</p>
        </div>
      );
    },
  };
});

describe("NetworkMapWidget Component", () => {
  it("renders without errors", () => {
    render(
      <Provider store={store}>
        <BrowserRouter>
          <NetworkMapWidget />
        </BrowserRouter>
      </Provider>
    );
    const widget = screen.getByTestId("network-map-widget");
    expect(widget).toBeInTheDocument();
  });
});
