import React from "react";
import { useNavigate } from "react-router-dom";
import { Bar } from "react-chartjs-2";
import { Columns } from "@arc-ui/components/dist/Columns";
import { VerticalSpace } from "@arc-ui/components/dist/VerticalSpace";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Button } from "@btdigital/nayan-component-library";

import CardBlock from "../../../../components/CardBlock";
import SeletonLoader from "../../../../components/SeletonLoader";
import GFHeading from "../../../../components/GFHeading";
import usedBandwidth from "../../../../shared/assets/images/svg/used-bandwidth.svg";
import availableBandwidth from "../../../../shared/assets/images/svg/available-bandwidth.svg";

import "./TopFivePortsByBandwidth.scss";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);
import { getOptionsStackChart } from "../../../../shared/constants/graphData";
import useAppContext from "../../../../shared/hooks/useAppContext";
import NotEnoughData from "../NotEnoughData";

export interface DataStackChart {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor: string;
    barThickness: number;
    borderWidth?: number;
    borderColor?: string;
    borderSkipped?: boolean;
  }[];
}
export type TopFivePortsByBandwidthProps = {
  data: DataStackChart;
};

export const TopFivePortsByBandwidth: React.FC<
  TopFivePortsByBandwidthProps
> = ({ data }) => {
  const navigate = useNavigate();
  const { loadingDashboard } = useAppContext();
  const viewPortInventory = () => {
    navigate("/port-inventory");
  };

  return (
    <div
      className="widget-content stackbar-wrap"
      data-testid="TopFivePortsByBandwidth"
    >
      <CardBlock className="custom-card">
        <CardBlock.Head enableHeaderBorder className="pt-8 pl-16 pr-16">
          <div className="d-flex card-header-wrp">
            <div className="title-wrp">
              <span className="text-title">
                <GFHeading
                  size="S5"
                  text="Top 5 Ports by Bandwidth Allocation"
                  weight="regular"
                />
              </span>
              <span className="text-label">
                <GFHeading
                  size="S7"
                  text="Ports with the highest allocated bandwidth in your network"
                  weight="light"
                />
              </span>
            </div>
          </div>
        </CardBlock.Head>
        <CardBlock.Body className="cardBlock-body">
          {data.datasets.length > 0 ? (
            <section className="dashboard_card_body pt-8 pb-8 pl-16 pr-16">
              {loadingDashboard ? (
                <SeletonLoader
                  className="pt-48 pb-40 pl-20 pr-40"
                  layout="barChart"
                />
              ) : (
                <>
                  <div
                    className="bar_graph top_five_ports"
                    data-testId="bandwith_graph"
                  >
                    {data.labels.length && (
                      <div className="labels_wrap" data-testid="graph_labels">
                        {data.labels.map((label) => (
                          <a
                            key={label}
                            className="top_graph_label"
                            onClick={() => {
                              navigate("/port-inventory/detail");
                            }}
                          >
                            {label.substring(0, 15) + "..."}
                          </a>
                        ))}
                      </div>
                    )}
                    <Bar options={getOptionsStackChart(data)} data={data} />
                  </div>
                  <VerticalSpace size="16" />
                  <Columns>
                    <Columns.Col spanL={12} spanM={12}>
                      <div className="bandwidthText">
                        <img src={usedBandwidth} alt="used bandwidth" />
                        <GFHeading
                          size="S7"
                          text="Used bandwidth"
                          weight="light"
                        />

                        <img
                          src={availableBandwidth}
                          alt="available bandwidth"
                        />
                        <GFHeading
                          size="S7"
                          text="Available bandwidth"
                          weight="light"
                        />
                      </div>
                    </Columns.Col>
                  </Columns>

                  <VerticalSpace size="8" />
                </>
              )}
            </section>
          ) : (
            <NotEnoughData />
          )}

          <div>
            <Button
              label="View all ports"
              className="quick_link_btn view_all_btn"
              dataTestId="view_all_btn"
              variant="link"
              iconTitle="next_arrow_alt"
              enableOriginalIcon={true}
              iconSize="sm"
              onPress={viewPortInventory}
            />
          </div>
        </CardBlock.Body>
      </CardBlock>
    </div>
  );
};
export default TopFivePortsByBandwidth;
