import React from "react";
import { render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import Header from ".";
import store from "../../../../redux/store";

describe("Header", () => {
  it("renders the Header component correctly", () => {
    const { getByAltText, getByText } = render(
      <Provider store={store}>
        <BrowserRouter>
          <Header />
        </BrowserRouter>
      </Provider>,
    );

    const image = getByAltText("Fabric port");
    expect(image).toBeInTheDocument();

    const updatedText = getByText(/Updated \d+ mins ago/i);
    expect(updatedText).toBeInTheDocument();
  });

  it("displays 'Good morning' greeting in the morning", () => {
    jest.useFakeTimers();
    const morningTime = new Date("2023-11-07T07:00:00"); 
    jest.setSystemTime(morningTime);
    
    (
      <Provider store={store}>
        <BrowserRouter>
          <Header />
        </BrowserRouter>
      </Provider>
    );
  });

  it("displays 'Good afternoon' greeting in the afternoon", () => {
    jest.useFakeTimers();
    const afternoonTime = new Date("2023-11-07T15:00:00");
    jest.setSystemTime(afternoonTime);

    render(
      <Provider store={store}>
        <BrowserRouter>
          <Header />
        </BrowserRouter>
      </Provider>,
    );
  });

  it("displays 'Good evening' greeting in the evening", () => {
    jest.useFakeTimers();
    const eveningTime = new Date("2023-11-07T20:00:00"); 
    jest.setSystemTime(eveningTime);

     render(
      <Provider store={store}>
        <BrowserRouter>
          <Header />
        </BrowserRouter>
      </Provider>,
    );
  });
});
