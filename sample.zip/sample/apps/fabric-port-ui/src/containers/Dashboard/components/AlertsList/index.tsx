import React from "react";
import AlertTile, { AlertTileProps } from "../AlertTile";

interface AlertsListProps {
  alertsList: AlertTileProps[];
}

const AlertsList: React.FC<AlertsListProps> = ({ alertsList }) => {
  return (
    <>
      <div className="alerts-list-wrapper fp-row">
        {alertsList.map((alert, id) => (
          <div className="col-8" key={id}>
            <AlertTile
              key={id}
              iconName={alert.iconName}
              mainHeading={alert.mainHeading}
              subHeading={alert.subHeading}
            ></AlertTile>
          </div>
        ))}
      </div>
    </>
  );
};

export default AlertsList;
