import React from "react";
import { render } from "@testing-library/react";
import TopFivePortsByBandwidth from ".";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import store from "../../../../redux/store";
import { dataStackChart } from "../../../../shared/constants/graphData";

describe("TopFivePortsByBandwidth", () => {
  it("renders the TopFivePortsByBandwidth component correctly", () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <BrowserRouter>
          <TopFivePortsByBandwidth data={dataStackChart}/>
        </BrowserRouter>
      </Provider>
    );

    const widget = getByTestId("TopFivePortsByBandwidth");
    expect(widget).toBeInTheDocument();
  });

  it("renders the correct component title and sub-title", () => {
    const { getByText } = render(
      <Provider store={store}>
        <BrowserRouter>
          <TopFivePortsByBandwidth data={dataStackChart}/>
        </BrowserRouter>
      </Provider>
    );

    const title = getByText("Top 5 Ports by Bandwidth Allocation");
    expect(title).toBeInTheDocument();

    const subTitle = getByText(
      "Ports with the highest allocated bandwidth in your network"
    );
    expect(subTitle).toBeInTheDocument();
  });

  it("renders the correct map key content", () => {
    const { getByText, getByAltText } = render(
      <Provider store={store}>
        <BrowserRouter>
          <TopFivePortsByBandwidth data={dataStackChart}/>
        </BrowserRouter>
      </Provider>
    );
    setTimeout(()=>{
    const used = getByText("Used bandwidth");
    expect(used).toBeInTheDocument();
    const rxIcon = getByAltText("used bandwidth");
    expect(rxIcon).toBeInTheDocument();

    const available = getByText("Available bandwidth");
    expect(available).toBeInTheDocument();
    const availableIcon = getByAltText("available bandwidth");
    expect(availableIcon).toBeInTheDocument();},5001);
  });

  it("renders the Bandwidth Allocation graph", () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <BrowserRouter>
          <TopFivePortsByBandwidth data={dataStackChart}/>
        </BrowserRouter>
      </Provider>
    );
setTimeout(()=>{
    const bandwithAllocation = getByTestId("bandwith_graph");
    expect(bandwithAllocation).toBeInTheDocument();
}, 5001);
  });
});
