import React from "react";
import { render, screen } from "@testing-library/react";
import Alerts from "./index";

describe("Alerts Component", () => {
  it("renders the component with title", () => {
    render(<Alerts title="Custom Title" />);
    expect(screen.getByText("Custom Title")).toBeInTheDocument();
    const alertElements = screen.queryAllByText(
      "High Threshold (75%) exceeded"
    );
    expect(alertElements.length).toBeGreaterThan(0);
    alertElements.forEach((element) => {
      expect(element).toBeInTheDocument();
    });
  });
});
