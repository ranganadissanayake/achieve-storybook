import React from "react";

import {
  Button,
  Icon,
  IconName,
  Label,
} from "@btdigital/nayan-component-library";

import "./QuickLink.scss";

interface QuickLinkProps {
  title: string;
  text: string;
  icon: IconName;
}

const QuickLink: React.FC<QuickLinkProps> = ({ title, text, icon }) => {
  return (
    <section className="quick_link" data-testid="quick_link">
      <div>
        <div className="icon_wrapper">
          <div className="icon_container">
            <Icon
              title={icon}
              className="quick_link_icon"
              showOriginal={icon === "help"}
            />
          </div>
        </div>
      </div>
      <div className="quick_link_content">
        <Label
          text={title}
          size="sm"
          helperTextStyles="quick_link_text"
          helper={text}
        />
        <Button
          label="Go to API Docs"
          className="quick_link_btn"
          variant="link"
          iconTitle="next_arrow_alt"
          enableOriginalIcon={true}
          iconSize="sm"
        />
      </div>
    </section>
  );
};

export default QuickLink;
