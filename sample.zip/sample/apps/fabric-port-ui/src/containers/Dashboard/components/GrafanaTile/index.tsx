import React from "react";

import { Button, Icon } from "@btdigital/nayan-component-library";

import GFHeading from "../../../../components/GFHeading";
import CardBlock from "../../../../components/CardBlock";

import "./GrafanaTile.scss";

const GRAFANA_URL =
  "http://18.168.252.69:3000/globalfabric/grafana/d/d59b1527-7c3e-438b-83e3-647cff17c930/global-fabric-dashboard?orgId=1&refresh=5s";

interface GrafanaTileProps {}

const GrafanaTile: React.FC<GrafanaTileProps> = () => {
  return (
    <div className="grafana_tile" data-testid="grafana_tile">
      <CardBlock className="grafana_tile_card">
        <div className="grafana_tile_card_content">
          <Icon
            title="info_alt"
            showOriginal={true}
            className="information_icon"
          />
          <div className="grafana_tile_text_container">
            <GFHeading
              size="S6"
              weight="regular"
              color="black"
              text="Want to dive deeper into network performance?"
            />
            <GFHeading
              size="S6"
              weight="light"
              color="boat-anchor"
              text="Check out our dedicated performance monitoring dashboard."
            />
          </div>
        </div>
        <Button
          label="View Performance"
          className="quick_link_btn"
          dataTestId="quick_link_btn"
          variant="link"
          iconTitle="arrow_alt_right"
          enableOriginalIcon={true}
          iconSize="lg"
          onPress={() => window.open(GRAFANA_URL, "_blank")?.focus()}
        />
      </CardBlock>
    </div>
  );
};

export default GrafanaTile;
