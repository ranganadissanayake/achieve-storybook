import { Button, TableV2 } from "@btdigital/nayan-component-library";
import React, { useEffect, useState } from "react";
import CardBlock from "../../../../components/CardBlock";
import GFHeading from "../../../../components/GFHeading";
import SeletonLoader from "../../../../components/SeletonLoader";

import PriorityLabel from "../../../../components/PriorityLabel"
import dayjs from "dayjs";
import { useApi } from "../../../../shared/helpers";
import useAppContext from "../../../../shared/hooks/useAppContext";
import { IncidentInventoryItem } from "../../../../shared/mappers/classes/dto/globalSupportCases.dto";
import { GlobalSupportCaseEntity } from "../../../../shared/mappers/classes/entity/globalSupportCases.entity";
import { globalSupportResponseToInventoryItem } from "../../../../shared/mappers/services/globalSupportCase.service";
import { SUPPORT_CASE_STATE } from "../../../../shared/types";
import "./IncidentManagement.scss";

type ActiveTab = "progress" | "resolved";

const yearDateFormat = "YYYY-MM-DD";

export const sortByDate = (a: IncidentInventoryItem, b: IncidentInventoryItem) => {
  return new Date(b.date).getTime() - new Date(a.date).getTime();
}

const filterByIncidentType = (entity: IncidentInventoryItem) => entity?.name.toLowerCase() !== "service request";

const filterOnlyOpenCases = (entity: IncidentInventoryItem) =>
  entity.state == SUPPORT_CASE_STATE.NEW
  || entity.state == SUPPORT_CASE_STATE.OPEN
  || entity.state == SUPPORT_CASE_STATE.AWAITING_INFO;

const filterOnlyClosedCases = (entity: IncidentInventoryItem) =>
  entity.state == SUPPORT_CASE_STATE.CANCELLED
  || entity.state == SUPPORT_CASE_STATE.CLOSED
  || entity.state == SUPPORT_CASE_STATE.RESOLVED;

const IncidentManagement = () => {
  const api = useApi();
  const { loadingDashboard } = useAppContext()
  const [_activeTab, setActiveTab] = React.useState<ActiveTab>("progress");
  const [_incidentInventoryDataOpen, setInventoryDataOpen] = useState<IncidentInventoryItem[]>([]);
  const [_incidentInventoryDataClosed, setInventoryDataClosed] = useState<IncidentInventoryItem[]>([]);

  useEffect(() => {
    api
      .getGlobalSupportCases(
        5,
        SUPPORT_CASE_STATE.ALL,
        dayjs(Date.now()).subtract(29, 'day').format(yearDateFormat),
        dayjs(Date.now()).format(yearDateFormat))
      .then((response) => {
        const mappedData = response.result
          .map((entity: GlobalSupportCaseEntity) => globalSupportResponseToInventoryItem(entity));
        const filteredData = mappedData.filter(filterByIncidentType);
        filteredData.sort(sortByDate);
        setInventoryDataOpen(filteredData.filter(filterOnlyOpenCases));
        setInventoryDataClosed(filteredData.filter(filterOnlyClosedCases));
      })
      .catch((error) => console.log(error));
  }, []);


  const openIncidentDetails = (systemId: string) => {
    window.open(`${process.env.REACT_APP_HELP_SUPPORT_ITEM_DETAIL_LINK}&sys_id=${systemId}`, "_blank", "noopener,noreferrer")
  };

  const columns = [
    {
      accessorKey: "name",
      header: "Case",
      id: "name",
      cell: (cdata) => {
        return (
          <div className="incident_row">
            <GFHeading size="S6" text={cdata.getValue()} weight="regular" />
            <GFHeading
              size="S7"
              text={`Case ${cdata.row.original.id}`}
              weight="light"
              className="row_subtitle"
            />
          </div>
        );
      },
      sticky: "left",
    },
    {
      id: "priority",
      header: "Priority",
      accessorKey: "priority",
      cell: (cdata) => {
        return (
          <div className="priority_row">
            <PriorityLabel
              priority={cdata.getValue()}
            />
          </div>
        );
      },
    },
    {
      accessorKey: "service",
      header: "Service",
      id: "service",
      cell: (cdata) => {
        return <GFHeading
          size="S6"
          text={cdata.getValue()}
          weight="light"
        />;
      },
    },
    {
      accessorKey: "state",
      header: "Status",
      id: "state",
      cell: (cdata) => {
        return (
          <GFHeading
            size="S7"
            text={cdata.getValue()}
            weight="regular"
            className={`batch ${cdata.getValue().split(" ")[0].toLowerCase()}`}
          />
        );
      },
    },
    {
      accessorKey: "date",
      header: "Date",
      id: "date",
    },
    {
      accessorKey: "generated",
      header: "Generated",
      id: "generated",
      cell: (cdata) => {
        return (
          <GFHeading
            size="S7"
            text={cdata.getValue()}
            weight="regular"
            className="batch generated"
          />
        );
      },
    },
    {
      accessorKey: "sys_id",
      header: "",
      id: "action",
      cell: (cdata) => {
        return (
          <Button
            label="View details"
            variant="link"
            className="incident_action"
            onPress={() => openIncidentDetails(cdata.getValue())}
          />
        );
      },
    }
  ];

  const tableColumn = React.useMemo(
    () =>
      _activeTab === "progress"
        ? columns
        : columns.filter((col) => col.id !== "priority"),
    [_activeTab]
  );

  return (
    <div
      className="widget-content incident_management"
      data-testid="IncidentManagement"
    >
      <CardBlock className="custom-card">
        <CardBlock.Head className="pt-8 pl-16 pr-16 incident_header">
          <div className="d-flex card-header-wrp">
            <div className="title-wrp">
              <GFHeading
                size="S5"
                text="Case Management"
                weight="regular"
              />
            </div>
            <Button
              iconSize="sm"
              iconTitle="chevron_right_2px"
              label="Raise a case"
              variant="outline"
              className="report_an_issue_btn"
              onPress={() => window.open(`${process.env.REACT_APP_HELP_SUPPORT_REPORT_AN_ISSUE}`, "_blank", "noopener,noreferrer")}
            />
          </div>
        </CardBlock.Head>

        <CardBlock.Body className="cardBlock-body pt-16 pr-16 incident_body">
          {loadingDashboard ? (<SeletonLoader layout={"table"} numberOfRows={4} />) :
            (<><ul className="tab_nav">
              <li
                className={_activeTab === "progress" ? "active" : "inactive"}
                onClick={() => setActiveTab("progress")}
              >
                <GFHeading size="S6" text="Open" weight="regular" />
                <GFHeading
                  size="S7"
                  text={`${_incidentInventoryDataOpen.length}`}
                  weight="regular"
                  className="number"
                />
              </li>
              <li
                className={_activeTab === "resolved" ? "active" : "inactive"}
                onClick={() => setActiveTab("resolved")}
                data-testid="resolved"
              >
                <GFHeading size="S6" text="Closed" weight="regular" />
                <GFHeading
                  size="S7"
                  text={`${_incidentInventoryDataClosed.length}`}
                  weight="regular"
                  className="number"
                />
              </li>
            </ul>
              <TableV2
                enableStickyColumn={true}
                data={
                  _activeTab === "progress"
                    ? _incidentInventoryDataOpen
                    : _incidentInventoryDataClosed
                }
                columns={tableColumn}
                enableColumnResize={false}
                tableMaxWidth="100%"
                tableMinWidth="100%"
                enableFixHeader={true}
                tableMaxHeight="392px"
                noDataMessage="No data to show"
                tableClassName={`case-management-table --${_activeTab}`}
              /></>)}
          <div>
            <Button
              label="View all Cases"
              className="view_all_btn"
              dataTestId="view_all_btn"
              variant="link"
              iconTitle="next_arrow_alt"
              enableOriginalIcon={true}
              iconSize="sm"
              onPress={() => window.open(`${process.env.REACT_APP_HELP_SUPPORT_VIEW_ALL}`, "_blank", "noopener,noreferrer")}
            />
          </div>
        </CardBlock.Body>
      </CardBlock>
    </div>
  );
};
export default IncidentManagement;