import React from "react";
import { render, screen } from "@testing-library/react";

import NotEnoughData from "./";

describe("NotEnoughData", () => {
  beforeEach(() => {
    render(<NotEnoughData />);
  });

  it("renders the NotEnoughData component correctly", () => {
    const widget = screen.getByTestId("not_enough_data");
    expect(widget).toBeInTheDocument();
  });

  it("renders the correct text and icon", () => {
    const text = screen.getByText("Not enough data to report this metric");
    expect(text).toBeInTheDocument();
    const icon = screen.getByAltText("Not Enough Data");
    expect(icon).toBeInTheDocument();
  });
});
