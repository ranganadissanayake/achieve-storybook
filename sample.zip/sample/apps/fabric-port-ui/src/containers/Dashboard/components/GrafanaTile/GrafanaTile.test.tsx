import React from "react";
import { render, screen } from "@testing-library/react";
import GrafanaTile from "./index";

describe("Grafana Tile", () => {
  beforeEach(() => {
    render(<GrafanaTile />);
  });

  it("renders the quick link component", () => {
    expect(screen.getByTestId("grafana_tile")).toBeInTheDocument();
  });

  it("renders with correct title and body text", () => {
    expect(
      screen.getByText("Want to dive deeper into network performance?")
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        "Check out our dedicated performance monitoring dashboard."
      )
    ).toBeInTheDocument();
  });

  it("renders the view performance button", () => {
    expect(screen.getByTestId("quick_link_btn")).toBeInTheDocument();
    expect(screen.getByText("View Performance")).toBeInTheDocument();
  });
});
