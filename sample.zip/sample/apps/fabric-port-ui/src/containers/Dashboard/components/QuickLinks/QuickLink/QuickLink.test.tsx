import React from "react";
import { render, screen } from "@testing-library/react";
import QuickLink from "./index";

describe("Quick Link", () => {
  beforeEach(() => {
    render(<QuickLink title="Link Tile" text="Link Text" icon="idea" />);
  });

  it("renders the quick link component", () => {
    expect(screen.getByTestId("quick_link")).toBeInTheDocument();
  });

  it("renders the with correct title and body text", () => {
    expect(screen.getByText("Link Tile")).toBeInTheDocument();
    expect(screen.getByText("Link Text")).toBeInTheDocument();
  });

  it("renders the quick link icon", () => {
    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });
});
