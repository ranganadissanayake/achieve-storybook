import React from "react";

import "../QuickLink/QuickLink.scss";
import "./QuickLinkLoading.scss";

interface QuickLinkLoadingProps {}

const QuickLinkLoading: React.FC<QuickLinkLoadingProps> = () => {
  return (
    <section
      className="quick_link quick_link_loading"
      data-testid="quick_link_loading"
    >
      <div>
        <div className="icon_wrapper">
          <div className="icon_container"></div>
        </div>
      </div>
      <div className="quick_link_content">
        <div className="quick_link_title"></div>
        <div className="quick_link_text"></div>
      </div>
    </section>
  );
};

export default QuickLinkLoading;
