import React from "react";
import { render, screen } from "@testing-library/react";
import QuickLinks from "./index";

describe("Quick Links", () => {
  beforeEach(() => {
    render(<QuickLinks />);
  });

  it("renders the quick links component", () => {
    expect(screen.getByTestId("quick_links")).toBeInTheDocument();
  });

  it("renders with correct title of the component", () => {
    expect(screen.getByText("Quick Links")).toBeInTheDocument();
  });
});
