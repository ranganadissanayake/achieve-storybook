import React from "react";

import { Card, Divider } from "@btdigital/nayan-component-library";

import Spotlight from "./SpotlightItem";
import images from "../../../../shared/assets";

import "./Spotlights.scss";
import GFHeading from "../../../../components/GFHeading";
import SeletonLoader from "../../../../components/SeletonLoader";
import useAppContext from "../../../../shared/hooks/useAppContext";

const SPOTLIGHTS: SpotlightType[] = [
  {
    title: "Global Fabric is all set to connect to AWS",
    body: "Sep 29, 2023",
    imgUrl: images.awsSpot,
  },
  {
    title: "Global Fabric rolled out in South America",
    body: "Sep 15, 2023",
    imgUrl: images.rolloutSpot,
  },
  {
    title: "BT recognised for an 18th year in the 2023 Gartner Magic Quadrant",
    body: "Aug 4, 2023",
    imgUrl: images.quadrantSpot,
  },
  {
    title:
      "Introducing an Enhanced Monitoring Dashboard with In-Depth Insights",
    body: "Jul 9, 2023",
    imgUrl: images.insightSpot,
  },
];

interface SpotlightType {
  title: string;
  body: string;
  imgUrl: string;
}

interface SpotlightsProps {}

const Spotlights: React.FC<SpotlightsProps> = () => {
  const { loadingDashboard } = useAppContext()
  return (
    <div className="spotlights" data-testid="spotlights">
      <Card cardStyle="spotlight_card">
        <GFHeading size="S5" text="Spotlight" weight="regular" />
        <Divider margin="md" className="divider" />
        {loadingDashboard ? (<SeletonLoader layout={"rowViewWithArrow"} numberOfRows={4} className="pt-16card-skeleton pos-r pt-16 pb-4 mt-8" />) :(
        <main className="spotlight_body">
          {SPOTLIGHTS.map(({ title, body, imgUrl }) => (
            <Spotlight key={title} title={title} text={body} imgUrl={imgUrl} />
          ))}
        </main>)}
      </Card>
    </div>
  );
};

export default Spotlights;
