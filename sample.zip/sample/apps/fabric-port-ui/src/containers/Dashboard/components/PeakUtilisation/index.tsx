import React from "react";
import { useNavigate } from "react-router-dom";
import { Bar } from "react-chartjs-2";

import { Button, DropdownInput } from "@btdigital/nayan-component-library";
import { Columns, VerticalSpace } from "@arc-ui/components";

import CardBlock from "../../../../components/CardBlock";
import GFHeading from "../../../../components/GFHeading";
import rxReceived from "../../../../shared/assets/images/svg/rx-received.svg";
import txTransmitted from "../../../../shared/assets/images/svg/tx-transmitted.svg";
import NotEnoughData from "../NotEnoughData";
import {
  PeakUtilisationData,
  generatePeakUtilisation,
} from "../../utils/peackUtilisationGraphData";

import "../TopFivePortsByBandwidth/TopFivePortsByBandwidth.scss";
import "./PeakUtilisation.scss";
import SeletonLoader from "../../../../components/SeletonLoader";
import useAppContext from "../../../../shared/hooks/useAppContext";

interface PeakUtilisationProps {
  title: string;
  subTitle: string;
  ctaText: string;
  ctaLink?: string;
  rawData: PeakUtilisationData[];
  onSelectDate?: (data: any) => void;
  selectedValue?: string;
}

const PeakUtilisation: React.FC<PeakUtilisationProps> = ({
  title,
  subTitle,
  ctaText,
  ctaLink = "/",
  rawData,
  onSelectDate,
  selectedValue
}) => {
  const navigate = useNavigate();
  const { loadingDashboard } = useAppContext();
  const { data, options, labels } = generatePeakUtilisation(rawData);

  return (
    <div
      className="widget-content stackbar-wrap top_five_ports"
      data-testid="peak_utilisation"
    >
      <CardBlock className="custom-card">
        <CardBlock.Head enableHeaderBorder className="pt-8 pl-16 pr-16">
          <div className="d-flex top_five_header">
            <div className="title-wrp">
              <GFHeading size="S5" weight="regular" text={title} />
              <GFHeading
                className="text-label"
                size="S7"
                weight="light"
                text={subTitle}
              />
            </div>
            <div>
              <DropdownInput
                type="number"
                name="timeDate"
                value={selectedValue}
                placeholder="Today"
                onlySelectedValue={false}
                keepErrorSpace={true}
                className="date_selector"
                options={[
                  { id: "past4Hours", value: "Today" },
                  { id: "past8Hours", value: "Last 8 hrs" },
                  { id: "past12Hours", value: "Last 12 hrs" },
                  { id: "past24hrs", value: "Yesterday" },
                  { id: "lastWeek", value: "Last week" },
                  { id: "lastMonth", value: "Last month" },
                  { id: "pastYear", value: "Last year" },
                ]}
                onSelect={onSelectDate}
              />
            </div>
          </div>
        </CardBlock.Head>
        <CardBlock.Body className="cardBlock-body">
          <section className="dashboard_card_body top_five_body pt-8 pb-8 pl-16 pr-16">
          {loadingDashboard ? (<SeletonLoader className="pt-48 pb-40 pl-20 pr-40" layout="barChart" numberOfBars ={['width-80', 'width-40', 'width-50', 'width-60', 'width-30'] }/>):(
          <>{labels.length > 0 ? (
            <>
              {labels.length === 5 && (
                <div className="graph_labels" data-testid="graph_labels">
                  {labels.map((label) => (
                    <a
                      key={label}
                      className="graph_label"
                      onClick={() => {
                        navigate("/port-inventory/detail");
                      }}
                    >
                      {label}
                    </a>
                  ))}
                </div>
              )}
              <div className="bar_graph" data-testId="peack_graph">
                <Bar data={data} options={options} />
              </div>
              <VerticalSpace size="16" />
              <Columns>
                <Columns.Col spanL={12} spanM={12}>
                  <div className="bandwidthText">
                    <img src={rxReceived} alt="rx" />
                    <GFHeading size="S7" text="RX (Received)" weight="light" />

                    <img src={txTransmitted} alt="tx" />
                    <GFHeading
                      size="S7"
                      text="TX (Transmitted)"
                      weight="light"
                    />
                  </div>
                </Columns.Col>
              </Columns>
              <VerticalSpace size="8" />
            </>
          ) : (
            <NotEnoughData />
            )}</>)}
          </section>
          <div>
            <Button
              label={ctaText}
              className="view_all_btn"
              dataTestId="view_all_btn"
              variant="link"
              iconTitle="next_arrow_alt"
              enableOriginalIcon={true}
              iconSize="sm"
              onPress={() => navigate(ctaLink)}
            />
          </div>
        </CardBlock.Body>
      </CardBlock>
    </div>
  );
};

export default React.memo(PeakUtilisation);
