import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@btdigital/nayan-component-library";
import { VerticalSpace } from "@arc-ui/components/dist/VerticalSpace";
import { Image } from "@arc-ui/components/dist/Image";
import { Align } from "@arc-ui/components/dist/Align";
import "./NoPorts.scss";
import noPortNew from "../../../../shared/assets/images/no-ports-new.png";
import GFHeading from "../../../../components/GFHeading";
import CardBlock from "../../../../components/CardBlock";

const NoPorts = () => {
  const navigate = useNavigate();
  return (
    <>
      <div className="widget-content no-ports-wrapper">
        <CardBlock className="custom-card">
          <CardBlock.Body className="cardBlock-body">
            <div className="no-port-content-section">
              <VerticalSpace size="32" />
              <Align vertical="center" horizontal="center">
                <Image src={noPortNew} />
              </Align>
              <VerticalSpace size="16" />

              <GFHeading
                size="S4"
                text="Create your first port"
                weight="regular"
                align="center"
              />
              <GFHeading size="S7" text="" weight="light" align="center">
                <p className="no-port-para">
                  It appears you don't have any ports at the moment. To begin,
                  let's get{""}
                  <br />
                  started by creating your very first port.
                </p>
              </GFHeading>
              <VerticalSpace size="8" />
            </div>
            <div className="fp-row">
              <div className="col-8">
                <Align horizontal="right">
                  <Button
                    label="Know more"
                    size="medium"
                    variant="outline"
                    iconCustomStyle="action-button"
                  />
                </Align>
              </div>
              <div className="col-8">
                <Align horizontal="left">
                  <Button
                    iconCustomStyle="action-button"
                    label="Create Port"
                    onPress={() => navigate("/create-new-port")}
                    variant="gradient"
                    size="medium"
                  />
                </Align>
              </div>
            </div>
            <VerticalSpace size="40" />
          </CardBlock.Body>
        </CardBlock>
      </div>
    </>
  );
};

export default NoPorts;
