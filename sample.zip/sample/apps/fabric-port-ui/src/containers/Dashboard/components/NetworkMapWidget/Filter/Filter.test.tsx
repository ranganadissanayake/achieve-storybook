import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import Filter, { FilterProps } from "./index";

jest.mock('../../../../../shared/assets', () => ({
  greenDot: 'green-dot-url',
  redDot: 'red-dot-url',
  disabledDot: 'disabled-dot-url',
}));

describe("Filter Component", () => {
  const mockProps: FilterProps = {
    isToggle: true,
    onClose: jest.fn(),
    filterOption: 'up',
    onChangeFilterUp: jest.fn(),
    onChangeFilterDown: jest.fn(),
    onChangeFilterDisabled: jest.fn(),
  };

  it("renders without errors", () => {
    render(
      <Filter {...mockProps}/>
    );
    const widget = screen.getByTestId("network-map-filter");
    expect(widget).toBeInTheDocument();
    expect(screen.getByText("Filter by")).toBeInTheDocument();
  });

  test('closes the filter when clicked outside', () => {
    render(<Filter {...mockProps} />);
    fireEvent.mouseDown(document.body);
    expect(mockProps.onClose).toHaveBeenCalledTimes(1);
  });
});
