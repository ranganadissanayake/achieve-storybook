import CardBlock from "../../../../../components/CardBlock";
import GFHeading from "../../../../../components/GFHeading";
import React, { useEffect } from "react";
import "./Filter.scss";
import { Radio } from "@btdigital/nayan-component-library";
import images from "../../../../../shared/assets";

export interface FilterProps {
  isToggle: boolean;
  onClose: () => void;
  filterOption?: string;
  onChangeFilterUp: (value: boolean) => void;
  onChangeFilterDown: (value: boolean) => void;
  onChangeFilterDisabled: (value: boolean) => void;
}
const Filter: React.FC<FilterProps> = ({
  isToggle,
  onClose,
  filterOption,
  onChangeFilterUp,
  onChangeFilterDown,
  onChangeFilterDisabled,
}) => {
  const modalRef = React.useRef<HTMLDivElement>(null);

  const handleClickOutside = (event: MouseEvent) => {
    if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
      onClose();
    }
  };

  useEffect(() => {
    if (isToggle) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isToggle]);
  return (
    <>
      {isToggle && (
        <div ref={modalRef} data-testid="network-map-filter">
          <CardBlock
            className="map-filter-wrapper"
          >
            <CardBlock.Head className="pt-8 pb-8 pr-16 pl-16 mb-2">
              <GFHeading size="S5" text="Filter by" weight="regular" />
            </CardBlock.Head>
            <CardBlock.Body className="filter-content-wrapper">
              <p className="content-title">Port Status</p>
              <section className="filter-data">
                <ul>
                  <li>
                    <Radio
                      id="portStatus"
                      key={1}
                      onSelect={onChangeFilterUp}
                      isCheckedDefault={filterOption === "up" ? true : false}
                    />
                    <span className="text">Up</span>
                    <img src={images.greenDot} alt="" srcSet="" />
                  </li>
                  <li>
                    <Radio
                      id="portStatus"
                      key={2}
                      onSelect={onChangeFilterDown}
                      isCheckedDefault={filterOption === "down" ? true : false}
                    />
                    <span className="text">Down</span>
                    <img src={images.redDot} alt="" srcSet="" />
                  </li>
                  <li>
                    <Radio
                      id="portStatus"
                      key={3}
                      onSelect={onChangeFilterDisabled}
                      isCheckedDefault={
                        filterOption === "disabled" ? true : false
                      }
                    />
                    <span className="text">Disabled</span>
                    <img src={images.disabledDot} alt="" srcSet="" />
                  </li>
                </ul>
              </section>
            </CardBlock.Body>
          </CardBlock>
        </div>
      )}
    </>
  );
};

export default Filter;
