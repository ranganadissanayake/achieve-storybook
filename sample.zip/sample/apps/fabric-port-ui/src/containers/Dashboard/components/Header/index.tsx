/* eslint-disable prettier/prettier */
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import images from "../../../../shared/assets/index";
import GFHeading from "../../../../components/GFHeading";
import { selectHasPorts } from "../../../../redux/portOnlySlice";
import { selectCurrentUser } from "../../../../redux/userProfileSlice";
import "./Header.scss";

const Header = () => {
  const hasPorts = useSelector(selectHasPorts);
  const { firstName } = useSelector(selectCurrentUser);
  const [greeting, setGreeting] = useState<string>('');
  const [userName, setUserName] = useState<string>("");
  const hasPortsLocal = localStorage.getItem("hasPorts");
  const checkPorts = hasPorts || hasPortsLocal;

  useEffect(() => {
    const currentTime = new Date().getHours();

    if (currentTime >= 5 && currentTime < 12) {
      setGreeting('Good morning');
    } else if (currentTime >= 12 && currentTime < 17) {
      setGreeting('Good afternoon');
    } else {
      setGreeting('Good evening');
    }
  }, []);

  useEffect(() => {
    if (firstName) {
      setUserName(firstName);
    }
  }, [firstName]);

    return (
        <section className="dashboard-header d-flex mt-20 mb-24">
            <div className="pg-logo-title d-flex">
                <img
                    src={images.dashboardLogo}
                    alt="Fabric port"
                />
                <div className={`title-wrp pl-16 ${checkPorts ? "" : "check-ports" }`}>
                    <GFHeading size="S4" text={checkPorts ? `${greeting}, ${userName}` : `Welcome ${userName}`} weight="regular" data-testid="greeting-text"/>
                    { checkPorts ? <span className="pg-intro" data-testid="pg-intro"><GFHeading size="S6" color="boat-anchor" text="Welcome back! Here’s what’s new while you were away." weight="light" /></span> : ""}
                </div>
            </div>
            <div className="auto-refresh-btn d-flex">
                <GFHeading size="S7" text="Updated 3 mins ago" color="boat-anchor" weight="light"/>
                <div className="refresh-btn ml-12"><img
                    src={images.refreshIcon}
                    alt="Refresh"
                /></div>
            </div>
        </section>

    )
}

export default Header;