import React from "react";
import {
  TableV2,
} from "@btdigital/nayan-component-library";
import DashboardCard from "../DashboardCard";

import "./style.scss";

interface AlertsProps {
  title?: string;
  refreshtime?: number;
}

const Alerts: React.FC<AlertsProps> = ({
  title = "Alert Notifications",
}) => {

  const data = [
    {
      alert: "High Threshold (75%) exceeded",
      associatedService: "Primary: DC01-GB-LON-100G",
      startDateTime: "18/09/24 13:00",
      endDateTime: "18/09/24 13:05",
    },
    {
      alert: "High Threshold (75%) exceeded",
      associatedService: "Primary: DC01-GB-LON-100G",
      startDateTime: "18/09/24 12:00",
      endDateTime: "18/09/24 12:05",
    },
    {
      alert: "High Threshold (75%) exceeded",
      associatedService: "Primary: DC01-GB-LON-100G",
      startDateTime: "18/09/24 11:00",
      endDateTime: "18/09/24 12:05",
    },
    {
      alert: "High Threshold (75%) exceeded",
      associatedService: "Primary: DC01-GB-LON-100G",
      startDateTime: "18/09/24 10:00",
      endDateTime: "18/09/24 12:05",
    },
    {
      alert: "High Threshold (75%) exceeded",
      associatedService: "Primary: DC01-GB-LON-100G",
      startDateTime: "18/09/24 09:00",
      endDateTime: "18/09/24 12:05",
    }
  ]; 

  const columns = [
    {
      accessorKey: "alert",
      header: "Alert",
      id: "alert",
    },
    {
      id: "associated-service",
      header: "Associated Service",
      accessorKey: "associatedService",
    },
    {
      accessorKey: "endDateTime",
      header: "Start Date Time",
      id: "start-date-time",
    },
    {
      accessorKey: "endDateTime",
      header: "End Date Time",
      id: "end-date-time",
    },
  ];

  return (
    <DashboardCard title={title} dashboardStyles="alert_notifications">
      <TableV2
        data={data}
        columns={columns}
        defaultPageSize={10}
      />
    </DashboardCard>
  );
};

export default Alerts;
