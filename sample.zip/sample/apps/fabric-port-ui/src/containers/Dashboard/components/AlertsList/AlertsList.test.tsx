import React from "react";
import { render, screen } from "@testing-library/react";
import AlertsList from "./index";
import { alertContentList } from "../../../../shared/constants";

describe("AlertsList Component", () => {
  it("renders the component with main heading and sub heading", () => {
    render(<AlertsList alertsList={alertContentList} />);
    expect(screen.getByText("Total ports")).toBeInTheDocument();
    expect(screen.getByText("Network services")).toBeInTheDocument();
  });
});
