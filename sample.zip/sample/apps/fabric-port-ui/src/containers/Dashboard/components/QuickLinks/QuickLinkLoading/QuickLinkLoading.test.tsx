import React from "react";
import { render, screen } from "@testing-library/react";
import QuickLinkLoading from "./index";

describe("Quick Link", () => {
  beforeEach(() => {
    render(<QuickLinkLoading />);
  });

  it("renders the quick link loading component", () => {
    expect(screen.getByTestId("quick_link_loading")).toBeInTheDocument();
  });
});
