import geographicalLocations from "./global/geographical-locations/response.json";
import sites from "./global/sites/response.json";
import customerSites from "./global/customer-sites/response.json";
import downloadLoa from "./port-a/download-loa/response.json";
import internetPricing from "./internet/internet-pricing/response.json";
import orderPortOnly from "./port-a/order-port-only/response.json";
import ipAddressOrdering from "./ip-address/ip-address-ordering/response.json";
import ipAddressPricing from "./ip-address/ip-address-pricing/response.json";
import ipAddressSearch from "./ip-address/ip-address-search/response.json";
import portADelete from "./port-a/port-a-delete/response.json";
import portADetails from "./port-a/port-a-details/response.json";
import portAPricing from "./port-a/port-a-pricing/response.json";
import portSearch from "./port-a/port-search/response.json";
import dataCenterPrices from "./port-b/data-center-prices/response.json";
import getPortBDetails from "./port-b/port-b-details/response.json";
import portCDetails from "./port-c/port-c-details/response.json";
import connectivityOptions from "./global/connectivity-options/response.json";
import internetConnectionDetails from "./internet/internet-connection-details/response.json";
import portCProviders from "./port-c/port-c-providers/response.json";
import portCQuoteList from "./port-c/port-c-quote-list/response.json";
import orderInternet from "./internet/order-internet/response.json";
import updateInternet from "./internet/internet-update/response.json";
import portAStatusUpdate from "./port-a/port-a-status-update/response.json";
import portBStatusUpdate from "./port-b/port-b-status-update/response.json";
import notifications from "./global/notifications/response.json";
import deleteInternetConnection from "./internet/delete-internet-connections/response.json";
import updateQuote from "./port-c/update-quote/response.json";
import subLocation from "./port-c/sub-location/response.json";
import portCQuoteDetails from "./port-c/port-c-quoteDetails/response.json";
import portCQuoteDelete from "./port-c/port-c-quote-delete/response.json";
import portCOrderQuote from "./port-c/port-c-orderQuote/response.json";
import internetStatusUpdate from "./internet/internet-status-update/response.json";
import ipAddressUpdate from "./ip-address/ip-address-update/response.json";
import billingAccount from "./global/billing-account/response.json";
import userProfile from "./global/user-profile/response.json";
import deleteIPAddress from "./ip-address/delete-ip-address/response.json";
import internetSearch from "./internet/internet-search/response.json";
import globalSupportCases from "./global/global-support-cases/response.json";
import ipAddressDetails from "./ip-address/ip-address-details/response.json";
import topNdata from "./global/top-n/response.json";
import validateAddress from "./port-c/validate-addresses/response.json";
import deleteSite from "./port-c/delete-site/response.json";
import deleteSiteContacts from "./port-c/site-contacts-delete/response.json";
import updateSiteContacts from "./port-c/site-contacts-update/response.json";
import sendEvent from "./global/send-events/response.json";
import siteContactDetails from "./port-c/site-contact-details/response.json";
import portCStatusUpdate from "./port-c/port-c-status-update/response.json";
import getCeaseQuoteDetails from "./cease-quote/response.json";
import portBCeaseDelete from "./port-b/port-b-cease-delete/response.json";
import portCCeaseDelete from "./port-c/port-c-cease-delete/response.json";
import createSite from "./port-c/create-site/response.json";
import eventsList from "./events-list/response.json";
import alarmsList from "./alarms-list/response.json";
import siteModify from "./port-c/update-site/response.json";

export const mockResponses = {
  geographicalLocations,
  sites,
  customerSites,
  downloadLoa,
  internetPricing,
  orderPortOnly,
  ipAddressOrdering,
  ipAddressPricing,
  ipAddressSearch,
  portADelete,
  portADetails,
  portAPricing,
  portSearch,
  dataCenterPrices,
  getPortBDetails,
  portCDetails,
  connectivityOptions,
  internetConnectionDetails,
  portCProviders,
  portCQuoteList,
  orderInternet,
  updateInternet,
  portAStatusUpdate,
  portBStatusUpdate,
  notifications,
  deleteInternetConnection,
  updateQuote,
  subLocation,
  portCQuoteDetails,
  portCQuoteDelete,
  portCOrderQuote,
  internetStatusUpdate,
  ipAddressUpdate,
  billingAccount,
  userProfile,
  deleteIPAddress,
  internetSearch,
  globalSupportCases,
  ipAddressDetails,
  topNdata,
  validateAddress,
  createSite,
  deleteSite,
  deleteSiteContacts,
  updateSiteContacts,
  sendEvent,
  portCStatusUpdate,
  siteContactDetails,
  getCeaseQuoteDetails,
  portBCeaseDelete,
  portCCeaseDelete,
  eventsList,
  alarmsList,
  siteModify,
};
