import { rest } from "msw";
import { mockResponses } from "./mock-responses/index.ts";

const baseUrlv1 = "/api/v1/globalfabric";
const baseUrlv2 = "/api/v2/globalfabric";

Object.values(mockResponses).forEach((x) => {
  sessionStorage.setItem(
    btoa(`${x.url}-${x["data-raw"]}`),
    btoa(JSON.stringify(x.response)),
  );
});

const generatorScheme = [
  {
    url: `${baseUrlv1}/cloudfabric-locations/geographical-locations`,
    getterKey: "geographicalLocations",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-locations/sites`,
    getterKey: "sites",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/globalfabric-locations/customer-sites`,
    getterKey: "customerSites",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/loa-downloads`,
    getterKey: "downloadLoa",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-internet-connections/prices`,
    getterKey: "internetPricing",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/port-only-orders`,
    getterKey: "orderPortOnly",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-ip-addresses/orders`,
    getterKey: "ipAddressOrdering",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-ip-addresses/prices`,
    getterKey: "ipAddressPricing",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-ip-addresses/search`,
    getterKey: "ipAddressSearch",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/globalfabric-customer-ports/port-only-ports`,
    getterKey: "portADelete",
    requestType: "delete",
  },
  {
    url: `${baseUrlv2}/cloudfabric-customer-ports/port-only-ports`,
    getterKey: "portADetails",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/data-center-ports`,
    getterKey: "getPortBDetails",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/port-only-prices`,
    getterKey: "portAPricing",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/port-only-prices`,
    getterKey: "PortMonitoring",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/globalfabric/monitors/events`,
    getterKey: "eventsList",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/globalfabric/monitors/alarms`,
    getterKey: "alarmsList",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/data-center-prices`,
    getterKey: "dataCenterPrices",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/connectivity-options`,
    getterKey: "connectivityOptions",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/globalfabric-internet-connections/?`,
    getterKey: "internetConnectionDetails",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/connectivity-options`,
    getterKey: "portCProviders",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-locations/customer-premises/1497250/sub-locations`,
    getterKey: "portCProviders",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/globalfabric-customer-ports/customer-premises-quotes`,
    getterKey: "portCQuoteList",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/customer-premises-quotes`,
    getterKey: "portCQuoteDelete",
    requestType: "delete",
  },
  {
    url: `${baseUrlv1}/cloudfabric-internet-connections/orders`,
    getterKey: "orderInternet",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-internet-connections/orders`,
    getterKey: "updateInternet",
    requestType: "patch",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/port-only-orders`,
    getterKey: "portAStatusUpdate",
    requestType: "patch",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/data-center-orders`,
    getterKey: "portBStatusUpdate",
    requestType: "patch",
  },
  {
    url: `${baseUrlv1}/globalfabric-customer-ports/customer-premises-quotes`,
    getterKey: "updateQuote",
    requestType: "patch",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/data-center-ports`,
    getterKey: "portBDelete",
    requestType: "delete",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/data-center-ports`,
    getterKey: "portBCeaseDelete",
    requestType: "delete",
  },
  {
    url: `${baseUrlv1}/monitors/event-notifications`,
    getterKey: "notifications",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/customer-premises-quotes`,
    getterKey: "portCQuoteDetails",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-billing-accounts`,
    getterKey: "billingAccount",
    requestType: "get",
  },
  {
    url: `/api/gf/bt-global/v2/user-profiles`,
    getterKey: "userProfile",
    requestType: "get",
    schemeModifier: (req, res, ctx) => {
      const encodedGetter = btoa(
        `${mockResponses.userProfile.url}-${mockResponses.userProfile["data-raw"]}`,
      );
      const url = new URL(req.url);
      const uuid = url.searchParams.get("uuid");
      const response = JSON.parse(atob(sessionStorage.getItem(encodedGetter)));

      const profile = response.find((item) => item.basicDetails.uuid === uuid);
      return res(ctx.json(profile));
    },
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/customer-premises-orders`,
    getterKey: "portCOrderQuote",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/globalfabric-internet-connections/orders`,
    getterKey: "updateInternet",
    requestType: "patch",
  },
  {
    url: `${baseUrlv1}/cloudfabric-ip-addresses/orders`,
    getterKey: "ipAddressUpdate",
    requestType: "patch",
  },
  {
    url: `${baseUrlv1}/cloudfabric-ip-addresses`,
    getterKey: "deleteIPAddress",
    requestType: "delete",
  },
  {
    url: `${baseUrlv1}/cloudfabric-internet-connections/search`,
    getterKey: "internetSearch",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/global-support-cases`,
    getterKey: "globalSupportCases",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/globalfabric-ip-addresses`,
    getterKey: "ipAddressDetails",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/globalfabric/monitors/utilization-reports`,
    getterKey: "topNdata",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/globalfabric/monitors/network-allocation-reports`,
    getterKey: "topNdataBandwidth",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-locations/validate-addresses`,
    getterKey: "validateAddress",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-locations/customer-premises`,
    getterKey: "createSite",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-locations/customer-premises/site-contacts`,
    getterKey: "updateSiteContacts",
    requestType: "patch",
  },
  {
    url: `${baseUrlv1}/monitors/event-notifications`,
    getterKey: "sendEvent",
    requestType: "post",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/customer-premises-orders`,
    getterKey: "portCStatusUpdate",
    requestType: "patch",
  },
  {
    url: `${baseUrlv1}/cloudfabric-locations/customer-sites`,
    getterKey: "deleteSite",
    requestType: "delete",
  },
  {
    url: `${baseUrlv1}/cloudfabric-locations/customer-premises/site-contacts`,
    getterKey: "siteContactDetails",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/cessation-charges/*`,
    getterKey: "getCeaseQuoteDetails",
    requestType: "get",
  },
  {
    url: `${baseUrlv1}/cloudfabric-customer-ports/customer-premises-orders/*`,
    getterKey: "portCCeaseDelete",
    requestType: "delete",
  },
  {
    url: `${baseUrlv1}/globalfabric/cloudfabric-locations/customer-premises`,
    getterKey: "siteModify",
    requestType: "patch",
  },
];

const generateHandlers = () => {
  return generatorScheme.map((scheme) =>
    rest[scheme.requestType](scheme.url, (req, res, ctx) => {
      const encodedGetter = btoa(
        `${mockResponses[scheme.getterKey].url}-${
          mockResponses[scheme.getterKey]["data-raw"]
        }`,
      );
      const response = JSON.parse(atob(sessionStorage.getItem(encodedGetter)));
      return res(ctx.json(response));
    }),
  );
};

export const handlers = generateHandlers();
