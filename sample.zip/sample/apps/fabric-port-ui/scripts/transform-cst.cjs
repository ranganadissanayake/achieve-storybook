#!/usr/bin/env node
"use strict";
var chalk = require('chalk');
var fs = require('fs');
var path = require('path');
var inputFile = path.join(process.cwd(), 'package.json');

try {
    if (!fs.existsSync(inputFile)) {
        console.log(chalk.red('\nError: the package.json file does not exist\n'));
        process.exit(1);
    }
}
catch (err) {
    console.error(err);
}

var rawData = fs.readFileSync(inputFile);
var packageDotJSON = JSON.parse(rawData);
packageDotJSON.homepage = "../cst/globalfabric/",

fs.writeFileSync(inputFile, JSON.stringify(packageDotJSON), function (err, data) {
    if (err) {
        console.log(chalk.red('\nError: Unable to write to file\n'));
        console.log(err);
    }
    if (data) {
        console.log(data);
    }
});