import resolve from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import typescript from '@rollup/plugin-typescript';
import postcss from 'rollup-plugin-postcss';
import dts from 'rollup-plugin-dts';
import filesize from 'rollup-plugin-filesize';
import autoprefixer from 'autoprefixer';
import babel from '@rollup/plugin-babel';
import svg from 'rollup-plugin-svg';
import url from '@rollup/plugin-url';
import copy from 'rollup-plugin-copy';
import postcssUrl from 'postcss-url';

const packageJson = require('./package.json');

const PACKAGE_NAME = '@btdigital/nayan-component-library';

const GLOBALS = {
    react: 'React',
    'react-dom': 'ReactDOM'
};

const PLUGINS = [
    postcss({
        extract: true,
        plugins: [
            autoprefixer(),
            postcssUrl([
                {
                    filter: 'src/components/Assets/fonts/BTCurve/*.ttf',
                    url: (asset) => asset.url.replace('../../Assets/fonts/BTCurve/', 'fonts/')
                }
            ])
        ]
    }),
    babel({
        babelHelpers: 'runtime',
        exclude: 'node_modules/**'
    }),
    resolve({
        browser: true,
        resolveOnly: [/^(?!react$)/, /^(?!react-dom$)/]
    }),
    typescript({
        tsconfig: './tsconfig.json'
    }),
    commonjs(),
    filesize(),
    svg(),
    url({
        include: ['**/*.ttf', '**/*.png', '**/*.svg'],
        limit: Infinity // makes sure files/fonts are bundled rather than copied directly to dist
    }),
    copy({
        targets: [{ src: './src/components/Assets/fonts/BTCurve/*', dest: 'dist/fonts/' }]
    })
];

const EXTERNAL = ['react', 'react-dom'];

const CJS_AND_ES_EXTERNALS = EXTERNAL.concat(/@babel\/runtime/);

const OUTPUT_DATA = [
    {
        file: packageJson.browser,
        format: 'umd'
    },
    {
        file: packageJson.main,
        format: 'cjs'
    },
    {
        file: packageJson.module,
        format: 'es'
    }
];

const config = OUTPUT_DATA.map(
    ({ file, format }) => ({
        input: 'src/index.ts',
        output: {
            file,
            format,
            name: PACKAGE_NAME,
            globals: GLOBALS
        },
        external: ['cjs', 'es'].includes(format) ? CJS_AND_ES_EXTERNALS : EXTERNAL,
        plugins: PLUGINS
    }),
    {
        input: 'dist/index.d.ts',
        output: [{ file: 'dist/index.d.ts', format: 'esm' }],
        plugins: [dts()],
        external: [/\.(css|less|scss)$/]
    }
);

export default config;
