module.exports = {
    setupFilesAfterEnv: ['<rootDir>/settings/jestSetup.js'],
    testEnvironment: 'jsdom',
    testResultsProcessor: 'jest-sonar-reporter',
    moduleNameMapper: {
        '.(css|less|scss)$': 'identity-obj-proxy',
        '\\.(jpg|ico|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$':
            '<rootDir>/mocks/fileMock.js',
        '\\.(css|less)$': '<rootDir>/mocks/fileMock.js',
        d3: '<rootDir>/node_modules/d3/dist/d3.min.js'
    }
};
