declare module '*.module.scss';
declare module '*.png';
declare module '*.svg';
