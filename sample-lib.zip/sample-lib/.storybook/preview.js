import { ThemeProvider } from '../src/context';

export const parameters = {
    actions: { argTypesRegex: '^on[A-Z].*' },
    controls: {
        matchers: {
            color: /(background|color)$/i,
            date: /Date$/
        }
    }
};

export const globalTypes = {
    theme: {
        name: 'Theme',
        description: 'Global theme',
        defaultValue: 'light',
        toolbar: {
            icon: 'lightning',
            items: ['light', 'dark'],
            showName: true
        }
    }
};

const storyBackground = (theme) => {
    document.documentElement.style.background = theme === 'light' ? '#ffffff' : '#2a2a2a';
    document.body.style.background = theme === 'light' ? '#ffffff' : '#2a2a2a';
};

export const decorators = [
    (Story, context) => {
        storyBackground(context.globals.theme);
        return (
            <ThemeProvider mode={context.globals.theme}>
                <Story />
            </ThemeProvider>
        );
    }
];
