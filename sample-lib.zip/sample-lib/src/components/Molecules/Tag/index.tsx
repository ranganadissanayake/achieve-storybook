import React from "react";

import Icon from "../../Atoms/Icon";
import { IconName } from "../../Assets/icons/iconLib";

import "./Tag.scss";

export interface TagProps {
    text: string;
    iconName?: IconName;
    iconInverse?: boolean;
    size?: 'sm' | 'lg';
    style?: 'default' | 'primary' | 'secondary';
    customStyleClass?: string;
    iconBefore?: boolean;
    iconColor?: string;
    textStyle?: string;
    showOriginalIcon?: boolean;
}

const Tag: React.FC<TagProps> = ({
    text,
    iconName = 'cross',
    size = 'sm',
    style = 'default',
    iconInverse = false,
    iconBefore = false,
    iconColor,
    customStyleClass,
    textStyle,
    showOriginalIcon = false
}) => {
    return (
        <span
            className={`tag_container tag_${size} tag_${style} ${customStyleClass}`}
            data-testid="tag"
        >
            {iconBefore && (
                <Icon
                    title={iconName}
                    size="sm"
                    inverse={iconInverse}
                    className="tag_icon"
                    color={iconColor}
                    showOriginal={showOriginalIcon}
                />
            )}
            <span className={`tag_text ${textStyle}`}>{text}</span>
            {!iconBefore && (
                <Icon
                    title={iconName}
                    size="sm"
                    inverse={iconInverse}
                    className="tag_icon"
                    color={iconColor}
                    showOriginal={showOriginalIcon}
                />
            )}
        </span>
    );
};

export default Tag;
