import React from "react";
import { render, screen } from "@testing-library/react";

import Tag from "./index";

describe("Tag", () => {
  test("renders the Tag component", () => {
    render(<Tag text="SELECTED FIRST" />);
    expect(screen.getByTestId("tag")).toBeInTheDocument();
  });

  test("renders the tag text", () => {
    render(<Tag text="SELECTED FIRST" />);
    expect(screen.getByText("SELECTED FIRST")).toBeInTheDocument();
  });

  test("renders the tag icon", () => {
    render(<Tag text="SELECTED FIRST" />);
    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });

  test("add tag_sm class to small size tag", () => {
    render(<Tag text="SELECTED FIRST" size="sm" />);
    expect(screen.getByTestId("tag")).toHaveClass("tag_sm");
  });

  test("add tag_lg class to large size tag", () => {
    render(<Tag text="SELECTED FIRST" size="lg" />);
    expect(screen.getByTestId("tag")).toHaveClass("tag_lg");
  });

  test("add tag_default class to default style tag", () => {
    render(<Tag text="SELECTED FIRST" style="default" />);
    expect(screen.getByTestId("tag")).toHaveClass("tag_default");
  });

  test("add tag_primary class to primary style tag", () => {
    render(<Tag text="SELECTED FIRST" style="primary" />);
    expect(screen.getByTestId("tag")).toHaveClass("tag_primary");
  });

  test("add tag_secondary class to secondary style tag", () => {
    render(<Tag text="SELECTED FIRST" style="secondary" />);
    expect(screen.getByTestId("tag")).toHaveClass("tag_secondary");
  });
});
