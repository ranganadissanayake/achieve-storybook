import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Tag from "./index";

export const DefaultStory = () => <Tag text="SELETED FIRST" />;

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Molecules/Tag",
  component: Tag,
} as ComponentMeta<typeof Tag>;

const Template: ComponentStory<typeof Tag> = (args) => <Tag {...args} />;

export const Playground = Template.bind({});
Playground.args = {
  text: "SELETED FIRST",
  iconName: "arrow_right",
  size: "sm",
  style: "primary",
  iconInverse: true,
};
