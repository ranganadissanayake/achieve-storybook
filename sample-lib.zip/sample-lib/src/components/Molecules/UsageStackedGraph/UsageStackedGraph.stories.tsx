import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import UsageStackedGraph, { UsageDataItem } from "./index";

const chartData: UsageDataItem[] = [
    {
        amount: 100,
        fillColor: '#088003',
        label: 'Used',
    },
    {
        amount: 20,
        fillColor: '#E6F4E5',
        label: 'Selected (Lowest)',
        dashColor: '#088003'
    },
    {
        amount: 20,
        fillColor: '#C4E4BF',
        label: 'Selected (Highest)',
        dashColor: '#088003'
    }
];

export const DefaultStory = () => (
    <UsageStackedGraph
        title="Associated Port Bandwidth"
        graphData={chartData}
        unitText="Mbps"
        showRemaining
        totalAmount={500} />
);

DefaultStory.storyName = "Default";

export default {
    title: "ReactComponentLibrary/Molecules/UsageStackedGraph",
    component: UsageStackedGraph,
} as ComponentMeta<typeof UsageStackedGraph>;

const Template: ComponentStory<typeof UsageStackedGraph> = (args) => (
    <UsageStackedGraph {...args} />
);

export const Playground = Template.bind({});
Playground.args = {
    title: "Associated Port Bandwidth",
    graphData: chartData,
    totalAmount: 500
};
