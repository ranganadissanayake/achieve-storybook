import React, { useMemo, useState } from 'react';
import Label from '../../Atoms/Label';
import classnames from 'classnames';
import './UsageStackedGraph.scss';

export type UsageDataItem = {
    amount: number,
    dashColor?: string,
    fillColor: string,
    label: string,
}

export type UsageStackedGraphProps = {
    title: string,
    unitText?: string,
    showRemaining?: boolean,
    graphData: UsageDataItem[],
    totalAmount: number,
    remainingSpaceColor?: string
}

type LegendOptionProps = {
    labelText: string,
    colorCode: string,
    dashColor?: string,
}

type LineChartItemProps = {
    colorCode: string,
    amount: number,
    totalAmount: number,
    dashColor?: string,
    unitText?: string,
}

type RemainingLabelProps = {
    graphData: UsageDataItem[],
    unitText?: string,
    totalAmount: number,
}

const LineChartItem: React.FC<LineChartItemProps> = ({
    colorCode,
    amount,
    totalAmount,
    dashColor,
    unitText
}: LineChartItemProps) => {
    const [active, setActive] = useState(false);

    const restrictToolTipDecimals = (val: number) => {
        let newVal = val;
        if (val.toString().split(".")[1]?.length > 3) {
            newVal = parseFloat(val.toFixed(3));
        }
        return newVal;
    }

    return (
        <React.Fragment>
            {amount > 0 && (
                <div
                    className={classnames('bandwidth-tooltip-wrapper', { '--dashed': dashColor })}
                    onMouseOver={() => setActive(true)}
                    onMouseOut={() => setActive(false)}
                    data-testid="line-chart-item"
                    style={{
                        width: `${(amount / totalAmount) * 100}%`,
                        backgroundColor: colorCode,
                        borderColor: `${dashColor ?? ''}`
                    }}
                >
                    {active && (
                        <div className="tooltip tip-top">
                            <Label
                                size="sm"
                                text={`${restrictToolTipDecimals(amount)} ${unitText}`}
                                isFontHeadline={false}
                            />
                        </div>
                    )}
                </div>
            )}
        </React.Fragment>
    );
};

const LegendOption: React.FC<LegendOptionProps> = ({
    labelText,
    colorCode,
    dashColor
}: LegendOptionProps) => {
    return (
        <div className="legend-item">
            <div
                className={classnames('legend-square', { '--dashed': dashColor })}
                style={{ backgroundColor: colorCode, borderColor: `${dashColor ?? ''}` }}
            ></div>
            <div className="legend-label-wrapper">
                <Label labelTextStyles="legend-label" text={labelText} />
            </div>
        </div>
    );
};

const RemainingUsage: React.FC<RemainingLabelProps> = ({
    graphData = [],
    unitText,
    totalAmount
}: RemainingLabelProps) => {
    const remainingAmount = useMemo(() => {
        return totalAmount - graphData.map((a) => a.amount).reduce((a, b) => a + b);
    }, [graphData, unitText, totalAmount]);

    return (
        <Label
            text={`${remainingAmount.toFixed(
                3
            )} ${unitText} of ${totalAmount} ${unitText} Available`}
            labelTextStyles="available-amount-label"
            data-testid="available-amount-label"
        />
    );
};

const UsageStackedGraph: React.FC<UsageStackedGraphProps> = ({
    title,
    graphData = [],
    showRemaining,
    unitText = '',
    totalAmount,
    remainingSpaceColor
}: UsageStackedGraphProps) => {
    const totalUsageAmount = useMemo(() => {
        return graphData.map((a) => a.amount).reduce((a, b) => a + b);
    }, [graphData]);

    return (
        <div className="utilization-graph" data-testid="utilization-graph">
            <div className="utilization-graph__heading">
                <Label text={title} labelTextStyles="title" />
                {showRemaining && (
                    <RemainingUsage
                        graphData={graphData}
                        totalAmount={totalAmount}
                        unitText={unitText}
                    />
                )}
            </div>
            <div className="utilization-graph__line-chart">
                <div className="line-chart-background">
                    {graphData.map((item: UsageDataItem) => (
                        <LineChartItem
                            key={item.label}
                            amount={item.amount}
                            totalAmount={totalAmount}
                            colorCode={item.fillColor}
                            dashColor={item.dashColor}
                            unitText={unitText}
                        />
                    ))}
                    <LineChartItem
                        amount={totalAmount - totalUsageAmount}
                        totalAmount={totalAmount}
                        colorCode={remainingSpaceColor || "#F0F0F0"}
                        unitText={unitText}
                    />
                </div>
            </div>
            <div className="utilization-graph__legend" data-testid="legends">
                {graphData.map((item: UsageDataItem) => (
                    <LegendOption
                        key={item.label}
                        labelText={item.label}
                        colorCode={item.fillColor}
                        dashColor={item.dashColor}
                    />
                ))}
                <LegendOption labelText="Available" colorCode="#f8efff" />
            </div>
        </div>
    );
};

export default UsageStackedGraph;
