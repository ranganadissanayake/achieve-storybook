import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import user from '@testing-library/user-event';

import UsageStackedGraph, { UsageDataItem } from "./index";

const chartData: UsageDataItem[] = [
  {
      amount: 100,
      fillColor: '#088003',
      label: 'Used',
  },
  {
      amount: 20,
      fillColor: '#E6F4E5',
      label: 'Selected (Lowest)',
      dashColor: '#088003'
  },
  {
      amount: 30,
      fillColor: '#C4E4BF',
      label: 'Selected (Highest)',
      dashColor: '#088003'
  },
  {
      amount: 200.23416,
      fillColor: '#f8efff',
      label: 'Free'
  },
];

describe("UsageStackedGraph", () => {
  test("should renders the UsageStackedGraph component", () => {
    render(<UsageStackedGraph graphData={chartData} title="Associated Port Bandwidth" totalAmount={98}/>);
    expect(screen.getByTestId("utilization-graph")).toBeInTheDocument();
    expect(screen.getByTestId("legends")).toBeInTheDocument();
  });

  test("should renders the UsageStackedGraph component with available space", () => {
    render(<UsageStackedGraph graphData={chartData} title="Associated Port Bandwidth" showRemaining totalAmount={78}/>);
    expect(screen.getByTestId("utilization-graph")).toBeInTheDocument();
  });
  test("should render the correct title", () => {
    render(<UsageStackedGraph graphData={chartData} title="Associated Port Bandwidth" totalAmount={87}/>);
    const title = screen.getByText("Associated Port Bandwidth");
    expect(title).toBeInTheDocument();
  });   
  test("should hover numbers correct to 3 decimal places", () => {
    render(<UsageStackedGraph graphData={chartData} title="Associated Port Bandwidth" totalAmount={87}/>);
    const items = screen.getAllByTestId("line-chart-item");
    
    expect(items[0]).toBeInTheDocument();
    user.hover(items[0]);
    expect(screen.getByText(100)).toBeInTheDocument();

    expect(items[1]).toBeInTheDocument();
    user.hover(items[1]);
    expect(screen.getByText(20)).toBeInTheDocument();

    expect(items[2]).toBeInTheDocument();
    user.hover(items[2]);
    expect(screen.getByText(30)).toBeInTheDocument();

    expect(items[3]).toBeInTheDocument();
    user.hover(items[3]);
    expect(screen.getByText(200.234)).toBeInTheDocument();
  });   
});
