import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Input from "./index";

export const DefaultStory = () => <Input name="name" label="Label" />;

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Molecules/Input",
  component: Input,
} as ComponentMeta<typeof Input>;

const keyEnter = (e: React.KeyboardEvent<HTMLInputElement>) => {
      console.log(e.code);
};

const Template: ComponentStory<typeof Input> = (args) => <Input {...args} />;

export const Playground = Template.bind({});
Playground.args = {
  name: "name",
  label: "Label",
  helper: "helper text",
  required: true,
  keyEnter: keyEnter,
};
