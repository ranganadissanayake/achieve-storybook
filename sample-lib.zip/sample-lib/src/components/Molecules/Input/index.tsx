import React from 'react';

import ErrorMessage from '../../Atoms/ErrorMessage';
import Icon from '../../Atoms/Icon';
import Label from '../../Atoms/Label';
import { IconName } from '../../Assets/icons/iconLib';
import './Input.scss';
import Tag from '../Tag';
import Asset from '../../Atoms/Asset';

/**
 * The properties required for the Input Component
 * @author Joel Chi <joel.abongwa@distributed.com>
 */

type sizeType = 'sm' | 'md' | 'lg';

export interface InputProps {
    /**
     * Enables Input to be associated with a label for accessibility purposes
     */
    id?: string;
    /**
     * The name of the associated data point submitted to the server
     */
    name?: string;
    /**
     * The type for the input. (Integer does not take "." and float accepts both "." and ",")
     */
    type?: 'text' | 'number' | 'integer' | 'float' | 'password';
    /**
     * The number of decimal places. (Only works for type float)
     */
    numberOfDecimalPlaces?: number;
    /**
     * Allow the input of negative numbers
     */
    allowNegative?: boolean;
    /**
     * Label for the Input
     */
    label?: string;
    /**
     * Specifies if the input is required - adds an asterix
     */
    required?: boolean;
    /**
     * Specifies if the input is optional - adds an optional text
     */
    optional?: boolean;
    /**
     * Supporting text for the input label
     */
    helper?: string;
    /**
     * Size for the input label text
     */
    labelSize?: 'lg' | 'sm' | 'xs';
    /**
     * Additional styles for the label text
     */
    labelTextStyles?: string;
    /**
     * Additional styles for the label container
     */
    containerStyles?: string;
    /**
     * Additional styles for the label helper
     */
    helperTextStyles?: string;
    /**
     * A placeholder for the input
     */
    placeholder?: string;
    /**
     * Value to display in the input field
     */
    value?: string;
    /**
     * The state of the input
     */
    state?: 'default' | 'error' | 'success' | 'disabled' | 'loading';
    /**
     * The size of the input
     */
    size?: sizeType;
    /**
     * A message to display in error state
     */
    errorMessage?: string;
    /**
     * The size of the error message
     */
    errorMessageSize?: sizeType;
    /**
     * Show/hide error message icon
     */
    showErrorIcon?: boolean;
    /**
     * Adjust size of error message icon
     */
    errorIconSize?: sizeType;
    /**
     * A name for an icon to show in input field
     */
    iconName?: IconName | 'none';
    /**
     * The size of the specified icon
     */
    iconSize?: sizeType;
    /**
     * Determines whether the icon should be bofore/after the input value
     */
    iconAfter?: boolean;
    /**
     * A name for the country whose asset should be displayed in input field
     */
    asset?: string | 'none';
    /**
     * A ref for the input element
     */
    inputRef?: React.MutableRefObject<any>;
    /**
     * When the input value is changed
     */
    onChange?: (text: string) => void;
    /**
     * When the input field is clicked
     */
    onClick?: () => void;
    /**
     * When the input field is focused
     */
    onFocus?: () => void;
    /**
     * When the input field looses focused
     */
    onBlur?: () => void;
    /**
     * When the icon is clicked
     */
    onIconClick?: () => void;
    /**
     * Specifies classes for additional styles
     */
    className?: string;
    /**
     * can trigger function on press enter
     */
    keyEnter?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
    /**
     * Set badge text
     */
    primaryBadgeText?: string;
    /**
     * Add custom styles as a class name
     */
    primaryBadgeCustomStyle?: string;
    /**
     * Position badge before the text
     */
    primaryBadgeBefore?: boolean;
    /**
     * Set badge icon color
     */
    primaryBadgeIconColor?: string;
    /**
     * Set badge icon
     */
    primaryBadgeIcon?: IconName;
    /**
     * Add custom styles as a class name for badge
     */
    primaryBadgeTextStyle?: string;
    /**
     * Show original icon
     */
    primaryBadgeIconShowOriginal?: boolean;
    /**
     * Show search icon in search dropdown
     */
    searchInput?: boolean;
    /**
     * Reserve space for error message
     */
    keepErrorSpace?: boolean;
    /**
     * Stops the user from typing into input field
     */
    disableTyping?: boolean;
    /**
     * Ensures user types only digits
     */
    allowOnlyDigits?: boolean;

    /**
    * Specify the category of an asset
    */
    assetCategory?: 'flags' | 'providers' | 'facility';

    /**
     * Specify the asset map
     */
     assetMap?: {};

     /**
     * Specify min character length
     */
    minLength?: number;

     /**
     * Specify max character length
     */
     maxLength?: number;

     /**
     * Specify a source for the asset
     */
     assetSrc?: string;

}

/**
 * Renders the Input component
 * @param {React.PropsWithChildren<InputProps>} props InputProps properties
 * @returns
 */
const Input: React.FC<InputProps> = ({
    id,
    name = '',
    value,
    label = '',
    required = false,
    optional = false,
    helper = '',
    labelSize = 'lg',
    labelTextStyles = '',
    containerStyles = '',
    helperTextStyles = '',
    size = 'sm',
    state = 'default',
    placeholder = '',
    errorMessage = '',
    errorMessageSize = 'md',
    showErrorIcon = true,
    iconName = 'none',
    iconSize = 'md',
    iconAfter = false,
    type = 'text',
    asset = 'none',
    allowNegative = false,
    inputRef,
    onChange,
    onClick,
    onFocus,
    onBlur,
    onIconClick,
    className = '',
    primaryBadgeText,
    primaryBadgeBefore,
    primaryBadgeCustomStyle = 'test-class',
    primaryBadgeIconColor,
    primaryBadgeIcon,
    primaryBadgeTextStyle,
    primaryBadgeIconShowOriginal = false,
    searchInput,
    keepErrorSpace = false,
    disableTyping = false,
    allowOnlyDigits = false,
    assetCategory,
    assetMap,
    numberOfDecimalPlaces,
    maxLength,
    minLength,
    keyEnter,
    assetSrc,
}) => {
    const [_value, setValue] = React.useState(value);

    const _onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        let val = e.target.value;

        if(!disableTyping && !(allowOnlyDigits && isNaN(Number(val)))) {
            if (type === 'integer') {
                val = `${val !== '' ? parseInt(val) : val}`;
            } else if (type === 'float') {
                val = val.replace(/[^0-9 \,\.]/, '');

                if(numberOfDecimalPlaces && val.split(".")[1]?.length > numberOfDecimalPlaces) {
                    const decimalVal = val.split(".")[1].substring(0,numberOfDecimalPlaces);
                    val = `${parseInt(val)}.${decimalVal}`
                }
            }
    
            if((type === "number" || type === "integer" ) && !allowNegative){
                val = `${Math.abs(Number(val))}`
            }
    
            setValue(val);
    
            if (onChange) {
                onChange(val);
            }
        } else {
            setValue(prev => prev ?? "")
        }
    };

    const _onKeyUp = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if(keyEnter && e.key === 'Enter') {
            keyEnter(e);
        }
    };

    const _onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (type === 'integer' && e.key === '.') {
            e.preventDefault();
        }

        if (
            type === 'float' &&
            (_value?.includes('.') || _value?.includes(',')) &&
            (e.key === '.' || e.key === ',')
        ) {
            e.preventDefault();
        }
    };

    React.useEffect(() => {
        setValue(value);
    }, [value]);

    const getIcon = React.useMemo(() => {
        if (label !== '' || helper !== '') {
            return 'spacing';
        }
        else
            return '';
    }, [label, helper]);

    const getType = React.useMemo(() => {
        if (type === 'integer') {
            return 'number';
        }
        else if (type === 'float') {
            return 'text';
        } else {
            return type
        }
    }, [type]);

    return (
        <div data-testid="inputElement" className={`input ${state} ${className}`}>
            {((label && label !== '') || (helper && helper !== '')) && (
                <Label
                    text={label}
                    required={required}
                    optional={optional}
                    helper={helper}
                    size={labelSize}
                    htmlFor={name}
                    labelTextStyles={labelTextStyles}
                    containerStyles={containerStyles}
                    helperTextStyles={helperTextStyles}
                />
            )}
            <div className="add-icon" ref={inputRef}>
                {searchInput && (
                    <Icon
                        className={`input-icon search-icon-gap input_${size} input_icon_${iconSize}  ${
                            label !== '' || helper !== '' ? 'spacing' : ''
                        }`}
                        title={'search'}
                        size={'md'}
                        onClick={onIconClick ?? onClick}
                    />
                )}
                {iconName && iconName !== 'none' && !iconAfter ? (
                    <Icon
                        className={`input-icon input_${size} input_icon_${iconSize}  ${getIcon}`}
                        title={iconName}
                        size={iconSize}
                        onClick={onIconClick ?? onClick}
                    />
                ) : (
                    asset &&
                    asset !== 'none' 
                    && assetMap &&(
                        <Asset asset={asset} className='asset icon' assetCategory={assetCategory} assetMap={assetMap} onClick={onIconClick ?? onClick}/>
                    )
                )}
                <input
                    data-testid="input"
                    type={getType}
                    id={id ?? name}
                    name={name}
                    ref={inputRef}
                    required={required}
                    placeholder={placeholder}
                    value={_value}
                    onChange={_onChange}
                    onKeyDown={_onKeyDown}
                    onKeyUp={_onKeyUp}
                    onClick={onClick}
                    onFocus={onFocus}
                    onBlur={onBlur}
                    maxLength={maxLength}
                    minLength={minLength}
                    className={`input_element input_${size} ${
                        iconName && iconName !== 'none'
                            ? iconAfter
                                ? 'icon-after'
                                : 'icon-before'
                            : ''
                    } ${
                        asset && asset !== 'none' && (iconAfter || !iconName || iconName === 'none')
                            ? 'flag_before'
                            : ''
                    } 
                    ${searchInput ? 'icon-before' : ''}
                    ${label !== '' || helper !== '' ? 'spacing' : ''}
                    ${assetCategory === 'providers' ? 'providers' : ''}`}
                    disabled={state === 'disabled'}
                />
                {primaryBadgeText &&
                    (iconAfter ? (
                        <>
                            <Tag
                                size="sm"
                                iconBefore={primaryBadgeBefore}
                                text={primaryBadgeText}
                                iconColor={primaryBadgeIconColor}
                                customStyleClass={`primary-badge ${primaryBadgeCustomStyle}`}
                                iconName={primaryBadgeIcon}
                                textStyle={primaryBadgeTextStyle}
                                showOriginalIcon={primaryBadgeIconShowOriginal}
                            />
                        </>
                    ) : (
                        <Tag
                            size="sm"
                            iconBefore={primaryBadgeBefore}
                            text={primaryBadgeText}
                            iconColor={primaryBadgeIconColor}
                            customStyleClass={`primary-badge ${primaryBadgeCustomStyle}`}
                            iconName={primaryBadgeIcon}
                            textStyle={primaryBadgeTextStyle}
                            showOriginalIcon={primaryBadgeIconShowOriginal}
                        />
                    ))}
                {iconName && iconName !== 'none' && iconAfter && (
                    <>
                        <Icon
                            className={`input-icon input-icon-after input_${size} input_icon_${iconSize}  ${
                                label !== '' || helper !== '' ? 'spacing' : ''
                            }`}
                            title={iconName}
                            size={iconSize}
                            onClick={onIconClick || onClick}
                        />
                    </>
                )}
                {state==='loading' && assetSrc && (
                    <>
                        <Asset 
                            className='input-icon asset-icon-after'
                            src={assetSrc}
                        />
                    </>
                )}
            </div>
            {state === 'error' && errorMessage !== '' ? (
                <ErrorMessage
                    message={errorMessage}
                    showIcon={showErrorIcon}
                    size={errorMessageSize}
                />
            ) : (
                keepErrorSpace && <div style={{ height: '0.875rem' }}></div>
            )}
        </div>
    );
};
 
export default Input;
