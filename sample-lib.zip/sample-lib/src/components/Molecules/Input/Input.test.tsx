import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import user from '@testing-library/user-event';

import Input from './index';

describe('Input', () => {
    test('renders the input component', () => {
        render(<Input name="name" />);
        expect(screen.getByTestId('inputElement')).toBeInTheDocument();
    });

    test('renders the label of the input component', () => {
        render(<Input name="name" label="Label" />);
        expect(screen.getByText('Label')).toBeInTheDocument();
    });

    test('renders the helper text of the input component', () => {
        render(<Input name="name" label="Label" helper="Helper text" />);
        expect(screen.getByText('Helper text')).toBeInTheDocument();
    });

    test('renders the error message in case of an error ', () => {
        render(
            <Input name="name" label="Label" state="error" errorMessage="Something went wrong" />
        );
        expect(screen.getByText('Something went wrong')).toBeInTheDocument();
    });

    test('add sm class to small size input component', () => {
        render(<Input name="name" label="Label" size="sm" />);
        expect(screen.getByTestId('input')).toHaveClass('input_sm');
    });

    test('add md class to medium size input component', () => {
        render(<Input name="name" label="Label" size="md" />);
        expect(screen.getByTestId('input')).toHaveClass('input_md');
    });

    test('add lg class to large size input component', () => {
        render(<Input name="name" label="Label" size="lg" />);
        expect(screen.getByTestId('input')).toHaveClass('input_lg');
    });

    test('add default class to default state input component', () => {
        render(<Input name="name" label="Label" state="default" />);
        expect(screen.getByTestId('inputElement')).toHaveClass('default');
    });

    test('add error class to error state input component', () => {
        render(<Input name="name" label="Label" state="error" />);
        expect(screen.getByTestId('inputElement')).toHaveClass('error');
    });

    test('add success class to success state input component', () => {
        render(<Input name="name" label="Label" state="success" />);
        expect(screen.getByTestId('inputElement')).toHaveClass('success');
    });

    test('add disabled class to disabled state input component', () => {
        render(<Input name="name" label="Label" state="disabled" />);
        expect(screen.getByTestId('inputElement')).toHaveClass('disabled');
    });

    test('add  icon to input component', () => {
        render(<Input name="name" iconName="search" />);
        expect(screen.getByTestId('icon')).toBeInTheDocument();
    });

    test('add icon-after class to icon after', () => {
        render(<Input name="name" iconName="search" iconAfter />);
        expect(screen.getByTestId('icon')).toHaveClass('input-icon-after');
    });
    test('displays the label text', () => {
        render(<Input label="Username" />);
        expect(screen.getByText('Username')).toBeInTheDocument();
    });
    test('setting disableTyping to true does not allow text input', () => {
        render(<Input label="Username" disableTyping />);

        const inputField = screen.getByRole("textbox");
        user.click(inputField);
        user.keyboard('hello')

        expect(inputField).toHaveValue("");
    });
    test('input field allows user to enter only digits', () => {
        render(<Input label="Username" allowOnlyDigits />);

        const inputField = screen.getByRole("textbox");
        user.click(inputField);
        user.keyboard('hello')

        expect(inputField).toHaveValue("");

        user.click(inputField);
        user.keyboard('123')

        expect(inputField).toHaveValue("123");
    });
    test('input allows user to enter only a certain number of decimal places', () => {
        render(<Input label="Username" allowOnlyDigits type='float' numberOfDecimalPlaces={3} />);

        const inputField = screen.getByRole("textbox");
        user.click(inputField);
        user.keyboard('123.2345')

        expect(inputField).toHaveValue("123.234");
    });
    test('input state is set to loading', () => {
        render(<Input label="Loading" state='loading' asset='loading-spinner' assetMap={''}/>);
        expect(screen.getByTestId('inputElement')).toHaveClass('loading');
    });
});
