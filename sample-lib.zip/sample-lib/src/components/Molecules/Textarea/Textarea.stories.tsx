import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Textarea from './index';

export const DefaultStory = () => <Textarea id="default" name="Default" />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/Textarea',
    component: Textarea
} as ComponentMeta<typeof Textarea>;

const Template: ComponentStory<typeof Textarea> = (args) => <Textarea {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    id: 'playground',
    label: 'Playground',
    name: 'Textarea',
    helperText: 'Some helper',
    required: true,
    optional: true,
    onChange: (value) => {
        console.log(value);
    }
};
