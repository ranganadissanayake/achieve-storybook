import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';

import Textarea from './index';

describe('Textarea', () => {
    test('renders the Checkbox component', () => {
        render(<Textarea id="text-area" name="textarea" />);

        expect(screen.getByRole('textbox')).toHaveClass('textarea');
    });
    test('textarea has label', () => {
        render(<Textarea id="text-area" name="textarea" label="Label" />);

        expect(screen.getByText('Label')).toBeInTheDocument();
    });
    test('add large class for large size Checkbox', () => {
        render(<Textarea id="text-area" name="textarea" placeholder="placeholder value" />);

        expect(screen.getByRole('textbox')).toHaveAttribute(
            'placeholder',
            expect.stringContaining('placeholder value')
        );
    });
    test('add error class for error state Textarea', () => {
        render(<Textarea id="text-area" name="textarea" state="error" />);

        expect(screen.getByRole('textbox')).toHaveClass('error-input');
    });
    test('add error class for Textarea if error message present', () => {
        render(
            <Textarea
                id="text-area"
                name="textarea"
                state="error"
                errorMessage="An error occurred"
            />
        );

        expect(screen.getByRole('textbox')).toHaveClass('error-input');
    });
    test('add row property to textarea', () => {
        render(<Textarea id="text-area" name="textarea" rows={10} />);

        expect(screen.getByRole('textbox')).toHaveAttribute('rows', expect.stringContaining('10'));
    });
    test('change event on the Checkbox', () => {
        const handleClick = jest.fn();
        const utils = render(<Textarea id="text-area" name="textarea" onChange={handleClick} />);
        const input = utils.getByRole('textbox');

        fireEvent.change(input, { target: { value: 'test' } });

        expect(screen.getByRole('textbox')).toHaveValue('test');
    });
});
