import React from 'react';

import classnames from 'classnames';

import Label from '../../Atoms/Label';
import ErrorMessage from '../../Atoms/ErrorMessage';

import './Textarea.scss';

export interface TextareaProps {
    id: string;
    name: string;
    rows?: number;
    state?: 'default' | 'error';
    label?: string;
    helperText?: string;
    labelTextStyles?: string;
    containerStyles?: string;
    helperTextStyles?: string;
    value?: string;
    errorMessage?: string;
    showErrorIcon?: boolean;
    errorMessageSize?: 'sm' | 'md' | 'lg';
    required?: boolean;
    optional?: boolean;
    disabled?: boolean;
    placeholder?: string;
    labelSize?: 'sm' | 'lg';
    allowResize?: boolean;
    keepErrorSpace?: boolean;
    onChange?: (text: string) => void;
}

const Textarea: React.FC<TextareaProps> = ({
    id,
    label,
    name,
    helperText,
    labelTextStyles = '',
    containerStyles = '',
    helperTextStyles = '',
    value,
    errorMessage,
    showErrorIcon = true,
    errorMessageSize = 'md',
    required,
    optional,
    disabled,
    onChange,
    state,
    placeholder,
    labelSize,
    rows = 5,
    allowResize = false,
    keepErrorSpace = false
}) => {
    return (
        <div className="textarea-wrapper">
            <label className="textarea-section" htmlFor={id}>
                {label && (
                    <Label
                        text={label}
                        size={labelSize}
                        helper={helperText}
                        required={required}
                        optional={optional}
                        labelTextStyles={labelTextStyles}
                        containerStyles={containerStyles}
                        helperTextStyles={helperTextStyles}
                        htmlFor={name}
                    />
                )}
                <textarea
                    id={id}
                    name={name}
                    placeholder={placeholder || 'Type...'}
                    disabled={disabled}
                    value={value}
                    className={classnames('textarea', {
                        'error-input': state === 'error',
                        'no-resize': !allowResize
                    })}
                    rows={rows}
                    onChange={(ev) => {
                        onChange && onChange(ev.target.value);
                    }}
                />
            </label>

            {errorMessage && state === 'error' ? (
                <ErrorMessage
                    data-testid="error-message-section"
                    message={errorMessage}
                    showIcon={showErrorIcon}
                    size={errorMessageSize}
                    className="textarea_error_message"
                />
            ) : (
                keepErrorSpace && <div style={{ height: '0.875rem' }}></div>
            )}
        </div>
    );
};

export default Textarea;
