import React, { useEffect } from 'react';

import './DonutPieChart.scss';
import DonutChart, { ChartData } from './chart';

export interface DonutPieChartProps {
    /**
     * Title for the chart or percentage value
     */
    title?: string;
    /**
     * caption for the chart
     */
    caption?: string;
    /**
     * data values for the charts accompanied by the colors
     */
    data: ChartData[];
    /**
     * size of the chart proportions
     */
    viewBoxSize?: number;
    /**
     * size of the radius of the chart from the center
     */
    innerRadius?: number;
    /**
     * size of the outer radius of the chart
     */
    outerRadius?: number;
    /**
     * duration taken for the animations
     */
    animationDuration?: number;
}

const DonutPieChart: React.FC<DonutPieChartProps> = ({
    data,
    title,
    caption,
    viewBoxSize = 500,
    innerRadius = 200,
    outerRadius = 250,
    animationDuration = 700
}) => {
    const ref = React.useRef(null);

    useEffect(() => {
        if (ref.current) {
            DonutChart(
                ref.current,
                data,
                viewBoxSize,
                innerRadius,
                outerRadius,
                animationDuration,
                title,
                caption
            );
        }
    }, [ref]);

    return (
        <div className="donut-pie-wrapper">
            <div className="graph" ref={ref} />
        </div>
    );
};

export default DonutPieChart;
