import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import DonutPieChart from './index';

const data = [
    { value: 80, color: '#3F187F' },
    { value: 25, color: '#8449CC' },
    { value: 15, color: '#D9D9D9' }
];

export const DefaultStory = () => <DonutPieChart data={data} title="80%" caption="used" />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/DonutPieChart',
    component: DonutPieChart
} as ComponentMeta<typeof DonutPieChart>;

const Template: ComponentStory<typeof DonutPieChart> = (args) => <DonutPieChart {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    title: '90%',
    caption: 'used',
    data
};
