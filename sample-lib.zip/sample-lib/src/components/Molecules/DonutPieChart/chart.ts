import * as d3 from 'd3';

export interface ChartData {
    value: number;
    color: string;
}

const DonutChart = (
    element: any,
    data: ChartData[],
    viewBoxSize: number,
    innerRadius: number,
    outerRadius: number,
    animationDuration: number,
    title?: string,
    caption?: string
) => {
    d3.select(element).select('svg').remove();

    const svg = d3
        .select(element)
        .append('svg')
        .attr('preserveAspectRatio', 'xMidYMid meet')
        .attr('height', '100%')
        .attr('width', '100%')
        .attr('viewBox', `0 0 ${viewBoxSize} ${viewBoxSize}`)
        .append('g')
        .attr('transform', `translate(${viewBoxSize / 2}, ${viewBoxSize / 2})`);

    const arcGenerator = d3
        .arc()
        .cornerRadius(0)
        .padAngle(0.02)
        .innerRadius(innerRadius)
        .outerRadius(outerRadius);

    const pieGenerator = d3
        .pie()
        .startAngle(0)
        .value((d) => d.value);

    const arcs = svg.selectAll().data(pieGenerator(data)).enter();

    arcs.append('path')
        .attr('d', arcGenerator)
        .style('fill', (d, _) => d.data.color)
        .transition()
        .duration(animationDuration)
        .attrTween('d', function (d) {
            const i = d3.interpolate(d.startAngle, d.endAngle);
            return function (t) {
                d.endAngle = i(t);
                return arcGenerator(d);
            };
        });

    svg.append('text')
        .attr('text-anchor', 'middle')
        .attr('y', '-20')
        .text(title)
        .style('font-size', 0)
        .transition()
        .duration(animationDuration)
        .style('font-size', '60px')
        .style('font-weight', 'bold')
        .style('font-family', 'BT Curve');

    svg.append('text')
        .attr('text-anchor', 'middle')
        .attr('y', '40')
        .text(caption)
        .style('font-size', 0)
        .transition()
        .duration(animationDuration)
        .style('font-size', '40px')
        .style('font-family', 'BT Curve');
};

export default DonutChart;
