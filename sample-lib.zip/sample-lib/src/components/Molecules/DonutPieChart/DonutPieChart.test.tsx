import React from 'react';
import { render } from '@testing-library/react';
import DonutPieChart from './index';

describe('DonutPieChart', () => {
  const testData = [
    { value: 30, color: '#FF5733' },
    { value: 50, color: '#33FF77' },
    { value: 20, color: '#3366FF' }
  ];

  it('renders with default props', () => {
    render(<DonutPieChart data={testData} />);
  });

  it('renders with custom props', () => {
    render(
      <DonutPieChart
        data={testData}
        title="Chart Title"
        caption="Chart Caption"
        viewBoxSize={400}
        innerRadius={150}
        outerRadius={200}
        animationDuration={500}
      />
    );
  });

});
