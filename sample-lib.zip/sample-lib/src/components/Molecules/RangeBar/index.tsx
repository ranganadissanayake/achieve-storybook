import React, { FC, useEffect, useState } from 'react';
import './RangeBar.scss';
import Input from '../Input';
import Label from '../../Atoms/Label';
import { isInteger } from 'lodash';

export interface RangeProps {
    /**
     * Set background type for graphical representation as DEFAULT | GRADIENT | SUCCESS | WARNING | CRITICAL
     */
    backgroundType:
        | BackgroundType.DEFAULT
        | BackgroundType.GRADIENT
        | BackgroundType.SUCCESS
        | BackgroundType.WARNING
        | BackgroundType.CRITICAL;
    /**
     * Set label for minimum input field
     */
    labelMin: string;
    /**
     * Set label for maximum input field
     */
    labelMax: string;
    /**
     * Set default value for minimum input field
     */
    defaultMinValue?: number;
    /**
     * Set default value for maximum input field
     */
    defaultMaxValue?: number;
    /**
     * Set placeholder for minimum input field
     */
    minPlaceholder?: string;
    /**
     * Set placeholder for maximum input field
     */
    maxPlaceholder?: string;
    /**
     * Set minimum input field
     */
    onMinChange?: (v: number) => void;
    /**
     * Set maximum input field
     */
    onMaxChange?: (v: number) => void;
    /**
     * Set minimum helper text
     */
    minHelperText?: string;
    /**
     * Set maximum helper text
     */
    maxHelperText?: string;
    /**
     * Set minimum helper text styles
     */
    minHelperTextStyle?: string;
    /**
     * Set maximum helper text styles
     */
    maxHelperTextStyle?: string;
    /**
     * Set range for minimum input range
     */
    maxInputRange: [number, number];
    /**
     * Set range for maximum input range
     */
    minInputRange: [number, number];
    /**
     * Set error icon for minimum error
     */
    showMinErrorIcon?: boolean;
    /**
     * Set error icon for maximum error
     */
    showMaxErrorIcon?: boolean;
    /**
     * Add custom class for stylings of minimum input field
     */
    customMinInputStyle?: string;
    /**
     * Add custom class for stylings of maximum input field
     */
    customMaxInputStyle?: string;
    /**
     * Set maximum error text
     */
    maxErrorText?: string;
    /**
     * Set minimum error text
     */
    minErrorText?: string;
    /**
     * Set error message for minimum > maximum
     */
    errorMinGreaterThanMax?: string;
    /**
     * Set error message for minimum > maximum
     */
    errorMaxGreaterThanMin?: string;
    /**
     * Set error message when min is empty
     */
    errorMinIsEmpty?: string;
    /**
     * Set error message when max is empty
     */
    errorMaxIsEmpty?: string;
    /**
     * Add custom styles for entire RangeBar component
     */
    customStyle?: string;
    /**
     * Set unit text
     */
    targetText?: string;
    /**
     * Set unit text size
     */
    targetTextSize?: 'lg' | 'sm' | 'xs';
    /**
     * Set unit text position
     */
    targetTextAlign?: 'start' | 'center' | 'end';
    /**
     * Add custom class for unit text styling
     */
    targetTextStyle?: string;
    /**
     * Set scale bar
     */
    enableScale?: boolean;
    /**
     * Disable fields
     */
    disabled?: boolean;
    /**
     * Reserve space for error message
     */
    keepErrorSpace?: boolean;
}

export enum BackgroundType {
    GRADIENT = 'linear-gradient(90deg, #FF7F00 0%, #34A827 6.77%, #34A827 48.44%, #34A827 93.23%, #FF7F00 100%)',
    SUCCESS = '#088003',
    WARNING = '#ffc501',
    DEFAULT = '#5514b4',
    CRITICAL = '#da020f'
}

export const RangeBar: FC<RangeProps> = ({
    backgroundType = BackgroundType.GRADIENT,
    labelMin,
    labelMax,
    maxInputRange,
    minInputRange,
    showMinErrorIcon = true,
    showMaxErrorIcon = true,
    customMinInputStyle,
    customMaxInputStyle,
    minErrorText,
    maxErrorText,
    errorMinGreaterThanMax,
    errorMaxGreaterThanMin,
    customStyle,
    targetText,
    targetTextSize = 'sm',
    targetTextStyle,
    enableScale = true,
    targetTextAlign = 'center',
    minPlaceholder,
    maxPlaceholder,
    minHelperText,
    maxHelperText,
    minHelperTextStyle,
    maxHelperTextStyle,
    keepErrorSpace = false,
    errorMinIsEmpty = '',
    errorMaxIsEmpty = '',
    defaultMinValue = null,
    defaultMaxValue = null,
    disabled = false,
    onMinChange,
    onMaxChange
}) => {
    const [valueMin, setValueMin] = useState<number>(defaultMinValue);
    const [valueMax, setValueMax] = useState<number>(defaultMaxValue);

    const [widthVal, setWidthVal] = useState(0);
    const [leftVal, setLeftVal] = useState(0);

    const [sliderWidth, setSliderWidth] = useState(0);
    const [sliderLeft, setSliderLeft] = useState(0);

    const [maxError, setMaxError] = useState('');
    const [minError, setMinError] = useState('');

    const onchangeMin = (value: number) => {
        if (onMinChange) {
            onMinChange(value);
        }

        setValueMin(value);
        if (valueMax && value >= valueMax) {
            setMinError(errorMinGreaterThanMax);
        } else if (value > minInputRange[1] || value < minInputRange[0] || !isInteger(value)) {
            setMinError(minErrorText);
        } else {
            setMinError('');
            setWidthVal(
                Math.floor(((valueMax - value) / (maxInputRange[1] - maxInputRange[0])) * 100)
            );
            setLeftVal(
                Math.floor(
                    100 - ((minInputRange[1] - value) / (minInputRange[1] - minInputRange[0])) * 100
                )
            );
        }
    };

    const onchangeMax = (value: number) => {
        if (onMaxChange) {
            onMaxChange(value);
        }
        
        setValueMax(value);
        if (valueMin && value <= valueMin) {
            setMaxError(errorMaxGreaterThanMin);
        } else if (value > maxInputRange[1] || value < maxInputRange[0] || !isInteger(value)) {
            setMaxError(maxErrorText);
        } else {
            setMaxError('');
            setWidthVal(
                Math.floor(((value - valueMin) / (maxInputRange[1] - maxInputRange[0])) * 100)
            );
        }
    };

    useEffect(() => {
        if (!minError && !maxError) {
            setSliderWidth(widthVal);
            setSliderLeft(leftVal);
        } else {
            setSliderWidth(0);
            setSliderLeft(0);
        }

        if (
            valueMin < valueMax &&
            valueMin >= minInputRange[0] &&
            valueMin <= minInputRange[1] &&
            valueMax >= maxInputRange[0] &&
            valueMax <= maxInputRange[1] &&
            isInteger(valueMin) &&
            isInteger(valueMax)
        ) {
            setMaxError('');
            setMinError('');
        }
    }, [widthVal, leftVal, minError, maxError]);

    React.useEffect(() => {
      if(defaultMinValue) {
        setValueMin(defaultMinValue);
        onchangeMin(defaultMinValue);
      }
      if(defaultMaxValue){
        setValueMax(defaultMaxValue);
        onchangeMax(defaultMaxValue);
      }
    }, [defaultMinValue, defaultMaxValue]);

    return (
        <>
            <div className={`range-wrapper ${customStyle}`}>
                <div className="range-inputs-wrapper">
                    <Input
                        label={labelMin}
                        type="integer"
                        name="min"
                        value={valueMin?.toString()}
                        onChange={(d: string) => onchangeMin(+d)}
                        className={customMinInputStyle}
                        errorMessage={minError || errorMinIsEmpty}
                        errorMessageSize={'sm'}
                        state={
                            disabled
                                ? 'disabled'
                                : minError || errorMinIsEmpty !== ''
                                ? 'error'
                                : 'default'
                        }
                        showErrorIcon={showMinErrorIcon}
                        iconSize={'md'}
                        placeholder={minPlaceholder}
                        helper={minHelperText}
                        helperTextStyles={minHelperTextStyle}
                        keepErrorSpace={keepErrorSpace}
                    />
                    <Input
                        label={labelMax}
                        type="integer"
                        name="max"
                        value={valueMax?.toString()}
                        onChange={(d: string) => onchangeMax(+d)}
                        className={`label-max-text ${customMaxInputStyle}`}
                        errorMessage={maxError || errorMaxIsEmpty}
                        errorMessageSize={'sm'}
                        showErrorIcon={showMaxErrorIcon}
                        iconSize={'md'}
                        state={
                            disabled
                                ? 'disabled'
                                : maxError || errorMaxIsEmpty !== ''
                                ? 'error'
                                : 'default'
                        }
                        placeholder={maxPlaceholder}
                        helper={maxHelperText}
                        helperTextStyles={maxHelperTextStyle}
                        keepErrorSpace={keepErrorSpace}
                    />
                </div>
                <div className="silder-wrapper">
                    <div className="silder-track">
                        <div
                            style={{
                                borderLeft: `${sliderWidth ? '1px solid black' : ''}`,
                                borderRight: `${sliderWidth ? '1px solid black' : ''}`,
                                width: `${sliderWidth}%`,
                                position: 'absolute',
                                left: `${sliderLeft}%`,
                                height: '100%',
                                background: `${backgroundType}`
                            }}
                        ></div>
                    </div>
                </div>
                {enableScale && (
                    <>
                        <div className="range-hr">
                            <div className="left"></div>
                            <div className="middle"></div>
                            <div className="right"></div>
                        </div>
                    </>
                )}

                <div className={`slider-unit-text`}>
                    <Label
                        text={targetText}
                        size={targetTextSize}
                        containerStyles={`text--${targetTextAlign} ${targetTextStyle}`}
                    />
                </div>
            </div>
        </>
    );
};

export default RangeBar;
