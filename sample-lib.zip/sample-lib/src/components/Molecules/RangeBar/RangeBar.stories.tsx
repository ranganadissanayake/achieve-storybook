import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { BackgroundType, RangeBar } from './index';

export const DefaultStory = () => (
    <RangeBar
        backgroundType={BackgroundType.DEFAULT}
        labelMin="Min Utilisation Threshold"
        labelMax="Max Utilisation Threshold"
        maxInputRange={[1, 102]}
        minInputRange={[0, 100]}
        minErrorText="Max"
        maxErrorText="Min"
        targetText="500 Mbps"
    />
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/RangeBar',
    component: RangeBar
} as ComponentMeta<typeof RangeBar>;

const Template: ComponentStory<typeof RangeBar> = (args) => <RangeBar {...args} />;

export const Playground = Template.bind({});
Playground.args = {
    labelMin: 'Minimum',
    labelMax: 'Maximum',
    minInputRange: [1, 99],
    maxInputRange: [2, 100],
    minErrorText: 'Out of min',
    maxErrorText: 'Out of max',
    showMinErrorIcon: true,
    showMaxErrorIcon: true,
    customStyle: '',
    errorMinGreaterThanMax: 'Value must less than max threshold',
    errorMaxGreaterThanMin: 'Value must greater than min threshold',
    backgroundType: BackgroundType.GRADIENT,
    targetText: '500 Mbps',
    enableScale: true,
    targetTextAlign: 'center',
    minPlaceholder: '1-99%',
    maxPlaceholder: '2-100%',
    onMinChange: (v: number) => {
        console.log(v);
    },
    onMaxChange: (v: number) => {
        console.log(v);
    }
};
