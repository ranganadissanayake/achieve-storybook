import React from 'react';
import { render, screen } from '@testing-library/react';
import user from '@testing-library/user-event';

import RangeBar, { BackgroundType } from './index';

describe('RangeBar', () => {
    beforeEach(() => {
        render(
            <RangeBar
                backgroundType={BackgroundType.DEFAULT}
                labelMin="Min Utilisation Threshold"
                labelMax="Max Utilisation Threshold"
                maxInputRange={[1, 102]}
                minInputRange={[0, 100]}
                minErrorText="Out of min"
                maxErrorText="Out of max"
                targetText="500 Mbps"
                minPlaceholder="1-99%"
                maxPlaceholder="2-100%"
                defaultMinValue={20}
                defaultMaxValue={80}
            />
        );
    });

    test('renders the RangeBar component with correct titles', () => {
        expect(screen.getByText("Min Utilisation Threshold")).toBeInTheDocument();
        expect(screen.getByText("Max Utilisation Threshold")).toBeInTheDocument();
    });

    test('displays the target text', () => {
        expect(screen.getByText("500 Mbps")).toBeInTheDocument();
    });

    test('correct default values for min and max inputs', () => {
        const minInput = screen.getByPlaceholderText("1-99%");
        const maxInput = screen.getByPlaceholderText("2-100%");
        expect(minInput).toHaveValue(20);
        expect(maxInput).toHaveValue(80);
    });

    test('displays min and max error messages displays',  () => {
        render(
            <RangeBar
                backgroundType={BackgroundType.DEFAULT}
                labelMin="Min Utilisation Threshold"
                labelMax="Max Utilisation Threshold"
                maxInputRange={[1, 102]}
                minInputRange={[0, 100]}
                minErrorText="Out of min"
                maxErrorText="Out of max"
                targetText="500 Mbps"
                minPlaceholder="1-99%"
                maxPlaceholder="2-100%"
                defaultMinValue={200}
                defaultMaxValue={800}
            />
        )

         expect(screen.getByText("Out of min")).toBeInTheDocument();
         expect(screen.getByText("Out of max")).toBeInTheDocument();
    });

    test('displays error message when min is greater than max',  () => {
        render(
            <RangeBar
                backgroundType={BackgroundType.DEFAULT}
                labelMin="Min Utilisation Threshold"
                labelMax="Max Utilisation Threshold"
                maxInputRange={[1, 102]}
                minInputRange={[0, 100]}
                minErrorText="Out of min"
                maxErrorText="Out of max"
                targetText="500 Mbps"
                minPlaceholder="1-99%"
                maxPlaceholder="2-100%"
                defaultMinValue={70}
                defaultMaxValue={50}
                errorMinGreaterThanMax="Value must less than max threshold"
                errorMaxGreaterThanMin="Value must greater than min threshold"
            />
        )

         expect(screen.getByText("Value must less than max threshold")).toBeInTheDocument();
         expect(screen.getByText("Value must greater than min threshold")).toBeInTheDocument();
    });

    test('displays error message when min is greater than max',  async () => {
        render(
            <RangeBar
                backgroundType={BackgroundType.DEFAULT}
                labelMin="Min Utilisation Threshold"
                labelMax="Max Utilisation Threshold"
                maxInputRange={[1, 102]}
                minInputRange={[0, 100]}
                minErrorText="Out of min"
                maxErrorText="Out of max"
                targetText="500 Mbps"
                minPlaceholder="1-99%"
                maxPlaceholder="2-100%"
                defaultMinValue={70}
                defaultMaxValue={50}
                errorMinGreaterThanMax="Value must less than max threshold"
                errorMaxGreaterThanMin="Value must greater than min threshold"
                disabled
            />
        )

        const min = await screen.getByDisplayValue(50);
        const max = await screen.getByDisplayValue(70);

         expect(min).toBeDisabled();
         expect(max).toBeDisabled();
    });
});