import * as React from 'react';
import 'react-datepicker/dist/react-datepicker.css';
import './DateSelector.scss';
import DatePicker from 'react-datepicker';

export interface DateSelectorProps {
    onChange?: (value: any) => void;
    minDate?: Date;
    onCalendarClose?:() => void;
    onCalendarOpen?:() => void;
}

const DateSelector: React.FC<DateSelectorProps> = ({ onChange, minDate, onCalendarClose, onCalendarOpen }) => {
    const [startDate, setStartDate] = React.useState(new Date());

    React.useEffect(() => {
        if (onChange) {
            onChange(startDate);
        }
    }, [startDate]);
    
    return (
        <DatePicker
            showIcon
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            toggleCalendarOnIconClick
            calendarClassName="date-picker-wrapper"
            minDate={minDate}
            onCalendarClose={onCalendarClose}
            onCalendarOpen={onCalendarOpen}
            dateFormat="dd/MM/yyyy"
            icon={
                <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        fill-rule="evenodd"
                        clip-rule="evenodd"
                        d="M2.5 2.5H0.833333C0.612522 2.50066 0.400944 2.58867 0.244806 2.74481C0.0886686 2.90094 0.00065947 3.11252 0 3.33333V19.1667C0.00065947 19.3875 0.0886686 19.5991 0.244806 19.7552C0.400944 19.9113 0.612522 19.9993 0.833333 20H19.1667C19.3875 19.9993 19.5991 19.9113 19.7552 19.7552C19.9113 19.5991 19.9993 19.3875 20 19.1667V3.33333C19.9993 3.11252 19.9113 2.90094 19.7552 2.74481C19.5991 2.58867 19.3875 2.50066 19.1667 2.5H17.5V0.416667C17.5 0.30616 17.4561 0.200179 17.378 0.122039C17.2998 0.0438988 17.1938 0 17.0833 0C16.9728 0 16.8668 0.0438988 16.7887 0.122039C16.7106 0.200179 16.6667 0.30616 16.6667 0.416667V2.5H3.33333V0.416667C3.33333 0.30616 3.28943 0.200179 3.21129 0.122039C3.13315 0.0438988 3.02717 0 2.91667 0C2.80616 0 2.70018 0.0438988 2.62204 0.122039C2.5439 0.200179 2.5 0.30616 2.5 0.416667V2.5ZM3.33333 3.33333V3.75C3.33333 3.86051 3.28943 3.96649 3.21129 4.04463C3.13315 4.12277 3.02717 4.16667 2.91667 4.16667C2.80616 4.16667 2.70018 4.12277 2.62204 4.04463C2.5439 3.96649 2.5 3.86051 2.5 3.75V3.33333H0.833333V6.66667H19.1667V3.33333H17.5V3.75C17.5 3.86051 17.4561 3.96649 17.378 4.04463C17.2998 4.12277 17.1938 4.16667 17.0833 4.16667C16.9728 4.16667 16.8668 4.12277 16.7887 4.04463C16.7106 3.96649 16.6667 3.86051 16.6667 3.75V3.33333H3.33333ZM0.833333 7.5V19.1667H19.1667V7.5H0.833333Z"
                        fill="#2A2A2A"
                    />
                </svg>
            }
        />
    );
};

export default DateSelector;
