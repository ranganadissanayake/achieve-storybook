import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import './DateSelector.scss';

import DateSelector from './index';

export const DefaultStory = () => <DateSelector />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/DateSelector',
    component: DateSelector
} as ComponentMeta<typeof DateSelector>;

const Template: ComponentStory<typeof DateSelector> = (args) => {
    return (
        <div className="date-story-wrapper">
            <DateSelector {...args} />{' '}
        </div>
    );
};

const getToday = new Date();
export const Playground = Template.bind({});

const onChangeFn = (value: any) => {
    console.log(value);
};

const onCalendarClose = () => {
    console.log("Calendar Close");
};

const onCalendarOpen = () => {
    console.log("Calendar Open");
};

Playground.args = {
    onChange: onChangeFn,
    minDate: getToday,
    onCalendarClose: onCalendarClose,
    onCalendarOpen: onCalendarOpen
};
