import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import DateSelector from './index';

describe('DateSelector', () => {
    it('renders without crashing', () => {
        render(<DateSelector />);
    });

    it('calls onChange when date is selected', () => {
        const onChangeMock = jest.fn();
        const { container } = render(<DateSelector onChange={onChangeMock} />);
        const datePickerInput = container.querySelector('.react-datepicker__input-container input');

        if (datePickerInput) {
            fireEvent.change(datePickerInput, { target: { value: new Date('2024-06-07') } });
        } else {
            // Handle case when input element is not found
            throw new Error('Datepicker input element not found');
        }

        expect(onChangeMock).toHaveBeenCalledTimes(2);
    });

    test('calls onCalendarClose and onCalendarOpen when calendar is toggled', () => {
        const onCalendarCloseMock = jest.fn();
        const onCalendarOpenMock = jest.fn();
        const minDate = new Date('2024-06-10');
        const { container } = render(
            <DateSelector
                minDate={minDate}
                onCalendarClose={onCalendarCloseMock}
                onCalendarOpen={onCalendarOpenMock}
            />
        );
        const datePickerInput = container.querySelector('.react-datepicker__input-container input');

        if (datePickerInput) {
            fireEvent.click(datePickerInput);
        }

        expect(onCalendarOpenMock).toHaveBeenCalled();
    });
});
