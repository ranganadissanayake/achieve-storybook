import React from 'react';
import classnames from 'classnames';

import './Tab.scss';
import TabTitle, { TabTitleProps } from './TabTitle';

export interface TabProps {
    children: React.ReactElement<TabTitleProps>[];
    variant?: 'background' | 'border';
    preSelectedTab?: number;
}

const Tab: React.FC<TabProps> = ({ children, variant, preSelectedTab = 0 }) => {
    let variantStyle = '';
    const [selectedTabIndex, setSelectedTabIndex] = React.useState<number>(0);

    variantStyle = `tab-${variant || 'background'}`;

    const overflowLimiter = (value: number) => {
        const limit = children.length;
        if (value >= limit) {
            setSelectedTabIndex(limit - 1);
        } else if (value <= 0) {
            setSelectedTabIndex(0);
        } else {
            setSelectedTabIndex(value);
        }
    };

    React.useEffect(() => {
        if (typeof preSelectedTab === 'number') {
            overflowLimiter(preSelectedTab);
        }
    }, [preSelectedTab]);

    return (
        <div>
            <div data-testid="variant-selector" className={classnames(variantStyle)}>
                <div className={classnames(variantStyle + '--list')}>
                    {children.map((item, index) => (
                        <TabTitle
                            key={item.props.label}
                            index={index}
                            label={item.props.label}
                            setSelectedTab={setSelectedTabIndex}
                            isActive={index === selectedTabIndex}
                        />
                    ))}
                </div>
            </div>
            {children[selectedTabIndex]}
        </div>
    );
};

export default Tab;
