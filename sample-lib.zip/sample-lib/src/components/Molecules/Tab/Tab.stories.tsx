import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Tab from "./index";
import TabContent from "./TabContent";

export const DefaultStory = () => (
  <Tab>
    <TabContent label="first">
      <div> first tab</div>
    </TabContent>
    <TabContent label="second">
      <div> second tab</div>
    </TabContent>
    <TabContent label="third">
      <div> third tab</div>
    </TabContent>
  </Tab>
);

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Molecules/Tab",
  component: Tab,
} as ComponentMeta<typeof Tab>;

const Template: ComponentStory<typeof Tab> = (args) => (
  <Tab {...args}>
    <TabContent label="first">
      <div> first tab</div>
    </TabContent>
    <TabContent label="second">
      <div> second tab</div>
    </TabContent>
    <TabContent label="third">
      <div> third tab</div>
    </TabContent>
  </Tab>
);

export const Playground = Template.bind({});

Playground.args = {
  preSelectedTab: 0,
};
