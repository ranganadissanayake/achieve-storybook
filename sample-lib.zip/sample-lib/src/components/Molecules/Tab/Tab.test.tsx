import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";

import Tab from "./index";
import TabContent from "./TabContent";

describe("Tab", () => {
  test("renders the Tab component", () => {
    render(
      <Tab>
        <TabContent label="first">
          <div> first tab</div>
        </TabContent>
        <TabContent label="second">
          <div> second tab</div>
        </TabContent>
        <TabContent label="third">
          <div> third tab</div>
        </TabContent>
      </Tab>
    );

    expect(screen.getByText("first")).toBeInTheDocument();
    expect(screen.getByText("second")).toBeInTheDocument();
    expect(screen.getByText("third")).toBeInTheDocument();
    expect(screen.getByText("first tab")).toBeInTheDocument();
  });
  test("add background class for background tab component", () => {
    render(
      <Tab>
        <TabContent label="first">
          <div> first tab</div>
        </TabContent>
        <TabContent label="second">
          <div> second tab</div>
        </TabContent>
      </Tab>
    );

    expect(screen.getByTestId("variant-selector")).toHaveClass(
      "tab-background"
    );
  });
  test("add border class for bordered tab component", () => {
    render(
      <Tab variant="border">
        <TabContent label="first">
          <div> first tab</div>
        </TabContent>
        <TabContent label="second">
          <div> second tab</div>
        </TabContent>
      </Tab>
    );

    expect(screen.getByTestId("variant-selector")).toHaveClass("tab-border");
  });
  test("preselect the second item when presect is passed to the tab component", () => {
    render(
      <Tab preSelectedTab={1}>
        <TabContent label="first">
          <div> first tab</div>
        </TabContent>
        <TabContent label="second">
          <div> second tab</div>
        </TabContent>
      </Tab>
    );

    expect(screen.getByText("second tab")).toBeInTheDocument();
  });
  test("switch tab when one is clicked tab component", () => {
    render(
      <Tab>
        <TabContent label="first">
          <div> first tab</div>
        </TabContent>
        <TabContent label="second">
          <div> second tab</div>
        </TabContent>
      </Tab>
    );

    expect(screen.getByText("first tab")).toBeInTheDocument();
    fireEvent.click(screen.getByText("second"));

    expect(screen.getByText("second tab")).toBeInTheDocument();
  });
  test('overflowLimiter selects last tab when preSelectedTab value is greater than the length of children', () => {
      render(
          <Tab preSelectedTab={10}>
              <TabContent label="first">
                  <div> first tab</div>
              </TabContent>
              <TabContent label="second">
                  <div> second tab</div>
              </TabContent>
          </Tab>
      );

      expect(screen.getByText('second tab')).toBeInTheDocument();
  });
});
