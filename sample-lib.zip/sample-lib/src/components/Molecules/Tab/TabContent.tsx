import React from "react";
import classnames from "classnames";

import "./Tab.scss";
export interface TabContentProps {
  label: string;
  children?: React.ReactElement | React.ReactElement[];
  contentSylesClassname?: string;
}

const TabContent: React.FC<TabContentProps> = ({
  children,
  contentSylesClassname,
}) => {
  return (
    <div
      className={classnames("tab-content", {
        [contentSylesClassname]: contentSylesClassname,
      })}
    >
      {children}
    </div>
  );
};

export default TabContent;
