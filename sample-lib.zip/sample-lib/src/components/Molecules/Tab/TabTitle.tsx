import React from "react";
import classnames from "classnames";

import "./Tab.scss";
export interface TabTitleProps {
  label: string;
  index: number;
  setSelectedTab: (index: number) => void;
  isActive?: boolean;
}

const TabTitle: React.FC<TabTitleProps> = ({
  label,
  index,
  setSelectedTab,
  isActive,
}) => {
  let stateStyles = "";
  const handleOnClick = React.useCallback(() => {
    setSelectedTab(index);
  }, [setSelectedTab, index]);
  stateStyles = isActive ? "tab-active" : "tab-inActive";
  return (
    <button onClick={handleOnClick} className={classnames("tab", stateStyles)}>
      <span className="tab--label">{label}</span>
    </button>
  );
};

export default TabTitle;
