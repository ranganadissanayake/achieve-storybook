import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Tile from "./index";

export const DefaultStory = () => (
    <Tile>
        <h4>Message</h4><br />
        <p>Sample description</p>
    </Tile>
);

DefaultStory.storyName = "Default";

export default {
    title: "ReactComponentLibrary/Molecules/Tile",
    component: Tile,
} as ComponentMeta<typeof Tile>;

const Template: ComponentStory<typeof Tile> = (args) => (
    <Tile {...args} />
);

export const Playground = Template.bind({});
Playground.args = {
    children: <p>Sample content </p>
};
