import React from 'react';
import './Tile.scss';


export interface TileProps {
  customClassName?: string;
}

const Tile = ({
  customClassName,
  children
}: React.PropsWithChildren<TileProps>) => {
  return (
    <div
      className="tile-container"
      data-testId="tile"
    >
      <div
        className={`tile ${customClassName}`}
      >
        {children}
      </div>
    </div>
  );
}

export default Tile;