import React from "react";
import { render, screen } from "@testing-library/react";
import Tile from "./index";

describe("Tile", () => {
  test("should render the alert component", () => {
    render(<Tile><span>Sample child content</span></Tile>);
    expect(screen.getByTestId("tile")).toBeInTheDocument();
  });

});