import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Breadcrumb, { Crumb } from './index';
import Icon from '../../Atoms/Icon';

const crumbs: Crumb[] = [
    { onClick: () => console.log('item1'), name: 'Item1' },
    { onClick: () => console.log('item2'), name: 'Item2' },
    { onClick: () => console.log('item3'), name: 'Item3' },
    { onClick: () => console.log('item4'), name: 'Item4' },
    { name: 'Current Page' }
];
export const DefaultStory = () => <Breadcrumb crumbs={crumbs} separator=">" />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/Breadcrumb',
    component: Breadcrumb
} as ComponentMeta<typeof Breadcrumb>;

const Template: ComponentStory<typeof Breadcrumb> = (args) => <Breadcrumb {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    separator: '>',
    crumbs: [
        {
            name: 'Crumb1',
            iconBefore: true,
            icon: <Icon title="call_routing" />,
            onClick: () => console.log('crumb1')
        },
        {
            name: 'Crumb2',
            iconBefore: true,
            icon: <Icon title="alert" />,
            onClick: () => console.log('crumb2')
        },
        {
            onClick: () => console.log('crumb3'),
            name: 'Crumb3',
            iconBefore: true,
            icon: <Icon title="add" />
        },
        {
            onClick: () => console.log('crumb4'),
            name: 'Crumb4',
            iconBefore: false,
            icon: <Icon title="archive" />
        },
        {
            onClick: () => console.log('crumb5'),
            name: 'Crumb5',
            icon: <Icon title="calender_accepted" />
        },
        {
            name: 'Crumb6',
            iconBefore: true,
            icon: <Icon title="cross" />
        }
    ]
};
