import React, { Fragment } from 'react';
import './Breadcrumb.scss';

/**
 * The properties required for the Breadcrumb Component
 * @author Charith Abeygunawardhana <charith.abeygunawardhana@bt.com>
 */
export type Crumb = {
    name: string;
    icon?: string | React.ReactElement;
    iconBefore?: boolean;
    onClick?: () => void;
};
export interface BreadcrumbProps {
    /**
     * Crumbs consists of name, onClick, icon and iconBefore attributes. onClick, icon and iconBefore are optional. By default iconBefore is set to true
     */
    crumbs: Crumb[];
    /**
     * Add crumbs separator as a string
     */
    separator: string | React.ReactNode;
}

const Breadcrumb: React.FC<BreadcrumbProps> = ({ crumbs, separator }) => {

    return (
        <section className="breadcrumb" data-testid="breadcrumb-content">
            {crumbs.map(({ name, icon, iconBefore = true, onClick }, i) => {
                const isLast = i === crumbs.length - 1;
                if (!isLast) {
                    return (
                        <Fragment key={i}>
                            {icon && iconBefore && (
                                <div
                                    className="crumb-icon"
                                    data-testid="crumb-icon"
                                >
                                    {icon}
                                </div>
                            )}

                            <a onClick={onClick} className="crumb-text" key={i}>
                                {name}
                            </a>

                            {icon && !iconBefore && (
                                <div
                                    className="crumb-icon"
                                    data-testid="crumb-icon-first-after"
                                >
                                    {icon}
                                </div>
                            )}
                            <div className="crumb-separator">
                                {separator}
                            </div>
                        </Fragment>
                    );
                }

                return (
                    <Fragment key={i}>
                        {icon && iconBefore && (
                            <div
                                className="crumb-icon-selected"
                                data-testid="crumb-icon-last"
                            >
                                {icon}
                            </div>
                        )}

                        <span
                            className="crumb-selected"
                            data-testid="crumb-name"
                        >
                            {name}
                        </span>

                        {icon && !iconBefore && (
                            <div
                                className="crumb-icon-selected"
                                data-testid="crumb-icon-last-after"
                            >
                                {icon}
                            </div>
                        )}
                    </Fragment>
                );
            })}
        </section>
    );
};

export default Breadcrumb;
