import React from 'react';
import { render, screen } from '@testing-library/react';

import Breadcrumb from './index';
import Icon from '../../Atoms/Icon';

const mockCrumbs = [
    { onClick: () => console.log('crumb'), name: 'crumb1' },
    { onClick: () => console.log('crumb'), name: 'crumb2' },
    { onClick: () => console.log('crumb'), name: 'crumb3', icon: <Icon title="call_routing" /> },
    { name: 'crumb4', icon: <Icon title="call_routing" /> }
];

const mockCrumbsIconAfter = [
    { onClick: () => console.log('crumb'), name: 'crumb1' },
    { onClick: () => console.log('crumb'), name: 'crumb2' },
    {
        onClick: () => console.log('crumb'),
        name: 'crumb3',
        icon: <Icon title="call_routing" />,
        iconBefore: false
    },
    {
        name: 'crumb4',
        icon: <Icon title="call_routing" />,
        iconBefore: false
    }
];

describe('Breadcrumb', () => {
    test('renders the Breadcrumb component', () => {
        render(<Breadcrumb crumbs={[]} separator=">" />);
        expect(screen.getByTestId('breadcrumb-content')).toBeInTheDocument();
    });

    test('renders with the crumb with link', () => {
        render(<Breadcrumb crumbs={mockCrumbs} separator=">" />);
        expect(screen.getByTestId('crumb-name')).toBeInTheDocument();
    });
    test('renders with the crumb icon', () => {
        render(<Breadcrumb crumbs={mockCrumbs} separator=">" />);
        expect(screen.getByTestId('crumb-icon')).toBeInTheDocument();
    });
    test('renders with the crumb icon in last crumb', () => {
        render(<Breadcrumb crumbs={mockCrumbs} separator=">" />);
        expect(screen.getByTestId('crumb-icon-last')).toBeInTheDocument();
    });
    test('renders with the crumb icon in last after the crumb text', () => {
        render(<Breadcrumb crumbs={mockCrumbsIconAfter} separator=">" />);
        expect(screen.getByTestId('crumb-icon-last-after')).toBeInTheDocument();
    });
    test('renders with the crumb icon in linked items after the crumb text', () => {
        render(<Breadcrumb crumbs={mockCrumbsIconAfter} separator=">" />);
        expect(screen.getByTestId('crumb-icon-first-after')).toBeInTheDocument();
    });
});
