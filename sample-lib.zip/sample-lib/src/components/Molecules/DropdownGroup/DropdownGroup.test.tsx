import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

import DropDownGroup from './index';
const props = {
    options: [
        { label: 'Locations', value: 'location', name: 'location' },
        { label: 'Marketplace', value: 'marketplace', name: 'location' },
        { label: 'Knowledge Hub', value: 'knowledge', name: 'location' }
    ],
    label: 'Options',
    isClearValue: true
};

describe('DropDownGroup', () => {
    test('renders the DropDownGroup component', () => {
        render(<DropDownGroup {...props} type="radio" />);

        expect(screen.getByText('Options')).toBeInTheDocument();
    });

    test('click event on the DropDownGroup to show radio', () => {
        render(<DropDownGroup {...props} type="radio" />);

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);
        expect(screen.getByText('location')).toBeInTheDocument();
    });

    test('select an option when the DropDownGroup is a radio', () => {
        const onChange = jest.fn();
        render(<DropDownGroup {...props} type="radio" />);

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);
        const option = screen.getByText('location');
        fireEvent.click(option);
        expect(screen.getByText('location')).toBeInTheDocument();
    });

    test('renders the DropDownGroup component with no options', () => {
        const noOptionsProps = {
            label: 'Options'
        };
        render(<DropDownGroup {...noOptionsProps} type="radio" />);

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);

        expect(screen.getByText('Options')).toBeInTheDocument();
    });

    test('clears the selection when the DropDownGroup is a radio', () => {
        const selectSideEffectsMock = jest.fn();
        render(
            <DropDownGroup
                {...props}
                type="radio"
                selectSideEffects={selectSideEffectsMock}
                defaultValue={['location']}
            />
        );

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);

        const radioOption = screen.getByLabelText('location');
        fireEvent.click(radioOption);

        expect(selectSideEffectsMock).toHaveBeenCalledWith([]);
    });

    test('click event on the DropDownGroup to show Checkbox', () => {
        render(<DropDownGroup {...props} type="checkbox" />);

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);

        expect(screen.getByText('marketplace')).toBeInTheDocument();
    });

    test('click event on the DropDownGroup to show Range', () => {
        render(<DropDownGroup {...props} type="range" />);

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);

        expect(screen.getByText('From')).toBeInTheDocument();
        expect(screen.getByTestId('range-slider')).toBeInTheDocument();
    });

    test('displays the correct value when the user drags the range slider', () => {
        render(<DropDownGroup {...props} type="range" />);
        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);
        const rangeSlider = screen.getByTestId('range-slider');
        fireEvent.mouseDown(rangeSlider);
        fireEvent.mouseMove(rangeSlider, { clientX: 200 });
        fireEvent.mouseUp(rangeSlider);
    });

    test('handles click outside of popover', () => {
        const setShowCTAPopover = jest.fn();
        const setShowPopover = jest.fn();
        const handleClickOutside = jest.fn();
        render(<DropDownGroup {...props} type="checkbox" setShowPopover={setShowPopover} />);

        fireEvent.click(screen.getByTestId('dropdown-group-trigger'));
        expect(screen.getByText('Options')).toBeInTheDocument();

        fireEvent.mouseDown(document.body);
        fireEvent.mouseUp(document.body);

        expect(setShowPopover).toHaveBeenCalledWith(false);
    });

    test('select a checkbox option and invoke side effects', () => {
        const selectSideEffectsMock = jest.fn();
        render(
            <DropDownGroup {...props} type="checkbox" selectSideEffects={selectSideEffectsMock} />
        );

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);

        const checkboxOption = screen.getByLabelText('location');
        fireEvent.click(checkboxOption);

        expect(selectSideEffectsMock).toHaveBeenCalledWith(['location']);
    });

    test('deselect a checkbox option and invoke side effects', () => {
        const selectSideEffectsMock = jest.fn();
        render(
            <DropDownGroup
                {...props}
                type="checkbox"
                defaultValue={['location']}
                selectSideEffects={selectSideEffectsMock}
            />
        );

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);

        const checkboxOption = screen.getByLabelText('location');
        fireEvent.click(checkboxOption);

        expect(selectSideEffectsMock).toHaveBeenCalledWith([]);
    });

    test('clears the selection when the DropDownGroup is a checkbox', () => {
        const selectSideEffectsMock = jest.fn();
        render(
            <DropDownGroup
                {...props}
                type="checkbox"
                selectSideEffects={selectSideEffectsMock}
                defaultValue={['location', 'marketplace']}
            />
        );

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);

        const checkboxOption = screen.getByLabelText('location');
        fireEvent.click(checkboxOption);

        expect(selectSideEffectsMock).toHaveBeenCalledWith(['marketplace']);
    });

    test('clears the selection when the DropDownGroup is a range', () => {
        const selectSideEffectsMock = jest.fn();
        render(
            <DropDownGroup
                {...props}
                type="range"
                selectSideEffects={selectSideEffectsMock}
                defaultValue={['10 - 50']}
            />
        );

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);
    });

    test('displays range slider and handles range button', () => {
        render(<DropDownGroup {...props} type="range" rangeButton={true} />);

        const input = screen.getByTestId('dropdown-group-trigger');
        fireEvent.click(input);

        const rangeSlider = screen.getByTestId('range-slider');
        expect(rangeSlider).toBeInTheDocument();

        const rangeButton = screen.getByText('Select');
        fireEvent.click(rangeButton);
    });

    test('clears the selection when isClear value is empty', () => {
        render(<DropDownGroup {...props} type="radio" rangeButton={true} />);

        expect(screen.queryByTestId("badge-wrapper")).not.toBeInTheDocument();
    });
});
