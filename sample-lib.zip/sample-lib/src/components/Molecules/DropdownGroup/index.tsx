import React from 'react';

import { useOnClickOutside } from '../../../hooks';

import './DropdownGroup.scss';
import '../DropdownInput/DropdownInput.scss';
import Label from '../../Atoms/Label';
import Checkbox from '../Checkbox';
import Radio from '../Radio';
import RangeSlider from '../RangeSlider';
import Badge from '../../Atoms/Badge';
import classnames from 'classnames';
import Icon from '../../Atoms/Icon';
import Button from '../Button';

export interface DropDownGroupOption {
    label?: string;
    name?: string;
    value: string;
}

export interface DropDownGroupProps {
    label?: string;
    type?: 'radio' | 'checkbox' | 'range';
    options?: Option[];
    rangeDefault?: { min: number; max: number };
    range?: { min: number; max: number };
    rangeUnit?: string;
    selectSideEffects?: (value: string | string[]) => void;
    defaultValue?: string[];
    rangeButton?: boolean;
    rangeButtonLabel?: string;
    controlledShowPopover?: boolean;
    setShowPopover?: (controlledShowPopover: boolean) => void;
    leftValidationRangebar?: string;
    rightValidationRangebar?: string;
    unitTextRangebar?: string;
    inputType?: 'number' | 'float';
    numberOfDecimalPlaces?: number;
    isClearValue?: boolean;
}

const DropDownGroup: React.FC<DropDownGroupProps> = ({
    label = '',
    options,
    type,
    range = { min: 0, max: 200 },
    rangeDefault = { min: 0, max: 200 },
    selectSideEffects,
    defaultValue = [],
    rangeButton,
    rangeButtonLabel = 'Select',
    controlledShowPopover,
    setShowPopover,
    leftValidationRangebar = 'Input value must be less than Max value',
    rightValidationRangebar = 'Input value must be greater than Min value',
    unitTextRangebar = 'Gbps',
    inputType,
    numberOfDecimalPlaces,
    isClearValue = false
}) => {
    const [showCTAPopover, setShowCTAPopover] = React.useState(false);
    const popoverRef = React.useRef<HTMLDivElement>(null);
    const [select, setSelect] = React.useState<string[]>(defaultValue);
    const [selectRange, setSelectRange] = React.useState({ ...range });

    const handleClickOutside = () => {
        setShowCTAPopover(!showCTAPopover);
        setShowPopover && setShowPopover(false);
    };

    useOnClickOutside(popoverRef, handleClickOutside);

    const handleSelectCheckbox = (value: boolean, option: Option) => {
        if (value) {
            setSelect([...select, option.value]);
            selectSideEffects && selectSideEffects([...select, option.value]);
            setSelect([...select, option.value]);
            selectSideEffects && selectSideEffects([...select, option.value]);
        } else {
            setSelect(select.filter((text) => text !== option.value));
            selectSideEffects && selectSideEffects(select.filter((text) => text !== option.value));
        }
    };
    const handleSelectRadio = (value: string) => {
        setShowCTAPopover(false);
        setShowPopover && setShowPopover(false);

        if (value !== select[0]) {
            setSelect([value]);
            selectSideEffects && selectSideEffects([value]);
        } else {
            setSelect([]);
            selectSideEffects && selectSideEffects([]);
        }
    };

    const handleSelectRange = ({ min, max }: { min: number; max: number }, clear?: boolean) => {
        setSelect([`${min} - ${max}`]);
        selectSideEffects && selectSideEffects([`${min} - ${max}`]);

        if (clear) {
            setSelect([]);
            selectSideEffects && selectSideEffects([]);
        }
    };

    const handleClear = (value?: string) => {
        setShowCTAPopover(false);
        setShowPopover && setShowPopover(false);

        switch (type) {
            case 'checkbox':
                return handleSelectCheckbox(false, { value: value });
            case 'radio':
                return handleSelectRadio(value);
            case 'range':
                return handleSelectRange({ ...rangeDefault }, true);
        }
    };

    const renderSelection = () => {
        switch (type) {
            case 'checkbox':
                return options.map((option) => (
                    <Checkbox
                        key={option.value}
                        id={option.value}
                        name={option.value}
                        isCheckedDefault={select.includes(option.value)}
                        onSelect={(value) => handleSelectCheckbox(value, option)}
                    />
                ));
            case 'radio':
                return options.map((option) => (
                    <Radio
                        key={option.value}
                        id={option.value}
                        inputname={option.name}
                        name={option.value}
                        isCheckedDefault={select.includes(option.value)}
                        onSelectValue={(value) => handleSelectRadio(value)}
                    />
                ));
            case 'range':
                return (
                    <div className="range-section">
                        <RangeSlider
                            min={rangeDefault.min}
                            max={rangeDefault.max}
                            onChangeSlider={({ min, max }: { min: number; max: number }) => {
                                setSelectRange({ min, max });
                                !rangeButton && handleSelectRange({ min, max });
                            }}
                            minDefault={selectRange.min}
                            maxDefault={selectRange.max}
                            unitText={unitTextRangebar}
                            leftLabel={'From'}
                            rightLabel={'To'}
                            leftValidationMessage={leftValidationRangebar}
                            rightValidationMessage={rightValidationRangebar}
                            inputType={inputType}
                            numberOfDecimalPlaces={numberOfDecimalPlaces}
                        />
                        {rangeButton && (
                            <Button
                                variant="outline"
                                label={rangeButtonLabel}
                                onPress={() => {
                                    handleSelectRange({ ...selectRange });
                                }}
                            />
                        )}
                    </div>
                );
        }
    };

    React.useEffect(() => {
        if (isClearValue) {
            handleClear(select[0]);
        }
    }, [isClearValue]);

    return (
        <div className={classnames('dropdown-group')}>
            <div
                data-testid="dropdown-group-trigger"
                className={classnames('dropdown-group--input', {
                    'is-expanded': showCTAPopover || controlledShowPopover
                })}
                onClick={() => {
                    setShowCTAPopover(!showCTAPopover);
                    setShowPopover && setShowPopover(!controlledShowPopover);
                }}
            >
                <Label text={label} size="xs" isFontHeadline={false} />
                {!!select.length && (
                    <span className="badge-wrapper" data-testid="badge-wrapper">
                        <Badge
                            text={`${select[0]}`}
                            style="default-light"
                            showClose
                            onClose={() => handleClear(select[0])}
                        />
                        {select.length > 1 && (
                            <Badge
                                text={`+${(select.length - 1).toString()}`}
                                style="default-light"
                            />
                        )}
                    </span>
                )}
                {!showCTAPopover || controlledShowPopover ? (
                    <Icon title="chevron_down" size="sm" />
                ) : (
                    <Icon title="chevron_up" size="sm" />
                )}
            </div>
            {(options?.length > 0 || type === 'range') &&
                (showCTAPopover || controlledShowPopover) && (
                    <div ref={popoverRef} className={classnames('dropdown-group--container')}>
                        <div
                            className={classnames('dropdown-group--container__menu-list', {
                                'has-padding': type === 'range'
                            })}
                        >
                            {renderSelection()}
                        </div>
                    </div>
                )}
        </div>
    );
};

export default DropDownGroup;
