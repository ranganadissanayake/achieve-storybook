import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import DropDownGroup from './index';

export const DefaultStory = () => (
    <DropDownGroup
        options={[
            { label: 'Locations', value: 'location' },
            { label: 'Marketplace', value: 'marketplace' },
            { label: 'Knowledge Hub', value: 'knowledge' }
        ]}
        label="Options"
        type="radio"
    />
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/DropdownGroup',
    component: DropDownGroup
} as ComponentMeta<typeof DropDownGroup>;

const Template: ComponentStory<typeof DropDownGroup> = (args) => <DropDownGroup {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    options: [
        { label: 'Locations', value: 'location', name: 'location' },
        { label: 'Marketplace', value: 'marketplace', name: 'location' },
        { label: 'Knowledge Hub', value: 'knowledge', name: 'location' }
    ],
    label: 'Options',
    type: 'radio'
};
