import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';

import DropdownInputMultiSelect from './index';

describe('DropdownInputMultiSelect', () => {
    const options = [
        { id: 'Canada', value: 'Canada' },
        { id: 'UK', value: 'United Kingdom' },
        { id: 'Belgium', value: 'Belgium' },
        { id: 'USA', value: 'United States' }
    ];

    test('renders the DropdownInputMultiSelect component', () => {
        render(<DropdownInputMultiSelect />);
        expect(screen.getByTestId('dropdown-multiselect')).toBeInTheDocument();
    });

    test('displays the selected value', () => {
        render(<DropdownInputMultiSelect type="text" value="Canada" options={options} />);
        expect(screen.getByText('Canada')).toBeInTheDocument();
    });

    test('displays the DropdownInputMultiSelect values value', () => {
        render(<DropdownInputMultiSelect type="text" value="Canada" options={options} />);
        expect(screen.getByText('Canada')).toBeInTheDocument();
        expect(screen.getByText('United Kingdom')).toBeInTheDocument();
        expect(screen.getByText('Belgium')).toBeInTheDocument();
        expect(screen.getByText('United States')).toBeInTheDocument();
    });

    test('displays the label text', () => {
        render(<DropdownInputMultiSelect type="text" label="Countries" options={options} />);
        expect(screen.getByText('Countries')).toBeInTheDocument();
    });

    test('displays the helper text', () => {
        render(<DropdownInputMultiSelect type="text" helper="Helper Text" options={options} />);
        expect(screen.getByText('Helper Text')).toBeInTheDocument();
    });

    test('updates the selected value when a new option is selected', () => {
        const handleChange = jest.fn();
        render(
            <DropdownInputMultiSelect
                type="text"
                value="Canada"
                options={options}
                onValueChanged={handleChange}
            />
        );
        fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Belgium' } });
        expect(handleChange).toHaveBeenCalledWith('Belgium');
        expect(screen.getByText('Belgium')).toBeInTheDocument();
        expect(screen.queryByText('Canada')).not.toBeInTheDocument();
    });

    test('filters the dropdown options when the user types in the input field', () => {
        render(<DropdownInputMultiSelect options={options} />);
        fireEvent.click(screen.getByRole('textbox'));
        fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Canada' } });

        expect(screen.getByText('Canada')).toBeInTheDocument();
    });

    test('renders the dropdown options with flag', () => {
        render(<DropdownInputMultiSelect options={options} showFlag />);
        fireEvent.click(screen.getByRole('textbox'));

        const option1 = screen.getByText('Canada');
        const option2 = screen.getByText('United Kingdom');
        const option3 = screen.getByText('Belgium');
        const option4 = screen.getByText('United States');

        expect(option1).toBeInTheDocument();
        expect(option2).toBeInTheDocument();
        expect(option3).toBeInTheDocument();
        expect(option4).toBeInTheDocument();

        fireEvent.click(option1);
        expect(screen.getByText('Canada')).toBeInTheDocument();
        expect(screen.queryByRole('United Kingdom')).not.toBeInTheDocument();
        expect(screen.queryByRole('Belgium')).not.toBeInTheDocument();
        expect(screen.queryByRole('United States')).not.toBeInTheDocument();
    });

    test('does not call onValueChanged when clicking on an already selected option', () => {
        const handleChange = jest.fn();
        render(
            <DropdownInputMultiSelect
                type="text"
                value="Canada"
                options={[{ id: 'Canada', value: 'Canada' }]}
                onValueChanged={handleChange}
            />
        );
        fireEvent.click(screen.getByRole('textbox'));
        fireEvent.click(screen.getByText('Canada'));
        expect(handleChange).not.toHaveBeenCalled();
    });
    test('displays no options when there are no options passed in', () => {
        render(<DropdownInputMultiSelect />);
        fireEvent.click(screen.getByRole('textbox'));
        expect(screen.queryAllByRole('option')).toHaveLength(0);
    });

    test('calls onSelect with the selected value when handleBlur is triggered', () => {
        const handleSelect = jest.fn();
        render(<DropdownInputMultiSelect options={options} onSelect={handleSelect} />);
        fireEvent.click(screen.getByRole('textbox'));
        fireEvent.click(screen.getByText('Canada'));
        fireEvent.blur(screen.getByRole('textbox'));
        expect(handleSelect).toHaveBeenCalledWith('Canada');
    });

    test('updates the selected value when an option is selected with showFlag prop', () => {
        const handleChange = jest.fn();
        render(
            <DropdownInputMultiSelect
                type="text"
                value="Canada"
                options={options}
                onValueChanged={handleChange}
                showFlag
            />
        );
        fireEvent.click(screen.getByRole('textbox'));
        fireEvent.click(screen.getByText('Belgium'));
    });
 it('should call getSelectedValues with selected values', () => {
    const mockGetSelectedValues = jest.fn();
    const { getByTestId, getByText } = render(
      <DropdownInputMultiSelect
        options={options}
        getSelectedValues={mockGetSelectedValues}
      />
    );

    fireEvent.click(getByTestId('dropdown-multiselect'));
    fireEvent.click(getByText('Canada'));
    fireEvent.click(getByText('Belgium'));
  });

  test('displays the default selected values', () => {
    const defaultSelectedValues = ['Canada', 'Belgium'];
    render(<DropdownInputMultiSelect type="text" options={options} defaultSelectedValues={defaultSelectedValues} />);
    expect(screen.getByText('Canada')).toBeInTheDocument();
    
});

  test('renders with correct props and state', () => {
    const options = [
      { id: '1', value: 'Option 1' },
      { id: '2', value: 'Option 2' },
      { id: '3', value: 'Option 3' },
    ];
  
    const props = {
      id: 'test-dropdown',
      name: 'test-dropdown-name',
      label: 'Test Dropdown',
      options: options,
      value: '',
      showFlag: true,
      onSelect: jest.fn(),
      onValueChanged: jest.fn(),
      getSelectedValues: jest.fn(),
      defaultSelectedValues: ['Option 1'],
    };
  
    render(<DropdownInputMultiSelect {...props} />);
  
    const dropdown = screen.getByTestId('dropdown-multiselect');
    expect(dropdown).toBeInTheDocument();
    const label = screen.getByText('Test Dropdown');
    expect(label).toBeInTheDocument();
  
    const flag = screen.getByTestId('dropdown-multiselect');
    expect(flag).toBeInTheDocument();
  });
  test('handles outside click correctly when badge icons are visible', () => {
    const { container, getByText } = render(<DropdownInputMultiSelect options={options} />);
    fireEvent.click(screen.getByRole('textbox'));
    fireEvent.click(screen.getByText('Canada'));
    fireEvent.click(screen.getByText('Belgium'));
    fireEvent.mouseDown(container);

    expect(screen.getByTestId('dropdown-multiselect')).not.toHaveClass('_showDropdown');

});
});