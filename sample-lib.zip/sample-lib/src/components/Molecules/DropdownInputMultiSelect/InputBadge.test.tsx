import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';

import InputBadge from './InputBadge';

describe('inputElementBadge', () => {
    test('renders the inputElementBadge component', () => {
        render(<InputBadge name="name" />);
        expect(screen.getByTestId('inputElementBadge')).toBeInTheDocument();
    });

    test('renders the label of the inputElementBadge component', () => {
        render(<InputBadge name="name" label="Label" />);
        expect(screen.getByText('Label')).toBeInTheDocument();
    });

    test('renders the helper text of the inputElementBadge component', () => {
        render(<InputBadge name="name" label="Label" helper="Helper text" />);
        expect(screen.getByText('Helper text')).toBeInTheDocument();
    });

    test('renders the error message in case of an error ', () => {
        render(
            <InputBadge
                name="name"
                label="Label"
                state="error"
                errorMessage="Something went wrong"
            />
        );
        expect(screen.getByText('Something went wrong')).toBeInTheDocument();
    });

    test('add sm class to small size inputElementBadge component', () => {
        render(<InputBadge name="name" label="Label" size="sm" />);
        expect(screen.getByTestId('input')).toHaveClass('input_sm');
    });

    test('add md class to medium size inputElementBadge component', () => {
        render(<InputBadge name="name" label="Label" size="md" />);
        expect(screen.getByTestId('input')).toHaveClass('input_md');
    });

    test('add lg class to large size inputElementBadge component', () => {
        render(<InputBadge name="name" label="Label" size="lg" />);
        expect(screen.getByTestId('input')).toHaveClass('input_lg');
    });

    test('add default class to default state inputElementBadge component', () => {
        render(<InputBadge name="name" label="Label" state="default" />);
        expect(screen.getByTestId('inputElementBadge')).toHaveClass('default');
    });

    test('add error class to error state input component', () => {
        render(<InputBadge name="name" label="Label" state="error" />);
        expect(screen.getByTestId('inputElementBadge')).toHaveClass('error');
    });

    test('add success class to success state inputElementBadge component', () => {
        render(<InputBadge name="name" label="Label" state="success" />);
        expect(screen.getByTestId('inputElementBadge')).toHaveClass('success');
    });

    test('add disabled class to disabled state inputElementBadge component', () => {
        render(<InputBadge name="name" label="Label" state="disabled" />);
        expect(screen.getByTestId('inputElementBadge')).toHaveClass('disabled');
    });
    test('add  icon to input component', () => {
        render(<InputBadge name="name" iconName="search" />);
        expect(screen.getByTestId('icon')).toBeInTheDocument();
    });

    test('add icon-after class to icon after', () => {
        render(<InputBadge name="name" iconName="search" iconAfter />);
        expect(screen.getByTestId('icon')).toHaveClass('input-icon-after');
    });
    test('calls onChange callback when input value changes', () => {
        const onChangeMock = jest.fn();
        render(<InputBadge name="name" onChange={onChangeMock} />);
        const inputElement = screen.getByTestId('input');
        fireEvent.change(inputElement, { target: { value: 'New value' } });
        expect(onChangeMock).toHaveBeenCalledWith('New value');
    });
    test('calls onChange callback when input value changes', () => {
        const onChangeMock = jest.fn();
        render(<InputBadge name="name" onChange={onChangeMock} />);
        const inputElement = screen.getByTestId('input');
        fireEvent.change(inputElement, { target: { value: 'New value' } });

        expect(onChangeMock).toHaveBeenCalledWith('New value');
    });

    test('calls onClick callback when input is clicked', () => {
        const onClickMock = jest.fn();
        render(<InputBadge name="name" onClick={onClickMock} />);
        const inputElement = screen.getByTestId('input');
        fireEvent.click(inputElement);
        expect(onClickMock).toHaveBeenCalledTimes(1);
    });

    test('calls onFocus callback when input is focused', () => {
        const onFocusMock = jest.fn();
        render(<InputBadge name="name" onFocus={onFocusMock} />);
        const inputElement = screen.getByTestId('input');
        fireEvent.focus(inputElement);
        expect(onFocusMock).toHaveBeenCalledTimes(1);
    });

    test('disables input when state is "disabled"', () => {
        render(<InputBadge name="name" state="disabled" />);
        const inputElement = screen.getByTestId('input');
        expect(inputElement).toBeDisabled();
    });

    test('renders badge icons', () => {
        const badgeIcons = ['badge1', 'badge2', 'badge3'];
        render(<InputBadge name="name" badgeIcons={badgeIcons} showBadgeIcons={true} />);
    });

    test('calls onCloseClick callback when badge is clicked', () => {
        const onCloseClickMock = jest.fn();
        const badgeIcons = ['badge1', 'badge2', 'badge3'];

        render(
            <InputBadge
                name="name"
                badgeIcons={badgeIcons}
                showBadgeIcons={true}
                onCloseClick={onCloseClickMock}
            />
        );

        const closeIconElement = screen.getByText('X');
        fireEvent.click(closeIconElement);
        expect(onCloseClickMock).toHaveBeenCalledWith('badge3');
    });

    test('calls onClick callback when input is clicked', () => {
        const onClickMock = jest.fn();
        render(<InputBadge name="name" onClick={onClickMock} />);
        const inputElement = screen.getByTestId('input');
        fireEvent.click(inputElement);
        expect(onClickMock).toHaveBeenCalledTimes(1);
    });

    test('calls onFocus callback when input is focused', () => {
        const onFocusMock = jest.fn();
        render(<InputBadge name="name" onFocus={onFocusMock} />);
        const inputElement = screen.getByTestId('input');
        fireEvent.focus(inputElement);
        expect(onFocusMock).toHaveBeenCalledTimes(1);
    });

    test('disables input when state is "disabled"', () => {
        render(<InputBadge name="name" state="disabled" />);
        const inputElement = screen.getByTestId('input');
        expect(inputElement).toBeDisabled();
    });

    test('renders badge icons', () => {
        const badgeIcons = ['badge1', 'badge2', 'badge3'];
        render(<InputBadge name="name" badgeIcons={badgeIcons} showBadgeIcons={true} />);
    });

    test('calls onCloseClick callback when badge is clicked', () => {
        const onCloseClickMock = jest.fn();

        const badgeIcons = ['badge1', 'badge2', 'badge3'];

        render(
            <InputBadge
                name="name"
                badgeIcons={badgeIcons}
                showBadgeIcons={true}
                onCloseClick={onCloseClickMock}
            />
        );

        const closeIconElement = screen.getByText('X');
        fireEvent.click(closeIconElement);
        expect(onCloseClickMock).toHaveBeenCalledWith('badge3');
    });
    test('displays the label text', () => {
        render(<InputBadge label="Username" />);
        expect(screen.getByText('Username')).toBeInTheDocument();
    });
});
