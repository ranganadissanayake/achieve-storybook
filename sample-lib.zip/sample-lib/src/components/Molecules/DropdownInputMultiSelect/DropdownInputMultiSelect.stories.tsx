import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import DropdownInputMultiSelect from './index';

export const DefaultStory = () => {
    const [countries, setCountries] = React.useState<string[]>();

    const getSelectedValues = (values: string[]) => {
        setCountries(values);
    };
    return (
        <DropdownInputMultiSelect
            type="text"
            name="Country"
            placeholder="Country"
            showFlag={false}
            onlySelectedValue={false}
            options={[
                { id: 'Canada', value: 'Canada' },
                { id: 'UK', value: 'United Kingdom' },
                { id: 'Belgium', value: 'Belgium' },
                { id: 'USA', value: 'United States' },
                { id: 'HongKong', value: 'HongKong' },
                { id: 'Australia', value: 'Australia' },
                { id: 'Mexico', value: 'Mexico' }
            ]}
            defaultValue="Country"
            getSelectedValues={getSelectedValues}
            defaultSelectedValues={countries}
        />
    );
};

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/DropdownInputMultiSelect',
    component: DropdownInputMultiSelect
} as ComponentMeta<typeof DropdownInputMultiSelect>;

const Template: ComponentStory<typeof DropdownInputMultiSelect> = (args) => (
    <DropdownInputMultiSelect {...args} />
);

export const Playground = Template.bind({});
Playground.args = {
    name: 'name',
    label: 'Country',
    required: true,
    showFlag: false,
    value: 'UK',
    options: [
        { id: 'CA', value: 'Canada' },
        { id: 'UK', value: 'United Kingdom' },
        { id: 'BE', value: 'Belgium' },
        { id: 'US', value: 'United States' },
        { id: 'HK', value: 'HongKong' },
        { id: 'AU', value: 'Australia' },
        { id: 'MX', value: 'Mexico' },
        { id: 'ARG', value: 'Argentina' },
    ],
    defaultValue: 'Country',
    defaultSelectedValues: ['Canada']
};
