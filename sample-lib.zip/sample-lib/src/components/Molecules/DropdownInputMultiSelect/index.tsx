import React from 'react';
import classnames from 'classnames';
import Flag, { Country } from '../../Atoms/Flag';
import InputBadge from './InputBadge';
import Checkbox from '../Checkbox';
import { Option } from '../DropdownInput';

import './DropdownInputMultiSelect.scss';

function compareValue(a: Option, b: Option) {
    if (a.value < b.value) {
        return -1;
    }
    if (a.value > b.value) {
        return 1;
    }
    return 0;
}

type InputSize = 'lg' | 'md' | 'sm';

export interface DropdownInputMultiSelectProps {
    /**
     * Enables Dropdown to be associated with a label for accessibility purposes
     */
    id?: string;
    /**
     * The name of the associated data point submitted to the server
     */
    name?: string;
    /**
     * The input type
     */
    type?: string;
    /**
     * Label for the Dropdown
     */
    label?: string;
    /**
     * Specifies if the dropdown is required - adds an asterix
     */
    required?: boolean;
    /**
     * Specifies if the dropdown is optional - adds an optional text
     */
    optional?: boolean;
    /**
     * Supporting text for the dropdown label
     */
    helper?: string;
    /**
     * Size for the dropdown label text
     */
    labelSize?: 'lg' | 'sm' | 'xs';
    /**
     * Additional styles for the label text
     */
    labelTextStyles?: string;
    /**
     * Additional styles for the label container
     */
    containerStyles?: string;
    /**
     * Additional styles for the label helper
     */
    helperTextStyles?: string;
    /**
     * A placeholder for the dropdown
     */
    placeholder?: string;
    /**
     * A  display/selected value
     */
    value?: string;
    /**
     * The state of the dropdown
     */
    state?: 'default' | 'error' | 'success' | 'disabled';
    /**
     * The size of the select input
     */
    size?: InputSize;
    /**
     * A message to display in error state
     */
    errorMessage?: string;
    /**
     * The size of the error message
     */
    errorMessageSize?: 'sm' | 'md' | 'lg';
    /**
     * Show/hide error message icon
     */
    showErrorIcon?: boolean;
    /**
     * Adjust size of error message icon
     */
    errorIconSize?: 'sm' | 'md' | 'lg';
    /**
     * The dropdown options
     */
    options?: Option[];
    /**
     * Determines whether user can only select from dropdown options
     */
    onlySelectedValue?: boolean;
    /**
     * Display countries with flags
     */
    showFlag?: boolean;
    /**
     * Allows user to search value
     */
    allowSearch?: boolean;
    /**
     * Specifies what happens when a new value is selected
     */
    onSelect?: (text: string) => void;
    /**
     * Specifies what when input value changes
     */
    onValueChanged?: (text: string) => void;
    /**
     * Specifies classes for additional styles
     */
    className?: string;
    /**
     * Specifies for default value
     */
    defaultValue?: string;
    /**
     * Specifies for get selected values
     */
    getSelectedValues?: (values: string[]) => void;
    /**
     * Specifies for default value
     */
    defaultSelectedValues?: string[];
    /**
     * Clears selected value
     */
    isClearValue?: boolean;
}
 
/**
 * Renders the Dropdown component
 * @param {React.PropsWithChildren<DropdownProps>} props DropdownProps properties
 * @returns
 */
const DropdownInputMultiSelect: React.FC<DropdownInputMultiSelectProps> = ({
    id,
    name = '',
    type = 'text',
    label = '',
    required = false,
    optional = false,
    helper = '',
    labelSize = 'lg',
    labelTextStyles = '',
    containerStyles = '',
    helperTextStyles = '',
    placeholder = '',
    value,
    state = 'default',
    errorMessage = '',
    errorMessageSize = 'md',
    showErrorIcon = true,
    size = 'sm',
    options = [],
    onlySelectedValue = true,
    showFlag = false,
    allowSearch = true,
    onSelect,
    onValueChanged,
    className = '',
    defaultValue,
    getSelectedValues,
    defaultSelectedValues,
    isClearValue = false
}) => {
    const _dropdownRef = React.useRef(null);
    const _inputRef = React.useRef(null);

    const [_showDropdown, setShowDropDown] = React.useState(false);
    const [_selected, setSelected] = React.useState<Option>();
    const sortedOptions = [...options].sort(compareValue);
    const [_options, setOptions] = React.useState(sortedOptions);
    const [_displayValue, setDisplayValue] = React.useState<string>(value ?? '');
    const [_displayFlag, setDisplayFlag] = React.useState<Country>();
    const [multiSelected, setMultiSelected] = React.useState(defaultSelectedValues);
    const [showBadgeIcons, setShowBadgeIcons] = React.useState<boolean>();
    const [badgeIconGap, setBadgeIconGap] = React.useState<boolean>(false);

    const handleMultiSelected = (selectedValue) => {
        setMultiSelected(selectedValue);
        getSelectedValues && getSelectedValues(selectedValue);
    };

    React.useEffect(() => {
        if (defaultSelectedValues?.length > 0 && !showBadgeIcons) {
            setShowBadgeIcons(true);
            setMultiSelected(defaultSelectedValues);
        } else {
            setShowBadgeIcons(false);
        }
    }, [defaultSelectedValues]);

    const _onValueChangedMultiSelect = React.useCallback(
        (val: string, currentOptions: Option[]) => {
            
            if (allowSearch) {
                if (type === 'number') {
                    const lastXter = parseInt(val.slice(-1));
                    if (lastXter >= 0 && lastXter <= 9) {
                        _filterDropdownMultiSelect(val, currentOptions);
                    } else {
                        _filterDropdownMultiSelect(
                            val.substring(0, val.length - 1),
                            currentOptions
                        );
                    }
                } else {
                    _filterDropdownMultiSelect(val, currentOptions);
                }
            }
        },
        [allowSearch, type]
    );

    const _filterDropdownMultiSelect = (val: string, currentOptions: Option[]) => {
        val !== '__' &&
            setOptions(
                currentOptions.filter(
                    ({ id: itemId, value: selectedValue }) =>
                        itemId.toLowerCase().includes(val.toLowerCase()) ||
                        selectedValue.toLowerCase().includes(val.toLowerCase())
                )
            );
        setDisplayValue(val);

        if (onValueChanged) {
            onValueChanged(val);
        }
    };

    const _onSelectValueMultiSelect = (selectedId: string, selectedValue: string) => {
        setSelected(_options.find((o) => o.id === selectedId));
        setDisplayValue(selectedValue);
        if (showFlag) {
            setDisplayFlag(selectedId as Country);
        }
        if (onSelect) {
            onSelect(selectedId);
        }
    };

    const _isDisplayValueValidMultiSelect = React.useMemo(() => {
        const currentValue = options.find(
            ({ value: displayedValue }) => displayedValue === _displayValue
        );
        if (currentValue) {
            if (showFlag) {
                setDisplayFlag(currentValue.id as Country);
            }
            return true;
        } else {
            return false;
        }
    }, [options, _displayValue, showFlag]);

    const _handleOutsideClickMultiSelect = (e: MouseEvent) => {
        if (
            ((_dropdownRef.current && !_dropdownRef.current.contains(e.target as Node)) ||
                !_dropdownRef.current) &&
            ((_inputRef.current && !_inputRef.current.contains(e.target as Node)) ||
                !_inputRef.current)
        ) {
            setShowDropDown(false);

            if (
                onlySelectedValue &&
                !options.find(({ value: displayedValue }) => displayedValue === _displayValue)
            ) {
                setDisplayValue('');
                if (onSelect) {
                    onSelect('');
                }
            } else {
                if (onSelect) {
                    onSelect(_displayValue);
                }
            }
        }
        setShowBadgeIcons(true);
        setBadgeIconGap(true);
    };

    const handleMultiselect = (multiSelected: string[], check: boolean, value: string) => {
        setShowBadgeIcons(true);
        setBadgeIconGap(true);

        if (check && multiSelected) {
            let findItem = multiSelected;
            findItem.forEach((element: string) => {
                if (element === value) {
                    handleMultiSelected([...multiSelected]);
                    handleMultiSelected([...multiSelected]);
                } else {
                    handleMultiSelected([...findItem, value]);
                    handleMultiSelected([...findItem, value]);
                }
            });
        } else if (!check && multiSelected) {
            let removeItem = multiSelected;
            let filteredItem = removeItem.filter(function (ele) {
                return ele != value;
            });
            if (filteredItem.length === 0) {
                handleMultiSelected(null);
                handleMultiSelected(null);
            } else {
                handleMultiSelected(filteredItem);
                handleMultiSelected(filteredItem);
            }
        } else {
            handleMultiSelected([value]);
            handleMultiSelected([value]);
        }
    };

    const _onFocusedMultiselect = React.useCallback(() => {
        setShowBadgeIcons(false);
        setBadgeIconGap(false);
        if (state !== 'disabled') {
            setShowDropDown(true);
            if (options.length > 0 && _options.length === 0) {
                setOptions([...options]);
            }
        }
    }, [options, _options]);

    const onCloseClick = (item: string) => {
        let removeItem = multiSelected;
        let filteredItem = removeItem.filter(function (ele) {
            return ele != item;
        });
        if (filteredItem.length === 0) {
            handleMultiSelected(null);
            handleMultiSelected(null);
        } else {
            handleMultiSelected(filteredItem);
            handleMultiSelected(filteredItem);
        }
        _filterDropdownMultiSelect('__', options);
    };

    React.useEffect(() => {
        if (isClearValue && multiSelected) {
            handleMultiSelected(null);
        }
    }, [isClearValue]);

    React.useEffect(() => {
        if (options.length > 0) {
            setOptions([...options]);
        }
    }, [options]);

    React.useEffect(() => {
        if (value && options.find((o) => o.id === value)) {
            setSelected(options.find((o) => o.id === value));
            setDisplayValue(options.find((o) => o.id === value).value);

            if (showFlag) {
                setDisplayFlag(value as Country);
            }
        } else {
            setDisplayValue(value);
        }

        if (onSelect) {
            onSelect(value);
        }
    }, [value, options, showFlag]);

    React.useEffect(() => {
        if (_showDropdown) {
            document.addEventListener('mousedown', _handleOutsideClickMultiSelect);
        }

        return () => {
            document.removeEventListener('mousedown', _handleOutsideClickMultiSelect);
        };
    }, [_showDropdown, _displayValue]);

    React.useEffect(()=>{
        if(multiSelected?.length===0){
            handleMultiselect([],false,"");
        }
    },[multiSelected])

    const isCheckMultiselect = (checkedValue: string, selectedItems: string[]) => {
        let isChecked = false;

        if (selectedItems) {
            selectedItems.forEach((element: string) => {
                if (element === checkedValue) {
                    isChecked = true;
                }
            });
        }

        return isChecked;
    };
    const showIcon = React.useMemo(() => {
        if (_options.length > 0) {
            if (_showDropdown) {
                return 'chevron_up';
            } else {
                return 'chevron_down';
            }
        } else {
            return 'none';
        }
    }, [_options, _showDropdown]);

    return (
        <div data-testid="dropdown-multiselect" className={`multiselect_container ${className}`}>
            <InputBadge
                id={id}
                name={name}
                value={_displayValue}
                label={label}
                required={required}
                optional={optional}
                helper={helper}
                labelSize={labelSize}
                labelTextStyles={labelTextStyles}
                containerStyles={containerStyles}
                helperTextStyles={helperTextStyles}
                placeholder={placeholder}
                state={state}
                errorMessage={errorMessage}
                errorMessageSize={errorMessageSize}
                showErrorIcon={showErrorIcon}
                size={size}
                iconName={showIcon}
                showDropdown={_showDropdown}
                iconAfter
                iconSize="sm"
                flag={showFlag && _isDisplayValueValidMultiSelect ? _displayFlag : 'none'}
                inputRef={_inputRef}
                onFocus={_onFocusedMultiselect}
                onClick={_onFocusedMultiselect}
                onIconClick={() => {
                    if (state !== 'disabled') {
                        setShowDropDown((prev) => !prev);
                    }
                }}
                showBadgeIcons={showBadgeIcons}
                onChange={(val) => _onValueChangedMultiSelect(val, options)}
                className="dropdown_input"
                badgeIcons={multiSelected}
                defaultValue={defaultValue}
                onCloseClick={onCloseClick}
            />
            {_options.length > 0 && (
                <div
                    className={classnames(
                        `select_container ${
                            badgeIconGap && multiSelected != null ? 'dropdown-gap' : ''
                        }`,
                        { _showDropdown }
                    )}
                    ref={_dropdownRef}
                >
                    <div className="dropdown_select">
                        {_options.map(({ id: idOption, value }) => (
                            <div
                                className={classnames(`dropdown_option ${isCheckMultiselect(value, multiSelected) ? "selected" : "" }`, { showFlag })}
                                key={idOption}
                                onClick={() => _onSelectValueMultiSelect(idOption, value)}
                            >
                                <Checkbox
                                    id={`'countryDropdown'${value}`}
                                    name={value}
                                    required={false}
                                    optional={false}
                                    onSelect={(v) => {
                                        handleMultiselect(multiSelected, v, value);
                                    }}
                                    isCheckedDefault={isCheckMultiselect(value, multiSelected)}
                                />

                                {showFlag && (
                                    <Flag size="sm" countryISOCode={idOption as Country} />
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default DropdownInputMultiSelect;
