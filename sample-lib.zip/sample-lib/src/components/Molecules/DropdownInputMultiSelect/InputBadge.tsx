import React from 'react';

import ErrorMessage from '../../Atoms/ErrorMessage';
import Icon from '../../Atoms/Icon';
import Label from '../../Atoms/Label';
import { IconName } from '../../Assets/icons/iconLib';
import Flag, { Country } from '../../Atoms/Flag';

import './InputBadge.scss';

type sizeType = 'sm' | 'md' | 'lg';

export interface InputBadgeProps {
    /**
     * Enables Input to be associated with a label for accessibility purposes
     */
    id?: string;
    /**
     * The name of the associated data point submitted to the server
     */
    name?: string;
    /**
     * The type for the input
     */
    type?: string;

    /**
     * Label for the Input
     */
    label?: string;
    /**
     * Specifies if the input is required - adds an asterix
     */
    required?: boolean;
    /**
     * Specifies if the input is optional - adds an optional text
     */
    optional?: boolean;
    /**
     * Supporting text for the input label
     */
    helper?: string;
    /**
     * Size for the input label text
     */
    labelSize?: 'lg' | 'sm' | 'xs';
    /**
     * Additional styles for the label text
     */
    labelTextStyles?: string;
    /**
     * Additional styles for the label container
     */
    containerStyles?: string;
    /**
     * Additional styles for the label helper
     */
    helperTextStyles?: string;
    /**
     * A placeholder for the input
     */
    placeholder?: string;
    /**
     * Value to display in the input field
     */
    value?: string;
    /**
     * The state of the input
     */
    state?: 'default' | 'error' | 'success' | 'disabled';
    /**
     * The size of the input
     */
    size?: sizeType;
    /**
     * A message to display in error state
     */
    errorMessage?: string;
    /**
     * The size of the error message
     */
    errorMessageSize?: sizeType;
    /**
     * Show/hide error message icon
     */
    showErrorIcon?: boolean;
    /**
     * Adjust size of error message icon
     */
    errorIconSize?: sizeType;
    /**
     * A name for an icon to show in input field
     */
    iconName?: IconName | 'none';
    /**
     * Dropdown value is displayed
     */
    showDropdown?: boolean;
    /**
     * The size of the specified icon
     */
    iconSize?: sizeType;
    /**
     * Determines whether the icon should be bofore/after the input value
     */
    iconAfter?: boolean;
    /**
     * A name for the country whose flag should be displayed in input field
     */
    flag?: Country | 'none';
    /**
     * A ref for the input element
     */
    inputRef?: React.MutableRefObject<any>;
    /**
     * When the input value is changed
     */
    onChange?: (text: string) => void;
    /**
     * When the input field is clicked
     */
    onClick?: () => void;
    /**
     * When the input field is focused
     */
    onFocus?: () => void;
    /**
     * When the icon is clicked
     */
    onIconClick?: () => void;
    /**
     * Specifies classes for additional styles
     */
    className?: string;
    /**
     * Specifies for get the data to show the badges
     */
    badgeIcons?: string[];
    /**
     * Specifies to set a default value
     */
    defaultValue?: string;
    /**
     * Specifies to switch badge icons
     */
    showBadgeIcons?: boolean;
    /**
     * Specifies to trigger a function on remove badges
     */
    onCloseClick?: (item: string) => void;
}

/**
 * Renders the InputBadge component
 * @param {React.PropsWithChildren<InputBadgeProps>} props InputProps properties
 * @returns
 */
const InputBadge: React.FC<InputBadgeProps> = ({
    id,
    name = '',
    value,
    label = '',
    required = false,
    optional = false,
    helper = '',
    labelSize = 'lg',
    labelTextStyles = '',
    containerStyles = '',
    helperTextStyles = '',
    size = 'sm',
    state = 'default',
    errorMessage = '',
    errorMessageSize = 'md',
    showErrorIcon = true,
    iconName = 'none',
    iconSize = 'md',
    iconAfter = false,
    type = 'text',
    flag = 'none',
    inputRef,
    onChange,
    onClick,
    onFocus,
    onIconClick,
    className = '',
    badgeIcons,
    defaultValue,
    showBadgeIcons,
    showDropdown = false,
    onCloseClick
}) => {
    let result = '';

    if (label !== '' || helper !== '') {
        result = 'space_above';
    }

    let iconClass = '';

    if (iconName && iconName !== 'none') {
        if (iconAfter) {
            iconClass = 'icon-after';
        } else {
            iconClass = 'icon-before';
        }
    }

    const isBadge = badgeIcons && showBadgeIcons;

    return (
        <div data-testid="inputElementBadge" className={`input-badge ${state} ${className}`}>
            {((label && label !== '') || (helper && helper !== '')) && (
                <Label
                    text={label}
                    required={required}
                    optional={optional}
                    helper={helper}
                    size={labelSize}
                    labelTextStyles={labelTextStyles}
                    containerStyles={containerStyles}
                    helperTextStyles={helperTextStyles}
                />
            )}
            <div className="add-icon" ref={inputRef}>
                {iconName && iconName !== 'none' && !iconAfter ? (
                    <Icon
                        className={`input-icon input_${size} input_icon_${iconSize}  ${result}`}
                        title={iconName}
                        size={iconSize}
                        onClick={onIconClick ?? onClick}
                    />
                ) : (
                    flag &&
                    flag !== 'none' && (
                        <Flag
                            countryISOCode={flag}
                            size="sm"
                            className={`input-icon input_${size} ${result} input_flag`}
                        />
                    )
                )}
                {!isBadge && (
                    <input
                        data-testid="input"
                        type={type}
                        id={id ?? name}
                        name={name}
                        ref={inputRef}
                        required={required}
                        placeholder={defaultValue}
                        onChange={(e) => {
                            onChange && onChange(e.target.value);
                        }}
                        onClick={onClick}
                        onFocus={onFocus}
                        className={`input_element input_${size} ${iconClass} ${
                            flag &&
                            flag !== 'none' &&
                            (iconAfter || !iconName || iconName === 'none')
                                ? 'flag_before'
                                : ''
                        } ${label !== '' || helper !== '' ? 'space_above' : ''}`}
                        disabled={state === 'disabled'}
                    />
                )}

                <div className="input-badge">
                    {isBadge && (
                        <>
                            <span className="badge-default">
                                <a onClick={onFocus}>{defaultValue}</a>
                            </span>
                            <span className="badge-text">
                                <span onClick={onFocus}>{badgeIcons[badgeIcons.length - 1]}</span>
                                <span
                                    onClick={() => onCloseClick(badgeIcons[badgeIcons.length - 1])}
                                    className="badge-icon"
                                >
                                    {`X`}
                                </span>
                            </span>
                        </>
                    )}
                    {badgeIcons?.length > 1 && (
                        <span className="badge-count">
                            <span onClick={onFocus}>{'+' + (badgeIcons.length - 1)}</span>
                        </span>
                    )}
                </div>

                {iconName && iconName !== 'none' && iconAfter && (
                    <Icon
                        className={`input-icon input-icon-after input_icon_${iconSize}  ${
                            label !== '' || helper !== '' ? 'space_above' : ''
                        } ${showDropdown ? 'is_expanded' : ''}`}
                        title={iconName}
                        size={iconSize}
                        onClick={onIconClick || onClick}
                    />
                )}
            </div>

            {state === 'error' && errorMessage !== '' && (
                <ErrorMessage
                    message={errorMessage}
                    showIcon={showErrorIcon}
                    size={errorMessageSize}
                />
            )}
        </div>
    );
};

export default InputBadge;
