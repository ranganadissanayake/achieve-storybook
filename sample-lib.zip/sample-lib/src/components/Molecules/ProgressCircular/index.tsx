import React, { useMemo, useState } from 'react';
import classnames from 'classnames';
import Tooltip from '../Tooltip/index';
import './ProgressCircular.scss';

export interface ProgressCircularProps {
    /**
     * current percentage of the progress
     */
    percent?: number;

    /**
     * class name to override default styles
     */
    className?: string;

    /**
     * width of the circle in case it is circular progress bar
     */
    circleWidth?: number;

    /**
     * stroke size for the circle
     */
    circleStrokeWidth?: number;

    /**
     * specify whether overlooking flag is enabled for circular progress bar
     */
    hasOverlookEnabled?: boolean;

    /**
     * remaning bandwidth for circular progress bar
     */
    remainingBandwidth?: number;
}

const ProgressCircular: React.FC<ProgressCircularProps> = ({
    percent = 0,
    className = '',
    circleWidth = 30,
    circleStrokeWidth = 4,
    hasOverlookEnabled = false,
    remainingBandwidth = 0
}: ProgressCircularProps) => {
    const [percentage, setPercentage] = useState(0);
    const svgConfig = useMemo(() => {
        const cValue = circleWidth / 2;
        const radius = (circleWidth - circleStrokeWidth) / 2;
        const dashArray = radius * Math.PI * 2;
        const dashOffset = hasOverlookEnabled
            ? dashArray - (dashArray * 25) / 100
            : dashArray - (dashArray * percentage) / 100;
        const viewport = circleWidth + circleStrokeWidth;
        return { cValue, radius, dashArray, dashOffset, viewport };
    }, [circleWidth, percentage, circleStrokeWidth, hasOverlookEnabled]);

    React.useEffect(() => {
        if (percent <= 0) {
            setPercentage(0);
        } else if (percent > 100) {
            setPercentage(100);
        } else {
            setPercentage(percent);
        }
    }, [percent]);

    return (
        <div
            className={classnames(`stepper-container circular ${className}`)}
            data-testid="progress-circular"
        >
            {
                <React.Fragment>
                    <Tooltip
                        direction="top"
                        content={
                            hasOverlookEnabled
                                ? 'Overbooking Enabled'
                                : `${remainingBandwidth} Mbps left`
                        }
                    >
                        <div
                            className="circular-progressbar"
                            data-testid="circular-progress-stepper"
                        >
                            <svg
                                width={svgConfig.viewport}
                                height={svgConfig.viewport}
                                viewBox={`0 0 ${svgConfig.viewport} ${svgConfig.viewport}`}
                            >
                                <defs>
                                    <linearGradient
                                        id="overlook-gradient"
                                        gradientUnits="userSpaceOnUse"
                                    >
                                        <stop stopColor="#0AFF00" />
                                        <stop offset="10" stopColor="#088003" />
                                    </linearGradient>
                                </defs>
                                <circle
                                    className={classnames('circle-background', {
                                        overlooked: hasOverlookEnabled
                                    })}
                                    cx={svgConfig.cValue}
                                    cy={svgConfig.cValue}
                                    r={svgConfig.radius}
                                    strokeWidth={`${circleStrokeWidth}px`}
                                />
                                <circle
                                    className={classnames('circle-progress', {
                                        green: percentage <= 74,
                                        amber: percentage >= 75 && percentage < 90,
                                        red: percentage >= 90,
                                        overlooked: hasOverlookEnabled
                                    })}
                                    cx={svgConfig.cValue}
                                    cy={svgConfig.cValue}
                                    r={svgConfig.radius}
                                    strokeWidth={`${circleStrokeWidth}px`}
                                    transform={`rotate(-90 ${svgConfig.cValue} ${svgConfig.cValue})`}
                                    style={{
                                        strokeDasharray: svgConfig.dashArray,
                                        strokeDashoffset:
                                            percentage <= 93 || percentage > 99
                                                ? svgConfig.dashOffset
                                                : svgConfig.dashOffset + (100 - percentage + 0.5)
                                    }}
                                />
                            </svg>
                        </div>
                    </Tooltip>
                </React.Fragment>
            }
        </div>
    );
};

export default ProgressCircular;
