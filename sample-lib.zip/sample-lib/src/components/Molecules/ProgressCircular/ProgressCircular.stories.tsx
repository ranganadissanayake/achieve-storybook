import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import ProgressCircular from "./index";

export const DefaultStory = () => (
    <ProgressCircular percent={30} />
);

DefaultStory.storyName = "Default";

export default {
    title: "ReactComponentLibrary/Molecules/ProgressCircular",
    component: ProgressCircular,
} as ComponentMeta<typeof ProgressCircular>;

const Template: ComponentStory<typeof ProgressCircular> = (args) => (
    <ProgressCircular {...args} />
);

export const Playground = Template.bind({});
Playground.args = {
    steps: ["Select Location", "Configuration", "Summary"],
    percent: 40,
    circleStrokeWidth: 5,
    circleWidth: 40,
    remainingBandwidth: 100
};
