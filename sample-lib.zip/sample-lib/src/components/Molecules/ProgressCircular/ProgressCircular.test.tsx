import React from "react";
import { render, screen } from "@testing-library/react";
import ProgressCircular from "./index";

describe("ProgressStepper", () => {
  test("should render circular progress bar", () => {
    render(<ProgressCircular percent={20} circleWidth={30} circleStrokeWidth={4}/>);
    expect(screen.getByTestId("circular-progress-stepper")).toBeInTheDocument();
  });

  test("should render circular progress bar with default data", () => {
    render(<ProgressCircular percent={20} />);
    expect(screen.getByTestId("circular-progress-stepper")).toBeInTheDocument();
  });
});
it('should render with default props', () => {
    render(<ProgressCircular />);
    const svgElement = screen.getByTestId('progress-circular');
    expect(svgElement).toBeInTheDocument();
    expect(svgElement.getAttribute('width'));
    expect(svgElement.getAttribute('height'));
});

it('should render with custom props', () => {
    render(
        <ProgressCircular
            percent={50}
            className="custom-class"
            circleWidth={60}
            circleStrokeWidth={6}
            hasOverlookEnabled
            remainingBandwidth={10}
        />
    );

    const svgElement = screen.getByTestId('circular-progress-stepper');
    expect(svgElement).toBeInTheDocument();
    expect(svgElement.getAttribute('width'));
    expect(svgElement.getAttribute('height'));
});

it('should set the percentage based on the percent prop', () => {
    render(<ProgressCircular percent={50} />);
    const svgElement = screen.getByTestId('circular-progress-stepper');
    const dashOffset = parseFloat(svgElement.style.strokeDashoffset);
    expect(dashOffset);
});
test("should set percentage to 100 when percent is greater than 100", () => {
   render(<ProgressCircular percent={120} />);
    const svgElement = screen.getByTestId('circular-progress-stepper');
    expect(svgElement).toBeInTheDocument();
    const circle = svgElement.querySelector('.circle-progress') as SVGCircleElement | null;

    if (circle) {
        expect(parseFloat(circle.style.strokeDashoffset)).toBe(0);
    } else {
        console.error('SVG circle element not found.');
    }
  });


test('should set the percentage based on the percent prop', () => {
    const { container } = render(<ProgressCircular percent={25} />);
    const svgElement = screen.getByTestId('circular-progress-stepper');
    expect(svgElement).toBeInTheDocument();
    const circle = svgElement.querySelector('.circle-progress') as SVGCircleElement | null;

    if (circle) {
        const circumference = circle.getTotalLength ? circle.getTotalLength() : 0;
        const percentage = 25;
        const dashOffset = circumference - (percentage / 100) * circumference;
        console.log('dashOffset:', dashOffset);
        expect(dashOffset).toBeCloseTo(0);
    } else {
        console.error('SVG circle element not found.');
    }
});