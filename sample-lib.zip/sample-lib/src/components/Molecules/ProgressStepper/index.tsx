import React from 'react';
import Label from '../../Atoms/Label';
import classnames from 'classnames';
import './ProgressStepper.scss';

export interface ProgressStepperProps {
    type?: 'progressbar' | 'stepper';
    percent?: number;
    steps: string[];
    currentStep: number;
    className?: string;
}

const ProgressStepper: React.FC<ProgressStepperProps> = ({
    type = 'stepper',
    percent = 0,
    steps = [],
    currentStep = 1,
    className = ''
}: ProgressStepperProps) => {
    const [currentProgress, setCurrentProgress] = React.useState(0);
    const [percentage, setPercentage] = React.useState(0);

    React.useEffect(() => {
        if (currentStep <= steps.length && currentStep > 0) {
            setCurrentProgress(currentStep);
        } else if (currentStep <= 0) {
            setCurrentProgress(0);
        } else if (currentStep > steps.length) {
            setCurrentProgress(steps.length);
        }

        if (percent) {
            if (percent < 0) {
                setPercentage(0);
            } else if (percent > 100) {
                setPercentage(100);
            } else {
                setPercentage(percent);
            }
        }
    }, [currentStep, percent]);

    return (
        <div
            className={classnames(`stepper-container ${className}`)}
            data-testid="progress-stepper"
        >
            {type === 'stepper' ? (
                <React.Fragment>
                    <div className="current-step">
                        <Label text={steps[currentProgress - 1] || steps[0]} />
                    </div>
                    <div className="current-step-counter">
                        <Label text={`Step ${currentProgress} of ${steps.length}`} />
                    </div>
                    <div className="progress-wrapper">
                        <div className="total-progress-bar">
                            <div
                                style={{ width: `${(currentProgress / steps.length) * 100}%` }}
                                className="current-progress-bar"
                            ></div>
                        </div>
                    </div>
                </React.Fragment>
            ) : (
                <div className="progress-wrapper">
                    <div className="total-progress-bar">
                        <div
                            style={{ width: `${percentage}%` }}
                            className="current-progress-bar"
                        ></div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ProgressStepper;
