import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import ProgressStepper from "./index";

export const DefaultStory = () => (
    <ProgressStepper currentStep={1} steps={["step one", "step two", "step three", "step four"]} />
);

DefaultStory.storyName = "Default";

export default {
    title: "ReactComponentLibrary/Molecules/ProgressStepper",
    component: ProgressStepper,
} as ComponentMeta<typeof ProgressStepper>;

const Template: ComponentStory<typeof ProgressStepper> = (args) => (
    <ProgressStepper {...args} />
);

export const Playground = Template.bind({});
Playground.args = {
    type: "stepper",
    steps: ["Select Location", "Configuration", "Summary"],
    currentStep: 3,
    percent: 40
};
