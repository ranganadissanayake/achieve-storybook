import React from "react";
import { render, screen } from "@testing-library/react";

import ProgressStepper from "./index";

describe("ProgressStepper", () => {
  const steps = ["step one", "step two", "step three", "step four"];

  test("should renders the ProgressStepper component", () => {
    render(<ProgressStepper currentStep={1} steps={steps} />);
    expect(screen.getByTestId("progress-stepper")).toBeInTheDocument();
  });

  test("should display step label for current step", () => {
    render(<ProgressStepper steps={steps}  currentStep={1} />);
    expect(screen.getByText("step one")).toBeInTheDocument();
  });

  test("should render last element if current step > steps", () => {
    render(<ProgressStepper steps={steps}  currentStep={5} />);
    expect(screen.getByText("step four")).toBeInTheDocument();
  });

  test("should render first element if current step < 1", () => {
    render(<ProgressStepper steps={steps}  currentStep={0} />);
    expect(screen.getByText("step one")).toBeInTheDocument();
  });

  test("should render progess bar", () => {
    render(<ProgressStepper type="progressbar" percent={10} steps={[]} currentStep={0}/>);
    expect(screen.getByTestId("progress-stepper")).toBeInTheDocument();
  });

  test("should render progess bar with 100%", () => {
    render(<ProgressStepper type="progressbar" percent={120} steps={[]} currentStep={0}/>);
    expect(screen.getByTestId("progress-stepper")).toBeInTheDocument();
  });

  test("should render progess bar with 0%", () => {
    render(<ProgressStepper type="progressbar" percent={-10} steps={[]} currentStep={0}/>);
    expect(screen.getByTestId("progress-stepper")).toBeInTheDocument();
  });

});
