import React from "react";
import { ComponentStory } from "@storybook/react";

import AvatarGroup from "./index";
import Avatar from "../../Atoms/Avatar";

import maleImage from "../../Assets/testImages/male.png";
import femaleImage from "../../Assets/testImages/female.png";

export const DefaultStory = () => (
  <AvatarGroup>
    <Avatar image={femaleImage} />
    <Avatar image={maleImage} />
    <Avatar />
  </AvatarGroup>
);

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Molecules/AvatarGroup",
  component: AvatarGroup,
  subcomponents: Avatar,
};

const Template: ComponentStory<typeof AvatarGroup> = (args) => (
  <AvatarGroup {...args} />
);

export const Playground = (args) => (
  <AvatarGroup size="md" {...args}>
    <Avatar image={femaleImage} />
    <Avatar image={maleImage} />
    <Avatar />
    <Avatar />
    <Avatar />
    <Avatar />
    <Avatar />
    <Avatar />
    <Avatar />
    <Avatar />
    <Avatar />
  </AvatarGroup>
);
