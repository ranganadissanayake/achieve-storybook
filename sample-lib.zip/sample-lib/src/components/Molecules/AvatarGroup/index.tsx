import React from "react";
import Avatar from "../../Atoms/Avatar";

import "./AvatarGroup.scss";

export interface AvatarGroupProps {
  children: React.JSX.Element[];
  size?: "ty" | "sm" | "md" | "lg" | "xl" | "xxl";
  title?: string;
  subtitle?: string;
  hideTitle?: boolean;
  hideSubtitle?: boolean;
}

const AvatarGroup: React.FC<AvatarGroupProps> = ({
  children,
  size = "lg",
  title = "",
  hideTitle = false,
  subtitle = "",
  hideSubtitle = false,
}) => {
  return (
    <span className="avatar-group-container">
      <span className={`avatar-group ${size}`} data-testid="avatar-group">
        <Avatar value={`${children.length}`} border hideTitle size={size} />
        {children.slice(0, 2).map((avatar) => ({
          ...avatar,
          props: { ...avatar.props, size, border: true },
        }))}
      </span>
      {title !== "" && !hideTitle && (
        <span className="title-container">
          <span className="title">{title}</span>
          {subtitle !== "" && !hideSubtitle && (
            <span className="subtitle">{subtitle}</span>
          )}
        </span>
      )}
    </span>
  );
};

export default AvatarGroup;
