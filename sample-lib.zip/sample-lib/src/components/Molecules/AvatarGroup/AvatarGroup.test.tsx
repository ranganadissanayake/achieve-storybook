import React from "react";
import { render, screen } from "@testing-library/react";

import AvatarGroup from "./index";
import Avatar from "../../Atoms/Avatar";

describe("AvatarGroup", () => {
  const avatarGroup = (
    <AvatarGroup size="md">
      <Avatar />
      <Avatar />
      <Avatar />
      <Avatar />
    </AvatarGroup>
  );

  test("renders the AvatarGroup component with right number of avatars", () => {
    render(avatarGroup);

    expect(screen.getByText("4")).toBeInTheDocument();
  });

  test("add correct ty class to tiny size AvatarGroup component", () => {
    render(
      <AvatarGroup size="ty">
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.getByTestId("avatar-group")).toHaveClass("ty");
  });

  test("add correct sm class to small size AvatarGroup component", () => {
    render(
      <AvatarGroup size="sm">
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.getByTestId("avatar-group")).toHaveClass("sm");
  });

  test("add correct md class to medium size AvatarGroup component", () => {
    render(
      <AvatarGroup size="md">
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.getByTestId("avatar-group")).toHaveClass("md");
  });

  test("add correct lg class to large size AvatarGroup component", () => {
    render(
      <AvatarGroup size="lg">
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.getByTestId("avatar-group")).toHaveClass("lg");
  });

  test("add correct xl class to extra large size AvatarGroup component", () => {
    render(
      <AvatarGroup size="xl">
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.getByTestId("avatar-group")).toHaveClass("xl");
  });

  test("add correct xxl class to extra extra large size AvatarGroup component", () => {
    render(
      <AvatarGroup size="xxl">
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.getByTestId("avatar-group")).toHaveClass("xxl");
  });

  test("add title to AvatarGroup component", () => {
    render(
      <AvatarGroup title="Aaron Andelson">
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.getByText("Aaron Andelson")).toBeInTheDocument();
  });

  test("hide title even when it is added", () => {
    render(
      <AvatarGroup title="Aaron Andelson" hideTitle>
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.queryByText("Aaron Andelson")).not.toBeInTheDocument();
  });

  test("add and subtitle to AvatarGroup component", () => {
    render(
      <AvatarGroup title="Aaron Andelson" subtitle="Product Team Lead">
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.getByText("Aaron Andelson")).toBeInTheDocument();
    expect(screen.getByText("Product Team Lead")).toBeInTheDocument();
  });

  test("hide subtitle even when it is present", () => {
    render(
      <AvatarGroup
        title="Aaron Andelson"
        subtitle="Product Team Lead"
        hideSubtitle
      >
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.queryByText("Product Team Lead")).not.toBeInTheDocument();
  });

  test("hide both title and subtitle when title is hidden", () => {
    render(
      <AvatarGroup
        title="Aaron Andelson"
        subtitle="Product Team Lead"
        hideTitle
      >
        <Avatar />
        <Avatar />
      </AvatarGroup>
    );

    expect(screen.queryByText("Aaron Andelson")).not.toBeInTheDocument();
    expect(screen.queryByText("Product Team Lead")).not.toBeInTheDocument();
  });
});
