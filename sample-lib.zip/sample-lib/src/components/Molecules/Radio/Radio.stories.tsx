import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Radio from './index';

export const DefaultStory = () => <Radio id="default" name="Default" />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/Radio',
    component: Radio
} as ComponentMeta<typeof Radio>;

const Template: ComponentStory<typeof Radio> = (args) => <Radio {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    id: 'playground',
    label: 'Playground',
    name: 'Radio',
    helperText: 'Some helper',
    required: true,
    optional: true,
    onSelect: () => {
        alert('Radio selected');
    }
};

const radioGroupDetails = [
    { id: 'idOne', name: 'one' },
    { id: 'idTwo', name: 'two' },
    { id: 'idThree', name: 'three' }
];

export const RadioGroup = () => {
    const [selectedDetail, setSelectedDetail] = React.useState('');

    return radioGroupDetails.map((detail) => (
        <Radio
            isCheckedDefault={selectedDetail === detail.id}
            {...detail}
            inputname="radioGroupDetails"
            onSelectValue={(value) => {
                setSelectedDetail(value);
            }}
        />
    ));
};
