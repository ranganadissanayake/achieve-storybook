import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';

import Radio from './index';

describe('Radio', () => {
    test('renders the Radio component', () => {
        render(<Radio id="radio-text" name="Radio" />);

        expect(screen.getByText('Radio')).toBeInTheDocument();
        expect(screen.getByRole('radio')).toHaveClass('radio');
    });
    test('radio has label', () => {
        render(<Radio id="radio-text" name="Radio" label="Label" />);

        expect(screen.getByText('Label')).toBeInTheDocument();
    });
    test('add success state', () => {
        render(<Radio id="radio-text" name="Radio" state="success" />);

        expect(screen.getByRole('radio')).toHaveClass('success-input');
    });
    test('add success class for success state Radio', () => {
        render(<Radio id="radio-text" name="Radio" state="success" />);

        expect(screen.getByRole('radio')).toHaveClass('success-input');
    });
    test('add error class for error state Radio', () => {
        render(<Radio id="radio-text" name="Radio" state="error" />);

        expect(screen.getByRole('radio')).toHaveClass('error-input');
    });
    test('add optional test on the radio label', () => {
        render(<Radio id="radio-text" name="Radio" optional={true} />);

        expect(screen.getByText('(optional)')).toBeInTheDocument();
    });
    test('add error class for Radio if error message present', () => {
        render(<Radio id="radio-text" name="Radio" errorMessage="An error occurred" />);

        expect(screen.getByRole('radio')).toHaveClass('error-input');
    });
    test('click event on the Radio', () => {
        const handleClick = jest.fn();
        const utils = render(<Radio id="radio-text" name="Click Me!" onSelect={handleClick} />);
        const input = utils.getByRole('radio');

        fireEvent.click(input);
        expect(handleClick).toHaveBeenCalledTimes(1);
        expect(screen.getByRole('radio')).toBeChecked();
    });
});
