import React, { useEffect } from 'react';
import classnames from 'classnames';

import Label from '../../Atoms/Label';

import './Radio.scss';
import ErrorMessage from '../../Atoms/ErrorMessage';

export interface RadioProps {
    id: string;
    name?: string;
    inputname?: string;
    isCheckedDefault?: boolean;
    state?: 'default' | 'success' | 'error';
    label?: string;
    helperText?: string;
    errorMessage?: string;
    required?: boolean;
    optional?: boolean;
    disabled?: boolean;
    onSelect?: (value: boolean) => void;
    onSelectValue?: (value: string) => void;
    readOnly?: boolean;
}

const Radio: React.FC<RadioProps> = ({
    id,
    label,
    name,
    inputname,
    isCheckedDefault,
    helperText,
    errorMessage,
    required,
    optional,
    disabled,
    onSelect,
    onSelectValue,
    state,
    readOnly
}) => {
    const [isChecked, setIsChecked] = React.useState(isCheckedDefault || false);
    const [isCheckedEffect, setIsCheckedEffect] = React.useState(isChecked);

    useEffect(() => {
        setIsCheckedEffect(isChecked);
    }, [isChecked]);

    useEffect(() => {
        setIsChecked(isCheckedDefault);
        setIsCheckedEffect(isCheckedDefault);
    }, [isCheckedDefault]);

    return (
        <div className={`radio-wrapper ${isCheckedEffect ? "is-checked" : ""}`}>
            {label && (
                <Label
                    text={label}
                    htmlFor={id}
                    helper={helperText}
                    required={required}
                    optional={optional}
                />
            )}
            <label className="radio-section" htmlFor={id}>
                <input
                    id={id}
                    type="radio"
                    checked={isCheckedEffect}
                    name={inputname}
                    onClick={() => {
                        setIsChecked(true);
                        onSelect && onSelect(true);
                        onSelectValue && onSelectValue(id);
                    }}
                    disabled={disabled}
                    className={classnames('radio', {
                        'error-input': errorMessage || state === 'error',
                        'success-input': state === 'success'
                    })}
                    readOnly={readOnly}
                />
                {name && (
                    <Label
                        size="sm"
                        htmlFor={id}
                        text={name}
                        helper={!label && helperText}
                        required={!label && required}
                        optional={!label && optional}
                    />
                )}
            </label>
            {errorMessage && <ErrorMessage message={errorMessage} />}
        </div>
    );
};

export default Radio;
