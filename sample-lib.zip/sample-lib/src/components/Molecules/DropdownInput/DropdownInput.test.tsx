import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';

import DropdownInput, { Option } from './index';

describe('DropdownInput', () => {
    const options = [
        { id: 'Canada', value: 'Canada' },
        { id: 'UK', value: 'United Kingdom' },
        { id: 'Belgium', value: 'Belgium' },
        { id: 'USA', value: 'United States' }
    ];

    test('renders the DropdownInput component', () => {
        render(<DropdownInput />);
        expect(screen.getByTestId('dropdown')).toBeInTheDocument();
    });

    test('displays the selected value', () => {
        render(<DropdownInput type="text" value="Canada" options={options} />);
        expect(screen.getByText('Canada')).toBeInTheDocument();
    });

    test('displays the dropdown values value', () => {
        render(<DropdownInput type="text" value="Canada" options={options} />);
        expect(screen.getByText('Canada')).toBeInTheDocument();
        expect(screen.getByText('United Kingdom')).toBeInTheDocument();
        expect(screen.getByText('Belgium')).toBeInTheDocument();
        expect(screen.getByText('United States')).toBeInTheDocument();
    });

    test('displays the label text', () => {
        render(<DropdownInput type="text" label="Countries" options={options} />);
        expect(screen.getByText('Countries')).toBeInTheDocument();
    });

    test('displays the helper text', () => {
        render(<DropdownInput type="text" helper="Helper Text" options={options} />);
        expect(screen.getByText('Helper Text')).toBeInTheDocument();
    });
    test('calls onChange when a new option is selected', () => {
        const handleChange = jest.fn();
        render(
            <DropdownInput type="text" value="Canada" options={options} onValueChanged={handleChange} />
        );
        fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Canada' } });
        expect(handleChange).toHaveBeenCalledTimes(0);
    });

    test('does not call onChange if the selected value is clicked', () => {
        const handleChange = jest.fn();
        render(
            <DropdownInput type="text" value="Canada" options={options} onValueChanged={handleChange} />
        );
        fireEvent.click(screen.getByText('Canada'));
        expect(handleChange).toHaveBeenCalledTimes(0);
    });

    test('calls onBlur when the dropdown loses focus', () => {
        const handleBlur = jest.fn();
        render(<DropdownInput type="text" value="Canada" options={options} />);
        fireEvent.blur(screen.getByRole('textbox'));
        expect(handleBlur).toHaveBeenCalledTimes(0);
    });

    test('does not call onBlur if an option is selected', () => {
        const handleBlur = jest.fn();
        render(<DropdownInput type="text" value="Canada" options={options} />);
        fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Belgium' } });
        fireEvent.blur(screen.getByRole('textbox'));
        expect(handleBlur).toHaveBeenCalledTimes(0);
    });

    test('updates the selected value when a new option is selected', () => {
        const handleChange = jest.fn();
        render(
            <DropdownInput
                type="text"
                value="Canada"
                options={options}
                onValueChanged={handleChange}
            />
        );
        fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Belgium' } });
        expect(handleChange).toHaveBeenCalledWith('Belgium');
        expect(screen.getByText('Belgium')).toBeInTheDocument();
        expect(screen.queryByText('Canada')).not.toBeInTheDocument();
    });

    test('filters the dropdown options when the user types in the input field', () => {
        render(<DropdownInput options={options} />);
        fireEvent.click(screen.getByRole('textbox'));
        fireEvent.change(screen.getByRole('textbox'), { target: { value: 'Canada' } });
        expect(screen.getByText('Canada')).toBeInTheDocument();
    });

    test('renders the dropdown options with flag', () => {
        render(<DropdownInput options={options} showAsset />);
        fireEvent.click(screen.getByRole('textbox'));

        const option1 = screen.getByText('Canada');
        const option2 = screen.getByText('United Kingdom');
        const option3 = screen.getByText('Belgium');
        const option4 = screen.getByText('United States');

        expect(option1).toBeInTheDocument();
        expect(option2).toBeInTheDocument();
        expect(option3).toBeInTheDocument();
        expect(option4).toBeInTheDocument();

        fireEvent.click(option1);
        expect(screen.getByText('Canada')).toBeInTheDocument();
        expect(screen.queryByRole('United Kingdom')).not.toBeInTheDocument();
        expect(screen.queryByRole('Belgium')).not.toBeInTheDocument();
        expect(screen.queryByRole('United States')).not.toBeInTheDocument();
    });

    test('calls onSelect with the selected value when handleBlur is triggered', () => {
        const handleSelect = jest.fn();
        render(<DropdownInput options={options} onSelect={handleSelect} />);
        fireEvent.click(screen.getByRole('textbox'));
        fireEvent.click(screen.getByText('Canada'));
        fireEvent.blur(screen.getByRole('textbox'));
        expect(handleSelect).toHaveBeenCalledWith('Canada');
    });
    test('updates the selected value when an option is selected with showFlag prop', () => {
        const handleChange = jest.fn();
        render(
            <DropdownInput
                type="text"
                value="Canada"
                options={options}
                onValueChanged={handleChange}
                showAsset
            />
        );
        fireEvent.click(screen.getByRole('textbox'));
        fireEvent.click(screen.getByText('Belgium'));
    });

    describe('DropdownInput for provider and flag asset categories', () => {
        const options = [
            { id: '1', value: 'Option 1', facilityProvider: 'Provider 1' },
            { id: '2', value: 'Option 2', facilityProvider: 'Provider 2' }
        ];
    
        it('sets display asset correctly for providers category when showAsset is true', () => {
            const {  getByText } = render(
                <DropdownInput label="Select" options={options} assetCategory="providers" showAsset placeholder='testing1'/>
            );
            screen.debug(undefined, Infinity)
            fireEvent.focus(screen.getByPlaceholderText('testing1'));
            fireEvent.click(getByText('Option 1'));
            expect(getByText('Option 1')).toBeInTheDocument();
        });
    
        it('sets display asset correctly for flags category when showAsset is true', () => {
            const { getByText } = render(
                <DropdownInput label="Select" options={options} assetCategory="flags" showAsset placeholder='testing1'/>
            );
            fireEvent.focus(screen.getByPlaceholderText('testing1'));
            fireEvent.click(getByText('Option 2'));
            expect(getByText('Option 2')).toBeInTheDocument(); // Assuming ID is displayed for flags category
        });
    
        it('does not display asset when showAsset is false', () => {
            render(
                <DropdownInput label="Select" options={options} assetCategory="providers" showAsset={false} placeholder='placeholder'/>
            );
            screen.debug(undefined,Infinity);
            fireEvent.focus(screen.getByPlaceholderText('placeholder'));
            fireEvent.click(screen.getByText('Option 1'));
            expect((screen.getAllByTestId('dropdown-option'))[0]).toBeInTheDocument();
        });
    
        it('does not display asset when assetCategory is not specified', () => {
            render(
                <DropdownInput label="Select" options={[{ id: '1', value: 'Option 1', facilityProvider: 'Provider 1',name: "test1" }]} showAsset placeholder='placeholder'/>
            );
            fireEvent.focus(screen.getByPlaceholderText('placeholder'));
            fireEvent.click(screen.getByText('Option 1'));
            expect((screen.getAllByTestId('dropdown-option'))[0]).toBeInTheDocument();
        });
    
    });

    describe('DropdownInput with name and without name', () => {
        const options = [
            { id: 'V6F', value: '1fab:dad:1111:2211::0d80:a66d/64', name: 'Site E Internet WAN IPv6 30Ln' },
            { id: 'V6G', value: '1ccb:dad:1111:2233::0d81:a64e/64', name: 'Site E Internet WAN IPv6 _Lng' }
        ]
        const options2 = [
            { id: 'V6F', value: '1fab:dad:1111:2211::0d80:a66d/64'},
            { id: 'V6G', value: '1ccb:dad:1111:2233::0d81:a64e/64' }
        ]
        it('renders the dropdown options with value and name', () => {
            render(<DropdownInput options={options} maxLengthRight={16}/>);
            fireEvent.click(screen.getByRole('textbox'));
            const option1 = screen.getByText('1fab:dad:1111:22...');
            const option2 = screen.getByText('1ccb:dad:1111:22...');
            expect(option1).toBeInTheDocument();
            expect(option2).toBeInTheDocument();
            expect((screen.getAllByTestId('dropdown-tooltip'))[0]).toBeInTheDocument();
            fireEvent.mouseEnter(screen.getByText('1fab:dad:1111:22...'));
            expect(screen.getAllByTestId('dropdown-tooltip').length).toBeGreaterThan(0);
        });

        it('renders the dropdown options without name', () => {
            const { container } = render(<DropdownInput options={options2} />);
            expect(container.getElementsByClassName('tooltip-container-right').length).toBe(0);
            fireEvent.click(screen.getByRole('textbox'));
            fireEvent.mouseEnter(screen.getByText('1fab:dad:1111:2211::0d80:a66d/64'));
            expect(screen.getAllByTestId('dropdown-item-default').length).toBe(2);
        });
    });
});
