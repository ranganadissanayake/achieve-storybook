import React, { ReactNode } from 'react';
import Asset from '../../Atoms/Asset/index';
import classnames from 'classnames';
import Input from '../Input';
import './DropdownInput.scss';
import Tooltip from '../Tooltip';

export interface Option {
    id: string;
    value: string;
    name?: string | ReactNode;
    facilityProvider?: string;
}

type Size = 'lg' | 'md' | 'sm';
/**
 * The properties required for the DropdownInput Component
 * @author Joel Chi <joel.abongwa@distributed.com>
 */
export interface DropdownInputProps {
    /**
     * Enables DropdownInput to be associated with a label for accessibility purposes
     */
    id?: string;
    /**
     * The name of the associated data point submitted to the server
     */
    name?: string;
    /**
     * The type for the input
     */
    type?: string;
    /**
     * Label for the DropdownInput
     */
    label?: string;
    /**
     * Specifies if the dropdown is required - adds an asterix
     */
    required?: boolean;
    /**
     * Specifies if the dropdown is optional - adds an optional text
     */
    optional?: boolean;
    /**
     * Supporting text for the dropdown label
     */
    helper?: string;
    /**
     * Size for the dropdown label text
     */
    labelSize?: 'lg' | 'sm' | 'xs';
    /**
     * Additional styles for the label text
     */
    labelTextStyles?: string;
    /**
     * Additional styles for the label container
     */
    containerStyles?: string;
    /**
     * Additional styles for the label helper
     */
    helperTextStyles?: string;
    /**
     * A placeholder for the dropdown
     */
    placeholder?: string;
    /**
     * A  display/selected value
     */
    value?: string;
    /**
     * The state of the dropdown
     */
    state?: 'default' | 'error' | 'success' | 'disabled' | 'loading';
    /**
     * The size of the select input
     */
    size?: Size;
    /**
     * A message to display in error state
     */
    errorMessage?: string;
    /**
     * The size of the error message
     */
    errorMessageSize?: 'sm' | 'md' | 'lg';
    /**
     * Show/hide error message icon
     */
    showErrorIcon?: boolean;
    /**
     * Adjust size of error message icon
     */
    errorIconSize?: 'sm' | 'md' | 'lg';
    /**
     * The dropdown options
     */
    options?: Option[];
    /**
     * Determines whether user can only select from dropdown options
     */
    onlySelectedValue?: boolean;
    /**
     * Display countries with flags
     */
    showAsset?: boolean;
    /**
     * Allows user to search value
     */
    allowSearch?: boolean;
    /**
     * Specifies what happens when a new value is selected
     */
    onSelect?: (text: string) => void;
    /**
     * Specifies what when input value changes
     */
    onValueChanged?: (text: string) => void;
    /**
     * Switch search features in ip search
     */
    searchInput?: boolean;
    /**
     * Specifies classes for additional styles
     */
    className?: string;

    /**
     * Reserve space for error message
     */
    keepErrorSpace?: boolean;

    /**
     * Specify the category of an asset
     */
    assetCategory?: 'flags' | 'providers' | 'facility';

    /**
     * Specify the asset map
     */
    assetMap?: {};

    /**
     * Specify the max length for right label
     */
    maxLengthRight?: number;

    /**
     * Specify the max length for left label
     */
    maxLengthLeft?: number;

    /**
     * Specify the source for the asset
     */
    assertSrc?: string;

    /**
     * When the input field is clicked
     */
    onClick?: () => void;
}

/**
 * Renders the DropdownInput component
 * @param {React.PropsWithChildren<DropdownInputProps>} props DropdownInputProps properties
 * @returns
 */
const DropdownInput: React.FC<DropdownInputProps> = ({
    id,
    name = '',
    type = 'text',
    label = '',
    required = false,
    optional = false,
    helper = '',
    labelSize = 'lg',
    labelTextStyles = '',
    containerStyles = '',
    helperTextStyles = '',
    placeholder = '',
    value,
    state = 'default',
    errorMessage = '',
    errorMessageSize = 'md',
    showErrorIcon = true,
    size = 'sm',
    options = [],
    onlySelectedValue = true,
    showAsset = false,
    allowSearch = true,
    onSelect,
    onValueChanged,
    className = '',
    searchInput,
    keepErrorSpace = false,
    assetCategory,
    assetMap,
    maxLengthRight = 15,
    assertSrc,
    maxLengthLeft = 15,
    onClick,
}) => {
    const _dropdownRef = React.useRef(null);
    const _inputRef = React.useRef(null);

    const [_showDropdown, setShowDropDown] = React.useState(false);
    const [_selected, setSelected] = React.useState<Option>();
    const [_options, setOptions] = React.useState(options);
    const [_displayValue, setDisplayValue] = React.useState<string>(value ?? '');
    const [_displayAsset, setDisplayAsset] = React.useState<string>();

    const _onValueChanged = React.useCallback(
        (val: string, currentOptions: Option[]) => {
            if (allowSearch) {
                if (type === 'number') {
                    const lastXter = parseInt(val.slice(-1));
                    if (lastXter >= 0 && lastXter <= 9) {
                        _filterDropdown(val, currentOptions);
                    } else {
                        _filterDropdown(val.substring(0, val.length - 1), currentOptions);
                    }
                } else {
                    _filterDropdown(val, currentOptions);
                }
            }
        },
        [allowSearch, type]
    );

    const _filterDropdown = (val: string, currentOptions: Option[]) => {
        setOptions(
            currentOptions.filter(
                ({ id: itemId, value: Value }) =>
                    itemId.toLowerCase().includes(val.toLowerCase()) ||
                    Value.toLowerCase().includes(val.toLowerCase())
            )
        );
        setDisplayValue(val);

        if (onValueChanged) {
            onValueChanged(val);
        }
    };

    const _onSelectValue = (selectedId: string, selectedValue: string, facility:string) => {
        setSelected(_options.find((o) => o.id === selectedId));
        setDisplayValue(selectedValue);
        if (showAsset) {
            setDisplayAsset(facility ? facility : selectedId);
        }
        if (onSelect) {
            onSelect(selectedId);
        }
        setShowDropDown(false);
    };

    const _isDisplayValueValid = React.useMemo(() => {
        const currentValue = options.find(({ value: val }) => val === _displayValue);
        if (currentValue) {
            if (showAsset) {
                setDisplayAsset(currentValue.facilityProvider?currentValue.facilityProvider:currentValue.id);
            }
            return true;
        } else {
            return false;
        }
    }, [options, _displayValue, showAsset]);

    const _handleOutsideClick = (e: MouseEvent) => {
        if (
            ((_dropdownRef.current && !_dropdownRef.current.contains(e.target as Node)) ||
                !_dropdownRef.current) &&
            ((_inputRef.current && !_inputRef.current.contains(e.target as Node)) ||
                !_inputRef.current)
        ) {
            setShowDropDown(false);

            if (onlySelectedValue && !options.find(({ value: val }) => val === _displayValue)) {
                setDisplayValue('');
                if (onSelect) {
                    onSelect('');
                }
            } else {
                if (onSelect) {
                    onSelect(
                        options.find(({ value: val }) => val === _displayValue)?.id ?? _displayValue
                    );
                }
            }
        }
    };

    const _onFocused = React.useCallback(() => {
        if (state !== 'disabled' && state !== 'loading') {
            setShowDropDown(true);
            if (options.length > 0 && _options.length === 0) {
                setOptions([...options]);
            } else if (options.length === 0 && _options.length !== 0) {
                setOptions([]);
            }
        }
        else if (state === 'loading'){
            onClick && onClick();
        }
    }, [options, _options]);

    React.useEffect(() => {
        if(options.length > 0) {
            setOptions([...options]);
        }
    }, [options]);

    React.useEffect(() => {
        if (value && options.find((o) => o.id === value)) {
            setSelected(options.find((o) => o.id === value));
            setDisplayValue(options.find((o) => o.id === value).value);

            if (showAsset && _selected) {
                setDisplayAsset(_selected.facilityProvider?_selected.facilityProvider as string:_selected.id as string);
            }
        } else {
            setDisplayValue(value);
        }

        if (onSelect) {
            onSelect(value);
        }
    }, [value, options, showAsset]);

    React.useEffect(() => {
        if (_showDropdown) {
            document.addEventListener('mousedown', _handleOutsideClick);
        }

        return () => {
            document.removeEventListener('mousedown', _handleOutsideClick);
        };
    }, [_showDropdown, _displayValue]);


    return (
        <div data-testid="dropdown" className={`dropdown_container ${className}`}>
            <Input
                id={id}
                name={name}
                value={_displayValue}
                label={label}
                required={required}
                optional={optional}
                helper={helper}
                labelSize={labelSize}
                labelTextStyles={labelTextStyles}
                containerStyles={containerStyles}
                helperTextStyles={helperTextStyles}
                placeholder={placeholder}
                state={state}
                errorMessage={errorMessage}
                errorMessageSize={errorMessageSize}
                showErrorIcon={showErrorIcon}
                size={size}
                iconName={
                    state === "loading" ? 'none' :
                    options && options.length > 0
                        ? _showDropdown
                            ? 'chevron_up'
                            : 'chevron_down'
                        : 'none'
                }
                iconAfter
                iconSize="sm"
                asset={showAsset && _isDisplayValueValid && assetCategory !== 'facility'? _displayAsset : 'none'}
                inputRef={_inputRef}
                onFocus={_onFocused}
                onClick={_onFocused}
                onIconClick={() => {
                    if (state !== 'disabled') {
                        setShowDropDown((prev) => !prev);
                    }
                }}
                onChange={(val) => _onValueChanged(val, options)}
                className="dropdown_input"
                searchInput={state!=="loading" && searchInput}
                keepErrorSpace={keepErrorSpace}
                disableTyping={!allowSearch}
                allowOnlyDigits={type === 'number' || type === 'integer'}
                assetCategory={assetCategory}
                assetMap={assetMap}
                assetSrc={state==="loading" && assertSrc}
            />
            { state !== 'loading' &&
            <div className="select-dropdown">
                {_options.length > 0 && (
                    <div
                        className={classnames(`select_container`, { _showDropdown, err_message: errorMessage !== "" })}
                        ref={_dropdownRef}
                    >
                        <div className="dropdown_select">
                            {_options.map(({ id: itemId, value: val, name: itemName, facilityProvider: facility}) => {
                                return (
                                    <div
                                        className={classnames(`dropdown_option`, { showAsset })}
                                        key={itemId}
                                        onClick={() => _onSelectValue(itemId, val, facility)}
                                        data-testid="dropdown-option"
                                    >
                                        {facility && (assetCategory === 'providers' || assetCategory === 'facility') && showAsset && (
                                            <Asset asset={facility.toLowerCase()} size='md' assetCategory={assetCategory} assetMap={assetMap} />
                                        )}

                                        {assetCategory === 'flags' && showAsset && (
                                            <Asset asset={itemId.toLowerCase()} size='md' assetCategory={assetCategory} assetMap={assetMap} />
                                        )}

                                        {!assetCategory && itemName && (
                                            <span className="item-left">{itemName}</span>
                                        )}

                                        {assetCategory === 'providers' || assetCategory === 'facility'? (
                                            <span>{itemName ?? val}</span>
                                        ) : (
                                            <>
                                                {itemName && val.length>maxLengthRight? 
                                                    <div className={itemName?'tooltip-container-right':''} data-testid="dropdown-tooltip">
                                                        <Tooltip direction="bottom" content={val}><span className={`${itemName ? 'item-right' : ''}`}>{val.substring(0, maxLengthRight).concat("...")}</span></Tooltip>
                                                    </div>
                                                    :itemName? 
                                                        <span className="item-right" data-title={val} data-testid="dropdown-item-default">{val}</span>
                                                    :<div className="tooltip-container-left">
                                                        {val.length>maxLengthLeft? 
                                                            <Tooltip direction="bottom" content={val} hasTarget={true}><span className="item-default" data-testid="dropdown-item-default">{val}</span></Tooltip>
                                                            :<span className="item-default" data-testid="dropdown-item-default">{val}</span>
                                                        }
                                                    </div>
                                                }
                                            </>
                                        )}
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                )}
            </div>
            }
        </div>
    );
};

export default DropdownInput;
