import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import DropdownInput from './index';

export const DefaultStory = () => (
    <DropdownInput
        type="number"
        name="threshold"
        helper="Low threshold"
        placeholder="1 to 99%"
        onlySelectedValue={false}
        keepErrorSpace={true}
        options={[
            { id: '1', value: '1%' },
            { id: '5', value: '5%' },
            { id: '10', value: '10%' },
            { id: '15', value: '15%' },
            { id: '20', value: '20%' },
            { id: '25', value: '25%' },
            { id: '30', value: '30%' },
            { id: '35', value: '35%' },
            { id: '40', value: '40%' },
            { id: '45', value: '45%' },
            { id: '50', value: '50%' },
            { id: '55', value: '55%' },
            { id: '60', value: '60%' },
            { id: '65', value: '65%' },
            { id: '70', value: '70%' },
            { id: '75', value: '75%' },
            { id: '80', value: '80%' },
            { id: '85', value: '85%' },
            { id: '90', value: '90%' },
            { id: '95', value: '95%' },
            { id: '99', value: '99%' }
        ]}
    />
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/DropdownInput',
    component: DropdownInput
} as ComponentMeta<typeof DropdownInput>;

const Template: ComponentStory<typeof DropdownInput> = (args) => <DropdownInput {...args} />;

export const Playground = Template.bind({});
Playground.args = {
    name: 'name',
    label: 'Label',
    helper: 'helper text',
    required: true,
    showAsset: true,
    // state: 'disabled',
    value: 'UK',
    onlySelectedValue: false,
    assetCategory: 'facility',
    options: [
        { id: 'CA', value: 'Canada' },
        { id: 'UK', value: 'United Kingdom and Scotland' },
        { id: 'BE', value: 'Belgium' },
        { id: 'US', value: 'United States' },
        { id: 'HK', value: 'HongKong' },
        { id: 'AU', value: 'Australia' },
        { id: 'MX', value: 'Mexico' },
        { id: 'ARG', value: 'Argentina' },
    ]
};

const valueAndNameTemplate: ComponentStory<typeof DropdownInput> = (args) => (
    <div><DropdownInput {...args} /></div>
    
);

export const valueAndName = valueAndNameTemplate.bind({});
valueAndName.args = {
    type: 'text',
    name: 'valueAndName',
    placeholder: 'Search IP name or input your WAN address',
    onlySelectedValue: false,
    options: [
        { id: 'A', value: '192.0.2.146/29', name: 'Site A Internet WAN IPv4' },
        { id: 'B', value: '192.0.2.145/29', name: 'Site B Internet WAN IPv4' },
        { id: 'C', value: '192.0.2.144/29', name: 'Site C Internet WAN IPv4' },
        { id: 'D', value: '192.0.2.143/29', name: 'Site D Internet WAN IPv4' },
        { id: 'E', value: '192.0.2.142/29', name: 'Site E Internet WAN IPv4' },
        { id: 'V6F', value: '1fab:dad:1111:2211::0d80:a66d/64', name: 'Site E Internet WAN IPv6 30Ln' },
        { id: 'V6G', value: '1ccb:dad:1111:2233::0d81:a64e/64', name: 'Site E Internet WAN IPv6 _Lng' }
    ],
    searchInput : true 
};

const withLongValueTemplate: ComponentStory<typeof DropdownInput> = (args) => (
    <div style={{width:'200px'}}><DropdownInput {...args} /></div>
);

export const withLongValue = withLongValueTemplate.bind({});
withLongValue.args = {
    type: 'text',
    name: 'withLongValue',
    placeholder: 'Search IP name or input your WAN address',
    onlySelectedValue: false,
    options: [
        { id: 'AA', value: '192.0.2.146/29'},
        { id: 'BB', value: '192.0.2.145/29' },
        { id: 'CC', value: '192.0.2.144/29'},
        { id: 'DC', value: '192.0.2.143/29' },
        { id: 'EE', value: '192.0.2.142/29' },
        { id: 'V6FF', value: '1fab:dad:1111:2211::0d80:a66d/64' },
        { id: 'V6GG', value: '1ccb:dad:1111:2233::0d81:a64e/64'}
    ],
    searchInput : true 
};
