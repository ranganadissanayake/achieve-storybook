import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';

import Tooltip from './index';

describe('ToolTip', () => {
    test('renders the Tooltip component', () => {
        render(
            <Tooltip content="Default Tooltip">
                <span>Tooltip example</span>
            </Tooltip>
        );

        expect(screen.getByText('Tooltip example')).toBeInTheDocument();
    });
    test('Mouse over the text to show tooltip', async () => {
        render(
            <Tooltip content="Default Tooltip">
                <span>Tooltip example</span>
            </Tooltip>
        );

        fireEvent.mouseOver(screen.getByText('Tooltip example'));

        await waitFor(() => screen.getByTestId('tooltip-content'));
        expect(screen.getByText('Default Tooltip')).toBeInTheDocument();
    });
    test('Mouse over the text to show tooltip top', async () => {
        render(
            <Tooltip direction="top" content="Default Tooltip">
                <span>Tooltip example</span>
            </Tooltip>
        );

        fireEvent.mouseOver(screen.getByText('Tooltip example'));

        await waitFor(() => screen.getByTestId('tooltip-content'));
        expect(screen.getByTestId('tooltip-content')).toHaveClass('tip-top');
    });
    test('Mouse over the text to show tooltip left', async () => {
        render(
            <Tooltip direction="left" content="Default Tooltip">
                <span>Tooltip example</span>
            </Tooltip>
        );

        fireEvent.mouseOver(screen.getByText('Tooltip example'));

        await waitFor(() => screen.getByTestId('tooltip-content'));
        expect(screen.getByTestId('tooltip-content')).toHaveClass('tip-left');
    });
    test('Mouse over the text to show tooltip right', async () => {
        render(
            <Tooltip direction="right" content="Default Tooltip">
                <span>Tooltip example</span>
            </Tooltip>
        );

        fireEvent.mouseOver(screen.getByText('Tooltip example'));

        await waitFor(() => screen.getByTestId('tooltip-content'));
        expect(screen.getByTestId('tooltip-content')).toHaveClass('tip-right');
    });
    test('Mouse over the text to show tooltip bottom', async () => {
        render(
            <Tooltip direction="bottom" content="Default Tooltip">
                <span>Tooltip example</span>
            </Tooltip>
        );

        fireEvent.mouseOver(screen.getByText('Tooltip example'));

        await waitFor(() => screen.getByTestId('tooltip-content'));
        expect(screen.getByTestId('tooltip-content')).toHaveClass('tip-bottom');
    });

    test('On mouse leave tooltip text should hide', async () => {
        render(
            <Tooltip direction="bottom" content="Default Tooltip">
                <span>Tooltip example</span>
            </Tooltip>
        );
        fireEvent.mouseOver(screen.getByText('Tooltip example'));
        fireEvent.mouseLeave(screen.getByText('Tooltip example'));
        expect(screen.queryByTestId('tooltip-content')).toBeNull();
    });
});
