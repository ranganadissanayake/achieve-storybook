import React, { useState, useRef } from 'react';
import Label from '../../Atoms/Label';
import './Tooltip.scss';

export interface TooltipProps {
    children: React.ReactElement;
    content: string;
    direction?: 'top' | 'right' | 'bottom' | 'left';
    /**
     * The amount of time in miliseconds for the Tooltip to appear
     */
    delay?: number;
    hasTarget?: boolean;
}

const Tooltip: React.FC<TooltipProps> = ({ content, children, delay, direction = 'right', hasTarget=false }) => {
    let timeout;
    const [active, setActive] = useState(false);
    const [tooltipPositionTop, setTooltipPositionTop] = useState(0)
    const [tooltipPositionLeft, setTooltipPositionLeft] = useState(0)
    const _tooltipRef = useRef<HTMLDivElement>(null);

    const showTip = (e) => {
        timeout = setTimeout(() => {
            setActive(true);
            if (hasTarget) {
                setTooltipPositionTop(e.clientY + 20)
                setTooltipPositionLeft(e.clientX )
            }
        }, delay || 500);
    };

    const hideTip = () => {
        clearInterval(timeout);
        setActive(false);
    };

    return (
        <div className="tooltip-wrapper" onMouseEnter={showTip} onMouseLeave={hideTip} ref={_tooltipRef} >
            {children}
            {active && content && (
                <div data-testid="tooltip-content" className={`tooltip tip-${direction}`} style={hasTarget?{ position: 'fixed', top: tooltipPositionTop, left: tooltipPositionLeft}:{}}>
                    <Label size="sm" text={content} isFontHeadline={false} />
                </div>
            )}
        </div>
    );
};

export default Tooltip;
