import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Label from '../../Atoms/Label';

import Tooltip from './index';

export const DefaultStory = () => (
    <Tooltip content="Default Tooltip">
        <Label text="Tooltip example" />
    </Tooltip>
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/Tooltip',
    component: Tooltip
} as ComponentMeta<typeof Tooltip>;

const Template: ComponentStory<typeof Tooltip> = (args) => (
    <div
        style={{
            padding: '120px'
        }}
    >
        <Tooltip {...args} content={`Tooltip ${args.direction}`}>
            <Label text="Tooltip example" />
        </Tooltip>
    </div>
);

export const Playground = Template.bind({});

Playground.args = {
    direction: 'top'
};
