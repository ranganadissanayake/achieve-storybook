import React from "react";
import Avatar from "../../Atoms/Avatar";
import classnames from "classnames";

import "./Stepper.scss";

export interface StepperProps {
  steps: string[];
  direction?: "horizontal" | "vertical";
  showLabel?: boolean;
  current?: number;
  initial?: number;
  size?: "sm" | "lg";
  alt?: boolean;
  className?: string;
}

const Stepper: React.FC<StepperProps> = ({
  steps,
  direction = "horizontal",
  showLabel = true,
  current = 1,
  initial = 1,
  size = "sm",
  alt = false,
  className = "",
}) => {
  const [currentStep, setCurrentStep] = React.useState(current);

  const overflowLimiter = (value: number) => {
    const limit = steps.length + initial;
    if (value >= limit) {
      setCurrentStep(limit - 1);
    } else if (value <= initial) {
      setCurrentStep(initial);
    } else {
      setCurrentStep(value);
    }
  };

  React.useEffect(() => {
    if (typeof current === "number") {
      overflowLimiter(current);
    }
  }, [current]);

  return (
    <div
      className={classnames(
        `stepper_container ${direction} ${size} ${className}`,
        { alt }
      )}
      data-testid="stepper"
    >
      {steps.map((step, index) => {
        return (
          <div
            className={classnames("stepper", {
              current: currentStep === index + initial,
              completed: currentStep > index + initial,
              alt,
              showLabel,
            })}
            key={index}
          >
            <Avatar
              size={size}
              value={currentStep <= index + initial ? `${index + initial}` : ""}
              iconName="tick_alt_2px"
              hideTitle
              hideSubtitle={!showLabel}
              subtitle={step}
              border
              className="stepper_avatar"
            />
            <hr className={`stepper_line ${size}`} data-testid="stepper_line" />
          </div>
        );
      })}
    </div>
  );
};

export default Stepper;
