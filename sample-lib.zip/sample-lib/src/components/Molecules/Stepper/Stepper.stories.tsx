import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Stepper from "./index";

export const DefaultStory = () => (
  <Stepper steps={["step one", "step two", "step three", "step four"]} />
);

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Molecules/Stepper",
  component: Stepper,
} as ComponentMeta<typeof Stepper>;

const Template: ComponentStory<typeof Stepper> = (args) => (
  <Stepper {...args} />
);

export const Playground = Template.bind({});
Playground.args = {
  steps: ["step one", "step two", "step three", "step four"],
  current: 3,
  size: "lg",
};
