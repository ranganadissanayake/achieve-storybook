import React from "react";
import { render, screen } from "@testing-library/react";

import Stepper from "./index";

describe("Stepper", () => {
  const steps = ["step one", "step two", "step three", "step four"];

  test("renders the Stepper component", () => {
    render(<Stepper steps={steps} />);
    expect(screen.getByTestId("stepper")).toBeInTheDocument();
  });

  test("add horizontal class to horizontal Stepper component", () => {
    render(<Stepper steps={steps} direction="horizontal" />);
    expect(screen.getByTestId("stepper")).toHaveClass("horizontal");
  });

  test("add vertical class to vertical Stepper component", () => {
    render(<Stepper steps={steps} direction="vertical" />);
    expect(screen.getByTestId("stepper")).toHaveClass("vertical");
  });

  test("add sm class to small size Stepper component", () => {
    render(<Stepper steps={steps} size="sm" />);
    expect(screen.getByTestId("stepper")).toHaveClass("sm");
  });

  test("add lg class to large size Stepper component", () => {
    render(<Stepper steps={steps} size="lg" />);
    expect(screen.getByTestId("stepper")).toHaveClass("lg");
  });

  test("add alt class to alt Stepper component", () => {
    render(<Stepper steps={steps} alt />);
    expect(screen.getByTestId("stepper")).toHaveClass("alt");
  });

  test("display step labels", () => {
    render(<Stepper steps={steps} showLabel />);
    expect(screen.getByText("step one")).toBeInTheDocument();
    expect(screen.getByText("step two")).toBeInTheDocument();
    expect(screen.getByText("step three")).toBeInTheDocument();
    expect(screen.getByText("step four")).toBeInTheDocument();
  });

  test("hide step labels", () => {
    render(<Stepper steps={steps} showLabel={false} />);
    expect(screen.queryByText("step one")).not.toBeInTheDocument();
    expect(screen.queryByText("step two")).not.toBeInTheDocument();
    expect(screen.queryByText("step three")).not.toBeInTheDocument();
    expect(screen.queryByText("step four")).not.toBeInTheDocument();
  });

  test("show current step number", () => {
    render(<Stepper steps={steps} current={3} />);
    expect(screen.getByText("3")).toBeInTheDocument();
  });

  test("show initial step number", () => {
    render(<Stepper steps={steps} initial={1} />);
    expect(screen.getByText("1")).toBeInTheDocument();
  });

  test("don't show number below initial step", () => {
      render(<Stepper steps={steps} initial={1} />);
      expect(screen.queryByText('0')).not.toBeInTheDocument();
  });
  test('limit current step to max step if value is higher', () => {
      render(<Stepper steps={steps} current={5} />);
      expect(screen.getByText('4')).toBeInTheDocument();
  });
});
