import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Icon from '../../Atoms/Icon';

import Checkbox from './index';

export const DefaultStory = () => <Checkbox id="default" name="Default" />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/Checkbox',
    component: Checkbox
} as ComponentMeta<typeof Checkbox>;

const Template: ComponentStory<typeof Checkbox> = (args) => <Checkbox {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    id: 'playground',
    label: 'Playground',
    name: 'Checkbox',
    helperText: 'Some helper',
    required: true,
    optional: true,
    onSelect: () => {
        alert('Checkbox selected');
    }
};
