import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';

import Checkbox from './index';

describe('Checkbox', () => {
    test('renders the Checkbox component', () => {
        render(<Checkbox id="checbox-text" name="Checkbox" />);

        expect(screen.getByText('Checkbox')).toBeInTheDocument();
        expect(screen.getByRole('checkbox')).toHaveClass('checkbox');
    });
    test('checkbox has label', () => {
        render(<Checkbox id="checbox-text" name="Checkbox" label="Label" />);

        expect(screen.getByText('Label')).toBeInTheDocument();
    });
    test('add large class for large size Checkbox', () => {
        render(<Checkbox id="checbox-text" name="Checkbox" size="large" />);

        expect(screen.getByRole('checkbox')).toHaveClass('sz-large');
    });
    test('add ', () => {
        render(<Checkbox id="checbox-text" name="Checkbox" state="success" />);

        expect(screen.getByRole('checkbox')).toHaveClass('success-input');
    });
    test('add success class for success state Checkbox', () => {
        render(<Checkbox id="checbox-text" name="Checkbox" state="success" />);

        expect(screen.getByRole('checkbox')).toHaveClass('success-input');
    });
    test('add error class for error state Checkbox', () => {
        render(<Checkbox id="checbox-text" name="Checkbox" state="error" />);

        expect(screen.getByRole('checkbox')).toHaveClass('error-input');
    });
    test('add optional test on the checkbox label', () => {
        render(<Checkbox id="checbox-text" name="Checkbox" optional={true} />);

        expect(screen.getByText('(optional)')).toBeInTheDocument();
    });
    test('add error class for Checkbox if error message present', () => {
        render(<Checkbox id="checbox-text" name="Checkbox" errorMessage="An error occurred" />);

        expect(screen.getByRole('checkbox')).toHaveClass('error-input');
    });
    test('click event on the Checkbox', () => {
        const handleClick = jest.fn();
        const utils = render(
            <Checkbox id="checbox-text" name="Click Me!" onSelect={handleClick} />
        );
        const input = utils.getByRole('checkbox');

        fireEvent.click(input);
        expect(handleClick).toHaveBeenCalledTimes(1);
        expect(screen.getByRole('checkbox')).toBeChecked();
    });
});
