import React, { useEffect } from 'react';
import classnames from 'classnames';

import Label from '../../Atoms/Label';
import ErrorMessage from '../../Atoms/ErrorMessage';

import './Checkbox.scss';

export interface CheckboxProps {
    id: string;
    name?: string;
    isCheckedDefault?: boolean;
    size?: 'default' | 'large';
    state?: 'default' | 'success' | 'error';
    label?: string;
    helperText?: string;
    errorMessage?: string;
    required?: boolean;
    optional?: boolean;
    disabled?: boolean;
    onSelect?: (value: boolean) => void;
}

const Checkbox: React.FC<CheckboxProps> = ({
    id,
    label,
    name,
    helperText,
    errorMessage,
    isCheckedDefault = false,
    required,
    optional,
    disabled,
    onSelect,
    state,
    size
}) => {
    const [isChecked, setIsChecked] = React.useState(isCheckedDefault);

    useEffect(() => {
        if (isCheckedDefault !== isChecked) {
            setIsChecked(isCheckedDefault);
        }
    }, [isCheckedDefault]);

    return (
        <div className="checkbox-wrapper">
            {label && (
                <Label text={label} helper={helperText} required={required} optional={optional} />
            )}
            <label className="checkbox-section" htmlFor={id}>
                <input
                    id={id}
                    type="checkbox"
                    checked={isChecked}
                    onChange={() =>
                        setIsChecked((prev) => {
                            onSelect?.(!prev);
                            return !prev;
                        })
                    }
                    disabled={disabled}
                    className={classnames('checkbox', {
                        'error-input': errorMessage || state === 'error',
                        'success-input': state === 'success',
                        'sz-large': size === 'large'
                    })}
                />
                {name && (
                    <Label
                        size="sm"
                        text={name}
                        helper={!label && helperText}
                        required={!label && required}
                        optional={!label && optional}
                    />
                )}
            </label>
            {errorMessage && <ErrorMessage message={errorMessage} />}
        </div>
    );
};

export default Checkbox;
