import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

import RangeDatepicker from './index';

describe('RangeDatepicker', () => {
    test('renders the RangeDatepicker component', () => {
        render(<RangeDatepicker />);

        expect(screen.getByText('Start date')).toBeInTheDocument();
    });
    it('handling start date input', () => {
        render(<RangeDatepicker />);
        const inputElement = document.querySelector('#startDate');
        if(inputElement){
            fireEvent.change(inputElement, { target: { value: '2000-01-02' } });
            expect(inputElement).toHaveValue('2000-01-02');
        }
    });
    it('handling end date input', () => {
        render(<RangeDatepicker />);
        const inputElement = document.querySelector('#endDate');
        if(inputElement){
            fireEvent.change(inputElement, { target: { value: '2020-01-03' } });
            expect(inputElement).toHaveValue('2020-01-03');
        }
    });
    it('error validation for start and end date', () => {
        render(<RangeDatepicker />);
        const inputElementStart = document.querySelector('#startDate');
        const inputElementEnd = document.querySelector('#endDate');
        if(inputElementStart && inputElementEnd){
            fireEvent.change(inputElementStart, { target: { value: '2020-01-03' } });
            fireEvent.change(inputElementEnd, { target: { value: '2020-01-03' } });
            expect(screen.getByText('Start date must be less than End date')).toBeInTheDocument();
            expect(screen.getByText('End date must be greater than Start date')).toBeInTheDocument();
        }
    });
    it('error validation success  for start and end date', () => {
        render(<RangeDatepicker />);
        const inputElementStart = document.querySelector('#startDate');
        const inputElementEnd = document.querySelector('#endDate');
        if(inputElementStart && inputElementEnd){
            fireEvent.change(inputElementStart, { target: { value: '2020-01-03' } });
            fireEvent.change(inputElementEnd, { target: { value: '2022-01-03' } });
            expect(screen).not.toContain('Start date must be less than End date');
            expect(screen).not.toContain('End date must be greater than Start date');
        }
    });

});
