import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import RangeDatepicker from './index';

export const DefaultStory = () => <RangeDatepicker />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/RangeDatePicker',
    component: RangeDatepicker
} as ComponentMeta<typeof RangeDatepicker>;
