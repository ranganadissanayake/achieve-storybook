import React, { FC, useEffect, useState } from 'react';
import classnames from 'classnames';
import dayjs from 'dayjs';
import './RangeDatepicker.scss';
import Input from '../Input';
import { ContainerRow, Column } from '../../Atoms/Grid';

export interface RangeDatepickerProps {
    onDateChange?: ({ startDate, endDate }: { startDate: string; endDate: string }) => void;
}

export const RangeDatepicker: FC<RangeDatepickerProps> = ({ onDateChange }) => {
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    const [startDateError, setStartDateError] = useState('');
    const [endDateError, setEndDateError] = useState('');

    var localizedFormat = require('dayjs/plugin/localizedFormat')
    dayjs.extend(localizedFormat)

    useEffect(() => {
        onDateChange &&
            onDateChange({
                startDate: dayjs(startDate).format('l'),
                endDate: dayjs(endDate).format('l')
            });
    }, [startDate, endDate]);

    const validateDate = (start: string, end: string) => {
        let isValidStartDate = true;
        let isValidEndDate = true;
        if (dayjs(start).isValid() && dayjs(end).isValid()) {
            isValidStartDate = dayjs(start).isBefore(end);
            if (isValidStartDate) {
                setStartDateError("")
            } else {
                setStartDateError("Start date must be less than End date")

            }
            isValidEndDate = dayjs(end).isAfter(start);
            if (isValidEndDate) {
                setEndDateError("")
            } else {
                setEndDateError("End date must be greater than Start date")

            }
        }

    }

    const handleSetStartDate = (inputValue: string) => {
        setStartDate(inputValue);
        validateDate(inputValue, endDate);
    };

    const handleSetEndDate = (inputValue: string) => {
        setEndDate(inputValue);
        validateDate(startDate, inputValue);
    };

    return (
        <div className="date-range-wrapper">
            <ContainerRow>
                <Column sm={16} md={16} lg={16} className="date-range-inputs">
                    <div className="date-range-main" data-testid="date-range">
                        <div className="left-field-value">
                            <div className="title-text">Start date</div>
                            <div>
                                <Input
                                    type="date"
                                    onChange={handleSetStartDate}
                                    name="startDate"
                                    value={startDate}
                                    placeholder={'dd/mm/yyy'}
                                    className={classnames('input-field range-input no-icon')}
                                    errorMessage={startDateError}
                                    state={startDateError ? 'error' : 'default'}
                                    errorMessageSize={'sm'}
                                    showErrorIcon={true}
                                    iconSize={'md'}
                                />
                            </div>
                        </div>
                        <div className="right-field-value">
                            <div className="title-text">End date</div>
                            <div>
                                <Input
                                    type="date"
                                    onChange={handleSetEndDate}
                                    name="endDate"
                                    value={endDate}
                                    placeholder={'dd/mm/yyy'}
                                    className={classnames('input-field range-input no-icon')}
                                    errorMessage={endDateError}
                                    state={endDateError ? 'error' : 'default'}
                                    errorMessageSize={'sm'}
                                    showErrorIcon={true}
                                    iconSize={'md'}
                                />
                            </div>
                        </div>
                    </div>
                </Column>
            </ContainerRow>
        </div>
    );
};

export default RangeDatepicker;
