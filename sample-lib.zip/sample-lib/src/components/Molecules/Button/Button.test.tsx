import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';

import Button from './index';
import { Info } from '../../Assets/icons';

describe('Button', () => {
    test('renders the Button component', () => {
        render(<Button label="Button" />);

        expect(screen.getByText('Button')).toBeInTheDocument();
    });
    test('add small class for small size button', () => {
        render(<Button label="Button" size="small" />);

        expect(screen.getByRole('button')).toHaveClass('button-small');
    });
    test('add medium class for medium size button', () => {
        render(<Button label="Button" size="medium" />);

        expect(screen.getByRole('button')).toHaveClass('button-medium');
    });
    test('add large class for large size button', () => {
        render(<Button label="Button" size="large" />);

        expect(screen.getByRole('button')).toHaveClass('button-large');
    });
    test('add solid class for a solid button', () => {
        render(<Button label="Button" variant="solid" />);

        expect(screen.getByRole('button')).toHaveClass('button-solid');
    });
    test('add outline class for an outline button', () => {
        render(<Button label="Button" variant="outline" />);

        expect(screen.getByRole('button')).toHaveClass('button-outline');
    });
    test('add link class for link button', () => {
        render(<Button label="Button" variant="link" />);

        expect(screen.getByRole('button')).toHaveClass('button-link');
    });
    test('add gradient class for gradient button', () => {
        render(<Button label="Button" variant="gradient" />);

        expect(screen.getByRole('button')).toHaveClass('button-gradient');
    });
    test('add an icon to the button', () => {
        render(<Button label="Button" iconTitle="accessibility" />);

        expect(screen.getByRole('button')).toContainElement(screen.getByTestId('icon'));
    });
    test('add an icon to the button in reverse', () => {
        render(<Button label="Button" iconTitle="accessibility" iconBefore={false} />);

        expect(screen.getByRole('button')).toContainElement(screen.getByTestId('icon'));
        expect(screen.getByTestId('reversed-icon')).toHaveClass('button--icon-wrapper__reverse');
    });
    test('click event on the button', () => {
        const handleClick = jest.fn();
        render(<Button label="Click Me!" onPress={handleClick} />);

        fireEvent.click(screen.getByText('Click Me!'));
        expect(handleClick).toHaveBeenCalledTimes(1);
    });
});
