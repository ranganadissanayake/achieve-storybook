import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Icon from '../../Atoms/Icon';

import Button from './index';

export const DefaultStory = () => <Button label="Default" />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/Button',
    component: Button
} as ComponentMeta<typeof Button>;

const Template: ComponentStory<typeof Button> = (args) => <Button {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    label: 'Playground',
    onPress: () => {
        alert('Button pressed');
    }
};
