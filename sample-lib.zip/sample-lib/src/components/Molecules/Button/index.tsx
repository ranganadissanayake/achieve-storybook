import React from 'react';
import classnames from 'classnames';

import Badge from '../../Atoms/Badge';
import Label from '../../Atoms/Label';
import Icon from '../../Atoms/Icon';
import { IconName } from '../../Assets/icons/iconLib';
import './Button.scss';

export interface ButtonProps {
    variant?: 'solid' | 'outline' | 'link' | 'gradient' | 'white';
    variantOutlineHighlight?: 'default' | 'outline-highlight',
    size?: 'small' | 'medium' | 'large';
    fullWidth?: boolean;
    label?: string;
    labelPosition?: 'left' | 'right' | 'center';
    labelContainerCustomStyle?: string;
    labelColor?: "default" | "black";
    helperText?: string;
    helperTextColor?: "default" | "black";
    iconCustomStyle?: string;
    iconTitle?: IconName;
    iconSize?: 'sm' | 'md' | 'lg';
    iconBefore?: boolean;
    iconInverted?: boolean;
    iconAlignment?: 'default' | 'balance';
    borderSize?: 'sm' | 'md' | 'lg',
    disabled?: boolean;
    className?: string;
    onPress?: (e?: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    dataTestId?: string;
    isFontHeadline?: boolean;
    bordered?: boolean;
    enableOriginalIcon?: boolean;
    /**
     * Set badge text
     */
    primaryBadgeText?: string;
    /**
     * Select badge variant
     */
    primaryBadgeVariant?:
        | 'default'
        | 'info'
        | 'critical'
        | 'warning'
        | 'success'
        | 'disabled'
        | 'default-light';
    /**
     * Set badge outline
     */
    primaryBadgeOutline?: boolean;
    /**
     * Add custom styles as a class name
     */
    primaryBadgeCustomStyle?: string;
}

const Button: React.FC<ButtonProps> = ({
    label,
    labelPosition = "center",
    labelContainerCustomStyle = "",
    labelColor = "default",
    onPress,
    variant,
    variantOutlineHighlight = "default",
    size = 'medium',
    iconCustomStyle = "",
    iconTitle,
    iconBefore,
    helperText,
    helperTextColor = "default",
    iconSize,
    iconAlignment="default",
    fullWidth = false,
    disabled,
    className = '',
    iconInverted = false,
    dataTestId,
    isFontHeadline = true,
    bordered = false,
    borderSize = "md",
    enableOriginalIcon = false,
    primaryBadgeText,
    primaryBadgeVariant,
    primaryBadgeCustomStyle,
    primaryBadgeOutline
}) => {
    let buttonStyles = '';

    buttonStyles = `button-${variant || 'solid'} ${borderSize} ${labelColor} ${variantOutlineHighlight} button-${size} ${className}`;
    const labelSizes = size === 'large' || size === 'medium' ? 'sm' : 'xs';
    return (
        <button
            data-testid={dataTestId}
            onClick={onPress}
            className={classnames(`button ${labelPosition}`, buttonStyles, { fullWidth, bordered })}
            disabled={disabled}
        >
            <div
                data-testid="reversed-icon"
                className={classnames('button--icon-wrapper', {
                    'button--icon-wrapper__reverse': !iconBefore
                })}
            >
                {iconTitle && (
                    <Icon
                        title={iconTitle}
                        className={classnames(`icon ${iconCustomStyle} ${iconAlignment}`, { icon_space: label })}
                        size={iconSize}
                        inverse={iconInverted}
                        showOriginal={enableOriginalIcon}
                    />
                )}

                {label && (
                    <Label
                        size={labelSizes}
                        text={label}
                        helper={helperText}
                        containerStyles={`label-container ${labelContainerCustomStyle}`}
                        labelTextStyles={`label ${labelColor}`}
                        helperTextStyles={`helper ${helperTextColor}`}
                        isFontHeadline={isFontHeadline}
                    />
                )}
            </div>
            <div>
                {primaryBadgeText && (
                    <Badge
                        text={primaryBadgeText}
                        style={primaryBadgeVariant}
                        customStyle={`primary-badge ${primaryBadgeCustomStyle}`}
                        outline={primaryBadgeOutline}
                    />
                )}
            </div>
        </button>
    );
};

export default Button;
