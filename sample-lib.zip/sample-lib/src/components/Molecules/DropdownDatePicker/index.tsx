import React from 'react';

import { useOnClickOutside } from '../../../hooks';

import './DropdownDatePicker.scss';
import '../DropdownInput/DropdownInput.scss';
import classnames from 'classnames';
import Badge from '../../Atoms/Badge';
import Icon from '../../Atoms/Icon';
import Label from '../../Atoms/Label';
import RangeDatepicker from '../RangeDatepicker';
import Button from '../Button';
import dayjs from 'dayjs';

export interface DropdownDatePickerProps {
    label?: string;
    selectSideEffects?: (value: string | string[]) => void;
    defaultValue?: string[];
    controlledShowPopover?: boolean;
    setShowPopover?: (controlledShowPopover: boolean) => void;
}

const DropdownDatePicker: React.FC<DropdownDatePickerProps> = ({
    label = '',
    selectSideEffects,
    defaultValue = [],
    controlledShowPopover,
    setShowPopover
}) => {
    const [showCTAPopover, setShowCTAPopover] = React.useState(false);
    const popoverRef = React.useRef<HTMLDivElement>(null);
    const [select, setSelect] = React.useState<string[]>(defaultValue);
    const [selectRange, setSelectRange] = React.useState<{ startDate: string; endDate: string }>();

    const handleClickOutside = () => {
        setShowCTAPopover(!showCTAPopover);
        setShowPopover && setShowPopover(false);
    };

    useOnClickOutside(popoverRef, handleClickOutside);

    const handleSelectRange = () => {
        const { startDate, endDate } = selectRange;
        if (dayjs(endDate,"DD/MM/YYYY").isValid() && dayjs(startDate,"DD/MM/YYYY").isValid() && dayjs(endDate).isAfter(startDate) && dayjs(startDate).isBefore(endDate)) {
            setSelect([`${startDate} - ${endDate}`]);
            selectSideEffects && selectSideEffects([`${startDate} - ${endDate}`]);
        }
    };

    const handleClear = () => {
        setSelect([]);
        selectSideEffects && selectSideEffects([]);
        setShowCTAPopover(false);
        setShowPopover && setShowPopover(false);
    };

    return (
        <div className={classnames('dropdown-group')}>
            <div
                data-testid="dropdown-group-trigger"
                className={classnames('dropdown-group--input', {
                    'is-expanded': showCTAPopover || controlledShowPopover
                })}
                onClick={() => {
                    setShowCTAPopover(!showCTAPopover);
                    setShowPopover && setShowPopover(!controlledShowPopover);
                }}
            >
                <Label text={label} size="xs" isFontHeadline={false} />
                {select.length > 0 ? (
                    <span>
                        <Badge
                            text={`${select[0]}`}
                            style="default-light"
                            showClose
                            onClose={handleClear}
                        />
                    </span>
                ) : (
                    ''
                )}
                {!showCTAPopover || controlledShowPopover ? (
                    <Icon title="chevron_down" size="sm" />
                ) : (
                    <Icon title="chevron_up" size="sm" />
                )}
            </div>
            {(showCTAPopover || controlledShowPopover) && (
                <div ref={popoverRef} className={classnames('dropdown-group--container')}>
                    <div className={classnames('dropdown-group--container__menu-list has-padding')}>
                        <div className="range-section">
                            <RangeDatepicker
                                onDateChange={(selectedRange) => {
                                    setSelectRange(selectedRange);
                                }}
                            />
                            <Button
                                variant="outline"
                                label={'Select'}
                                onPress={() => {
                                    handleSelectRange();
                                }}
                            />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DropdownDatePicker;
