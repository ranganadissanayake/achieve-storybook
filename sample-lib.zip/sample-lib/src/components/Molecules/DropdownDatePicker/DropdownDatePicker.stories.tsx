import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import DropdownDatePicker from './index';

export const DefaultStory = () => <DropdownDatePicker />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/DropdownDatePicker',
    component: DropdownDatePicker
} as ComponentMeta<typeof DropdownDatePicker>;

const Template: ComponentStory<typeof DropdownDatePicker> = (args) => (
    <DropdownDatePicker {...args} />
);

export const Playground = Template.bind({});

Playground.args = {
    label: 'Date Added',
    selectSideEffects: (value) => {
        alert(value);
    }
};
