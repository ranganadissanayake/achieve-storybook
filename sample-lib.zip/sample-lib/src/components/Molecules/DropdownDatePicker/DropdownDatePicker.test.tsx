import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import DropdownDatePicker from './index';

describe('DropdownDatePicker', () => {
    it('renders with default props', () => {
        render(<DropdownDatePicker />);
    });

    it('toggles popover visibility on click', () => {
        render(<DropdownDatePicker />);
        const trigger = screen.getByTestId('dropdown-group-trigger');

        expect(screen.queryByText('Select')).not.toBeInTheDocument();
        fireEvent.click(trigger);
        expect(screen.getByText('Select')).toBeInTheDocument();

        fireEvent.click(trigger);
        expect(screen.queryByText('Select')).not.toBeInTheDocument();
    });

    it('clears the selection and closes popover on badge click', () => {
        render(<DropdownDatePicker />);
        const trigger = screen.getByTestId('dropdown-group-trigger');
    
        fireEvent.click(trigger);
        const selectButton = screen.getByText('Select');
        expect(selectButton).toBeInTheDocument();
    
        fireEvent.click(selectButton); 
    
        expect(screen.queryByText('X')).not.toBeInTheDocument();
    });
});
