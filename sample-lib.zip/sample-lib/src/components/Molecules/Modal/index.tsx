import React, { ReactNode, useEffect } from 'react';

import classnames from 'classnames';

import Icon from '../../Atoms/Icon';
import { IconName } from '../../Assets/icons/iconLib';

import './Modal.scss';
import Button from '../Button';

/**
 * The properties required for the Modal Component
 * @author Joel Chi <joel.abongwa@distributed.com>
 */
export interface ModalProps {
    /**
     * Shows/Hides the close button (X)
     */
    hideCloseIcon?: boolean;
    /**
     * Determines the size of the modal
     */
    size?: 'sm' | 'md' | 'lg';
    /**
     * Defines an icon to display at top of modal
     */
    topIcon?: IconName;
    /**
     * Specifies a style for the top icon
     */
    topIconStyle?: 'success' | 'warning' | 'critical' | 'none' | 'info';
    /**
     * Specifies a size for the top icon
     */
    topIconSize?: 'sm' | 'md' | 'lg';
    /**
     * Specifies a padding for the entire modal
     */
    modalPadding?: 'default' | 'small';
    /**
     * Specifies a size for the buttons
     */
    buttonsSize?: 'small' | 'medium' | 'large';
    /**
     * Specifies a color for the top icon
     */
    IconColor?: string;
    /**
     * Defines a title text for the modal
     */
    title?: string | ReactNode;
    /**
     * Defines a message text for the modal
     */
    message?: string | ReactNode;
    /**
     * Defines more message text for the modal
     */
    complementaryMessage?: string;
    /**
     * Justifies the content of the modal
     */
    contentAlign?: 'left' | 'center';
    /**
     * Defines a text for the cancel button
     */
    cancelText?: string;
    /**
     * Defines a text for the action button
     */
    actionText?: string;
    /**
     * Hides/shows buttons
     */
    hideButtons?: boolean;
    /**
     * Difines other content for the button
     */
    children?: React.ReactNode;
    /**
     * Difines action for the okay button
     */
    onOk?: () => void;
    /**
     * Difines action for the cancel button
     */
    onCancel?: () => void;
    /**
     * Defines confirm action. Note: This additional action
     * is added because there is onCancel action for same button
     */
    onConfirm?: () => void;
    /**
     * Closes/opens the modal
     */
    closeModal?: boolean;
    /**
     * Allows closing/opening of modal by clicking outside
     */
    outsideClose?: boolean;
    /**
     * Defines additional styles for the modal
     */
    className?: string;
    /**
     * Set the position of the title
     */
    titlePosition?: 'default' | 'top';
    /**
     * Hide Cancel Button
     */
    hideCancelButton?: boolean;
    /**
     * GIF
     */
    gifSource?: string;
}

/**
 * Renders the Modal component
 * @param {React.PropsWithChildren<ModalProps>} props ModalProps properties
 * @returns
 */
const Modal: React.FC<ModalProps> = ({
    hideCloseIcon = false,
    size = 'md',
    topIcon,
    topIconStyle = 'none',
    topIconSize = 'sm',
    modalPadding = 'default',
    buttonsSize = 'large',
    IconColor = '',
    title = '',
    message = '',
    complementaryMessage = '',
    contentAlign = 'left',
    cancelText = 'Cancel',
    actionText = 'Ok',
    hideButtons = false,
    children,
    closeModal = true,
    outsideClose = true,
    onOk,
    onCancel,
    onConfirm,
    className = '',
    titlePosition = 'default',
    hideCancelButton = false,
    gifSource
}) => {
    const modalRef = React.useRef(null);

    const handleOutsideClick = (e: MouseEvent) => {
        if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
            onCancel();
        }
    };

    useEffect(() => {
        if (outsideClose) {
            document.addEventListener('mousedown', handleOutsideClick);
        }

        return () => {
            document.removeEventListener('mousedown', handleOutsideClick);
        };
    }, [outsideClose]);

    return (
        <div data-testid="modal" className={classnames('modal', className, { close: closeModal })}>
            <div
                data-testid="modal-card"
                ref={modalRef}
                className={`modal_card ${size} ${modalPadding}`}
            >
                {(topIcon || !hideCloseIcon) && (
                    <header data-testid="modal-header" className={`modal_header ${contentAlign}`}>
                        {gifSource && (
                            <div>
                                <img className="top_icon" src={gifSource} alt="GIF" />
                            </div>
                        )}
                        {topIcon &&
                            (topIconStyle === 'none' ? (
                                <Icon
                                    title={topIcon}
                                    size={topIconSize}
                                    color={IconColor}
                                    className="top_icon"
                                />
                            ) : (
                                <div
                                    data-testid="top-icon"
                                    className={`top_icon_container ${topIconStyle}`}
                                >
                                    <Icon title={topIcon} size={topIconSize} className="top_icon" />
                                </div>
                            ))}

                        {!hideCloseIcon && (
                            <span data-testid="close-icon">
                                <Icon
                                    onClick={onCancel}
                                    title="cross_new"
                                    size="lg"
                                    className="close_icon"
                                />
                            </span>
                        )}
                    </header>
                )}
                <main data-testid="modal-body" className={`modal_body ${contentAlign}`}>
                    {!!title && <h2 className={`modal_title ${titlePosition}`}>{title}</h2>}
                    <div>
                        {!!message && <p className="modal_text">{message}</p>}
                        {!!complementaryMessage && (
                            <p className="modal_text">{complementaryMessage}</p>
                        )}
                    </div>
                    {children && <div>{children}</div>}
                </main>

                {!hideButtons && (
                    <footer data-testid="modal-footer" className="modal_footer">
                        {!hideCancelButton && (
                            <Button
                                onPress={onConfirm ?? onCancel}
                                fullWidth
                                label={cancelText}
                                variant="outline"
                                size={buttonsSize}
                            />
                        )}
                        <Button
                            className={hideCancelButton ? 'half-width' : ''}
                            onPress={onOk}
                            fullWidth
                            label={actionText}
                            variant="gradient"
                            size={buttonsSize}
                        />
                    </footer>
                )}
            </div>
        </div>
    );
};

export default Modal;
