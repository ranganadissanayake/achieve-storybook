import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';

import Modal from './index';

describe('Modal', () => {
    test('renders the Modal component', () => {
        render(<Modal />);
        expect(screen.getByTestId('modal')).toBeInTheDocument();
    });

    test('displays the close icon', () => {
        render(<Modal />);
        expect(screen.getByTestId('close-icon')).toBeInTheDocument();
    });

    test('hides the close icon', () => {
        render(<Modal hideCloseIcon />);
        expect(screen.queryByTestId('close-icon')).not.toBeInTheDocument();
    });

    test('add sm class to small size modal', () => {
        render(<Modal size="sm" />);
        expect(screen.getByTestId('modal-card')).toHaveClass('sm');
    });

    test('add md class to medium size modal', () => {
        render(<Modal size="md" />);
        expect(screen.getByTestId('modal-card')).toHaveClass('md');
    });

    test('add lg class to large size modal', () => {
        render(<Modal size="lg" />);
        expect(screen.getByTestId('modal-card')).toHaveClass('lg');
    });

    test('displays top icon', () => {
        render(<Modal topIcon="tick" topIconStyle="success" />);
        expect(screen.getByTestId('top-icon')).toBeInTheDocument();
    });

    test('add success class to success top icon', () => {
        render(<Modal topIcon="tick" topIconStyle="success" />);
        expect(screen.getByTestId('top-icon')).toHaveClass('success');
    });

    test('add warning class to warning top icon', () => {
        render(<Modal topIcon="tick" topIconStyle="warning" />);
        expect(screen.getByTestId('top-icon')).toHaveClass('warning');
    });

    test('add critical class to critical top icon', () => {
        render(<Modal topIcon="tick" topIconStyle="critical" />);
        expect(screen.getByTestId('top-icon')).toHaveClass('critical');
    });

    test('renders the modal title', () => {
        render(<Modal title="Modal Title" />);
        expect(screen.getByText('Modal Title')).toBeInTheDocument();
    });

    test('renders the modal message', () => {
        render(<Modal title="Modal Title" message="Modal message" />);
        expect(screen.getByText('Modal message')).toBeInTheDocument();
    });

    test('renders the modal additional message', () => {
        render(<Modal title="Modal Title" complementaryMessage="Modal additional message" />);
        expect(screen.getByText('Modal additional message')).toBeInTheDocument();
    });

    test('adds left class to left content modal', () => {
        render(<Modal contentAlign="left" />);
        expect(screen.getByTestId('modal-header')).toHaveClass('left');
        expect(screen.getByTestId('modal-body')).toHaveClass('left');
    });

    test('adds center class to center content modal', () => {
        render(<Modal contentAlign="center" />);
        expect(screen.getByTestId('modal-header')).toHaveClass('center');
        expect(screen.getByTestId('modal-body')).toHaveClass('center');
    });

    test('renders the modal cancel text', () => {
        render(<Modal cancelText="Close Modal" />);
        expect(screen.getByText('Close Modal')).toBeInTheDocument();
    });

    test('renders the modal action text', () => {
        render(<Modal actionText="Leave" />);
        expect(screen.getByText('Leave')).toBeInTheDocument();
    });

    test('renders the modal buttons', () => {
        render(<Modal />);
        expect(screen.getByTestId('modal-footer')).toBeInTheDocument();
    });

    test('hides the modal buttons', () => {
        render(<Modal hideButtons />);
        expect(screen.queryByTestId('modal-footer')).not.toBeInTheDocument();
    });

    test('hides the modal ', () => {
        render(<Modal closeModal={true} />);
        expect(screen.getByTestId('modal')).toHaveClass('close');
    });

    test('shows the modal ', () => {
        render(<Modal closeModal={false} />);
        expect(screen.getByTestId('modal')).not.toHaveClass('close');
    });

    test('calls onCancel when clicking outside the modal', () => {
        const onCancelMock = jest.fn();
        render(<Modal onCancel={onCancelMock} />);

        fireEvent.mouseDown(document);

        expect(onCancelMock).toHaveBeenCalled();
    });

    test('hides the cancel buttons', () => {
        render(<Modal hideCancelButton={true} />);
        expect(screen.queryByTestId('cancel')).not.toBeInTheDocument();
    });

    test('check for confirm action on cancel button', () => {
        const onConfirmMock = jest.fn();
        render(<Modal cancelText="Confirm action button" onConfirm={onConfirmMock} />);
        const actionBttn = screen.getByText('Confirm action button');
        fireEvent.click(actionBttn);
        expect(onConfirmMock).toHaveBeenCalled();
    });
});
