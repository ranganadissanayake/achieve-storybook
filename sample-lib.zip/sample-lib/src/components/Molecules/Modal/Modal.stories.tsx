import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Modal from './index';
import Button from '../Button';

export const DefaultStory = () => (
    <Modal
        topIcon="cloud_desktop"
        topIconStyle="warning"
        size="md"
        title="Unsaved changes"
        message="Do you want to leave this page ?"
        complementaryMessage="Your uncompleted configuration information will be lost."
        contentAlign="center"
        actionText="Leave"
        onOk={() => alert('Leaving')}
    />
);

DefaultStory.storyName = 'Default';

const Decorator = ({ story, ...props }) => {
    const [showModal, setShowModal] = React.useState(false);

    const openModal = () => {
        setShowModal(true);
    };

    const closeModal = () => {
        setShowModal(false);
    };

    return (
        <div>
            <Button onPress={openModal} label="Open Modal" />
            {React.cloneElement(story(), {
                ...props,
                closeModal: !showModal,
                onCancel: closeModal
            })}
        </div>
    );
};

export default {
    title: 'ReactComponentLibrary/Molecules/Modal',
    component: Modal,
    decorators: [(story) => <Decorator story={story} />]
} as ComponentMeta<typeof Modal>;

const Template: ComponentStory<typeof Modal> = (args) => <Modal {...args} />;

export const Playground = Template.bind({});
Playground.args = {
    topIcon: 'tick',
    topIconStyle: 'success',
    size: 'md',
    title: 'Unsaved changes',
    message: 'Do you want to leave this page ?',
    complementaryMessage: 'Your uncompleted configuration will be lost. ',
    contentAlign: 'left',
    actionText: 'Confirm',
    onOk: () => alert('A confirmation')
};
