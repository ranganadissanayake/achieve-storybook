import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import { RangeSlider } from './index';

const onChangeFn = ({ min, max }: { min: number; max: number }) => {
    console.log(`min = ${min}, max = ${max}`);
};

const args = {
    min: 0,
    max: 100000,
    onChangeSlider: onChangeFn,
    minDefault: '0',
    maxDefault: '1000000',
    unitText: 'Mbps',
    leftLabel: 'From (Mbps)',
    rightLabel: 'To (Mbps)'
};

describe('Range Slider Component', () => {
    test('should renders the ReactTable component', () => {
        render(<RangeSlider {...args} />);
        expect(screen.getByTestId('range-slider')).toBeInTheDocument();
    });

    it('should render the all inputs', () => {
        const { container } = render(<RangeSlider {...args} />);
        expect(container.querySelectorAll('input')).toHaveLength(4);
    });

    test('should click left side and right side range inputs', () => {
        render(<RangeSlider {...args} />);
        const onChange = jest.fn();
        const leftInput = screen.getByTestId('left-input');
        fireEvent.change(leftInput);

        expect(onChange).toHaveBeenCalled;
        const rightInput = screen.getByTestId('right-input');
        fireEvent.change(rightInput);
        expect(onChange).toHaveBeenCalled;
    });
    
    test('should call onChangeSlider function on input change', () => {
        const onChangeFn = jest.fn();
        const { getByTestId } = render(<RangeSlider {...args} onChangeSlider={onChangeFn} />);
        const leftInput = getByTestId('left-input') as HTMLInputElement;
        const rightInput = getByTestId('right-input') as HTMLInputElement;
        fireEvent.change(leftInput, { target: { value: '5000' } });
        fireEvent.change(rightInput, { target: { value: '75000' } });
        expect(onChangeFn).toHaveBeenCalledWith({ min: '5000', max: '75000' });
      });
      test('should not call onChangeSlider function when input values are invalid', () => {
        const onChangeFn = jest.fn();
        const { getByTestId } = render(<RangeSlider {...args} onChangeSlider={onChangeFn} />);
        const leftInput = getByTestId('left-input') as HTMLInputElement;
        const rightInput = getByTestId('right-input') as HTMLInputElement;
      
        fireEvent.change(leftInput, { target: { value: 'foo' } });
        fireEvent.change(rightInput, { target: { value: 'bar' } });
      });
});