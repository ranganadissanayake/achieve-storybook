import React ,{ ChangeEvent, FC, useCallback, useEffect, useState, useRef } from 'react';
import classnames from 'classnames';
import Input from '../Input';
import { ContainerRow, Column } from '../../Atoms/Grid';
import './RangeSlider.scss';

// The properties required for the Range slider componet
export interface RangeSliderProps {
    min: number;
    max: number;
    onChangeSlider: Function;
    minDefault: string | number;
    maxDefault: string | number;
    unitText: string;
    leftLabel: string;
    rightLabel: string;
    leftValidationMessage? : string;
    rightValidationMessage? : string;
    inputType?: 'number' | 'float';
    numberOfDecimalPlaces?: number;
}

export const RangeSlider: FC<RangeSliderProps> = ({
    min,
    max,
    minDefault,
    maxDefault,
    onChangeSlider,
    unitText,
    leftLabel,
    rightLabel,
    leftValidationMessage = "Input value must be less than Max value",
    rightValidationMessage = "Input value must be greater than Min value",
    inputType = "number",
    numberOfDecimalPlaces = 3,

}) => {
    const [minValText, setMinValText] = useState(Number(minDefault));
    const [maxValText, setMaxValText] = useState(Number(maxDefault));
    const [errorLeft, setErrorLeft] = useState('');
    const [errorRight, setErrorRight] = useState('');
    const minValRef = useRef<HTMLInputElement>(null);
    const maxValRef = useRef<HTMLInputElement>(null);
    const range = useRef<HTMLDivElement>(null);
    const [checkInit, setCheckInit] = useState<boolean>(true);

    // calculating presentage to drow slider
    const getPercentage = useCallback(
        (value: number) => Math.round(((value - min) / (max - min)) * 100),
        [min, max]
    );

    const updateRangeStyles = () => {
        if (
            maxValRef.current &&
            Number(minValText) <= max &&
            Number(minValText) >= 0 &&
            Number(minValText) < Number(maxValText)
        ) {
            const minPercent = getPercentage(minValText);
            const maxPercent = getPercentage(+maxValRef.current.value);
            if (range.current) {
                range.current.style.left = `${minPercent}%`;
                range.current.style.width = `${maxPercent - minPercent}%`;
            }
            setErrorLeft('');
            setErrorRight('');
        }
    };
    // genarating range when min value is getting change
    useEffect(() => {
        updateRangeStyles();
    }, [minValText, getPercentage]);

    // rerender the scaller (fixing a issue)
    useEffect(() => {
        updateRangeStyles();
    }, []);

    // genarating range when max value is getting change
    useEffect(() => {
        if (
            minValRef.current &&
            Number(maxValText) <= max &&
            Number(maxValText) > 0 &&
            Number(maxValText) > Number(minValText)
        ) {
            const minPercent = getPercentage(+minValRef.current.value);
            const maxPercent = getPercentage(maxValText);

            if (range.current) {
                range.current.style.width = `${maxPercent - minPercent}%`;
            }
            setErrorLeft('');
            setErrorRight('');
        }
    }, [maxValText, getPercentage]);

    // taking user selected values and pass to onChangeSlider call back
    useEffect(() => {
        onChangeSlider({
            min: minValRef.current?.value && inputType !== "float" ? minValRef.current.value : minValText,
            max: maxValRef.current?.value && inputType !== "float" ? maxValRef.current.value : maxValText
        });
    }, [minValText, maxValText]);

    useEffect(() => {
        setMinValText(Number(minDefault));
        setMaxValText(Number(maxDefault));
    }, [minDefault, maxDefault]);

    // error handling left input
    const changeMinInput = (inputValue: string) => {
        if (Number(inputValue) > max || Number(inputValue) >= maxValText) {
            setErrorLeft(leftValidationMessage);
            setMinValText(Number(inputValue));
        } else {
            setErrorLeft('');
            setMinValText(Number(inputValue));
            setCheckInit(false);
        }
        setCheckInit(false);
    };

    // error handling right input
    const changeMaxInput = (inputValue: string) => {
        if ((inputValue != '' && Number(inputValue) <= 0) || Number(inputValue) <= minValText) {
            setErrorRight(rightValidationMessage);
            setMaxValText(Number(inputValue));
        } else if (Number(inputValue) > max) {
            setErrorRight(leftValidationMessage);
            setMaxValText(Number(inputValue));
        } else {
            setErrorRight('');
            setMaxValText(Number(inputValue));
            setCheckInit(false);
        }
        setCheckInit(false);
    };

   

    return (
        <div className="range-slider-wrapper">
            <ContainerRow>
                <Column sm={16} md={16} lg={16} className="range-slider-inputs">
                    <div className="range-slider-main" data-testid="range-slider">
                        <div className="slider__left-value">
                            <div className="title-text">{leftLabel}</div>
                            <div>
                                <Input
                                    type={inputType}
                                    numberOfDecimalPlaces={numberOfDecimalPlaces}
                                    onChange={changeMinInput}
                                    name="minvalue"
                                    value={
                                        minValText >= 0 && !checkInit ? minValText.toString() : ''
                                    }
                                    placeholder={unitText}
                                    className="input-field range-input"
                                    errorMessage={errorLeft}
                                    state={errorLeft ? 'error' : 'default'}
                                    errorMessageSize={'sm'}
                                    showErrorIcon={true}
                                    iconSize={'md'}
                                />{' '}
                            </div>
                        </div>
                        <div className="slider__right-value">
                            <div className="title-text">{rightLabel}</div>
                            <div>
                                <Input
                                    type={inputType}
                                    numberOfDecimalPlaces={numberOfDecimalPlaces}
                                    onChange={changeMaxInput}
                                    name="maxvalue"
                                    value={
                                        maxValText != 0 && !checkInit ? maxValText.toString() : ''
                                    }
                                    placeholder={unitText}
                                    className="input-field range-input"
                                    errorMessage={errorRight}
                                    state={errorRight ? 'error' : 'default'}
                                    errorMessageSize={'sm'}
                                    showErrorIcon={true}
                                    iconSize={'md'}
                                />{' '}
                            </div>
                        </div>
                    </div>
                </Column>
            </ContainerRow>
            <ContainerRow>
                <Column sm={16} md={16} lg={16} className="range-slider-bar">
                    <div
                        className={`range-container ${
                            errorLeft !== '' || errorRight !== '' ? 'error-gap' : ''
                        } ${checkInit ? 'init' : ''}`}
                    >
                        <input
                            type="range"
                            min={min}
                            max={max}
                            value={minValText}
                            ref={minValRef}
                            onChange={(event: ChangeEvent<HTMLInputElement>) => {
                                const value = Math.min(+event.target.value, maxValText - 1);
                                setMinValText(value);
                                event.target.value = value.toString();
                                setCheckInit(false);
                            }}
                            className={classnames('range-slider-wrapper thumb thumb--zindex-3', {
                                'range-slider-wrapper thumb--zindex-5': minValText > max - min
                            })}
                            data-testid="left-input"
                        />
                        <input
                            type="range"
                            min={min}
                            max={max}
                            value={maxValText}
                            ref={maxValRef}
                            onChange={(event: ChangeEvent<HTMLInputElement>) => {
                                const value = Math.max(+event.target.value, minValText - 1);
                                if (minValText < value) {
                                    setMaxValText(value);
                                    event.target.value = value.toString();
                                    setCheckInit(false);
                                }
                            }}
                            className="thumb thumb--zindex-4"
                            data-testid="right-input"
                        />

                        <div className="range-slider">
                            <div className="slider__track"></div>
                            <div ref={range} className="slider__range"></div>
                        </div>
                    </div>
                </Column>
            </ContainerRow>
        </div>
    );
};

export default RangeSlider;
