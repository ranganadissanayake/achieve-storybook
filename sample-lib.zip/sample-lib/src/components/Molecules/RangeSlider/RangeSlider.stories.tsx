import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { RangeSlider } from './index';

const onChangeSlider = ({ min, max }: { min: number; max: number }) => {
    // console.log(`min = ${min}, max = ${max}`);
};

export const DefaultStory = () => (
    <RangeSlider
        min={0}
        max={100}
        onChangeSlider={onChangeSlider}
        minDefault={'0'}
        maxDefault={'100'}
        unitText={'Mbps'}
        leftLabel={'From (Mbps)'}
        rightLabel={'To (Mbps)'}
    />
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/RangeSlider',
    component: RangeSlider
} as ComponentMeta<typeof RangeSlider>;

const Template: ComponentStory<typeof RangeSlider> = (args) => <RangeSlider {...args} />;

export const Playground = Template.bind({});
Playground.args = {
    leftLabel:'From (Mbps)',
    rightLabel:'To (Mbps)',
    min: 0,
    max: 1000000,
    onChangeSlider: onChangeSlider,
    minDefault: '0',
    maxDefault: '1000000',
    unitText: 'Mbps'
};
