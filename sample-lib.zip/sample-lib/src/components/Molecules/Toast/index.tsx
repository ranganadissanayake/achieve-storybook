import React, { useEffect } from 'react';
import Icon from '../../Atoms/Icon';
import './Toast.scss';
import { IconName } from '../../Assets/icons/iconLib';
import Button from '../Button';
import { useToast } from '../../../hooks';

export interface ToastItem {
    /**
     * Set the id of the Toast
     */
    id: string | number;
    /**
     * Set the title of the Toast
     */
    title?: string;
    /**
     * Set the type of the Toast
     */
    type: 'success' | 'warning' | 'critical' | 'info' | 'empty';
    /**
     * Set the description of the Toast
     */
    description?: string | React.ReactNode;
    /**
     * Set the sussces Toast action title
     */
    actionTitle?: string;
    /**
     * Set the sussces Toast action
     */
    action?: () => void;
    /**
     * Set the action icon
     */
    actionIconTitle?: IconName;
}
export interface ToastProps {
    /**
     * Set className extention
     */
    className?: string;
    /**
     * Set the position of the Toast
     */
    position?: 'top' | 'bottom';
    /**
     * The list of the Toasts
     */
    toastList: ToastItem[];
    /**
     * Auto disappear time
     */
    timeout?: number;
    /**
     * Add a delete sideeffect function to be called on delete
     */
    deleteSideEffect?: () => void;
}

const Toast = ({
    className,
    position = 'top',
    toastList,
    timeout = 30000,
    deleteSideEffect
}: React.PropsWithChildren<ToastProps>) => {
    const toast = useToast();

    useEffect(() => {
        const interval = setInterval(() => {
            if (toastList.length) {
                toastList.forEach((data,i)=>{
                    handleDelete(toastList[i].id);
                })
            }
        }, timeout);

        return () => {
            clearInterval(interval);
        };
    }, [toastList, timeout]);

    const handleDelete = (id: string | number) => {
        toast.removeToast(id);
        deleteSideEffect && deleteSideEffect();
    };

    const matchIcon = (type: string): IconName => {
        switch (type) {
            case 'success':
                return 'tick';
            case 'warning':
                return 'warning';
            case 'critical':
                return 'alert';
            case 'info':
                return 'info_bold';
            default:
                return 'alert';
        }
    };

    return (
        <div className={`toast-container ${position}-right`} data-testid="toast">
            {toastList.map((selectedToast, i) => (
                <div
                    key={`${selectedToast.id}-${i}`}
                    className={`toast ${selectedToast.type}  ${position}-right ${className}`}
                >
                    <div className="toast-left__item">
                        <Icon title={matchIcon(selectedToast.type)} showOriginal={selectedToast.type === 'warning' || selectedToast.type === 'info' ? true : false} />
                    </div>
                    <div className="toast-middle__item">
                        <p className="title">{selectedToast.title}</p>
                        <p className="description">{selectedToast.description}</p>
                        {selectedToast.type === 'success' && selectedToast.action && (
                            <div>
                                <Button
                                    size="medium"
                                    variant="link"
                                    label={selectedToast.actionTitle}
                                    iconTitle={selectedToast.actionIconTitle ?? 'chevron_right'}
                                    iconSize="sm"
                                    onPress={selectedToast.action}
                                    className="button-styles"
                                />
                            </div>
                        )}
                    </div>
                    <div
                        className="toast-right__item"
                        onClick={() => handleDelete(selectedToast.id)}
                    >
                        <Icon title={'cross_alt'} size="lg" color="var(--brand-black)"/>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default Toast;
