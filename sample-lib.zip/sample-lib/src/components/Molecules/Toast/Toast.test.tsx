import React from 'react';
import { render, screen } from '@testing-library/react';
import Toast from './index';

describe('Toast', () => {
    test('should render the toast component', () => {
        render(
            <Toast
                position="top"
                toastList={[
                    {
                        id: 0,
                        title: 'Success',
                        description: 'This is a success toast component',
                        type: 'success'
                    }
                ]}
            />
        );
        expect(screen.getByTestId('toast')).toBeInTheDocument();
    });
    test('should render the toast success component', () => {
        render(
            <Toast
                position="top"
                toastList={[
                    {
                        id: 0,
                        title: 'Success',
                        description: 'This is a success toast component',
                        type: 'success'
                    }
                ]}
            />
        );
        expect(screen.getByTestId('toast')).toBeInTheDocument();
        expect(screen.getByText('Success')).toBeInTheDocument();
        expect(screen.getByText('This is a success toast component')).toBeInTheDocument();
    });
    test('should render the toast critical component', () => {
        render(
            <Toast
                position="top"
                toastList={[
                    {
                        id: 3,
                        title: 'Critical',
                        description: 'This is a critical toast component',
                        type: 'critical'
                    }
                ]}
            />
        );
        expect(screen.getByTestId('toast')).toBeInTheDocument();
        expect(screen.getByText('Critical')).toBeInTheDocument();
        expect(screen.getByText('This is a critical toast component')).toBeInTheDocument();
    });
    test('should render the toast warning component', () => {
        render(
            <Toast
                position="top"
                toastList={[
                    {
                        id: 2,
                        title: 'Warning',
                        description: 'This is a warning toast component',
                        type: 'warning'
                    }
                ]}
            />
        );
        expect(screen.getByTestId('toast')).toBeInTheDocument();
        expect(screen.getByText('Warning')).toBeInTheDocument();
        expect(screen.getByText('This is a warning toast component')).toBeInTheDocument();
    });
    test('should render the toast warning component', () => {
        render(
            <Toast
                position="top"
                toastList={[
                    {
                        id: 4,
                        title: 'Informational',
                        description: 'This is an informational toast component',
                        type: 'info'
                    }
                ]}
            />
        );
        expect(screen.getByTestId('toast')).toBeInTheDocument();
        
    });
    test('should render the toast warning component', () => {
        render(
            <Toast
                position="top"
                toastList={[
                    {
                        id: 5,
                        title: 'Informational',
                        description: 'This is an informational toast component',
                        type: 'empty'
                    }
                ]}
            />
        );
        expect(screen.getByTestId('toast')).toBeInTheDocument();
        expect(screen.getByText('Informational')).toBeInTheDocument();
        expect(screen.getByText('This is an informational toast component')).toBeInTheDocument();
    });
  
    test('should auto-dismiss toast after timeout', async () => {
        render(
            <Toast
                position="top"
                toastList={[
                    {
                        id: 0,
                        title: 'Auto Dismiss',
                        description: 'This toast will auto-dismiss',
                        type: 'info'
                    }
                ]}
                timeout={1000} 
            />
        );

        expect(screen.getByText('Auto Dismiss')).toBeInTheDocument();
        expect(screen.getByText('This toast will auto-dismiss')).toBeInTheDocument();

        await new Promise((resolve) => setTimeout(resolve, 1100)); 
    });
});
