import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Toast from './index';
import { useToast } from '../../../hooks';
import Button from '../Button';
import { RandomId } from '../../../utils';

export const DefaultStory = () => (
    <Toast
        position="bottom"
        timeout={200000}
        toastList={[
            {
                id: RandomId(),
                title: 'Success',
                description: 'This is a success toast component',
                type: 'success'
            },
            {
                id: RandomId(),
                title: 'Success',
                description: (
                    <span>
                        This is a success{' '}
                        <a href="https://www.bt.com" target="_blank">
                            google{' '}
                        </a>{' '}
                        toast component
                    </span>
                ),
                type: 'success',
                actionTitle: 'Action',
                action: () => {
                    alert('clicked the toast notification');
                }
            },
            {
                id: RandomId(),
                title: 'Warning',
                description: 'This is a warning toast component',
                type: 'warning'
            },
            {
                id: RandomId(),
                title: 'Critical',
                description: 'This is a critical toast component',
                type: 'critical'
            },
            {
                id: RandomId(),
                title: 'Informational',
                description: 'This is an informational toast component',
                type: 'info'
            }
        ]}
    />
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Molecules/Toast',
    component: Toast
} as ComponentMeta<typeof Toast>;

export const Playground = () => {
    const toast = useToast();

    return (
        <div>
            <Button
                label="Success"
                onPress={() => {
                    toast.addToast(
                        {
                            title: 'Success',
                            description: 'This is a success toast component',
                            type: 'success'
                        },
                        { timeout: 10000 }
                    );
                }}
            />
            <Button
                label="Success With Action"
                onPress={() => {
                    toast.addToast(
                        {
                            title: 'Success',
                            description: (
                                <span>
                                    This is a success{' '}
                                    <a href="https://www.bt.com/" target="_blank">
                                        google{' '}
                                    </a>{' '}
                                    toast component
                                </span>
                            ),
                            type: 'success',
                            actionTitle: 'Action',
                            action: () => {
                                alert('clicked the toast notification');
                            }
                        },
                        { timeout: 10000 }
                    );
                }}
            />
            <Button
                label="Warning"
                onPress={() => {
                    toast.addToast(
                        {
                            title: 'Warning',
                            description: 'This is a warning toast component',
                            type: 'warning'
                        },
                        {
                            position: 'bottom'
                        }
                    );
                }}
            />
            <Button
                label="Critical"
                onPress={() => {
                    toast.addToast({
                        title: 'Critical',
                        description: 'This is a critical toast component',
                        type: 'critical'
                    });
                }}
            />
            <Button
                label="Informational"
                onPress={() => {
                    toast.addToast({
                        title: 'Informational',
                        description: 'This is an informational toast component',
                        type: 'info'
                    });
                }}
            />
        </div>
    );
};
