import React, { SVGProps } from "react";


export const Required = (props: SVGProps<SVGAElement>) => (
  <svg
    width="8"
    height="16"
    viewBox="0 0 14 18"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <title>RequiredMark</title>
    <path
      d="M7.38 7.06L5.1 5.4L5.42 8.2H3.66L3.98 5.34L1.66 7.06L0.78 5.54L3.4 4.4L0.78 3.26L1.66 1.74L3.96 3.42L3.64 0.599999H5.4L5.08 3.44L7.38 1.74L8.26 3.26L5.64 4.4L8.26 5.54L7.38 7.06Z"
      fill="#DA020F"
    />
  </svg>
);
