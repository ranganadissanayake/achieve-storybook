import React,{ SVGProps } from "react";


export const Info = (props: SVGProps<SVGSVGElement>) => (
  <svg
    width={20}
    height={20}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    data-testid="info-icon"
    {...props}
  >
    <path
      d="M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28Zm0 27a13 13 0 1 1 13-13 13.015 13.015 0 0 1-13 13Z"
      fill="#2A2A2A"
    />
    <path
      d="M16 8.993a1 1 0 1 0 0 2 1 1 0 0 0 0-2Zm-.005 3.984a.5.5 0 0 0-.5.5l-.002 9.01a.5.5 0 0 0 1 0l.002-9.01a.5.5 0 0 0-.5-.5Z"
      fill="#2A2A2A"
    />
  </svg>
);
