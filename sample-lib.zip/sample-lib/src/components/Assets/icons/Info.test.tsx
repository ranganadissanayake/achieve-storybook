import React from "react";
import { render, screen } from "@testing-library/react";

import { Info } from "./Info";

describe("Info", () => {
    test("renders the Info component", () => {
        render(<Info />);
        expect(screen.getByTestId("info-icon")).toBeInTheDocument();
    });

});