import React from 'react';

import { render } from '@testing-library/react';

import { Required } from './Required';

describe('Required', () => {
    it('renders the SVG component', () => {
        render(<Required />);
        const svgElement = document.querySelector('svg');
        expect(svgElement).toBeInTheDocument();
    });
});
