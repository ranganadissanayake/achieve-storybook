import React from 'react';

import UK from '../../Assets/flags/UK.png';
import Belgium from '../../Assets/flags/Belgium.png';
import Denmark from '../../Assets/flags/Denmark.png';
import Euro from '../../Assets/flags/Euro.png';
import France from '../../Assets/flags/France.png';
import Finland from '../../Assets/flags/Finland.png';
import Germany from '../../Assets/flags/Germany.png';
import Italy from '../../Assets/flags/Italy.png';
import Switzerland from '../../Assets/flags/Switzerland.png';
import Sweden from '../../Assets/flags/Sweden.png';
import Romania from '../../Assets/flags/Romania.png';
import Poland from '../../Assets/flags/Poland.png';
import Norway from '../../Assets/flags/Norway.png';
import Netherland from '../../Assets/flags/Netherland.png';
import Ireland from '../../Assets/flags/Ireland.png';
import Brazil from '../../Assets/flags/Brazil.png';
import Canada from '../../Assets/flags/Canada.png';
import Mexico from '../../Assets/flags/Mexico.png';
import USA from '../../Assets/flags/USA.png';
import Australia from '../../Assets/flags/Australia.png';
import HongKong from '../../Assets/flags/HongKong.png';
import Austria from '../../Assets/flags/Austria.png';
import CzechRepublic from '../../Assets/flags/Czech_Republic.png';
import Spain from '../../Assets/flags/Spain.png';
import UAE from '../../Assets/flags/UAE.png';
import Portugal from '../../Assets/flags/Portugal.png';
import Argentina from '../../Assets/flags/Argentina.png';
import China from '../../Assets/flags/China.png';
import Columbia from '../../Assets/flags/Columbia.png';
import Greece from '../../Assets/flags/Greece.png';
import Hungary from '../../Assets/flags/Hungary.png';
import India from '../../Assets/flags/India.png';
import Indonesia from '../../Assets/flags/Indonesia.png';
import Japan from '../../Assets/flags/Japan.png';
import Korea from '../../Assets/flags/Korea.png';
import Luxembourg from '../../Assets/flags/Luxembourg.png';
import Malaysia from '../../Assets/flags/Malaysia.png';
import NewZealand from '../../Assets/flags/NewZealand.png';
import Phillippines from '../../Assets/flags/Phillipines.png';
import Russia from '../../Assets/flags/Russia.png';
import Singapore from '../../Assets/flags/Singapore.png';
import SouthAfrica from '../../Assets/flags/SouthAfrica.png';
import Taiwan from '../../Assets/flags/Taiwan.png';
import Thailand from '../../Assets/flags/Thailand.png';
import Turkey from '../../Assets/flags/Turkish.png';
import './Flag.scss';

export type Country =
    | 'UK'
    | 'BE'
    | 'DN'
    | 'Euro'
    | 'FR'
    | 'FI'
    | 'DE'
    | 'IT'
    | 'CH'
    | 'SW'
    | 'RO'
    | 'PL'
    | 'NO'
    | 'NL'
    | 'IE'
    | 'BR'
    | 'CA'
    | 'MX'
    | 'US'
    | 'AU'
    | 'HK'
    | 'AT'
    | 'PT'
    | 'CZ'
    | 'ES'
    | 'UAE'
    | 'ARG'
    | 'CN'
    | 'CO'
    | 'GR'
    | 'HG'
    | 'IN'
    | 'ID'
    | 'JP'
    | 'KR'
    | 'LX'
    | 'MA'
    | 'NZ'
    | 'PH'
    | 'RU'
    | 'SG'   
    | 'SA'
    | 'TW'
    | 'TH'
    | 'TUR';

export interface FlagProps {
    countryISOCode: Country;
    size?: 'sm' | 'md' | 'lg';
    showName?: boolean;
    nameGap?: 'ty' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl';
    className?: string;
}

const Flag: React.FC<FlagProps> = ({
    countryISOCode,
    size = 'md',
    showName = false,
    className = '',
    nameGap = 'md'
}) => {
    let args;

    switch (countryISOCode) {
        case 'UK':
            args = { src: UK };
            break;
        case 'BE':
            args = { src: Belgium };
            break;
        case 'DN':
            args = { src: Denmark };
            break;
        case 'Euro':
            args = { src: Euro };
            break;
        case 'FR':
            args = { src: France };
            break;
        case 'FI':
            args = { src: Finland };
            break;
        case 'DE':
            args = { src: Germany };
            break;
        case 'IT':
            args = { src: Italy };
            break;
        case 'CH':
            args = { src: Switzerland };
            break;
        case 'SW':
            args = { src: Sweden };
            break;
        case 'RO':
            args = { src: Romania };
            break;
        case 'PL':
            args = { src: Poland };
            break;
        case 'NO':
            args = { src: Norway };
            break;
        case 'NL':
            args = { src: Netherland };
            break;
        case 'IE':
            args = { src: Ireland };
            break;
        case 'BR':
            args = { src: Brazil };
            break;
        case 'CA':
            args = { src: Canada };
            break;
        case 'MX':
            args = { src: Mexico };
            break;
        case 'US':
            args = { src: USA };
            break;
        case 'AU':
            args = { src: Australia };
            break;
        case 'HK':
            args = { src: HongKong };
            break;
        case 'AT':
            args = { src: Austria };
            break;
        case 'CZ':
            args = { src: CzechRepublic };
            break;
        case 'ES':
            args = { src: Spain };
            break;
        case 'UAE':
            args = { src: UAE };
            break;
        case 'PT':
            args = { src: Portugal };
            break;
        case 'ARG':
            args = { src: Argentina };
            break;
        case 'CN':
            args = { src: China };
            break;
        case 'CO':
            args = { src: Columbia };
            break;
        case 'GR':
            args = { src: Greece };
            break;
        case 'HG':
            args = { src: Hungary };
            break;
        case 'IN':
            args = { src: India };
            break;
        case 'ID':
            args = { src: Indonesia };
            break;
        case 'JP':
            args = { src: Japan };
            break;
        case 'KR':
            args = { src: Korea };
            break;
        case 'LX':
            args = { src: Luxembourg };
            break;
        case 'MA':
            args = { src: Malaysia };
            break;
        case 'NZ':
            args = { src: NewZealand };
            break;
        case 'PH':
            args = { src: Phillippines };
            break;
        case 'RU':
            args = { src: Russia };
            break;
        case 'SG':
            args = { src: Singapore };
            break;
        case 'SA':
            args = { src: SouthAfrica };
            break;
        case 'TW':
            args = { src: Taiwan };
            break;
        case 'TH':
            args = { src: Thailand };
            break;
        case 'TUR':
            args = { src: Turkey };
            break;
        default:
            args = { src: UK };
    }

    const CountryFlag = (
        <img
            {...args}
            data-testid="flag"
            alt={countryISOCode}
            className={`flag ${size} ${className}`}
        />
    );

    return showName ? (
        <span className={`flag-container name_gap_${nameGap}`}>
            {CountryFlag}
            <span className={`country ${size} ${className}`}>{countryISOCode}</span>
        </span>
    ) : (
        CountryFlag
    );
};

export default Flag;
