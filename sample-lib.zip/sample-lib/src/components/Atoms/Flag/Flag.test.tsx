import React from "react";
import { render, screen } from "@testing-library/react";

import Flag from "./index";

describe("Flag", () => {
  test("renders the Flag component", () => {
    render(<Flag countryISOCode="CA" />);

    expect(screen.getByTestId("flag")).toBeInTheDocument();
  });
  test("add sm class to small size flag", () => {
    render(<Flag countryISOCode="CA" size="sm" />);

    expect(screen.getByTestId("flag")).toHaveClass("sm");
  });
  test("add md class to medium size flag", () => {
    render(<Flag countryISOCode="CA" size="md" />);

    expect(screen.getByTestId("flag")).toHaveClass("md");
  });
  test("add lg class to large size flag", () => {
    render(<Flag countryISOCode="CA" size="lg" />);

    expect(screen.getByTestId("flag")).toHaveClass("lg");
  });
  test("add the correct alt attribute", () => {
    render(<Flag countryISOCode="CA" size="lg" />);

    expect(screen.getByTestId("flag")).toHaveAttribute("alt", "CA");
  });
  test("display name of countryISOCode", () => {
    render(<Flag countryISOCode="CA" showName />);
    expect(screen.getByText("CA")).toBeInTheDocument();
  });

  test("display name of countryISOCode UK", () => {
    render(<Flag countryISOCode="UK" showName />);
    expect(screen.getByText("UK")).toBeInTheDocument();
  });

  test("display name of countryISOCode BE", () => {
    render(<Flag countryISOCode="BE" showName />);
    expect(screen.getByText("BE")).toBeInTheDocument();
  });

  test("display name of countryISOCode DN", () => {
    render(<Flag countryISOCode="DN" showName />);
    expect(screen.getByText("DN")).toBeInTheDocument();
  });

  test("display name of countryISOCode DN", () => {
    render(<Flag countryISOCode="DN" showName />);
    expect(screen.getByText("DN")).toBeInTheDocument();
  });

  test("display name of countryISOCode Euro", () => {
    render(<Flag countryISOCode="Euro" showName />);
    expect(screen.getByText("Euro")).toBeInTheDocument();
  });

  test("display name of countryISOCode FR", () => {
    render(<Flag countryISOCode="FR" showName />);
    expect(screen.getByText("FR")).toBeInTheDocument();
  });

  test("display name of countryISOCode FI", () => {
    render(<Flag countryISOCode="FI" showName />);
    expect(screen.getByText("FI")).toBeInTheDocument();
  });

  test("display name of countryISOCode DE", () => {
    render(<Flag countryISOCode="DE" showName />);
    expect(screen.getByText("DE")).toBeInTheDocument();
  });

  test("display name of countryISOCode IT", () => {
    render(<Flag countryISOCode="IT" showName />);
    expect(screen.getByText("IT")).toBeInTheDocument();
  });

  test("display name of countryISOCode CH", () => {
    render(<Flag countryISOCode="CH" showName />);
    expect(screen.getByText("CH")).toBeInTheDocument();
  });

  test("display name of countryISOCode SW", () => {
    render(<Flag countryISOCode="SW" showName />);
    expect(screen.getByText("SW")).toBeInTheDocument();
  });

  test("display name of countryISOCode RO", () => {
    render(<Flag countryISOCode="RO" showName />);
    expect(screen.getByText("RO")).toBeInTheDocument();
  });

  test("display name of countryISOCode PL", () => {
    render(<Flag countryISOCode="PL" showName />);
    expect(screen.getByText("PL")).toBeInTheDocument();
  });


  test("display name of countryISOCode NO", () => {
    render(<Flag countryISOCode="NO" showName />);
    expect(screen.getByText("NO")).toBeInTheDocument();
  });

  test("display name of countryISOCode NL", () => {
    render(<Flag countryISOCode="NL" showName />);
    expect(screen.getByText("NL")).toBeInTheDocument();
  });

  test("display name of countryISOCode IE", () => {
    render(<Flag countryISOCode="IE" showName />);
    expect(screen.getByText("IE")).toBeInTheDocument();
  });

  test("display name of countryISOCode BR", () => {
    render(<Flag countryISOCode="BR" showName />);
    expect(screen.getByText("BR")).toBeInTheDocument();
  });

  test("display name of countryISOCode MX", () => {
    render(<Flag countryISOCode="MX" showName />);
    expect(screen.getByText("MX")).toBeInTheDocument();
  });


  test("display name of countryISOCode US", () => {
    render(<Flag countryISOCode="US" showName />);
    expect(screen.getByText("US")).toBeInTheDocument();
  });

  test("display name of countryISOCode Australia", () => {
    render(<Flag countryISOCode="AU" showName />);
    expect(screen.getByText("AU")).toBeInTheDocument();
  });

  test("display name of countryISOCode HongKong", () => {
    render(<Flag countryISOCode="HK" showName />);
    expect(screen.getByText("HK")).toBeInTheDocument();
  });
  test("display name of countryISOCode Austria", () => {
    render(<Flag countryISOCode="AT" showName />);
    expect(screen.getByText("AT")).toBeInTheDocument();
  });
  test("display name of countryISOCode Spain", () => {
    render(<Flag countryISOCode="ES" showName />);
    expect(screen.getByText("ES")).toBeInTheDocument();
  });
  test("display name of countryISOCode UAE", () => {
    render(<Flag countryISOCode="UAE" showName />);
    expect(screen.getByText("UAE")).toBeInTheDocument();
  });
  test("display name of countryISOCode Portugal", () => {
    render(<Flag countryISOCode="PT" showName />);
    expect(screen.getByText("PT")).toBeInTheDocument();
  });
  test("display name of countryISOCode Czech Republic", () => {
    render(<Flag countryISOCode="CZ" showName />);
    expect(screen.getByText("CZ")).toBeInTheDocument();
  });
  test("display name of countryISOCode Argentina", () => {
    render(<Flag countryISOCode="ARG" showName />);
    expect(screen.getByText("ARG")).toBeInTheDocument();
  });
  test("display name of countryISOCode China", () => {
    render(<Flag countryISOCode="CN" showName />);
    expect(screen.getByText("CN")).toBeInTheDocument();
  });
  test("display name of countryISOCode Columbia", () => {
    render(<Flag countryISOCode="CO" showName />);
    expect(screen.getByText("CO")).toBeInTheDocument();
  });
  test("display name of countryISOCode Greece", () => {
    render(<Flag countryISOCode="GR" showName />);
    expect(screen.getByText("GR")).toBeInTheDocument();
  });
  test("display name of countryISOCode Hungary", () => {
    render(<Flag countryISOCode="HG" showName />);
    expect(screen.getByText("HG")).toBeInTheDocument();
  });
  test("display name of countryISOCode India", () => {
    render(<Flag countryISOCode="IN" showName />);
    expect(screen.getByText("IN")).toBeInTheDocument();
  });
  test("display name of countryISOCode Indonesia", () => {
    render(<Flag countryISOCode="ID" showName />);
    expect(screen.getByText("ID")).toBeInTheDocument();
  });
  test("display name of countryISOCode Japan", () => {
    render(<Flag countryISOCode="JP" showName />);
    expect(screen.getByText("JP")).toBeInTheDocument();
  });
  test("display name of countryISOCode Korea", () => {
    render(<Flag countryISOCode="KR" showName />);
    expect(screen.getByText("KR")).toBeInTheDocument();
  });
  test("display name of countryISOCode Luxembourg", () => {
    render(<Flag countryISOCode="LX" showName />);
    expect(screen.getByText("LX")).toBeInTheDocument();
  });
  test("display name of countryISOCode Malaysia", () => {
    render(<Flag countryISOCode="MA" showName />);
    expect(screen.getByText("MA")).toBeInTheDocument();
  });
  test("display name of countryISOCode NewZealand", () => {
    render(<Flag countryISOCode="HG" showName />);
    expect(screen.getByText("HG")).toBeInTheDocument();
  });
  test("display name of countryISOCode Phillippines", () => {
    render(<Flag countryISOCode="PH" showName />);
    expect(screen.getByText("PH")).toBeInTheDocument();
  });
  test("display name of countryISOCode Russia", () => {
    render(<Flag countryISOCode="RU" showName />);
    expect(screen.getByText("RU")).toBeInTheDocument();
  });
  test("display name of countryISOCode Singapore", () => {
    render(<Flag countryISOCode="SG" showName />);
    expect(screen.getByText("SG")).toBeInTheDocument();
  });
  test("display name of countryISOCode SouthAfrica", () => {
    render(<Flag countryISOCode="SA" showName />);
    expect(screen.getByText("SA")).toBeInTheDocument();
  });
  test("display name of countryISOCode Taiwan", () => {
    render(<Flag countryISOCode="TW" showName />);
    expect(screen.getByText("TW")).toBeInTheDocument();
  });
  test("display name of countryISOCode Thailand", () => {
    render(<Flag countryISOCode="TH" showName />);
    expect(screen.getByText("TH")).toBeInTheDocument();
  });
  test("display name of countryISOCode Turkey", () => {
    render(<Flag countryISOCode="TUR" showName />);
    expect(screen.getByText("TUR")).toBeInTheDocument();
  });
});
