import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Flag from "./index";

export const DefaultStory = () => <Flag country="UK" />;

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Atoms/Flag",
  component: Flag,
} as ComponentMeta<typeof Flag>;

const Template: ComponentStory<typeof Flag> = (args) => <Flag {...args} />;

export const Playground = Template.bind({});
Playground.args = {
  country: "Belgium",
  size: "lg",
};
