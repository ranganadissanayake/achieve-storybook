import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import Card from '.';
import Button from '../../Molecules/Button';
import Label from '../Label';
import { Divider, Input } from '../..';

//children component for default
const DefaultChildrenComponent: React.FC = () => {
    return (
        <div>
            <Label text="Hello World!"></Label>
        </div>
    );
};

export const DefaultStory = () => (
    <Card>
        <DefaultChildrenComponent />
    </Card>
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Atoms/Card',
    component: Card
} as ComponentMeta<typeof Card>;

//children component for playground
const PlayGroundChildrenComponent: React.FC = () => (
    <div>
        <Label text="Hello World!"></Label>
        <Divider margin="lg"></Divider>
        <Input iconName="education" name="name" required />
        <Divider margin="lg"></Divider>
        <Button label="Create" variant="gradient"></Button>
    </div>
);
const Template: ComponentStory<typeof Card> = (args) => (
    <Card {...args}>
        <PlayGroundChildrenComponent />
    </Card>
);

export const Playground = Template.bind({});

Playground.args = {
    width: '400px',
    height: 'auto'
};
