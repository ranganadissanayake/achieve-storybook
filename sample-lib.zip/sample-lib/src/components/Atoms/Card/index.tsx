import React from 'react';
import './Card.scss';

export interface CardProps {
    /**Add custom height px/rem etc...*/
    height?: string;
    /**Add custom width px/rem etc...*/
    width?: string;
    /**Add custom styles*/
    cardStyle?: string;
    /**on click functionality*/
    onClick?: (d?: any) => void;
}

export const Card: React.FC<React.PropsWithChildren<CardProps>> = ({
    children,
    height,
    width,
    cardStyle,
    onClick
}) => {
    return (
        <div style={{ height, width }} className={`card ${cardStyle}`} data-testid="card" onClick={onClick}>
            <div data-testid="card-content" className="card-content">
                {children}
            </div>
        </div>
    );
};

export default Card;
