import React from 'react';
import { render, screen } from '@testing-library/react';

import Card from './index';

describe('Card', () => {
    test('not renders the Card component with empty react component', () => {
        render(<Card />);
        expect(screen.getByTestId('card')).not.toHaveClass('card-content');
    });

    test('renders the Card component with props', () => {
        render(<Card />);
        expect(screen.getByTestId('card-content')).toBeInTheDocument();
    });
});
