import classNames from 'classnames';
import React from 'react';
import Label from '../Label';

import './Toggle.scss';

export interface ToggleProps {
    checked?: boolean;
    size?: 'lg' | 'md' | 'sm';
    showText?: boolean;
    disabled?: boolean;
    success?: boolean;
    label?: string;
    checkedTitle?: string;
    unCheckedTitle?: string;
    dataTestId?: string;
    onChange?: (value: boolean) => void;
}

const Toggle: React.FC<ToggleProps> = ({
    label,
    checked = false,
    size = 'md',
    showText = true,
    disabled = false,
    success = false,
    checkedTitle = 'Yes',
    unCheckedTitle = 'No',
    dataTestId = "toggle-slidder",
    onChange
}) => {
    const [_isChecked, setIsChecked] = React.useState<boolean>();

    React.useEffect(() => {
        if (!success) {
            setIsChecked(checked);
        }
    }, [checked, success]);

    React.useEffect(() => {
        if (success) {
            setIsChecked(true);
        }
    }, [success]);

    return (
        <div data-testid="toggle" className="toggle_container">
            <label data-testid="toggle-label" className={`switch ${size}`}>
                <input
                    type="checkbox"
                    checked={_isChecked}
                    disabled={disabled}
                    data-testid="input-check"
                    onChange={() => {
                        if (!success) {
                            setIsChecked((prev) => {
                                if (onChange) {
                                    onChange(!prev);
                                }
                                return !prev;
                            });
                        }
                    }}
                />
                <span
                    data-testid={dataTestId}
                    className={classNames('slider', {
                        disabled,
                        success
                    })}
                >
                    <span className={'ball'}></span>
                    <span className={'text'}>
                        {size !== 'sm' && showText && (_isChecked ? checkedTitle : unCheckedTitle)}
                    </span>
                </span>
            </label>
            {label && <Label text={label} size="sm" />}
        </div>
    );
};

export default Toggle;
