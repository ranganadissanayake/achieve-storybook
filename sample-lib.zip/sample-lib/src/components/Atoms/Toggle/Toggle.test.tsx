import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";

import Toggle from "./index";

describe("Toggle", () => {
  test("renders the Toggle component", () => {
    render(<Toggle />);

    expect(screen.getByTestId("toggle")).toBeInTheDocument();
  });
  test("add small class for small size toggle", () => {
    render(<Toggle size="sm" />);

    expect(screen.getByTestId("toggle-label")).toHaveClass("sm");
  });
  test("add large class for large size toggle", () => {
    render(<Toggle size="lg" />);

    expect(screen.getByTestId("toggle-label")).toHaveClass("lg");
  });
  test("add label for labelled toggle", () => {
    render(<Toggle label="Toggle Label" />);

    expect(screen.getByText("Toggle Label")).toBeInTheDocument();
  });
  test("add disabled class to disabled toggle", () => {
    render(<Toggle disabled />);

    expect(screen.getByTestId("toggle-slidder")).toHaveClass("disabled");
  });
  test("add success class to success toggle", () => {
    render(<Toggle success />);

    expect(screen.getByTestId("toggle-slidder")).toHaveClass("success");
  });
  test("add 'No' to large size unchecked toggle'", () => {
    render(<Toggle size="lg" />);

    expect(screen.getByText("No")).toBeInTheDocument();
  });
  test("add 'Yes' to large size checked toggle'", () => {
    render(<Toggle size="lg" checked />);

    expect(screen.getByText("Yes")).toBeInTheDocument();
  });

  test("Should change status of the check box", () => {
    const onChange = jest.fn();
    render(<Toggle size="lg" checked onChange={onChange}/>);
    fireEvent(screen.getByTestId("toggle-slidder"),
      new MouseEvent('click', {
        bubbles: true,
        cancelable: true,
      }));
    expect(screen.getByText("No")).toBeInTheDocument();
    expect(onChange).toHaveBeenCalled();
  });
});
