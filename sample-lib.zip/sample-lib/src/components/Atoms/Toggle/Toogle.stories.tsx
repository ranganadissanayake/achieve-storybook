import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Toggle from "./index";

export const DefaultStory = () => <Toggle />;

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Atoms/Toggle",
  component: Toggle,
} as ComponentMeta<typeof Toggle>;

const Template: ComponentStory<typeof Toggle> = (args) => <Toggle {...args} />;

export const Playground = Template.bind({});

Playground.args = {
  label: "Playground",
};
