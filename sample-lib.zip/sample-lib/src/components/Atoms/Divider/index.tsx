import React from 'react';

import './Divider.scss';

export interface DividerProps {
    style?: 'default' | 'desktop' | 'tablet_landscape' | 'tablet_portrait' | 'mobile';
    width?: 'full' | 'half' | 'third' | 'quart';
    margin?: 'none' | 'ty' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl';
    align?: 'left' | 'center' | 'right';
    orientation?: 'vertical' | 'horizontal';
    className?: string;
}

const Divider: React.FC<DividerProps> = ({
    width = 'full',
    style = 'default',
    margin = 'md',
    align = 'center',
    orientation = 'horizontal',
    className = ''
}) => {
    let mappedAlign;
    if(align==='left'){
     mappedAlign='align-left';
    }else if(align==='right'){
        mappedAlign='align-right';
    }else{
        mappedAlign='center';
    }
    return orientation === 'horizontal' ? (
        <hr
            data-testid="divider"
            className={`divider ${width} ${style} margin_${margin} ${mappedAlign} ${className}`}
        />
    ) : (
        <span
            data-testid="vertical"
            className={`divider vertical margin_${margin} ${mappedAlign} ${className}`}
        ></span>
    );
};

export default Divider;
