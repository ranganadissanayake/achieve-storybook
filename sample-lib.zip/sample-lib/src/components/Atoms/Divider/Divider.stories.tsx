import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Divider from './index';

export const DefaultStory = () => <Divider />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Atoms/Divider',
    component: Divider,
    decorators: [
        (story, options) => {
            return options.args.orientation && options.args.orientation === 'vertical' ? (
                <div style={{ height: '20px', display: 'flex', alignItems: 'center' }}>
                    <div>Content Above</div>
                    {story()}
                    <div>Content Below</div>
                </div>
            ) : (
                <div>
                    <div style={{ textAlign: 'center' }}>Content Above</div>
                    {story()}
                    <div style={{ textAlign: 'center' }}>Content Below</div>
                </div>
            );
        }
    ]
} as ComponentMeta<typeof Divider>;

const Template: ComponentStory<typeof Divider> = (args) => <Divider {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    margin: 'sm',
    style: 'mobile'
};
