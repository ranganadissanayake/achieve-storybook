import React from 'react';
import { render, screen } from '@testing-library/react';

import Divider from './index';

describe('Divider', () => {
    test('renders the Divider component', () => {
        render(<Divider />);
        expect(screen.getByTestId('divider')).toBeInTheDocument();
    });
    test('add class default to default style divider', () => {
        render(<Divider />);
        expect(screen.getByTestId('divider')).toHaveClass('default');
    });
    test('add class desktop to desktop style divider', () => {
        render(<Divider style="desktop" />);
        expect(screen.getByTestId('divider')).toHaveClass('desktop');
    });
    test('add class tablet_landscape to tablet_landscape style divider', () => {
        render(<Divider style="tablet_landscape" />);
        expect(screen.getByTestId('divider')).toHaveClass('tablet_landscape');
    });
    test('add class tablet_portrait to tablet_portrait style divider', () => {
        render(<Divider style="tablet_portrait" />);
        expect(screen.getByTestId('divider')).toHaveClass('tablet_portrait');
    });
    test('add class mobile to mobile style divider', () => {
        render(<Divider style="mobile" />);
        expect(screen.getByTestId('divider')).toHaveClass('mobile');
    });
    test('add class full to full width divider', () => {
        render(<Divider width="full" />);
        expect(screen.getByTestId('divider')).toHaveClass('full');
    });
    test('add class half to half width divider', () => {
        render(<Divider width="half" />);
        expect(screen.getByTestId('divider')).toHaveClass('half');
    });
    test('add class third to third width divider', () => {
        render(<Divider width="third" />);
        expect(screen.getByTestId('divider')).toHaveClass('third');
    });
    test('add class quart to a quarter width divider', () => {
        render(<Divider width="quart" />);
        expect(screen.getByTestId('divider')).toHaveClass('quart');
    });
    test('add class margin_none to a divider with no margin', () => {
        render(<Divider margin="none" />);
        expect(screen.getByTestId('divider')).toHaveClass('margin_none');
    });
    test('add class margin_ty to a divider with tiny margin', () => {
        render(<Divider margin="ty" />);
        expect(screen.getByTestId('divider')).toHaveClass('margin_ty');
    });
    test('add class margin_sm to a divider with small margin', () => {
        render(<Divider margin="sm" />);
        expect(screen.getByTestId('divider')).toHaveClass('margin_sm');
    });
    test('add class margin_md to a divider with medium margin', () => {
        render(<Divider margin="md" />);
        expect(screen.getByTestId('divider')).toHaveClass('margin_md');
    });
    test('add class margin_lg to a divider with large margin', () => {
        render(<Divider margin="lg" />);
        expect(screen.getByTestId('divider')).toHaveClass('margin_lg');
    });
    test('add class margin_xl to a divider with extra large margin', () => {
        render(<Divider margin="xl" />);
        expect(screen.getByTestId('divider')).toHaveClass('margin_xl');
    });
    test('add class margin_xxl to a divider with extra extra large margin', () => {
        render(<Divider margin="xxl" />);
        expect(screen.getByTestId('divider')).toHaveClass('margin_xxl');
    });
    test('add class left to left aligned divider ', () => {
        render(<Divider align="left" />);
        expect(screen.getByTestId('divider')).toHaveClass('align-left');
    });
    test('add class center to center aligned divider', () => {
        render(<Divider align="center" />);
        expect(screen.getByTestId('divider')).toHaveClass('center');
    });
    test('add class right to right aligned divider', () => {
        render(<Divider align="right" />);
        expect(screen.getByTestId('divider')).toHaveClass('align-right');
    });
    test('add class vertical to vertical orientation divider ', () => {
        render(<Divider orientation="vertical" />);
        expect(screen.getByTestId('vertical')).toHaveClass('vertical');
    });
});
