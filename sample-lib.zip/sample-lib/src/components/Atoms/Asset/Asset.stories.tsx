import React from 'react';
import { ComponentStory, ComponentMeta } from "@storybook/react";
import Asset, { AssetProps } from './index';


export const DefaultStory = ()=><Asset asset='ad' assetCategory='flags' size="sm"/>

DefaultStory.storyName = "Default";

export default {
    title: "ReactComponentLibrary/Atoms/Asset",
    component: Asset,
} as ComponentMeta<typeof Asset>;
