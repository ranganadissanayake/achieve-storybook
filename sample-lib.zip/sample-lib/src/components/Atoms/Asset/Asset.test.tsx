import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import Asset from './index';

describe('Asset component', () => {
  const mockRequireContext = (images) => {
    const keys = () => Object.keys(images);
    const context = (key) => images[key];
    context.keys = keys;
    return context;
  };
  
  const mockFlags = {
    './us.svg': 'us_image',
    './gb.svg': 'gb_image',
  };
  
  const mockProviders = {
    './equinix.svg': 'equinix_image',
  };
  
  jest.mock('webpack', () => ({
    default: {
      require: {
        context: jest.fn((file) => {
          if (file.includes('flags')) return mockRequireContext(mockFlags);
          if (file.includes('providers')) return mockRequireContext(mockProviders);
        }),
      },
    },
  }));

  it('renders image', () => {
    const { queryByTestId } = render(
      <Asset
        src="../../Assets/icons/img/alert.png"
      />
    );
    const nameElement = queryByTestId('name');
    expect(nameElement).toBeNull();
  });

  it('applies custom className', () => {
    const { container } = render(
      <Asset
        src="../../Assets/icons/img/alert.png"
        className="custom-className"
      />
    );
    expect(container.querySelector('img')).toBeInTheDocument();
  });

  it('applies custom asset', () => {
    const { container } = render(
      <Asset
        asset='gb'
        className="custom-className"
      />
    );
    expect(container.querySelector('img')).toBeInTheDocument();
  });

  it('uses assetCategory of flags', () => {
    const { container } = render(
      <Asset
        asset='gb'
        className="custom-className"
        assetCategory='flags'
      />
    );
    expect(container.querySelector('img')).toBeInTheDocument();
  });

  it('uses assetCategory of provider', () => {
    const { container } = render(
      <Asset
        asset='equinix'
        className="custom-className"
        assetCategory='flags'
      />
    );
    expect(container.querySelector('img')).toBeInTheDocument();
  });

  it('renders an image from flags', async() => {
    render(<Asset asset="us" assetCategory="flags" />);
    await waitFor(()=>{
      const image = screen.getByTestId('asset-img');
      expect(image).not.toHaveAttribute('src', '');
    })
  });

  it('renders an image from providers', async() => {
    render(<Asset asset="equinix" assetCategory="providers" />);
    await waitFor(()=>{
      const image = screen.getByTestId('asset-img');
      expect(image).not.toHaveAttribute('src', '');
    })
  });

  it('renders an image with the default src flags', async() => {
    render(<Asset asset="test" assetCategory="flags" />);
    await waitFor(()=>{
      const image = screen.getByTestId('asset-img');
      expect(image).not.toHaveAttribute('src', '');
    })
  });

  it('renders an image with the default src providers', async() => {
    render(<Asset asset="test" assetCategory="providers" />);
    await waitFor(()=>{
      const image = screen.getByTestId('asset-img');
      expect(image).not.toHaveAttribute('src', '');
    })
  });

  it('renders an image with the given src prop', () => {
    const testSrc = 'test_image';
    render(<Asset src={testSrc} />);
    const image = screen.getByTestId('asset-img');
    expect(image).toHaveAttribute('src', testSrc);
  });

});
