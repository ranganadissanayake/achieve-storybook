import React, { useState, useEffect } from 'react';
import './Asset.scss';
export interface AssetProps {
    src?: string;
    asset?: string;
    size?: 'sm' | 'md' | 'lg';
    className?: string;
    assetCategory?: 'flags' | 'providers' | 'facility';
    assetMap?: {};
    onClick?: ()=>void;

}

const Asset: React.FC<AssetProps> = ({
    src,
    asset,
    size = 'md',
    className = '',
    assetCategory = 'flags',
    assetMap = {},
}) => {
    const [assetSrc, setAssetSrc] = useState<string | null>(null);

    useEffect(() => {
        const loadAsset = () => {
            if (assetCategory === 'flags') {
                assetMap[asset.toLowerCase()]
                    ? setAssetSrc(assetMap[asset.toLowerCase()])
                    : setAssetSrc(assetMap['gb']);
            }
            else if (assetCategory === 'providers' || assetCategory === 'facility') {
                assetMap[asset.toLowerCase()]
                    ? setAssetSrc(assetMap[asset.toLowerCase()])
                    : setAssetSrc(assetMap['equinix']);
            }
        }
        if (asset) {
            loadAsset();
        }
    }, [asset, assetCategory]);

    return (
        <>
            <img
                src={assetSrc || src}
                alt={asset || ''}
                data-testid="asset-img"
                className={`asset ${size} ${className} ${assetCategory === 'providers' || assetCategory === 'facility' ? 'provider' : ""}`}
            />
        </>
    );
};

export default Asset;



