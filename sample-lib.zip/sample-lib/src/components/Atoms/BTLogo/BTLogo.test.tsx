import React from "react";
import { render, screen } from "@testing-library/react";

import BTLogo from "./index";

describe("BTLogo", () => {
  test("renders the BTLogo component", () => {
    render(<BTLogo />);
    expect(screen.getByTestId("bt_logo")).toBeInTheDocument();
  });

  test("display the text BT in the logo", () => {
    render(<BTLogo />);
    expect(screen.getByText("BT")).toBeInTheDocument();
  });

  test("add default class to default color logo", () => {
    render(<BTLogo color="default" />);
    expect(screen.getByTestId("bt_logo")).toHaveClass("default");
  });

  test("add brand class to brand color logo", () => {
    render(<BTLogo color="brand" />);
    expect(screen.getByTestId("bt_logo")).toHaveClass("brand");
  });

  test("add bt_logo_ty class to tiny size logo", () => {
    render(<BTLogo size="ty" />);
    expect(screen.getByTestId("bt_logo")).toHaveClass("bt_logo_ty");
  });

  test("add bt_logo_sm class to small size logo", () => {
    render(<BTLogo size="sm" />);
    expect(screen.getByTestId("bt_logo")).toHaveClass("bt_logo_sm");
  });

  test("add bt_logo_md class to medium size logo", () => {
    render(<BTLogo size="md" />);
    expect(screen.getByTestId("bt_logo")).toHaveClass("bt_logo_md");
  });

  test("add bt_logo_lg class to large size logo", () => {
    render(<BTLogo size="lg" />);
    expect(screen.getByTestId("bt_logo")).toHaveClass("bt_logo_lg");
  });

  test("add bt_logo_xl class to extra large size logo", () => {
    render(<BTLogo size="xl" />);
    expect(screen.getByTestId("bt_logo")).toHaveClass("bt_logo_xl");
  });

  test("add bt_logo_xxl class to extra extra large size logo", () => {
    render(<BTLogo size="xxl" />);
    expect(screen.getByTestId("bt_logo")).toHaveClass("bt_logo_xxl");
  });

  test("display label text", () => {
    render(<BTLogo label="Hello BT" />);
    expect(screen.getByText("Hello BT")).toBeInTheDocument();
  });

  test("display subBrand text", () => {
    render(<BTLogo subBrand="REDCARE" />);
    expect(screen.getByText("REDCARE")).toBeInTheDocument();
  });

  test("hide label text when subBrand is present", () => {
    render(<BTLogo subBrand="WHOLESALE" label="Hello BT" />);
    expect(screen.getByText("WHOLESALE")).toBeInTheDocument();
    expect(screen.queryByText("Hello BT")).not.toBeInTheDocument();
  });
});
