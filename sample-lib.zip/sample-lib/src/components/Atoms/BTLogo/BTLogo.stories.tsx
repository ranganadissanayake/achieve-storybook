import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import BTLogo from "./index";

export const DefaultStory = () => <BTLogo />;

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Atoms/BTLogo",
  component: BTLogo,
} as ComponentMeta<typeof BTLogo>;

const Template: ComponentStory<typeof BTLogo> = (args) => <BTLogo {...args} />;

export const Playground = Template.bind({});

Playground.args = {
  color: "brand",
  size: "md",
};
