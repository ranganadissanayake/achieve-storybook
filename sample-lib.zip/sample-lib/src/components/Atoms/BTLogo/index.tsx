import React from 'react';

import './BTLogo.scss';

/**
 * The properties required for the BT Logo Component
 * @author Joel Chi <joel.abongwa@distributed.com>
 */
export interface BTLogoProps {
    /**
     * Defines a color for the Logo
     */
    color?: 'default' | 'brand' | 'inverse';
    /**
     * Defines a size for the logo
     */
    size?: 'ty' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl';
    /**
     * Add a text to go with the logo
     */
    label?: string;
    /**
     * Gap between the logo and the label/subBrand
     */
    labelGap?: 'ty' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl';
    /**
     * Specify a sub brand for the logo
     */
    subBrand?: 'REDCARE' | 'WHOLESALE';
    /**
     * Add a class to customize the style of the logo
     */
    className?: string;
}

/**
 * Renders the BT Logo component
 * @param {React.PropsWithChildren<BTLogoProps>} props BTLogo properties
 * @returns
 */
const BTLogo: React.FC<BTLogoProps> = ({
    color = 'default',
    size = 'md',
    label = '',
    labelGap = 'lg',
    subBrand,
    className = ''
}) => {
    return (
        <span
            className={`bt_logo_container ${color} bt_logo_${size} label_gap_${labelGap} ${className}`}
            data-testid="bt_logo"
        >
            <span className="bt_logo">
                <span className="text">BT</span>
            </span>
            {(subBrand || label !== '') && <label className="label">{subBrand ?? label}</label>}
        </span>
    );
};

export default BTLogo;
