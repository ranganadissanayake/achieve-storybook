import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Label from "./index";

export const DefaultStory = () => <Label text="Label" />;

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Atoms/Label",
  component: Label,
} as ComponentMeta<typeof Label>;

const Template: ComponentStory<typeof Label> = (args) => <Label {...args} />;

export const Playground = Template.bind({});
Playground.args = {
  text: "Label",
  required: true,
  helper: "Helper Text",
};
