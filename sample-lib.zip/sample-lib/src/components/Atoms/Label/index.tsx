import React from 'react';
import classnames from 'classnames';
import { Required } from '../../Assets/icons';

import './Label.scss';

export interface LabelProps {
    text?: string;
    required?: boolean;
    optional?: boolean;
    helper?: string;
    size?: 'lg' | 'md' | 'sm' | 'xs';
    htmlFor?: string;
    labelTextStyles?: string;
    containerStyles?: string;
    helperTextStyles?: string;
    isFontHeadline?: boolean;
}

const Label: React.FC<LabelProps> = ({
    text = '',
    helper = '',
    size = 'lg',
    required = false,
    optional = false,
    htmlFor = '',
    isFontHeadline = true,
    labelTextStyles,
    containerStyles,
    helperTextStyles
}) => {
    return (
        <label
            className={classnames('label-container', { [containerStyles]: containerStyles })}
            htmlFor={htmlFor}
        >
            {text && text !== '' && (
                <span>
                    {required && <Required />}
                    <span
                        className={classnames('label', {
                            'label-small': size === 'sm',
                            'label-medium': size === 'md',
                            'label-x-small': size === 'xs',
                            [labelTextStyles]: labelTextStyles,
                            'font-headline': isFontHeadline,
                            'font-curve': !isFontHeadline
                        })}
                    >
                        {text}
                    </span>
                    {optional && !required && (
                        <span
                            className={classnames('optional', {
                                'optional-small': size === 'sm' || size === 'xs'
                            })}
                        >
                            (optional)
                        </span>
                    )}
                </span>
            )}
            {helper !== '' && (
                <span
                    className={classnames('helper', {
                        'helper-small': size === 'sm',
                        'helper-x-small': size === 'xs',
                        [helperTextStyles]: helperTextStyles
                    })}
                >
                    {helper}
                </span>
            )}
        </label>
    );
};

export default Label;
