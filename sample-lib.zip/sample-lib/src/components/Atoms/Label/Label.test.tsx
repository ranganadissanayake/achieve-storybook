import React from "react";
import { render, screen } from "@testing-library/react";

import Label from "./index";

describe("Label", () => {
  test("renders the Label component", () => {
    render(<Label text="Label" />);

    expect(screen.getByText("Label")).toBeInTheDocument();
  });
  test("renders a required Label component", () => {
    render(<Label text="Label" required />);

    expect(screen.getByText("Label")).toBeInTheDocument();
    expect(screen.getByTitle("RequiredMark")).toBeInTheDocument();
  });
  test("renders the Label component with helper text", () => {
    render(<Label text="Label" helper="Helper Text" />);

    expect(screen.getByText("Label")).toBeInTheDocument();
    expect(screen.getByText("Helper Text")).toBeInTheDocument();
  });
  test("renders a required Label component with helper text", () => {
    render(<Label text="Label" required helper="Helper Text" />);

    expect(screen.getByText("Label")).toBeInTheDocument();
    expect(screen.getByText("Helper Text")).toBeInTheDocument();
    expect(screen.getByTitle("RequiredMark")).toBeInTheDocument();
  });
  test("add medium class for medium size label", () => {
    render(<Label text="Label" size="md" />);

    expect(screen.getByText("Label")).toHaveClass("label-medium");
  });
  test("add small class for small size label", () => {
    render(<Label text="Label" size="sm" />);

    expect(screen.getByText("Label")).toHaveClass("label-small");
  });
  test("add extra small class for extra small size label", () => {
    render(<Label text="Label" size="xs" />);

    expect(screen.getByText("Label")).toHaveClass("label-x-small");
  });
  test("add small class to helper small size label", () => {
    render(<Label text="Label" helper="Helper Text" size="sm" />);

    expect(screen.getByText("Label")).toHaveClass("label-small");
    expect(screen.getByText("Helper Text")).toHaveClass("helper-small");
  });
});
