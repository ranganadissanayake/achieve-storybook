import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

import Badge from './index';

describe('Badge', () => {
    test('renders the Badge component', () => {
        render(<Badge text="Badge" />);

        expect(screen.getByText('Badge')).toBeInTheDocument();
    });
    test('add outline class to outlined badge', () => {
        render(<Badge text="Badge" outline />);

        expect(screen.getByText('Badge')).toHaveClass('outline');
    });
    test('add info class to info badge', () => {
        render(<Badge text="Badge" style="info" />);

        expect(screen.getByText('Badge')).toHaveClass('info');
    });
    test('add critical class to critical badge', () => {
        render(<Badge text="Badge" style="critical" />);

        expect(screen.getByText('Badge')).toHaveClass('critical');
    });
    test('add warning class to warning badge', () => {
        render(<Badge text="Badge" style="warning" />);

        expect(screen.getByText('Badge')).toHaveClass('warning');
    });
    test('add success class to success badge', () => {
        render(<Badge text="Badge" style="success" />);

        expect(screen.getByText('Badge')).toHaveClass('success');
    });
    test('renders the Badge component with close icon', () => {
        const onCloseMock = jest.fn();
        render(<Badge text="Badge" showClose onClose={onCloseMock} />);

        const clearIcon = screen.getByTestId('badge-close-icon');
        expect(screen.getByTestId('badge-close-icon')).toBeInTheDocument();
    });
    test('check close icon action on badge', () => {
        const onCloseMock = jest.fn();
        render(<Badge text="Badge" showClose onClose={onCloseMock} />);

        const clearIcon = screen.getByTestId('badge-close-icon');
        fireEvent.click(clearIcon);
        expect(onCloseMock).toHaveBeenCalledTimes(1);
    });
});
