import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Badge from "./index";

export const DefaultStory = () => <Badge text="BADGE" />;

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Atoms/Badge",
  component: Badge,
} as ComponentMeta<typeof Badge>;

const Template: ComponentStory<typeof Badge> = (args) => <Badge {...args} />;

export const Playground = Template.bind({});

Playground.args = {
  text: "Playground",
  style: "default",
};
