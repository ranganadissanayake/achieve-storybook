import React from 'react';

import classnames from 'classnames';

import './Badge.scss';

export interface BadgeProps {
    text: string;
    style?:
        | 'default'
        | 'info'
        | 'critical'
        | 'warning'
        | 'success'
        | 'disabled'
        | 'default-light'
        | 'disabled-inverse'
        | 'disabled-inverted'
    outline?: boolean;
    customStyle?: string;
    showClose?: boolean;
    onClose?: () => void;
}

const Badge: React.FC<BadgeProps> = ({
    text,
    outline = false,
    style = 'default',
    customStyle,
    showClose = false,
    onClose
}) => {
    return (
        <span className={classnames(`badge ${style} ${customStyle}`, { outline })}>
            {text}
            {showClose && (
                <span
                    className="close-icon"
                    data-testid="badge-close-icon"
                    onClick={(e) => {
                        onClose();
                        e.stopPropagation();
                    }}
                >
                    X
                </span>
            )}
        </span>
    );
};

export default Badge;
