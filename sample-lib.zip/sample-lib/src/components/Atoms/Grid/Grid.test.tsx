import React from 'react';
import { render } from '@testing-library/react';
import { Container, ContainerRow, ContainerFluid, Column } from './index';

describe('Grid components', () => {
    test('renders Container component', () => {
        const { getByText } = render(
            <Container data-testid="container">Container Component</Container>
        );
        const containerElement = getByText('Container Component');
        expect(containerElement).toBeInTheDocument();
        expect(containerElement).toHaveTextContent('Container Component');
    });

    test('renders ContainerRow component', () => {
        const { getByText } = render(
            <ContainerRow data-testid="container-row">ContainerRow Component</ContainerRow>
        );
        const containerRowElement = getByText('ContainerRow Component');
        expect(containerRowElement).toBeInTheDocument();
        expect(containerRowElement).toHaveTextContent('ContainerRow Component');
    });

    test('renders ContainerFluid component', () => {
        const { getByText } = render(
            <ContainerFluid data-testid="container-fluid">ContainerFluid Component</ContainerFluid>
        );
        const containerFluidElement = getByText('ContainerFluid Component');
        expect(containerFluidElement).toBeInTheDocument();
        expect(containerFluidElement).toHaveTextContent('ContainerFluid Component');
    });

    test('renders Column component with default props', () => {
        const { getByText } = render(<Column data-testid="column">Column Component</Column>);
        const columnElement = getByText('Column Component');
        expect(columnElement).toBeInTheDocument();
    });
});
