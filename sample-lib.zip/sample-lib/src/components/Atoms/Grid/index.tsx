import React from 'react';
import classnames from 'classnames';

import './Grid.scss';

export interface GridProps {
    children: React.ReactNode;
    className?: string;
}

type ColumnRange = 1 | 2 | 4 | 8 | 16;

export interface ColumnProps extends GridProps {
    sm?: ColumnRange;
    md?: ColumnRange;
    lg?: ColumnRange;
}

export const Container: React.FC<GridProps> = ({ children, className = '' }) => {
    return <div className={classnames(`container ${className}`)}>{children}</div>;
};

export const ContainerRow: React.FC<GridProps> = ({ children, className = '' }) => {
    return <div className={classnames(`container__row ${className}`)}>{children}</div>;
};

export const ContainerFluid: React.FC<GridProps> = ({ children, className = '' }) => {
    return <div className={classnames(`container container--fluid ${className}`)}>{children}</div>;
};

export const Column: React.FC<ColumnProps> = ({
    children,
    className = '',
    sm = 1,
    md = 1,
    lg = 1
}) => {
    return (
        <div
            className={classnames(
                `container__col-sm-${sm} container__col-md-${md} container__col-lg-${lg} ${className}`
            )}
        >
            {children}
        </div>
    );
};
