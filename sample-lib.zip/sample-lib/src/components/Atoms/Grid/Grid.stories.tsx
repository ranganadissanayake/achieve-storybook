import React from 'react';
import { ComponentMeta } from '@storybook/react';

import { Container, ContainerRow, ContainerFluid, Column } from './index';
import Label from '../Label';

export const DefaultStory = () => (
    <>
        <Container className="container-stories">
            <Label text="Container with rows & columns" />
            <ContainerRow className="hidden-md-down">
                <Column lg={1} md={1} sm={1}>
                    <Label text="col 1" />
                </Column>
            </ContainerRow>
            <ContainerRow>
                <Column lg={2} md={2} sm={2}>
                    <Label text="col 2" />
                </Column>
            </ContainerRow>
            <ContainerRow>
                <Column lg={4} md={4} sm={4}>
                    <Label text="col 4" />
                </Column>
            </ContainerRow>
            <ContainerRow>
                <Column lg={8} md={8} sm={8}>
                    <Label text="col 8" />
                </Column>
            </ContainerRow>
            <ContainerRow>
                <Column lg={16} md={16} sm={16}>
                    <Label text="col 16" />
                </Column>
            </ContainerRow>
            <ContainerRow className="hidden-md-down">
                {Array.from(Array(16).keys()).map((item) => (
                    <Column>
                        <Label text="col 1" />
                    </Column>
                ))}
            </ContainerRow>
            <ContainerRow>
                {Array.from(Array(8).keys()).map((item) => (
                    <Column lg={2} md={2} sm={2}>
                        <Label text="col 2" />
                    </Column>
                ))}
            </ContainerRow>
            <ContainerRow>
                {Array.from(Array(4).keys()).map((item) => (
                    <Column lg={4} md={4} sm={4}>
                        <Label text="col 4" />
                    </Column>
                ))}
            </ContainerRow>
            <ContainerRow>
                {Array.from(Array(2).keys()).map((item) => (
                    <Column lg={8} md={8} sm={8}>
                        <Label text="col 8" />
                    </Column>
                ))}
            </ContainerRow>
        </Container>
        <Container className="container-stories">
            <ContainerFluid>
                <Label text="Fluid container " />
                <Column>
                    <Label text="Fluid container with column 1" />
                </Column>
                <Column lg={8} md={8} sm={8}>
                    <Label text="Fluid container with column 8" />
                </Column>
            </ContainerFluid>
        </Container>

        <Container className="container-stories">
            <Label text="Row with mixed columns" />

            <ContainerRow>
                <Column lg={8} md={8} sm={8}>
                    <Label text="col 8" />
                </Column>
                <Column lg={4} md={4} sm={4}>
                    <Label text="col 4" />
                </Column>
                <Column lg={2} md={2} sm={2}>
                    <Label text="col 2" />
                </Column>
                <Column lg={2} md={2} sm={2} className="hidden-md-up">
                    <Label text="col 2" />
                </Column>
                <Column lg={1} md={1} sm={1} className="hidden-md-down">
                    <Label text="col 1" />
                </Column>
                <Column lg={1} md={1} sm={1} className="hidden-md-down">
                    <Label text="col 1" />
                </Column>
            </ContainerRow>
        </Container>
    </>
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Atoms/Grid'
} as ComponentMeta<typeof Container>;
