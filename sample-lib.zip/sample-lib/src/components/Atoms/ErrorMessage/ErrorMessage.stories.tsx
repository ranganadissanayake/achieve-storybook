import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";
import ErrorMessage from "./index";

export const DefaultStory = () => <ErrorMessage />;

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Atoms/ErrorMessage",
  component: ErrorMessage,
} as ComponentMeta<typeof ErrorMessage>;

const Template: ComponentStory<typeof ErrorMessage> = (args) => (
  <ErrorMessage {...args} />
);

export const Playground = Template.bind({});
Playground.args = {
  message: "Sorry, something went wrong",
};
