import React from 'react';
import Icon from '../Icon';

import './ErrorMessage.scss';

export interface ErrorMessageProps {
    message?: string;
    showIcon?: boolean;
    size?: 'sm' | 'md' | 'lg';
    className?: string;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({
    message = 'Error',
    showIcon = true,
    size = 'sm',
    className = ''
}) => {
    return (
        <span className={`error_message em_${size} ${className}`}>
            {showIcon && <Icon title="alert" size={size} />}
            <span className="text">{message}</span>
        </span>
    );
};

export default ErrorMessage;
