import React from "react";
import { render, screen } from "@testing-library/react";

import ErrorMessage from "./index";

describe("ErrorMessage", () => {
  test("renders ErrorMessage component", () => {
    render(<ErrorMessage message="Error Message" />);

    expect(screen.getByText("Error Message")).toBeInTheDocument();
  });

  test("renders an icon in the error message", () => {
    render(<ErrorMessage message="Error Message" />);

    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });
});
