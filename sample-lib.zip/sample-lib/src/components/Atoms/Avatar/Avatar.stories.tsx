import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Avatar from "./index";

import maleImage from "../../Assets/testImages/male.png";

export const DefaultStory = () => <Avatar />;

DefaultStory.storyName = "Default";

export default {
  title: "ReactComponentLibrary/Atoms/Avatar",
  component: Avatar,
} as ComponentMeta<typeof Avatar>;

const Template: ComponentStory<typeof Avatar> = (args) => <Avatar {...args} />;

export const Playground = Template.bind({});

Playground.args = {
  title: "Aron Anderson",
  subtitle: "Senior Product Manager",
  image: maleImage,
  onClick: () => {
    alert("Avatar clicked");
  },
};
