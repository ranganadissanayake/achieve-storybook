import React from 'react';
import classnames from 'classnames';

import Icon from '../../Atoms/Icon';
import { IconName } from '../../Assets/icons/iconLib';

import './Avatar.scss';

const getInitials = (fullname: string) => {
    var names = fullname.split(' '),
        initials = names[0].substring(0, 1).toUpperCase();

    if (names.length > 1) {
        initials += names[names.length - 1].substring(0, 1).toUpperCase();
    }
    return initials;
};

export interface AvatarProps {
    size?: 'ty' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl';
    title?: string;
    subtitle?: string;
    image?: string;
    border?: boolean;
    hideTitle?: boolean;
    hideSubtitle?: boolean;
    iconName?: IconName;
    className?: string;
    value?: string;
    onClick?: () => void;
}

const Avatar: React.FC<AvatarProps> = ({
    title = '',
    subtitle = '',
    image = '',
    size = 'lg',
    border = false,
    hideTitle = false,
    hideSubtitle = false,
    iconName = 'user',
    className = '',
    value = '',
    onClick
}) => {
    let content = <Icon title={iconName} color="white" className={`avatar_icon ${size}`} />;

    if (title !== '') {
        content = <span className={`avatar_text_${size}`}>{getInitials(title)}</span>;
    }

    if (value !== '') {
        content = <span className={`avatar_text_${size}`}>{value}</span>;
    }

    if (image !== '') {
        content = <img src={image} alt="" title="Avatar Image" className={`img ${size}`} />;
    }

    return (
        <span className={`avatar_container ${className}`} data-testid="avatar-container">
            <span
                className={classnames(`avatar ${size}`, {
                    border: border,
                    image: image !== '',
                    linked: !!onClick
                })}
                onClick={onClick}
                data-testid="avatar"
            >
                {content}
            </span>
            {((title !== '' && !hideTitle) || (subtitle !== '' && !hideSubtitle)) && (
                <span className="title-container">
                    {title !== '' && !hideTitle && <span className="title">{title}</span>}
                    {subtitle !== '' && !hideSubtitle && (
                        <span className="subtitle">{subtitle}</span>
                    )}
                </span>
            )}
        </span>
    );
};

export default Avatar;
