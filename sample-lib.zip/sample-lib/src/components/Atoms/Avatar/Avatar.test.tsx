import React from "react";
import { render, screen } from "@testing-library/react";

import Avatar from "./index";

describe("Avatar", () => {
  test("renders the Avatar component with an icon", () => {
    render(<Avatar />);
    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });

  test("renders the Avatar component and title", () => {
    render(<Avatar title="Aaron Anderson" />);
    expect(screen.getByText("AA")).toBeInTheDocument();
    expect(screen.getByText("Aaron Anderson")).toBeInTheDocument();
  });

  test("renders the Avatar component with initials but no title", () => {
    render(<Avatar title="Aaron Anderson" hideTitle />);
    expect(screen.getByText("AA")).toBeInTheDocument();
    expect(screen.queryByText("Aaron Anderson")).not.toBeInTheDocument();
  });

  test("renders the Avatar component with title and subtitle", () => {
    render(<Avatar title="Mary Doh" subtitle="Senior Product Manager" />);
    expect(screen.getByText("Mary Doh")).toBeInTheDocument();
    expect(screen.getByText("Senior Product Manager")).toBeInTheDocument();
  });

  test("hides the subtitle", () => {
    render(
      <Avatar title="Mary Doh" subtitle="Senior Product Manager" hideSubtitle />
    );
    expect(
      screen.queryByText("Senior Product Manager")
    ).not.toBeInTheDocument();
  });

  test("renders the Avatar component with an image", () => {
    render(
      <Avatar title="Mary Doh" image="../../Assets/testImages/male.png" />
    );

    expect(screen.getByTitle("Avatar Image")).toHaveAttribute(
      "src",
      "../../Assets/testImages/male.png"
    );
  });

  test("add ty class to tiny size avatar", () => {
    render(<Avatar size="ty" />);
    expect(screen.getByTestId("avatar")).toHaveClass("ty");
  });

  test("add sm class to small size avatar", () => {
    render(<Avatar size="sm" />);
    expect(screen.getByTestId("avatar")).toHaveClass("sm");
  });

  test("add md class to medium size avatar", () => {
    render(<Avatar size="md" />);
    expect(screen.getByTestId("avatar")).toHaveClass("md");
  });

  test("add lg class to large size avatar", () => {
    render(<Avatar size="lg" />);
    expect(screen.getByTestId("avatar")).toHaveClass("lg");
  });

  test("add xl class to extra large size avatar", () => {
    render(<Avatar size="xl" />);
    expect(screen.getByTestId("avatar")).toHaveClass("xl");
  });

  test("add xxl class to extra extra large size avatar", () => {
    render(<Avatar size="xxl" />);
    expect(screen.getByTestId("avatar")).toHaveClass("xxl");
  });

  test("add border class to bordered avatar", () => {
    render(<Avatar border />);
    expect(screen.getByTestId("avatar")).toHaveClass("border");
  });

  test("add link class to linked avatar", () => {
    render(
      <Avatar
        onClick={() => {
          alert("Avatar clicked");
        }}
      />
    );
    expect(screen.getByTestId("avatar")).toHaveClass("linked");
  });
});
