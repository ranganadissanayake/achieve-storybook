import React from 'react';
import Icon from '../index';

import icons, { IconName } from '../../../Assets/icons/iconLib';

import './Library.scss';

export interface LibraryProps {
    /**
     * Determines teh size of the icons
     */
    size?: 'sm' | 'md' | 'lg';
    /**
     * A hexadecimal string color for the icons
     */
    color?: string;
    /**
     * Inverses the color of the icons
     */
    inverse?: boolean;
}

const Library: React.FC<LibraryProps> = ({ size = 'md', color = '', inverse = false }) => {
    const iconNames = Object.keys(icons);

    return (
        <div className="icon_library">
            {iconNames.map((icon) => (
                <div className="library_item">
                    <Icon title={icon as IconName} size={size} color={color} inverse={inverse} />
                    <span>{icon}</span>
                </div>
            ))}
        </div>
    );
};

export default Library;
