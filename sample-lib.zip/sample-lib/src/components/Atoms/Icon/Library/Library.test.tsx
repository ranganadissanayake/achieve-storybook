import React from 'react';
import { render } from '@testing-library/react';
import Library, { LibraryProps } from './index';
import icons from '../../../Assets/icons/iconLib';

describe('Library Component', () => {
    const defaultProps: LibraryProps = {
        size: 'md',
        color: '',
        inverse: false
    };

    it('renders correctly with default props', () => {
        const { getByText } = render(<Library />);
        expect(getByText('five_g')).toBeInTheDocument();
        const iconNames = Object.keys(icons);
        const libraryItems = getByText('five_g');
    });

    it('renders correctly with custom props', () => {
        const customProps: LibraryProps = {
            size: 'sm',
            color: '#ff0000',
            inverse: true
        };
        const { getByText } = render(<Library {...customProps} />);
        expect(getByText('five_g')).toBeInTheDocument();
        const iconNames = Object.keys(icons);
        const libraryItems = getByText('five_g');
    });
});
