import React from "react";
import { render, screen } from "@testing-library/react";

import Icon from "./index";

describe("Icon", () => {
  test("renders the Icon component", () => {
    render(<Icon title="add" />);

    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });
  test("add icon_sm class to small icon", () => {
    render(<Icon title="add" size="sm" />);

    expect(screen.getByTestId("icon")).toHaveClass("icon_sm");
  });
  test("add icon_md class to medium icon", () => {
    render(<Icon title="add" size="md" />);

    expect(screen.getByTestId("icon")).toHaveClass("icon_md");
  });
  test("add icon_lg class to medium icon", () => {
    render(<Icon title="add" size="lg" />);

    expect(screen.getByTestId("icon")).toHaveClass("icon_lg");
  });
  test("add more classes with classname", () => {
    render(<Icon title="add" className="moreClass" />);

    expect(screen.getByTestId("icon")).toHaveClass("moreClass");
  });
  test("add inverse class to inverse icon", () => {
    render(<Icon title="add" inverse />);

    expect(screen.getByTestId("icon")).toHaveClass("inverse");
  });
  test("add specific color to icon", () => {
    render(<Icon title="add" color="#ff0000" />);

    expect(screen.getByTestId("icon"));
  });
});
