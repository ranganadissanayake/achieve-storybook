import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Icon from "./index";
import IconLibrary from './Library/index';

export const DefaultStory = () => <Icon title="alert" />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Atoms/Icon',
    component: Icon
} as ComponentMeta<typeof Icon>;

const Template: ComponentStory<typeof Icon> = (args) => <Icon {...args} />;

export const Playground = Template.bind({});
Playground.args = {
    title: 'accessibility',
    size: 'md',
    inverse: true
};

const LibTemplate: ComponentStory<typeof IconLibrary> = (args) => <IconLibrary {...args} />;

export const Library = LibTemplate.bind({});
Library.args = {
    size: 'md',
    inverse: false
};