import React, { useCallback, useState } from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import TableV2, { PaginationState } from './index';
import { Notifications, mockData, persons, customTable } from './data';
import Icon from '../../Atoms/Icon';

export const DefaultStory = () => {
    return <TableV2 data={persons.data} columns={persons.columns} />;
};

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Organisms/TableV2',
    component: TableV2
} as ComponentMeta<typeof TableV2>;

const noDataAction = () => {
    console.log('No data action');
};

const NotificationsTemplate: ComponentStory<typeof TableV2> = (args) => {
    return (
        <>
            <TableV2
                data={Notifications.data}
                columns={Notifications.columns}
                rowDataAttribute={'isRead'}
                enablePagination={false}
                defaultPageSize={10}
                pageSizes={[10, 25, 50, 100]}
                tableClassName="notifications-table"/>
            <br />
        </>
    )
};

const SingleRowSelectTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedValue, setSelectedValue] = useState();
    const handleChildButtonClick = (value: any) => {
        setSelectedValue(value);
    };
    return (
        <>
            <TableV2
                data={[...mockData.data]}
                columns={[...mockData.columns]}
                tableClassName="common-table"
                onSelectValue={handleChildButtonClick}
                enableSingleRowSelection={true}
            />
            <br />
            <div>{JSON.stringify(selectedValue)}</div>
        </>
    );
};

const EnablePaginationTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedValue, setSelectedValue] = useState();
    const handleChildButtonClick = (value: any) => {
        setSelectedValue(value);
    };
    return (
        <>
            <TableV2
                data={[...mockData.data]}
                columns={[...mockData.columns]}
                enablePagination={true}
                defaultPageSize={10}
                pageSizes={[10, 25, 50, 100]}
                tableClassName="common-table"
                onSelectValue={handleChildButtonClick}
                enableSingleRowSelection={true}
            />
            <br />
            <div>{JSON.stringify(selectedValue)}</div>
        </>
    );
};

const paginationServerSideTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedValue, setSelectedValue] = useState();
    const handleChildButtonClick = (value: any) => {
        setSelectedValue(value);
    };
    const getPaginationDetails = (details: PaginationState) => {
        console.log(details);
    };
    return (
        <>
            <TableV2
                data={[...mockData.data]}
                columns={[...mockData.columns]}
                enablePagination={true}
                defaultPageSize={10}
                pageSizes={[10, 25, 50, 100]}
                tableClassName="common-table"
                onSelectValue={handleChildButtonClick}
                enableSingleRowSelection={true}
                onChangePaginationFn={getPaginationDetails}
                setManualPagination = {true}
                setPageCount={2}
                setTotalCount={100}
                noDatadescription={"It appears you don't have any ports at the moment. To begin, let's get started by creating your very first port."}
                noDataMessage={"No ports to show"}
                noDataActionLabel={"Create New Port"}
                noDataAction={noDataAction}
            />
            <br />
            <div>{JSON.stringify(selectedValue)}</div>
        </>
    );
};

const ColResizeTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedValue, setSelectedValue] = useState();
    const handleChildButtonClick = (value: any) => {
        setSelectedValue(value);
    };
    return (
        <>
            <TableV2
                data={mockData.data}
                columns={mockData.columns}
                tableClassName="common-table"
                onSelectValue={handleChildButtonClick}
                enableColumnResize={true}
                tableMinWidth="100%"
            />
        </>
    );
};

const EnableFixedRowHeightTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedValue, setSelectedValue] = useState();
    const handleChildButtonClick = (value: any) => {
        setSelectedValue(value);
    };
    return (
        <>
            <TableV2
                data={[...mockData.data]}
                columns={[...mockData.columns]}
                enablePagination={true}
                defaultPageSize={10}
                pageSizes={[10, 25, 50, 100]}
                tableClassName="common-table"
                onSelectValue={handleChildButtonClick}
                enableSingleRowSelection={true}
                enableFixedRowHieght={true}
            />
            <br />
            <div>{JSON.stringify(selectedValue)}</div>
        </>
    );
};

const FixedHeaderTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedValue, setSelectedValue] = useState();
    const handleChildButtonClick = (value: any) => {
        setSelectedValue(value);
    };
    return (
        <>
            <TableV2
                data={[...mockData.data]}
                columns={[...mockData.columns]}
                tableClassName="common-table"
                onSelectValue={handleChildButtonClick}
                enableSingleRowSelection={true}
                enableFixHeader={true}
                tableMaxHeight="500px"
            />
            <br />
            <div>{JSON.stringify(selectedValue)}</div>
        </>
    );
};

const StickyColumnTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedValue, setSelectedValue] = useState();
    const handleChildButtonClick = (value: any) => {
        setSelectedValue(value);
    };
    return (
        <>
            <TableV2
                data={[...mockData.data]}
                columns={[...mockData.columns]}
                tableClassName="common-table"
                onSelectValue={handleChildButtonClick}
                enableSingleRowSelection={true}
                enableFixHeader={true}
                enableStickyColumn={true}
                tableMaxHeight="500px"
                tableMaxWidth="700px"
            />
            <br />
            <div>{JSON.stringify(selectedValue)}</div>
        </>
    );
};

const EnableMultiRowSelectionTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedData, setSelectedData] = useState();
    const handleChange = useCallback((data: any) => {
        setSelectedData(data);
    }, []);
    return (
        <>
            <TableV2
                data={[...mockData.data]}
                columns={[...mockData.columns]}
                enablePagination={true}
                defaultPageSize={10}
                pageSizes={[10, 25, 50, 100]}
                tableClassName="common-table"
                enableMultiRowSelection={true}
                onMultiSelectValue={handleChange}
            />
            <br />
            <div>{JSON.stringify(selectedData)}</div>
        </>
    );
};

const EnableExpandTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedData, setSelectedData] = useState();
    const handleChange = useCallback((data: any) => {
        setSelectedData(data);
    }, []);
    return (
        <>
            <TableV2
                data={[...persons.data]}
                columns={[...persons.columns]}
                enablePagination={false}
                defaultPageSize={5}
                pageSizes={[5, 10, 25, 50, 100]}
                tableClassName="common-table"
                enableMultiRowSelection={true}
                enableExpand={true}
                onMultiSelectValue={handleChange}
            />
            <br />
            <div>{JSON.stringify(selectedData)}</div>
        </>
    );
};

const SingleRowSelectionExpandTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedData, setSelectedData] = useState();
    const handleChange = useCallback((data: any) => {
        setSelectedData(data);
    }, []);
    return (
        <>
            <TableV2
                data={[...persons.data]}
                columns={[...persons.columns]}
                enablePagination={false}
                defaultPageSize={5}
                pageSizes={[5, 10, 25, 50, 100]}
                tableClassName="common-table"
                enableSingleSelectExpand={true}
                onMultiSelectValue={handleChange}
                enableSingleRowSelectionWithExpandRow={true}
            />
            <br />
            <div>{JSON.stringify(selectedData)}</div>
        </>
    );
};

const disableSubRowSelectTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedData, setSelectedData] = useState();
    const handleChange = useCallback((data: any) => {
        setSelectedData(data);
    }, []);
    return (
        <>
            <TableV2
                data={[...persons.data]}
                columns={[...persons.columns]}
                tableClassName="common-table"
                enableSingleSelectExpand={true}
                disableSubRowSelection={true}
                onMultiSelectValue={handleChange}
            />
            <br />
            <div>{JSON.stringify(selectedData)}</div>
        </>
    );
};

const canExpandTemplate: ComponentStory<typeof TableV2> = (args) => {
    return (
        <>
            <TableV2
                data={[...persons.data]}
                columns={[...persons.columns]}
                tableClassName="common-table"
                disableSubRowSelection={true}
                enableCanExpand={true}
            />
        </>
    );
};

const customTableTemplate: ComponentStory<typeof TableV2> = (args) => {
    const [selectedData, setSelectedData] = useState();
    const handleChange = useCallback((data: any) => {
        setSelectedData(data);
    }, []);
    var selectedRowId;
    const singleRowExpand = (table: any, row: any) => {
        const expanded = row.getIsExpanded();
        table.toggleAllRowsExpanded(false);
        row.toggleExpanded(!expanded);
    }
    const singleRowSelect = (table: any, row: any) => {
        const selected = row.getIsSelected();
        table.toggleAllRowsSelected(false);
        row.toggleSelected(!selected);
    }
    return (<>
        <TableV2 data={[...customTable.data]}
            columns={[...customTable.columns]}
            tableClassName="port-b-inventory-table"
            enableStickyColumn

                tableMinWidth="100%"
            customCol={{
                accessorFn: row => row.firstName,
                id: 'firstName',
                cell: ({ table, row, getValue }) => (
                    <>
                        {row.depth === 0 &&
                            <div className='expandable-cell'>
                                <button
                                    className={`button-radio ${((!row.getCanExpand() && row.getIsSelected()) || row.getIsSomeSelected() || row.getIsAllSubRowsSelected()) ? 'selected-on' : ''}`}
                                    onClick={(event: React.MouseEvent<HTMLButtonElement>) => {
                                        table.toggleAllRowsExpanded(false);
                                        row.toggleExpanded(true);
                                        selectedRowId = row.id;
                                        singleRowSelect(table, row)

                                    }}
                                >
                                    <span className='button-radio__active-dot'></span>
                                </button>
                                <div className='expandable-cell__value'>{getValue()}{row.getIsSelected() ? 'true' : 'false'}{row.id}{row.parentId}</div>
                                <div className='expand-icon-wrp'>
                                    {row.getCanExpand() && (
                                        <button
                                            className='expand-btn'
                                            onClick={(event: React.MouseEvent<HTMLButtonElement>) => {
                                                singleRowExpand(table, row);
                                            }}
                                            style={{ cursor: 'pointer' }}
                                        >
                                            {row.getIsExpanded() ? <Icon title="chevron_up_2px" /> : <Icon title="chevron_down_2px" />}
                                        </button>
                                    )}
                                </div>
                            </div>}

                        {row.depth === 1 &&
                            <div className='selectable-cell'>
                                <div className="checkbox-wrp">
                                    <button
                                        className={`button-checkbox ${row.getIsSelected() && 'checked-on'}`}
                                        onClick={(event: React.MouseEvent<HTMLButtonElement>) => {
                                            selectedRowId !== row.parentId && table.resetRowSelection();
                                            selectedRowId = row.parentId
                                            row.toggleSelected();
                                            setTimeout(() => { const elements = document.querySelectorAll(".sub-row.row-selected"); elements.length === 0 && table.resetRowSelection(); }, 10);
                                        }}
                                    >
                                        <span className='button-checkbox__active-tick'></span>
                                    </button>
                                </div>
                                <div className='selectable-cell__value'>{getValue()}{row.getIsSelected() ? 'true' : 'false'}{row.id}{row.parentId}</div>
                            </div>
                        }
                    </>
                ),
                header: () => <span>First Name</span>,
            }
            }
        />
        <br />
        <div>{JSON.stringify(selectedData)}</div>
    </>
    )
};

export const SingleRowSelect = SingleRowSelectTemplate.bind({});
export const NotificationsMock = NotificationsTemplate.bind({});
export const EnablePagination = EnablePaginationTemplate.bind({});
export const paginationServerSide = paginationServerSideTemplate.bind({});
export const ColResize = ColResizeTemplate.bind({});
export const EnableFixedRowHeight = EnableFixedRowHeightTemplate.bind({});
export const FixedHeader = FixedHeaderTemplate.bind({});
export const StickyColumn = StickyColumnTemplate.bind({});
export const EnableMultiRowSelection = EnableMultiRowSelectionTemplate.bind({});
export const EnableExpand = EnableExpandTemplate.bind({});
export const SingleRowSelectionExpand = SingleRowSelectionExpandTemplate.bind({});
export const disableSubRowSelect = disableSubRowSelectTemplate.bind({});
export const canExpandWithoutSelectionTemplate = canExpandTemplate.bind({});
export const customColumns = customTableTemplate.bind({});
