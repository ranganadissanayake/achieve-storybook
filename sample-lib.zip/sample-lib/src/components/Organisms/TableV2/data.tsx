import Critical from '../../Assets/icons/svg/critical.svg';
import Successful from '../../Assets/icons/svg/successful.svg';
import Informational from '../../Assets/icons/svg/info.svg';
import Warning from '../../Assets/icons/svg/warning.svg';
import Icon from '../../Atoms/Icon';
import React from 'react';

const severityIcons = {
    Critical,
    Successful,
    Informational,
    Warning,
};

const generateNotificationColumns = () => [
    {
        id: 'severityLevel',
        header: '',
        accessorKey: 'severityLevel',
        cell: (cellData) => {
            const iconSrc = severityIcons[cellData.getValue()] || null;
            return <img src={iconSrc} alt={cellData.getValue()} />;
        },
    },
    {
        id: 'title',
        header: '',
        accessorKey: 'title',
        cell: ({ row }) => (
            <>
                <div className='title'>{row.original.title}</div>
                <div className='description'>{row.original.description}</div>
                <div className='dateTime'>{row.original.dateTime}</div>
            </>
        ),
    },
    {
        id: 'isRead',
        header: '',
        accessorKey: 'isRead',
        cell: (cellData) => (!cellData.getValue() ? <div className='status'></div> : null),
    },
];

const notificationColumns = generateNotificationColumns();

const mockTColumns = [
    {
        id: 'associatedNetwork',
        header: 'Associated Network Services',
        accessorKey: 'associatedNetwork',
        cell: ({ row }) => (
            <>
                <div className="link">{row.original.associatedNetwork}</div>
            </>
        ),
        sticky: "left",
    },
    {
        id: 'status',
        header: "Status",
        accessorKey: "status",
        cell: (cellData) => {
            const iconSrc = cellData.getValue() === 'live' ? Successful : null;
            return <img src={iconSrc} alt={cellData.getValue()} />;
        },
    },
    {
        id: 'type',
        header: "Type",
        accessorKey: "type",
    },
    {
        id: 'ipAddresses',
        header: "IP Address(es)",
        accessorKey: "ipAddresses",
    },
    {
        id: 'vlanId',
        header: "VLAN ID",
        accessorKey: "vlanId",
    },
    {
        id: 'allocation',
        header: "Allocation",
        accessorKey: "allocation",
    },
    {
        id: 'geographicBoundary',
        header: "Geographic Boundary",
        accessorKey: "geographicBoundary",
    },
    {
        id: 'created',
        header: "Created",
        accessorKey: "created",
    }
];
const mockTData = [{
    associatedNetwork: "Global VPN",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Ashburn Metro VPN",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Ashburn Google",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "South East UK Internet",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Global VPN",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Ashburn Metro VPN",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Ashburn Google",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "South East UK Internet",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Global VPN",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Ashburn Metro VPN",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Ashburn Google",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "South East UK Internet",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Global VPN",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Ashburn Metro VPN",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "Ashburn Google",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
},
{
    associatedNetwork: "South East UK Internet",
    status: "live",
    type: "Internet",
    ipAddresses: "10.235.235.220",
    vlanId: "101",
    allocation: "200 Mbps",
    geographicBoundary: "Global",
    created: "27 Dec 2022",
}]
const personsTData = [
    {
        firstName: "Nikolas",
        lastName: "Lakin",
        age: 1,
        visits: 592,
        progress: 51,
        status: "single",
        subRows: [
            {
                firstName: "Reta",
                lastName: "Cummings",
                age: 38,
                visits: 641,
                progress: 81,
                status: "complicated"
            },
            {
                firstName: "Sydnie",
                lastName: "Schneider",
                age: 13,
                visits: 916,
                progress: 48,
                status: "single"
            },
            {
                firstName: "Nigel",
                lastName: "McClure",
                age: 4,
                visits: 278,
                progress: 94,
                status: "single"
            }
        ]
    },
    {
        firstName: "Gerda",
        lastName: "Streich",
        age: 0,
        visits: 861,
        progress: 97,
        status: "relationship",
        subRows: [
            {
                firstName: "Dolores",
                lastName: "Larkin",
                age: 12,
                visits: 112,
                progress: 13,
                status: "complicated"
            },
            {
                firstName: "Christy",
                lastName: "Cormier",
                age: 33,
                visits: 548,
                progress: 56,
                status: "single"
            },
            {
                firstName: "Trycia",
                lastName: "Bechtelar",
                age: 26,
                visits: 382,
                progress: 11,
                status: "complicated"
            }
        ]
    },
    {
        firstName: "Karlie",
        lastName: "Larkin",
        age: 7,
        visits: 575,
        progress: 34,
        status: "complicated",
    },
    {
        firstName: "Zion",
        lastName: "Koelpin",
        age: 10,
        visits: 554,
        progress: 25,
        status: "complicated",
    },
    {
        firstName: "Milan",
        lastName: "Hoeger",
        age: 30,
        visits: 392,
        progress: 22,
        status: "relationship",
        subRows: [
            {
                firstName: "Hosea",
                lastName: "Schuster",
                age: 7,
                visits: 375,
                progress: 83,
                status: "complicated"
            },
            {
                firstName: "Sienna",
                lastName: "Upton",
                age: 16,
                visits: 666,
                progress: 84,
                status: "complicated"
            },
            {
                firstName: "Era",
                lastName: "Roob",
                age: 13,
                visits: 626,
                progress: 6,
                status: "complicated"
            }
        ]
    },
    {
        firstName: "William",
        lastName: "Waelchi",
        age: 24,
        visits: 478,
        progress: 22,
        status: "complicated",
    },
    {
        firstName: "Alvera",
        lastName: "Lakin",
        age: 28,
        visits: 177,
        progress: 27,
        status: "complicated",
        subRows: [
            {
                firstName: "Arnaldo",
                lastName: "Ryan",
                age: 36,
                visits: 948,
                progress: 1,
                status: "complicated"
            },
            {
                firstName: "Johnson",
                lastName: "Goyette",
                age: 19,
                visits: 776,
                progress: 72,
                status: "relationship"
            },
            {
                firstName: "Rollin",
                lastName: "Rodriguez",
                age: 14,
                visits: 317,
                progress: 27,
                status: "relationship"
            }
        ]
    },
    {
        firstName: "Fabiola",
        lastName: "Wiza",
        age: 35,
        visits: 759,
        progress: 6,
        status: "relationship"
    }
]

const personsColumns = [
    {
        accessorFn: (row) => row.firstName,
        id: 'firstName',
        cell: (info) => info.getValue(),
        header: () => <span>First Name</span>,
    },
    {
        accessorFn: (row) => row.lastName,
        id: 'lastName',
        cell: (info) => info.getValue(),
        header: () => <span>Last Name</span>,
    },
    {
        accessorKey: 'age',
        header: () => 'Age',
    },
    {
        accessorKey: 'visits',
        header: () => <span>Visits</span>,
    },
    {
        accessorKey: 'status',
        header: 'Status',
    },
    {
        accessorKey: 'progress',
        header: 'Profile Progress',
    },
];

export const Notifications = {
    columns: notificationColumns,
    data: [{
        title: 'Customer Port Configuration Change Failure ',
        description: `Failure to change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> for reason <x>  `,
        type: 'Utilisation',
        severityLevel: 'Critical',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Success ',
        description: `Successful change of Customer Port <name> <portId> configuration <parameter> <value> by <username> `,
        type: 'Utilisation',
        severityLevel: 'Successful',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated',
        description: `Change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated ',
        description: `Change Customer “IAD40 44372 Round Table Data Center” EE-89-UPDG-3672722 configuration <parameter> <value> initiated by <username>  `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change – access bandwidth order complete ',
        description: `Data Centre Connection <name> <portId> access cease order raised with lead time of <x days> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port: Port Only being deleted ',
        description: `Port Only <name> <portId> is being deleted by <username> `,
        type: 'Utilisation',
        severityLevel: 'Warning',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change Failure ',
        description: `Failure to change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> for reason <x>  `,
        type: 'Utilisation',
        severityLevel: 'Critical',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Success ',
        description: `Successful change of Customer Port <name> <portId> configuration <parameter> <value> by <username> `,
        type: 'Utilisation',
        severityLevel: 'Successful',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated',
        description: `Change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated ',
        description: `Change Customer “IAD40 44372 Round Table Data Center” EE-89-UPDG-3672722 configuration <parameter> <value> initiated by <username>  `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change – access bandwidth order complete ',
        description: `Data Centre Connection <name> <portId> access cease order raised with lead time of <x days> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port: Port Only being deleted ',
        description: `Port Only <name> <portId> is being deleted by <username> `,
        type: 'Utilisation',
        severityLevel: 'Warning',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change Failure ',
        description: `Failure to change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> for reason <x>  `,
        type: 'Utilisation',
        severityLevel: 'Critical',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Success ',
        description: `Successful change of Customer Port <name> <portId> configuration <parameter> <value> by <username> `,
        type: 'Utilisation',
        severityLevel: 'Successful',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated',
        description: `Change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated ',
        description: `Change Customer “IAD40 44372 Round Table Data Center” EE-89-UPDG-3672722 configuration <parameter> <value> initiated by <username>  `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change – access bandwidth order complete ',
        description: `Data Centre Connection <name> <portId> access cease order raised with lead time of <x days> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port: Port Only being deleted ',
        description: `Port Only <name> <portId> is being deleted by <username> `,
        type: 'Utilisation',
        severityLevel: 'Warning',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change Failure ',
        description: `Failure to change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> for reason <x>  `,
        type: 'Utilisation',
        severityLevel: 'Critical',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Success ',
        description: `Successful change of Customer Port <name> <portId> configuration <parameter> <value> by <username> `,
        type: 'Utilisation',
        severityLevel: 'Successful',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated',
        description: `Change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated ',
        description: `Change Customer “IAD40 44372 Round Table Data Center” EE-89-UPDG-3672722 configuration <parameter> <value> initiated by <username>  `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change – access bandwidth order complete ',
        description: `Data Centre Connection <name> <portId> access cease order raised with lead time of <x days> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port: Port Only being deleted ',
        description: `Port Only <name> <portId> is being deleted by <username> `,
        type: 'Utilisation',
        severityLevel: 'Warning',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change Failure ',
        description: `Failure to change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> for reason <x>  `,
        type: 'Utilisation',
        severityLevel: 'Critical',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Success ',
        description: `Successful change of Customer Port <name> <portId> configuration <parameter> <value> by <username> `,
        type: 'Utilisation',
        severityLevel: 'Successful',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated',
        description: `Change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated ',
        description: `Change Customer “IAD40 44372 Round Table Data Center” EE-89-UPDG-3672722 configuration <parameter> <value> initiated by <username>  `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change – access bandwidth order complete ',
        description: `Data Centre Connection <name> <portId> access cease order raised with lead time of <x days> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port: Port Only being deleted ',
        description: `Port Only <name> <portId> is being deleted by <username> `,
        type: 'Utilisation',
        severityLevel: 'Warning',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change Failure ',
        description: `Failure to change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> for reason <x>  `,
        type: 'Utilisation',
        severityLevel: 'Critical',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Success ',
        description: `Successful change of Customer Port <name> <portId> configuration <parameter> <value> by <username> `,
        type: 'Utilisation',
        severityLevel: 'Successful',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated',
        description: `Change Customer Port <name> <portId> configuration <parameter> <value> initiated by <username> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: false
    },
    {
        title: 'Customer Port Configuration Change Initiated ',
        description: `Change Customer “IAD40 44372 Round Table Data Center” EE-89-UPDG-3672722 configuration <parameter> <value> initiated by <username>  `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port Configuration Change – access bandwidth order complete ',
        description: `Data Centre Connection <name> <portId> access cease order raised with lead time of <x days> `,
        type: 'Utilisation',
        severityLevel: 'Informational',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    },
    {
        title: 'Customer Port: Port Only being deleted ',
        description: `Port Only <name> <portId> is being deleted by <username> `,
        type: 'Utilisation',
        severityLevel: 'Warning',
        dateTime: '24/June/23 9:28 AM',
        isRead: true
    }]
};

export const mockData = {
    columns: mockTColumns,
    data: mockTData
};

export const persons = {
    columns: personsColumns,
    data: personsTData
};
