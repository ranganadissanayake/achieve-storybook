import React, { HTMLProps, useEffect, useState } from 'react';
import {
    getCoreRowModel,
    useReactTable,
    ColumnResizeMode,
    flexRender,
    ColumnDef,
    getPaginationRowModel,
    getFilteredRowModel,
    ExpandedState,
    getExpandedRowModel,
    Row
} from '@tanstack/react-table';
import './TableV2.scss';
import Icon from '../../Atoms/Icon';
import noDataIcon from '../../Assets/icons/img/no-data.png';
import Tooltip from '../../Molecules/Tooltip';
import Button from '../../Molecules/Button';

const unshiftPrecheck = (columns: ColumnDef<any>[], appendItem: ColumnDef<any>) => {
    const isPresent = columns.find((column) => column.id === appendItem.id);

    if (isPresent) {
        return;
    }
    columns.unshift(appendItem);
};

const RenderExpand = ({ row }: { row: Row<any> }) => (
    <div className="expand-icon-wrp">
        {row.getCanExpand() && (
            <button
                className="expand-btn"
                {...{
                    onClick: row.getToggleExpandedHandler(),
                    style: { cursor: 'pointer' }
                }}
            >
                {row.getIsExpanded() ? (
                    <Icon title="chevron_up_2px" />
                ) : (
                    <Icon title="chevron_down_2px" />
                )}
            </button>
        )}
    </div>
);

export type PaginationState = {
    pageIndex: number
    pageSize: number
}

interface TableProps {
    data: any[];
    columns: ColumnDef<any>[];
    enablePagination?: boolean
    pageSizes?: number[];
    rowDataAttribute?: string;
    defaultPageSize?: number;
    tableClassName?: string;
    onSelectValue?: (value: any) => void;
    onMultiSelectValue?: (value: any) => void;
    hideTableHeader?: boolean;
    enableSingleRowSelection?: boolean;
    enableColumnResize?: boolean;
    enableFixedRowHieght?: boolean;
    enableCanExpand?: boolean;
    tableMinWidth?: string;
    tableMaxWidth?: string;
    tableMaxHeight?: string;
    enableFixHeader?: boolean;
    enableMultiRowSelection?: boolean;
    enableExpand?: boolean;
    enableStickyColumn?: boolean;
    enableStickyRow?: boolean;
    enableSingleSelectExpand?: boolean;
    disableSubRowSelection?: boolean;
    customCol?:any;
    enableHorizontalScrollBar?:boolean;
    noDataMessage?:string;
    noDatadescription?:string;
    noDataActionLabel?:string,
    noDataAction?: () => void;
    onChangePaginationFn?: (paginationDetail : PaginationState) => void;
    setManualPagination?: boolean;
    setPageCount?: number;
    setTotalCount?: number;
    enableSingleRowSelectionWithExpandRow?: boolean;
}

const TableV2: React.FC<TableProps> = ({
    data,
    columns,
    enablePagination,
    pageSizes,
    defaultPageSize,
    rowDataAttribute,
    tableClassName,
    onSelectValue,
    onMultiSelectValue,
    enableSingleRowSelection,
    enableColumnResize,
    enableFixedRowHieght,
    enableCanExpand,
    tableMinWidth,
    tableMaxWidth,
    tableMaxHeight,
    enableFixHeader,
    hideTableHeader,
    enableMultiRowSelection,
    enableSingleSelectExpand,
    enableExpand,
    enableStickyColumn,
    enableStickyRow,
    disableSubRowSelection,
    enableHorizontalScrollBar,
    customCol,
    noDataMessage,
    noDatadescription,
    noDataActionLabel,
    noDataAction,
    onChangePaginationFn,
    setManualPagination,
    setPageCount,
    setTotalCount,
    enableSingleRowSelectionWithExpandRow,
}) => {
    if (customCol) columns.unshift(customCol);
    enableSingleRowSelection &&
        unshiftPrecheck(columns, {
            id: 'singleRowSelect',
            header: () => <span></span>,
            cell: ({ row }) => (
                <label className="radio-btn">
                    <input
                        id="selectRow"
                        type="radio"
                        name="selectRow"
                        {...{
                            checked: row.getIsSelected(),
                            onChange: () => {
                                singleRowSelection(row);        
                            }
                        }}
                    />
                    <span className="radio-btn__helper">
                        <span className="radio-btn__helper--active-dot"></span>
                    </span>
                </label>
            )
        });

        if (enableMultiRowSelection && !enableExpand) {
        unshiftPrecheck(columns, {
            id: 'select',
            header: () => (
                <IndeterminateCheckbox
                    {...{
                        checked: table.getIsAllRowsSelected(),
                        indeterminate: table.getIsSomeRowsSelected(),
                        onChange: table.getToggleAllRowsSelectedHandler()
                    }}
                />
            ),
            cell: ({ row }) => (
                <div className="px-1">
                    <IndeterminateCheckbox
                        {...{
                            checked: row.getIsSelected(),
                            disabled: !row.getCanSelect(),
                            indeterminate: row.getIsSomeSelected(),
                            onChange: row.getToggleSelectedHandler()
                        }}
                    />
                </div>
            )
        });
    }

    (enableMultiRowSelection && enableExpand) &&
        columns.unshift({
            id: 'select',
            header: () => (
                <div className="expand-action-wrp">
                    <IndeterminateCheckbox
                        {...{
                            checked: table.getIsAllRowsSelected(),
                            indeterminate: table.getIsSomeRowsSelected(),
                            onChange: table.getToggleAllRowsSelectedHandler()
                        }}
                    />
                </div>
            ),
            cell: ({ row, getValue }) => (
                <div
                    style={{
                        paddingLeft: `${row.depth * 2}rem`
                    }}
                >
                    <div className="expand-action-wrp">
                        {RenderExpand({ row })}

                        {row.depth == 0 && (
                            <IndeterminateCheckbox
                                {...{
                                    checked: row.getIsSelected(),
                                    indeterminate:
                                        row.getIsSomeSelected() || row.getIsAllSubRowsSelected(),
                                    onChange: row.getToggleSelectedHandler()
                                }}
                            />
                        )}

                        {row.depth == 1 && !disableSubRowSelection && (
                            <IndeterminateCheckbox
                                {...{
                                    checked: row.getIsSelected(),
                                    indeterminate:
                                        row.getIsSomeSelected() || row.getIsAllSubRowsSelected(),
                                    onChange: row.getToggleSelectedHandler()
                                }}
                            />
                        )}

                        {getValue()}
                    </div>
                </div>
            )
        });

    enableSingleSelectExpand &&
        unshiftPrecheck(columns, {
            id: 'select',
            cell: ({ row, getValue }) => (
                <div
                    style={{
                        paddingLeft: `${row.depth * 2}rem`
                    }}
                >
                    <div className="expand-action-wrp">
                        {RenderExpand({ row })}
                        {row.depth == 0 && (
                            <div className="single-selector">
                                <label className="radio-btn">
                                    <input
                                        id={`selectRow-${row.id + 1}`}
                                        type="radio"
                                        name="selectRow"
                                        className={` ${!row.getCanExpand() && 'no-expand'} ${
                                            row.getIsSomeSelected() || row.getIsAllSubRowsSelected()
                                                ? 'active'
                                                : 'inactive'
                                        }`}
                                        {...{
                                            checked: row.getIsSelected(),
                                            onChange: () => {
                                                singleRowSelection(row);
                                            }
                                        }}
                                    />
                                    <span className="radio-btn__helper">
                                        <span className="radio-btn__helper--active-dot"></span>
                                    </span>
                                </label>
                            </div>
                        )}
                        {row.depth == 1 && !disableSubRowSelection && (
                            <IndeterminateCheckbox
                                {...{
                                    checked: row.getIsSelected(),
                                    indeterminate:
                                        row.getIsSomeSelected() || row.getIsAllSubRowsSelected(),
                                    onChange: row.getToggleSelectedHandler()
                                }}
                            />
                        )}
                        {getValue()}
                    </div>
                </div>
            )
        });

    enableCanExpand &&
        unshiftPrecheck(columns, {
            id: 'expand',
            cell: ({ row, getValue }) => (
                <div
                    style={{
                        paddingLeft: `${row.depth * 2}rem`
                    }}
                >
                    {RenderExpand({ row })}
                    {getValue()}
                </div>
            )
        });

    const singleRowSelection = (row) => {
        const selected = row.getIsSelected();
        table.toggleAllRowsSelected(false);
        row.toggleSelected(!selected);
        onSelectValue(row.original);
        if(enableSingleRowSelectionWithExpandRow){
            row.getToggleExpandedHandler()();
        }
    };

    function IndeterminateCheckbox({
        indeterminate,
        className = '',
        ...rest
    }: { indeterminate?: boolean } & HTMLProps<HTMLInputElement>) {
        const ref = React.useRef<HTMLInputElement>(null!);
        React.useEffect(() => {
            typeof indeterminate === 'boolean' && (ref.current.indeterminate = !rest.checked && indeterminate);
        }, [ref, indeterminate]);
        return (
            <div className="checkbox-wrp">
                <input
                    type="checkbox"
                    ref={ref}
                    className={className + ' cursor-pointer '}
                    {...rest}
                />
                <label></label>
            </div>
        );
    }

    const [columnResizeMode] = React.useState<ColumnResizeMode>('onChange');
    const [rowSelection, setRowSelection] = React.useState({});
    const [expanded, setExpanded] = React.useState<ExpandedState>({});
    const [pagination, setPagination] = useState({
        pageIndex: 0, //initial page index
        pageSize: 10, //default page size
      });

      React.useEffect(() => {
          if (onChangePaginationFn) {
              onChangePaginationFn(pagination);
          }
      }, [pagination]);

    const table = useReactTable({
        data,
        columns,
        state: {
            rowSelection,
            expanded,
            pagination,
        },
        getCoreRowModel: getCoreRowModel(),
        manualPagination: setManualPagination,
        enableRowSelection: true,
        enableMultiRowSelection: true,
        onRowSelectionChange: setRowSelection,
        getFilteredRowModel: getFilteredRowModel(),
        getPaginationRowModel: enablePagination && getPaginationRowModel(),
        columnResizeMode,
        onExpandedChange: setExpanded,
        getSubRows: (row) => row.subRows,
        getExpandedRowModel: getExpandedRowModel(),
        onPaginationChange: setPagination, //update the pagination state when internal APIs mutate the pagination state
        pageCount:setPageCount,
        enableSubRowSelection: true,
    });
    const rowDataAttr = (attr: string, value: string) => {
        return { [`data-${attr}`]: value };
    };
    const extractColumn = (value: string) => {
        const match = value.match(/_(.+)/);
        return match && match[1];
    };

    (enableMultiRowSelection || enableSingleSelectExpand) &&
        useEffect(() => {
            onMultiSelectValue &&
                onMultiSelectValue(table.getSelectedRowModel().flatRows.map((row) => row.original));
        }, [rowSelection, table, onMultiSelectValue]);
    return (
        <div className="dataTable-component">
            <div
                className={`dataTable-wrapper 
            ${tableClassName} 
            ${enableFixedRowHieght && 'fixed-row-height'} 
            ${tableMaxHeight && 'hasMaxHeight'} 
            ${tableMinWidth && 'hasMinWidth'} 
            ${tableMaxWidth && 'hasMaxWidth'} 
            ${enableStickyColumn && !enableHorizontalScrollBar && 'sticky-column'} 
            ${enableStickyRow && 'sticky-row'}
            ${enableSingleRowSelection && 'single-row-selection'}
            ${enablePagination && 'has-pagination'}
            ${enableColumnResize && 'col-resize'}
            ${enableMultiRowSelection && 'multi-row-selection'}
            ${(enableExpand || enableCanExpand) && 'row-expand'}
            ${(enableSingleSelectExpand || enableCanExpand) && 'single-row-expand'}
            ${disableSubRowSelection && 'disabled-sub-row-selection'}
            ${enableHorizontalScrollBar && 'enableHorizontalScrollBar'}
            ${enableStickyColumn && enableHorizontalScrollBar && 'sticky-col'}
            ${
                !enableSingleRowSelection &&
                !enableMultiRowSelection &&
                !enableSingleSelectExpand &&
                !enableExpand &&
                !enableCanExpand &&
                'simple-sticky-column'
            }
            `}
                {...{
                    style: {
                        minWidth: tableMinWidth,
                        maxWidth: tableMaxWidth,
                        maxHeight: tableMaxHeight
                    }
                }}
            >
                <table
                    className="tbl"
                    role="table"
                    {...(enableColumnResize && {
                        style: {
                            minWidth: tableMinWidth,
                            width: table.getCenterTotalSize()
                        }
                    })}
                >
                    <thead
                        className={`${hideTableHeader ? 'hide-tbl-thead' : ''} ${
                            enableFixHeader && 'fixed-header'
                        }`}
                        data-testid="thead"
                    >
                        {table.getHeaderGroups().map((headerGroup) => (
                            <tr
                                key={headerGroup.id}
                                className={`tbl-row row-${headerGroup.id}`}
                                role="row"
                            >
                                {headerGroup.headers.map((header) => (
                                    <th
                                        key={header.id}
                                        className={`tbl-th col-${header.column.id.replace(/"/g, '')}`}
                                        role="cell"
                                        {...(enableColumnResize && {
                                            key: header.id,
                                            colSpan: header.colSpan,
                                            style: {
                                                width: header.getSize()
                                            }
                                        })}
                                    >
                                        {flexRender(
                                            header.column.columnDef.header,
                                            header.getContext()
                                        )}
                                        <div
                                            {...(enableColumnResize && {
                                                onMouseDown: header.getResizeHandler(),
                                                onTouchStart: header.getResizeHandler(),
                                                className: `resizer ${
                                                    header.column.getIsResizing()
                                                        ? 'isResizing'
                                                        : ''
                                                }`
                                            })}
                                        ></div>
                                    </th>
                                ))}
                            </tr>
                        ))}
                    </thead>
                    <tbody>
                        {table.getRowModel().rows.map((row) => (
                            <tr
                                key={row.id}
                                className={`tbl-row row-${row.id} ${row.depth === 1 && 'sub-row'} ${
                                    row.depth === 0 && 'parent-row'
                                } ${row.getIsExpanded() && 'expanded'} ${
                                    row.getCanExpand() && 'can-expand'
                                } ${row.getIsSelected() && 'row-selected'}`}
                                {...rowDataAttr(rowDataAttribute, row.original[rowDataAttribute])}
                                role="row"
                                onClick={()=>{
                                    if(enableSingleRowSelectionWithExpandRow){
                                        row.getToggleExpandedHandler()();
                                    }
                                }}
                            >
                                {row.getVisibleCells().map((cell) => (
                                    <td
                                        key={cell.id}
                                        className={`tbl-td td-${cell.id} col-${extractColumn(
                                            cell.id
                                        )}`}
                                        role="cell"
                                    >
                                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
                {!data.length && (
                    <div className="col-16">
                        <div className="nodata-message">
                            <div className="message-icon">
                                <img src={noDataIcon} />
                            </div>
                            <div className="message-text"> {noDataMessage ?? 'No results found'} </div>
                            <div className="message-description">{noDatadescription ?? ''}</div>
                            { noDataAction && (
                                <div className="message-action"> <Button onPress={noDataAction} label={noDataActionLabel ?? 'Create New Port'} variant="gradient" size="medium" /></div>
                            )}
                        </div>
                    </div>
                )}
            </div>
            {enablePagination && (
                <div className={`table-pagination ${data.length <= defaultPageSize && 'disabled-paginatio'}`}>
                    <div className="pagination-status">
                        {pageSizes && (
                            <>
                                <span className={`show-text`}>
                                    <span className="fp-b"> Rows per page </span>
                                </span>
                                <span className="page-select">
                                    <select
                                        value={table.getState().pagination.pageSize}
                                        onChange={(e) => {
                                            table.setPageSize(Number(e.target.value));
                                        }}
                                        disabled={ setTotalCount < 10 || table.getExpandedRowModel().rows.length < 10 }
                                    >
                                        {pageSizes &&
                                            pageSizes?.map((pageSize) => (
                                                <option key={pageSize} value={pageSize}>
                                                    {pageSize}
                                                </option>
                                            ))}
                                    </select>
                                </span>
                            </>
                        )}
                    </div>
                    <div className="pagination-actions">
                    <span className={`page_count`}>
                            <span className="fp-b">
                                {table.getState().pagination.pageSize *
                                    table.getState().pagination.pageIndex +
                                    1}
                            </span>{' '}
                            -{' '}
                            <span className="fp-b">
                                {table.getPageCount() === table.getState().pagination.pageIndex + 1
                                    ? table.getExpandedRowModel().rows.length
                                    : table.getState().pagination.pageSize +
                                      table.getState().pagination.pageSize *
                                          table.getState().pagination.pageIndex}
                            </span>{' '}
                            of{' '}
                            <span className="fp-b">
                                {setTotalCount ?? table.getExpandedRowModel().rows.length}
                            </span>{' '}
                        </span>
                        <button data-testid="first-page" onClick={() => table.firstPage()} disabled={!table.getCanPreviousPage()}>
                            <Tooltip content="First Page" direction="bottom"><Icon title="pagination_first" size="lg"/></Tooltip>
                        </button>
                        <button data-testid="previous-page" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()} >
                            <Tooltip content="Previous Page" direction="bottom"><Icon title="pagination_back" size="lg"/></Tooltip>
                        </button>
                        <button data-testid="next-page" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>
                            <Tooltip content="Next Page" direction="bottom"><Icon title="pagination_next" size="lg"/></Tooltip>
                        </button>
                        <button data-testid="last-page" onClick={() => table.lastPage()} disabled={!table.getCanNextPage()}>
                            <Tooltip content="Last Page" direction="bottom"><Icon title="pagination_last" size="lg"/></Tooltip>
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};
export default TableV2;
