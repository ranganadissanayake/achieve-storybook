import React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import TableV2 from '.';
import { mockData } from './data';

const sampleData = [
    { id: 1, name: 'John', age: 30 },
    { id: 2, name: 'Alice', age: 25 },
    { id: 3, name: 'Bob', age: 35 },
];

const sampleColumns = [
    { id: 'id', Header: 'ID', accessor: 'id' },
    { id: 'name', Header: 'Name', accessor: 'name' },
    { id: 'age', Header: 'Age', accessor: 'age' },
];

function IndeterminateCheckbox({
    indeterminate,
    className = '',
    onChange,
}) {
    const uniqueId = `checkbox-${Math.random().toString(36).substr(2, 9)}`;

    return (
        <div className="checkbox-wrp">
            <input
                type="checkbox"
                id={uniqueId} // Use the generated ID as the 'id' attribute
                className={className + ' cursor-pointer '}
                checked={indeterminate}
                onChange={onChange}
            />
            <label htmlFor={uniqueId}>Checkbox Label</label> {/* Use 'htmlFor' to associate with the input */}
        </div>
    );
}

describe('TableV2 Component', () => {
    it('should render without errors', () => {
        render(<TableV2 data={sampleData} columns={sampleColumns} />);
        // Ensure that the component renders without errors
        expect(screen.getByTestId('thead')).toBeInTheDocument();
    });

    it('should render data correctly', () => {
        render(<TableV2 data={sampleData} columns={sampleColumns} />);
        // Check if the data is rendered in the table
        setTimeout(()=>{expect(screen.getByText('John')).toBeInTheDocument();
        expect(screen.getByText('Alice')).toBeInTheDocument();
        expect(screen.getByText('Bob')).toBeInTheDocument();},10);
    });

    it('should handle single row selection', () => {
        const onSelectValueMock = jest.fn();
        render(
            <TableV2
                data={sampleData}
                columns={sampleColumns}
                enableSingleRowSelection={true}
                onSelectValue={onSelectValueMock}
            />
        );

        const radioButtons = screen.getAllByRole('radio');
        expect(radioButtons).toHaveLength(sampleData.length);

        fireEvent.click(radioButtons[1]); // Select Alice

        expect(onSelectValueMock).toHaveBeenCalledWith(sampleData[1]);
    });
    it('should handle multi-row selection', () => {
        const onMultiSelectValueMock = jest.fn();
        render(
            <TableV2
                data={sampleData}
                columns={sampleColumns}
                enableMultiRowSelection={true}
                onMultiSelectValue={onMultiSelectValueMock}
            />
        );
    
        const checkboxes = document.querySelectorAll('.checkbox-wrp input[type="checkbox"]');
        
        setTimeout(()=>{expect(checkboxes.length).toBe(sampleData.length);
    
        checkboxes[0].click();
        checkboxes[2].click();
    
        expect(onMultiSelectValueMock).toHaveBeenCalledWith([sampleData[0], sampleData[2]]);}, 10);
    });

    it('should expand rows when enableExpand is true', () => {
        render(<TableV2 data={sampleData} columns={sampleColumns} enableExpand={true} />);
        const expandButtons = document.querySelectorAll('.expand-btn');

        const buttonToClick = expandButtons[1] as HTMLButtonElement;
        setTimeout(()=>{buttonToClick.click();

        expect(screen.getByText('Alice')).toBeInTheDocument();
        expect(screen.getByText('Age: 25')).toBeInTheDocument();},10);
    });

    it('should paginate data when enablePagination is true', () => {
        render(
            <TableV2
                data={mockData.data}
                columns={mockData.columns}
                enablePagination={true}
                defaultPageSize={10}
                pageSizes={[10, 25, 50, 100]}
            />
        );

        

        const nextPageButton = screen.getByTestId('next-page');
        const prevPageButton = screen.getByTestId('previous-page');
        const lastPageButton = screen.getByTestId('last-page');
        const firstPageButton = screen.getByTestId('first-page');

        setTimeout(()=>{expect(screen.getByText('John')).toBeInTheDocument();
        expect(screen.queryByText('Alice')).toBeNull();},10);
        expect(screen.queryByText('Bob')).toBeNull();

        fireEvent.click(nextPageButton);
        expect(screen.queryByText('John')).toBeNull();
        setTimeout(()=>{expect(screen.getByText('Alice')).toBeInTheDocument();
        expect(screen.getByText('Bob')).toBeInTheDocument();},10);

        fireEvent.click(prevPageButton);
        setTimeout(()=>{expect(screen.getByText('John')).toBeInTheDocument();},10);
        expect(screen.queryByText('Alice')).toBeNull();
        expect(screen.queryByText('Bob')).toBeNull();

        fireEvent.click(lastPageButton);
        setTimeout(()=>{expect(screen.getByText('John')).toBeInTheDocument();},10);
        expect(screen.queryByText('Alice')).toBeNull();
        expect(screen.queryByText('Bob')).toBeNull();

        fireEvent.click(firstPageButton);
        setTimeout(()=>{expect(screen.getByText('John')).toBeInTheDocument();},10);
        expect(screen.queryByText('Alice')).toBeNull();
        expect(screen.queryByText('Bob')).toBeNull();
    });


    it('should handle row expansion when enableCanExpand is true', () => {
        render(<TableV2 data={sampleData} columns={sampleColumns} enableCanExpand={true} />);
        const expandButtons = document.querySelectorAll('.expand-btn');

        const buttonToClick = expandButtons[1] as HTMLButtonElement;
        setTimeout(()=>{buttonToClick.click();

        expect(screen.getByText('Alice')).toBeInTheDocument();
        expect(screen.getByText('Age: 25')).toBeInTheDocument();},10);
    });

    it('should handle single select expand when enableSingleSelectExpand is true', () => {
        render(
            <TableV2
                data={sampleData}
                columns={sampleColumns}
                enableSingleSelectExpand={true}
                enableCanExpand={true}
            />
        );
        const expandButtons = document.querySelectorAll('.expand-btn');

        if (expandButtons.length > 1) {
            fireEvent.click(expandButtons[0]);
            expect(screen.getByText('Alice')).toBeInTheDocument();
            expect(screen.getByText('Age: 25')).toBeInTheDocument();
            const radioButtons = screen.getAllByRole('radio');
            fireEvent.click(radioButtons[0]);
            expect(radioButtons[0]).toBeChecked();
        }
    });
    it('should display "No results found" message when there is no data', () => {
        render(<TableV2 data={[]} columns={sampleColumns} />);
        expect(screen.getByText('No results found')).toBeInTheDocument();
    });

    it('should resize columns when enableColumnResize is true', () => {
        const { container } = render(
            <TableV2 data={sampleData} columns={sampleColumns} enableColumnResize={true} />
        );
        const columnHeader = container.querySelector('.tbl-th');
        const resizer = container.querySelector('.resizer');
        expect(columnHeader).toBeInTheDocument();
        expect(resizer).toBeInTheDocument();
        fireEvent.mouseDown(resizer);
    });
    it('should render custom columns when customCol prop is provided', () => {
        render(
            <TableV2
                data={sampleData}
                columns={sampleColumns}
                customCol={{
                    id: 'custom',
                    Header: 'Custom',
                    accessor: (row) => row.name.toUpperCase(),
                }}
            />
        );
    });
    it('should add "select" column when enableMultiRowSelection and enableExpand are true', () => {
        render(
            <TableV2
                data={mockData.data}
                columns={mockData.columns}
                enableMultiRowSelection={true}
                enableExpand={true}
            />
        );
        const selectColumnHeader = document.querySelector('.tbl-th');

        expect(selectColumnHeader).toBeInTheDocument();
    });
    it('should call onMultiSelectValue when enableMultiRowSelection is true and rowSelection changes', async () => {
        const mockOnMultiSelectValue = jest.fn();
        const { rerender } = render(
            <TableV2
                data={mockData.data}
                columns={mockData.columns}
                enableMultiRowSelection={true}
                onMultiSelectValue={mockOnMultiSelectValue}
            />
        );
        const updatedRowSelection = [
            { id: 1, name: 'John', age: 30 },
            { id: 2, name: 'Alice', age: 25 },
        ];
        rerender(
            <TableV2
                data={mockData.data}
                columns={mockData.columns}
                enableMultiRowSelection={true}
                onMultiSelectValue={mockOnMultiSelectValue}
                rowSelection={updatedRowSelection}
            />
        );
        setTimeout(() => { expect(mockOnMultiSelectValue).toHaveBeenCalledWith(updatedRowSelection); }, 10);
    });

    it('should apply CSS classes based on props', () => {
        const { container } = render(
            <TableV2
                data={[]}
                columns={[]}
                tableClassName="custom-table"
                enableFixedRowHieght={true}
                tableMaxHeight="500px"
                tableMinWidth="300px"
                tableMaxWidth="800px"
                enableStickyColumn={true}
                enableSingleRowSelection={true}
                enablePagination={true}
                enableColumnResize={true}
                enableMultiRowSelection={true}
                enableExpand={true}
                enableCanExpand={true}
                enableSingleSelectExpand={true}
                enableStickyRow={true}
                disableSubRowSelection={true}
                enableHorizontalScrollBar={true}
            />
        );
        const dataTableWrapper = container.querySelector('.dataTable-wrapper');
        expect(dataTableWrapper).toHaveClass('custom-table');
        expect(dataTableWrapper).toHaveClass('fixed-row-height');
        expect(dataTableWrapper).toHaveClass('hasMaxHeight');
        expect(dataTableWrapper).toHaveClass('hasMinWidth');
        expect(dataTableWrapper).toHaveClass('hasMaxWidth');
        setTimeout(() => { expect(dataTableWrapper).toHaveClass('sticky-column'); }, 10);
        expect(dataTableWrapper).toHaveClass('single-row-selection');
        expect(dataTableWrapper).toHaveClass('has-pagination');
        expect(dataTableWrapper).toHaveClass('col-resize');
        expect(dataTableWrapper).toHaveClass('multi-row-selection');
        expect(dataTableWrapper).toHaveClass('row-expand');
        expect(dataTableWrapper).toHaveClass('single-row-expand');
        expect(dataTableWrapper).toHaveClass('disabled-sub-row-selection');
        expect(dataTableWrapper).toHaveClass('enableHorizontalScrollBar');
        expect(dataTableWrapper).toHaveClass('sticky-col');
    });

    it('should render IndeterminateCheckbox for depth 1 rows with appropriate props', () => {
        const row = {
            depth: 1,
            getIsSelected: () => true,
            getIsSomeSelected: () => true,
            getIsAllSubRowsSelected: () => false,
            getToggleSelectedHandler: jest.fn(),
        };

        const { getByLabelText } = render(
            <IndeterminateCheckbox
                checked={row.getIsSelected()}
                indeterminate={row.getIsSomeSelected() || row.getIsAllSubRowsSelected()}
                onChange={row.getToggleSelectedHandler}
            />
        );
        const checkbox = getByLabelText('Checkbox Label');
        expect(checkbox).toBeInTheDocument();
        expect(checkbox).toBeChecked();
        setTimeout(() => { expect(checkbox).toHaveAttribute('aria-checked', 'mixed'); }, 10);
        fireEvent.click(checkbox);
        expect(row.getToggleSelectedHandler).toHaveBeenCalled();
    });

    it('should render IndeterminateCheckbox for depth 1 rows with appropriate props', () => {
        const row = {
            depth: 1,
            getIsSelected: () => true,
            getIsSomeSelected: () => true,
            getIsAllSubRowsSelected: () => false,
            getToggleSelectedHandler: jest.fn(),
        };

        const { getByRole } = render(
            <IndeterminateCheckbox
                checked={row.getIsSelected()}
                indeterminate={row.getIsSomeSelected() || row.getIsAllSubRowsSelected()}
                onChange={row.getToggleSelectedHandler}
            />
        );
        const checkbox = getByRole('checkbox');
        expect(checkbox).toBeInTheDocument();
        expect(checkbox).toBeChecked(); // Make sure it's checked
        setTimeout(() => { expect(checkbox).toHaveAttribute('aria-checked', 'mixed'); }, 10); // Make sure it's indeterminate
        fireEvent.click(checkbox);
        expect(row.getToggleSelectedHandler).toHaveBeenCalled();
    });

    it('should not render IndeterminateCheckbox for depth 1 rows with disableSubRowSelection', () => {
        const row = {
            depth: 1,
        };

        const { queryByRole } = render(
            <IndeterminateCheckbox
                checked={false}
                indeterminate={false}
                onChange={() => { }}
            />
        );
        const checkbox = queryByRole('checkbox');
        setTimeout(() => { expect(checkbox).toBeNull(); }, 10);
    });
    it('should render the <thead> element with appropriate class names and data-testid', () => {
        const hideTableHeader = true;
        const enableFixHeader = true;
    
        render(
            <TableV2
                data={mockData.data}
                columns={mockData.columns}
                hideTableHeader={hideTableHeader}
                enableFixHeader={enableFixHeader}
            />
        );
    
        const theadElement = document.querySelector('[data-testid="thead"]');
        expect(theadElement).toHaveClass('hide-tbl-thead');
        expect(theadElement).toHaveClass('fixed-header');
    });

    it('calls nextPage function when pagination button is clicked', () => {
        const mockTable = {
          nextPage: jest.fn(),
          getCanNextPage: () => true
        };
        
        const props = {
          data: mockData.data,
          columns: mockData.columns,
          table: mockTable, // Provide the mockTable object here
          enablePagination : true,
          pageSizes : [1, 2],
         defaultPageSize : 1,
        };
    
        render(<TableV2 {...props} />);

        const nextPageButton = screen.getByTestId('next-page');
        const prevPageButton = screen.getByTestId('previous-page');
        const lastPageButton = screen.getByTestId('last-page');
        const firstPageButton = screen.getByTestId('first-page');

        fireEvent.click(nextPageButton);
        fireEvent.click(lastPageButton);
        fireEvent.click(prevPageButton);
        fireEvent.click(firstPageButton);

        expect(screen.getAllByText('Global VPN')[0]).toBeInTheDocument();
      });
});
