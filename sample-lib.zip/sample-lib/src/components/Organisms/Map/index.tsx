import React, { useEffect } from 'react';
import { MarkerClusterer } from '@googlemaps/markerclusterer';

import city from '../../Assets/icons/img/city-pin-nopad.png';
import dataCenter from '../../Assets/icons/img/datacenter-pin-nopad.png';
import portCAllSite from '../../Assets/icons/img/port-c-location.png';
import {
    createDivider,
    createFilterControl,
    createFullScreenControl,
    createZoomInControl,
    createZoomOutControl
} from './utils';

import './Map.scss';

export interface MapCordinates {
    lat: number;
    lng: number;
}

export interface IlocationData {
    focus: MapCordinates;
    data: any[];
}

/**
 * The properties required for the Map Component
 */
export interface MapProps {
    /**
     *specifies which type of map need to show in map component. For country and initial need to give "single". For city need to give "single-city",for datacenter need to give "data-center", for facility need to give "facility" as maptype
     */
    mapType?: string;
    /**
     * specify unique div id where map will render.
     */
    mapId?: string;

    /**
     *specifies the zoom level of the map. Zoom can be done from 0 to 18. Expected Values from 0 to 18.
     */
    zoom?: number;

    /** 
    *specifies the coordinates should show on the map.The object consist of  2 key value pairs in the top level, focus and data. focus consist of lattitude and logitude which the map will focus. The second key data is an array of objects and this data is used to add markers and info window to the map. For country selection  only focus will be there and the focus data consist of country latitude(lat) and longitude(lng) and data will be an empty array.                  
    Sample Data: https://jsoneditoronline.org/#left=cloud.2a02331760fe468ea8a7b1444a0b054e 
    For city selection focus data consist of city lat and lng . Then data key consist of city data as 0th array element with data consist of position key which have lat and lng of the city and label that shows in the map and type which is city , which is used to show the custom marker.
    Sample Data : https://jsoneditoronline.org/#left=cloud.cb5ec9ee8d03460bae4c0352f714a910
    For Data center selection focus data consist of city lat and lng . Then data key consist the same elements as in the city slection with 0th element as city . Then the all the facilities whcih that particular data center have with having details like position(lat,lng),label to show in the map, type as "dataCenter",Then name of the facility,then logo of the datacenter,then address
    Sample Data : https://jsoneditoronline.org/#left=cloud.c7daf8b9448d4cde8ec3eea80a28c1a4
    For Facility selection  focus data consist of city lat and lng . Then data key consist the same elements as in the city slection with 0th element as city .Then need to provide the selected facility data with having details like position(lat,lng),label to show in the map, type as "dataCenter",Then name of the facility,then logo of the datacenter,then address
    For secondary facility location selection , after selecting the primary location the secondary location tile will open with country select box disabled . So user need to select the city while selecting the city we need to pass coordinates as like passing normal city. For data center selection also we need to follow same as like  in the primary data center selection. For facility selection we need to follow same as like the facility but need to add the second facility details also in the data array.
    For port c all sites 
    sample data :https://jsoneditoronline.org/#left=cloud.25bfd33b265b4a0a9e5b8eb434c6757c
    For port c selected site
    sample data :https://jsoneditoronline.org/#left=cloud.96b0d74bd6054606ad6d5f0a9196bd68
    */
    coordinate?: any;
    searchPlace?: string;
    handleGeocode?: (geocode: { latitude: number; longitude: number }) => void;
    handleMoreDetails?: (portId: string) => void;
    sourceData?: any[];
    destinationData?: any[];
    friendlySiteName?: string;
    /**
     * This function will be called when user click on the filter button.
     */
    onClickFilter?: (data?: any) => void;
}

/**
 * Renders the Map component
 * @param {React.PropsWithChildren<MapProps>} props MapProps properties
 * @returns
 */
const Map: React.FC<MapProps> = ({
    mapType = 'single',
    mapId = 'mapArea',
    zoom,
    coordinate,
    searchPlace,
    handleGeocode,
    handleMoreDetails,
    sourceData = [],
    destinationData = [],
    friendlySiteName,
    onClickFilter
}) => {
    const defaultControls = {
        mapTypeControl: false,
        streetViewControl: false
    };

    let myStyle = [
        { elementType: 'labels.icon', stylers: [{ visibility: 'off' }] },
        { elementType: 'labels.text.fill', stylers: [{ color: '#2a2a2a' }] },
        { featureType: 'administrative.land_parcel', stylers: [{ visibility: 'off' }] },
        { featureType: 'administrative.neighborhood', stylers: [{ visibility: 'off' }] },
        {
            featureType: 'landscape.man_made',
            elementType: 'geometry.fill',
            stylers: [{ color: '#f0f0f0' }, { visibility: 'on' }]
        },
        {
            featureType: 'landscape.natural',
            elementType: 'geometry.fill',
            stylers: [{ color: '#c4e4bf' }]
        },
        {
            featureType: 'landscape.natural.landcover',
            elementType: 'geometry.fill',
            stylers: [{ color: '#f0f0f0' }, { visibility: 'simplified' }]
        },
        {
            featureType: 'landscape.natural.terrain',
            elementType: 'geometry.fill',
            stylers: [{ color: '#c4e4bf' }, { visibility: 'on' }]
        },
        { featureType: 'poi.business', stylers: [{ visibility: 'off' }] },
        {
            featureType: 'poi.business',
            elementType: 'labels.icon',
            stylers: [{ visibility: 'on' }]
        },
        {
            featureType: 'poi.government',
            elementType: 'labels.icon',
            stylers: [{ visibility: 'on' }]
        },
        { featureType: 'poi.medical', stylers: [{ visibility: 'on' }] },
        { featureType: 'poi.park', elementType: 'labels.text', stylers: [{ visibility: 'off' }] },
        { featureType: 'road', elementType: 'labels', stylers: [{ visibility: 'off' }] },
        { featureType: 'road.arterial', stylers: [{ visibility: 'off' }] },
        {
            featureType: 'road.highway',
            elementType: 'geometry.fill',
            stylers: [{ color: '#c8c8c8' }]
        },
        {
            featureType: 'road.highway',
            elementType: 'geometry.stroke',
            stylers: [{ color: '#aaaaaa' }]
        },
        { featureType: 'road.highway', elementType: 'labels', stylers: [{ visibility: 'off' }] },
        { featureType: 'road.local', stylers: [{ visibility: 'off' }] },
        { featureType: 'water', elementType: 'geometry.fill', stylers: [{ color: '#9bbcf9' }] },
        { featureType: 'water', elementType: 'labels.text', stylers: [{ visibility: 'off' }] }
    ];

    async function initMap(): Promise<void> {
        let map: google.maps.Map;
        let InforObj: any[] = [];
        const { Map } = (await google.maps.importLibrary('maps')) as google.maps.MapsLibrary;

        map = new Map(document.getElementById(mapId) as HTMLElement, {
            mapTypeControlOptions: {
                mapTypeIds: [
                    'myStyle',
                    google.maps.MapTypeId.ROADMAP,
                    google.maps.MapTypeId.TERRAIN
                ]
            },
            mapTypeId: 'myStyle',
            center: coordinate?.focus,
            zoom: zoom,
            minZoom: 2,
            disableDefaultUI: true,
            ...defaultControls
        });

        /**
         * A customized popup on the map.
         */
        class Popup extends google.maps.OverlayView {
            position: google.maps.LatLng;
            containerDiv: HTMLDivElement;
            innerDiv: HTMLDivElement;

            constructor(position: google.maps.LatLng) {
                super();
                this.position = position;

                this.innerDiv = document.createElement('div');
                this.innerDiv.classList.add('popup-bubble');

                // This zero-height div is positioned at the bottom of the bubble.
                const bubbleAnchor = document.createElement('div');
                bubbleAnchor.classList.add('popup-bubble-anchor');
                bubbleAnchor.appendChild(this.innerDiv);

                // This zero-height div is positioned at the bottom of the tip.
                this.containerDiv = document.createElement('div');
                this.containerDiv.classList.add('popup-container');
                this.containerDiv.appendChild(bubbleAnchor);

                // Optionally stop clicks, etc., from bubbling up to the map.
                Popup.preventMapHitsAndGesturesFrom(this.containerDiv);
            }

            onAdd() {
                this.getPanes()!.floatPane.appendChild(this.containerDiv);
            }

            onRemove() {
                if (this.containerDiv.parentElement) {
                    this.containerDiv.parentElement.removeChild(this.containerDiv);
                }
            }

            draw(position = this.position, tooltipContent = '', portGroup = false) {
                this.innerDiv.innerHTML = tooltipContent;

                if (tooltipContent !== '') {
                    this.containerDiv.classList.add('show_arrow');
                }

                if (portGroup) {
                    this.containerDiv.classList.add('port_group');
                } else {
                    this.containerDiv.classList.remove('port_group');
                }

                const divPosition = this.getProjection().fromLatLngToDivPixel(position)!;

                // Hide the popup when it is far out of view.
                const display =
                    Math.abs(divPosition?.x ?? 0) < 4000 && Math.abs(divPosition?.y ?? 0) < 4000
                        ? 'block'
                        : 'none';

                if (display === 'block') {
                    this.containerDiv.style.left = (divPosition?.x ?? 0) + 'px';
                    this.containerDiv.style.top = (divPosition?.y ?? 0) + 'px';
                }

                if (this.containerDiv.style.display !== display) {
                    this.containerDiv.style.display = display;
                }
            }

            hide() {
                if (this.containerDiv && this.containerDiv.style.visibility === 'visible') {
                    this.containerDiv.style.visibility = 'hidden';
                }
            }

            show(position: google.maps.LatLng, tooltipContent: string, portGroup) {
                this.draw(position, tooltipContent, portGroup);
                if (this.containerDiv) {
                    this.containerDiv.style.visibility = 'visible';
                }
            }
        }

        let hoverPopup = new Popup(coordinate?.focus);
        hoverPopup.setMap(map);
        hoverPopup.onRemove();
        hoverPopup.hide();

        if (mapType === 'single') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );
        } else if (mapType === 'single-city') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );

            const mapData = new google.maps.Marker({
                position: coordinate?.focus,
                map,
                icon: {
                    url: city,
                    labelOrigin: new google.maps.Point(10, 25)
                },
                label: coordinate?.data[0]?.label
            });
        } else if (mapType === 'data-center') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );

            // Create markers.
            for (let i = 0; i < coordinate?.['data']?.length ?? 0; i++) {
                const mapData = new google.maps.Marker({
                    position: coordinate?.['data'][i].position,
                    icon: {
                        url: coordinate?.['data'][i].type === 'city' ? city : dataCenter,
                        labelOrigin:
                            coordinate?.['data'][i].type === 'city'
                                ? new google.maps.Point(10, 25)
                                : new google.maps.Point(10, 35)
                    },
                    label: coordinate?.['data'][i].label,
                    map: map
                });
            }
        } else if (mapType === 'facility') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );

            // Create markers.
            for (let i = 0; i < coordinate?.['data']?.length ?? 0; i++) {
                if (i != 0) {
                    const contentString =
                        '<div id="contentMap"><div class="logo_container"><div class="img-wrp"><img src=' +
                        coordinate?.['data'][i].logo +
                        ' width="18" height="18" alt="Logo" /></div></div><div class="content-wrp"><span>' +
                        coordinate?.['data'][i].name +
                        '</span><p>' +
                        coordinate?.['data'][i].value +
                        '</p></div></div>';

                    const marker = new google.maps.Marker({
                        position: coordinate?.['data'][i].position,
                        icon: {
                            url: dataCenter,
                            labelOrigin: new google.maps.Point(10, 35)
                        },
                        label: coordinate?.['data'][i].label,
                        map: map
                    });
                    const infoWindow = new google.maps.InfoWindow({
                        content: contentString,
                        maxWidth: 280
                    });

                    infoWindow.open(marker.get('map'), marker);
                    InforObj[0] = infoWindow;

                    marker.addListener('mouseover', function () {
                        infoWindow.open(marker.get('map'), marker);
                        InforObj[0] = infoWindow;
                    });
                }
            }
        } else if (mapType === 'port-c-all-sites') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );

            // Create markers.
            for (let i = 0; i < coordinate?.['data']?.length ?? 0; i++) {
                const mapData = new google.maps.Marker({
                    position: coordinate?.['data'][i].position,
                    icon: {
                        url: portCAllSite
                    },
                    map: map
                });
            }
        } else if (mapType === 'port-c-selected-site') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );

            const contentString =
                '<div id="contentMap"><div class="content-wrp"><span>' +
                coordinate?.name +
                '</span><p>' +
                coordinate?.address +
                '</p></div></div>';

            const mapData = new google.maps.Marker({
                position: coordinate?.focus,
                map,
                icon: {
                    url: portCAllSite
                }
            });

            const infoWindow = new google.maps.InfoWindow({
                content: contentString,
                maxWidth: 280
            });

            InforObj[0] = infoWindow;

            mapData.addListener('mouseover', function () {
                infoWindow.open(mapData.get('map'), mapData);
                InforObj[0] = infoWindow;
            });
        } else if (mapType === 'search-place') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );
            if (!searchPlace) {
                map.setCenter({ lat: 0, lng: 0 });
            } else {
                const request = {
                    query: searchPlace,
                    fields: ['formatted_address', 'name', 'geometry']
                };

                const markerDefault = [
                    '<svg width="25.6" height="32" viewBox="0 0 26 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                    '<path d="M25.0999 12.8C25.0999 16.1761 23.5733 19.2691 21.2038 22.3459C19.2106 24.934 16.6594 27.464 13.989 30.1123C13.5947 30.5033 13.1979 30.8968 12.7999 31.2935C12.4019 30.8968 12.0051 30.5033 11.6109 30.1123C8.94037 27.464 6.38923 24.934 4.39605 22.3459C2.02649 19.2691 0.499908 16.1761 0.499908 12.8C0.499908 6.0069 6.0068 0.5 12.7999 0.5C19.593 0.5 25.0999 6.0069 25.0999 12.8Z" fill="#5514B4" stroke="white" stroke-linecap="round" stroke-linejoin="round" />',
                    '<path d="M12.9998 18C15.7612 18 17.9998 15.7614 17.9998 13C17.9998 10.2386 15.7612 8 12.9998 8C10.2384 8 7.99979 10.2386 7.99979 13C7.99979 15.7614 10.2384 18 12.9998 18Z" fill="white" />',
                    '</svg>'
                ].join('\n');

                const service = await new google.maps.places.PlacesService(map);
                service.findPlaceFromQuery(
                    request,
                    (
                        results: google.maps.places.PlaceResult[] | null,
                        status: google.maps.places.PlacesServiceStatus
                    ) => {
                        if (
                            status === google.maps.places.PlacesServiceStatus.OK &&
                            results &&
                            results.length
                        ) {
                            handleGeocode?.({
                                latitude: results[0].geometry.location.lat() || 0,
                                longitude: results[0].geometry.location.lng() || 0
                            });

                            for (let i = 0; i < results.length; i++) {
                                const contentString =
                                    '<div id="contentMap"><div class="content-wrp"><span>' +
                                    friendlySiteName +
                                    '</span>' +
                                    `<p>${searchPlace}</p>` +
                                    '</div></div>';

                                const marker = new google.maps.Marker({
                                    position: results[i].geometry.location,
                                    icon: {
                                        url:
                                            'data:image/svg+xml;charset=UTF-8,' +
                                            encodeURIComponent(markerDefault),
                                        labelOrigin: new google.maps.Point(10, 35)
                                    },
                                    label: results[i].label,
                                    map: map
                                });
                                const infoWindow = new google.maps.InfoWindow({
                                    content: contentString,
                                    maxWidth: 280
                                });
                                InforObj[0] = infoWindow;

                                marker.addListener('mouseover', function () {
                                    marker.setIcon(
                                        'data:image/svg+xml;charset=UTF-8,' +
                                            encodeURIComponent(markerDefault)
                                    );
                                    infoWindow.open(marker.get('map'), marker);
                                    InforObj[0] = infoWindow;
                                });
                            }
                            map.setCenter(results[0].geometry!.location!);
                        } else {
                            handleGeocode?.({ latitude: 0, longitude: 0 });
                            map.setCenter({ lat: 0, lng: 0 });
                        }
                    }
                );
            }
        } else if (mapType === 'cloud-port') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );
            if (coordinate && coordinate.showInfoWindow === true) {
                const contentString =
                    '<div id="contentMap"><div class="content-wrp"><span>' +
                    coordinate?.['data'][0].name +
                    '</span><p>' +
                    coordinate?.['data'][0].value +
                    '</p></div></div>';

                const marker = new google.maps.Marker({
                    position: coordinate?.['data'][0].position,
                    icon: {
                        url: dataCenter,
                        labelOrigin: new google.maps.Point(10, 35)
                    },
                    label: coordinate?.['data'][0].label,
                    map: map
                });
                const infoWindow = new google.maps.InfoWindow({
                    content: contentString,
                    maxWidth: 280
                });

                infoWindow.open(marker.get('map'), marker);
                InforObj[0] = infoWindow;

                marker.addListener('mouseover', function () {
                    infoWindow.open(marker.get('map'), marker);
                    InforObj[0] = infoWindow;
                });

                map.setCenter(coordinate?.focus);
                map.setZoom(map.getZoom() - 1);
            } else if (coordinate && !coordinate.showInfoWindow && coordinate.data.length > 0) {
                let mIcon = {
                    path: google.maps.SymbolPath.CIRCLE,
                    fillOpacity: 1,
                    fillColor: '#5514B4',
                    strokeOpacity: 1,
                    strokeWeight: 2,
                    strokeColor: '#fff',
                    scale: 16
                };
                for (let i = 0; i < coordinate?.data.length; i++) {
                    const mapData = new google.maps.Marker({
                        position: coordinate?.data[i]?.position,
                        map,
                        icon: {
                            url: mIcon,
                            labelOrigin: new google.maps.Point(10, 25)
                        },
                        label: {
                            color: '#fff',
                            fontSize: '12px',
                            fontWeight: '700',
                            text: coordinate?.data[i]?.label
                        }
                    });
                }
            }
        } else if (mapType === 'network') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );

            const svgTemplate = [
                '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<circle cx="12" cy="12" r="12" fill="white" fill-opacity="0.12"/>',
                '<circle cx="12" cy="12" r="7" fill="{{ fill }}" stroke="{{ stroke }}" stroke-width="2"/>',
                '</svg>'
            ].join('\n');

            const svgGroupTemplate = [
                '<svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<circle cx="22" cy="22" r="22" fill="white" fill-opacity="0.12"/>',
                '<circle cx="22" cy="22" r="15" fill="{{ fill }}" stroke="{{ stroke }}" stroke-width="2"/>',
                '</svg>'
            ].join('\n');

            const warning = svgTemplate
                .replace('{{ fill }}', '#FED55A')
                .replace('{{ stroke }}', '#FEF6DE');
            const critical = svgTemplate
                .replace('{{ fill }}', '#F63A38')
                .replace('{{ stroke }}', '#FFE9EC');
            const healthy = svgTemplate
                .replace('{{ fill }}', '#56B54B')
                .replace('{{ stroke }}', '#E6F4E5');
            const warningGroup = svgGroupTemplate
                .replace('{{ fill }}', '#FEF6DE')
                .replace('{{ stroke }}', '#FED55A');
            const criticalGroup = svgGroupTemplate
                .replace('{{ fill }}', '#FFE9EC')
                .replace('{{ stroke }}', '#F63A38');
            const healthyGroup = svgGroupTemplate
                .replace('{{ fill }}', '#E6F4E5')
                .replace('{{ stroke }}', '#56B54B');

            const getPortLabel = (port: any) => {
                if (port.label !== '') {
                    return {
                        text: `${port.label ?? 0}`,
                        color: '#2a2a2a',
                        fontSize: '12px',
                        fontFamily: 'BT Curve Bold',
                        fontWeight: '700'
                    };
                } else {
                    return '';
                }
            };

            const getIconUrl = (port: any) => {
                if (port.number > 1) {
                    return port.status === 'up'
                        ? healthyGroup
                        : port.status === 'down'
                        ? criticalGroup
                        : warningGroup;
                } else {
                    return port.status === 'up'
                        ? healthy
                        : port.status === 'down'
                        ? critical
                        : warning;
                }
            };

            const getIconsize = (port: any) => (port.number > 1 ? 44 : 24);

            const markers = coordinate?.data.map((port) => {
                const upPortHoverString =
                    '<div class="details_container">' +
                    port.number +
                    ` Port${port.number > 1 ? 's' : ''}` +
                    '</div>';

                const needAttentionPortHoverString =
                    '<div class="details_container need_attention">' +
                    '<svg fill="none" height="12" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1" viewBox="0 0 12 12" width="12" xmlns="http://www.w3.org/2000/svg"><circle cx="6" cy="6" r="5"/><line x1="6" x2="6" y1="4" y2="6"/><line x1="6" x2="6.005" y1="8" y2="8"/></svg></span>' +
                    `${
                        port.number === 1
                            ? 'Port needs '
                            : `${port.needAttention}/${port.number} ports need `
                    }` +
                    'attention!</span></div>';

                const multiplePortClickString =
                    '<div class="details_container"><div class="details_content click_string"><div class="main_content"><div class="port_info_container"><div class="logo_container"><div class="logo_wrapper"><img src=' +
                    port.logo +
                    ' width="24" height="24" alt="Logo" /></div></div><div class="port_info"><label class="provider_name">' +
                    port.provider +
                    '</label><label class="port_name">' +
                    port.name +
                    '</label><label class="provider_name">' +
                    port.serviceId +
                    '</label></div></div></div><hr class="divider" /><div class="p_status_info"><div class="p_status"><div class="p_status_bar p_status_up"></div><div class="p_status_content"><label class="p_status_name">Port up</label><label class="p_status_value">' +
                    port.portStatus.up +
                    '</label></div></div><div class="p_status"><div class="p_status_bar p_status_critical"></div><div class="p_status_content"><label class="p_status_name">Critical</label><label class="p_status_value">' +
                    port.portStatus.critical +
                    '</label></div></div><div class="p_status"><div class="p_status_bar p_status_warning"></div><div class="p_status_content"><label class="p_status_name">Warning</label><label class="p_status_value">' +
                    port.portStatus.warning +
                    '</label></div></div></div><div class="cta" id="view_all_ports"><span>View all ports</span>' +
                    '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="arrow-right">' +
                    '<path id="Icon" d="M4.1665 10.0001H15.8332M15.8332 10.0001L9.99984 4.16675M15.8332 10.0001L9.99984 15.8334" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>' +
                    '</g></svg></div></div></div>';

                const singlePortClickString =
                    '<div class="details_container"><div class="details_content click_string"><div class="main_content">' +
                    '<div class="port_info_container"><div class="logo_container"><div class="logo_wrapper"><img src=' +
                    port.logo +
                    ' width="18" height="18" alt="Logo" /></div></div><div class="port_info"><label class="provider_name">' +
                    port.provider +
                    '</label><label class="port_name">' +
                    port.name +
                    '</label><label class="provider_name">' +
                    port.serviceId +
                    '</label></div></div><span class="port_status ' +
                    port.status +
                    '">' +
                    `${
                        port.status === 'up'
                            ? 'Port up'
                            : port.status === 'down'
                            ? 'Port down'
                            : 'Warning'
                    }` +
                    '</span></div><div class="cta" id="more_details"><span>More details</span>' +
                    '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="arrow-right">' +
                    '<path id="Icon" d="M4.1665 10.0001H15.8332M15.8332 10.0001L9.99984 4.16675M15.8332 10.0001L9.99984 15.8334" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>' +
                    '</g></svg></div></div></div>';

                const tooltipHoverContent =
                    port.status === 'up' ? upPortHoverString : needAttentionPortHoverString;

                const marker = new google.maps.Marker({
                    position: port.position,
                    icon: {
                        url:
                            'data:image/svg+xml;charset=UTF-8,' +
                            encodeURIComponent(getIconUrl(port)),
                        scaledSize: new google.maps.Size(getIconsize(port), getIconsize(port))
                    },
                    optimized: false,
                    label: getPortLabel(port),
                    status: port.status,
                    map: map
                });

                const infoWindowClick = new google.maps.InfoWindow({
                    content: port.number === 1 ? singlePortClickString : multiplePortClickString,
                    maxWidth: 400
                });

                const onClickMoreDetails = () => {
                    handleMoreDetails(port.portId);
                };

                google.maps.event.addListener(infoWindowClick, 'domready', function () {
                    if (document.getElementById('more_details')) {
                        document.getElementById('more_details').onclick = onClickMoreDetails;
                    }
                    if (document.getElementById('view_all_ports')) {
                        document.getElementById('view_all_ports').onclick = onClickMoreDetails;
                    }
                });

                marker.addListener('mouseover', function () {
                    hoverPopup.show(
                        { lat: port.position.lat, lng: port.position.lng },
                        tooltipHoverContent,
                        port.number > 1
                    );
                });

                marker.addListener('mouseout', function () {
                    setTimeout(() => {
                        hoverPopup.hide();
                    }, 10000);

                    setTimeout(() => {
                        infoWindowClick.close();
                    }, 2000);
                });

                marker.addListener('click', function () {
                    infoWindowClick.open(marker.get('map'), marker);
                    InforObj[0] = infoWindowClick;
                });

                return marker;
            });

            const getPortsNumber = (markers) => {
                const num = markers
                    .map(({ label }) => (label !== '' ? parseInt(label.text) : 0))
                    .reduce((sum, num) => sum + num, 0);
                return num - markers.map(({ label }) => label).filter((v) => v !== '').length;
            };

            const getDisplayIcon = (markers) => {
                const markerStatus = markers.map(({ status }) => status);

                return markerStatus.includes('down')
                    ? criticalGroup
                    : markerStatus.includes('warning')
                    ? warningGroup
                    : healthyGroup;
            };

            const clusterString =
                '<div class="details_container">' + '2/5' + ' ports need attention' + '</div>';

            const infowindow = new google.maps.InfoWindow({
                content: clusterString,
                maxWidth: 400
            });

            const renderer = {
                render: ({ count, position, markers }) =>
                    new google.maps.Marker({
                        icon: {
                            url:
                                'data:image/svg+xml;charset=UTF-8,' +
                                encodeURIComponent(getDisplayIcon(markers)),
                            scaledSize: new google.maps.Size(44, 44)
                        },
                        label: {
                            text: `${count + getPortsNumber(markers)}`,
                            color: '#2a2a2a',
                            fontSize: '12px',
                            fontFamily: 'BT Curve Bold',
                            fontWeight: '700'
                        },
                        position,
                        zIndex: Number(google.maps.Marker.MAX_ZINDEX) + count
                    })
            };

            const markerCluster = new MarkerClusterer({ markers, map, renderer });

            google.maps.event.addListener(markerCluster, 'onmouseover', function (mCluster) {
                infowindow.content += '<div>Something</div>';
                infowindow.setPosition(mCluster.getCenter());
                infowindow.open(map);
                InforObj[0] = infowindow;
            });

            google.maps.event.addListener(markerCluster, 'onmouseout', function (c) {
                infowindow.close();
            });
        } else if (mapType === 'porBDetail') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );
            // Create markers.
            const markerDefault = [
                '<svg width="25.6" height="32" viewBox="0 0 26 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<path d="M25.0999 12.8C25.0999 16.1761 23.5733 19.2691 21.2038 22.3459C19.2106 24.934 16.6594 27.464 13.989 30.1123C13.5947 30.5033 13.1979 30.8968 12.7999 31.2935C12.4019 30.8968 12.0051 30.5033 11.6109 30.1123C8.94037 27.464 6.38923 24.934 4.39605 22.3459C2.02649 19.2691 0.499908 16.1761 0.499908 12.8C0.499908 6.0069 6.0068 0.5 12.7999 0.5C19.593 0.5 25.0999 6.0069 25.0999 12.8Z" fill="#5514B4" stroke="white" stroke-linecap="round" stroke-linejoin="round" />',
                '<path d="M12.9998 18C15.7612 18 17.9998 15.7614 17.9998 13C17.9998 10.2386 15.7612 8 12.9998 8C10.2384 8 7.99979 10.2386 7.99979 13C7.99979 15.7614 10.2384 18 12.9998 18Z" fill="white" />',
                '</svg>'
            ].join('\n');
            const markerHover = [
                '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<g clip-path="url(#clip0_13197_138686)">',
                '<path d="M28.0999 12.8C28.0999 16.1761 26.5733 19.2691 24.2038 22.3459C22.2106 24.934 19.6594 27.464 16.989 30.1123C16.5947 30.5033 16.1979 30.8968 15.7999 31.2935C15.4019 30.8968 15.0051 30.5033 14.6108 30.1123C11.9404 27.464 9.38922 24.934 7.39604 22.3459C5.02649 19.2691 3.4999 16.1761 3.4999 12.8C3.4999 6.0069 9.0068 0.5 15.7999 0.5C22.593 0.5 28.0999 6.0069 28.0999 12.8Z" fill="#996CD5" stroke="white" stroke-linecap="round" stroke-linejoin="round" />',
                '<path d="M15.9998 18C18.7612 18 20.9998 15.7614 20.9998 13C20.9998 10.2386 18.7612 8 15.9998 8C13.2384 8 10.9998 10.2386 10.9998 13C10.9998 15.7614 13.2384 18 15.9998 18Z" fill="white" />',
                '</g>',
                '<defs>',
                '<clipPath id="clip0_13197_138686">',
                '<rect width="32" height="32" fill="white" />',
                '</clipPath>',
                '</defs>',
                '</svg>'
            ].join('\n');

            for (let i = 0; i < coordinate?.['data']?.length ?? 0; i++) {
                const contentString =
                    '<div id="contentMap"><div class="content-wrp"><span>' +
                    coordinate?.['data'][i]?.facilityName +
                    '</span><p>' +
                    coordinate?.['data'][i]?.facilityAddress?.siteAddressLine1 +
                    ', ' +
                    coordinate?.['data'][i]?.facilityAddress?.siteAddressLine2 +
                    '</p><p>' +
                    coordinate?.['data'][i]?.facilityAddress?.city +
                    ', ' +
                    '</p><p>' +
                    coordinate?.['data'][i]?.facilityAddress?.countyOrState +
                    '</p><p>' +
                    coordinate?.['data'][i]?.facilityAddress?.country +
                    ', ' +
                    coordinate?.['data'][i]?.facilityAddress?.postcode;
                '</p><p>' + '</p></div></div>';

                const marker = new google.maps.Marker({
                    position: coordinate?.['data'][i].position,
                    icon: {
                        url:
                            'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(markerDefault),
                        labelOrigin: new google.maps.Point(10, 35)
                    },
                    label: coordinate?.['data'][i].label,
                    map: map
                });
                const infoWindow = new google.maps.InfoWindow({
                    content: contentString,
                    maxWidth: 280
                });
                InforObj[0] = infoWindow;

                marker.addListener('mouseover', function () {
                    marker.setIcon(
                        'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(markerHover)
                    );
                    infoWindow.open(marker.get('map'), marker);
                    InforObj[0] = infoWindow;
                });
                marker.addListener('mouseout', function () {
                    marker.setIcon(
                        'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(markerDefault)
                    );
                    infoWindow.close(marker.get('map'), marker);
                });
            }
        } else if (mapType === 'connectingSites') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );

            // Create markers.
            const markerSourceDefault = [
                '<svg width="25.6" height="32" viewBox="0 0 26 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<path d="M25.0999 12.8C25.0999 16.1761 23.5733 19.2691 21.2038 22.3459C19.2106 24.934 16.6594 27.464 13.989 30.1123C13.5947 30.5033 13.1979 30.8968 12.7999 31.2935C12.4019 30.8968 12.0051 30.5033 11.6109 30.1123C8.94037 27.464 6.38923 24.934 4.39605 22.3459C2.02649 19.2691 0.499908 16.1761 0.499908 12.8C0.499908 6.0069 6.0068 0.5 12.7999 0.5C19.593 0.5 25.0999 6.0069 25.0999 12.8Z" fill="#5514B4" stroke="white" stroke-linecap="round" stroke-linejoin="round" />',
                '<path d="M12.9998 18C15.7612 18 17.9998 15.7614 17.9998 13C17.9998 10.2386 15.7612 8 12.9998 8C10.2384 8 7.99979 10.2386 7.99979 13C7.99979 15.7614 10.2384 18 12.9998 18Z" fill="white" />',
                '</svg>'
            ].join('\n');
            const markerSourceHover = [
                '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<g clip-path="url(#clip0_13197_138686)">',
                '<path d="M28.0999 12.8C28.0999 16.1761 26.5733 19.2691 24.2038 22.3459C22.2106 24.934 19.6594 27.464 16.989 30.1123C16.5947 30.5033 16.1979 30.8968 15.7999 31.2935C15.4019 30.8968 15.0051 30.5033 14.6108 30.1123C11.9404 27.464 9.38922 24.934 7.39604 22.3459C5.02649 19.2691 3.4999 16.1761 3.4999 12.8C3.4999 6.0069 9.0068 0.5 15.7999 0.5C22.593 0.5 28.0999 6.0069 28.0999 12.8Z" fill="#996CD5" stroke="white" stroke-linecap="round" stroke-linejoin="round" />',
                '<path d="M15.9998 18C18.7612 18 20.9998 15.7614 20.9998 13C20.9998 10.2386 18.7612 8 15.9998 8C13.2384 8 10.9998 10.2386 10.9998 13C10.9998 15.7614 13.2384 18 15.9998 18Z" fill="white" />',
                '</g>',
                '<defs>',
                '<clipPath id="clip0_13197_138686">',
                '<rect width="32" height="32" fill="white" />',
                '</clipPath>',
                '</defs>',
                '</svg>'
            ].join('\n');
            const markerSourceSecondary = [
                '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<g clip-path="url(#clip0_13197_138389)">',
                '<path d="M28.0999 12.8C28.0999 16.1761 26.5733 19.2691 24.2038 22.3459C22.2106 24.934 19.6594 27.464 16.989 30.1123C16.5947 30.5033 16.1979 30.8968 15.7999 31.2935C15.4019 30.8968 15.0051 30.5033 14.6109 30.1123C11.9404 27.464 9.38923 24.934 7.39605 22.3459C5.02649 19.2691 3.49991 16.1761 3.49991 12.8C3.49991 6.0069 9.0068 0.5 15.7999 0.5C22.593 0.5 28.0999 6.0069 28.0999 12.8Z" fill="#712DC2" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>',
                '<path d="M15.9998 18C18.7612 18 20.9998 15.7614 20.9998 13C20.9998 10.2386 18.7612 8 15.9998 8C13.2384 8 10.9998 10.2386 10.9998 13C10.9998 15.7614 13.2384 18 15.9998 18Z" fill="white"/>',
                '</g>',
                '<defs>',
                '<clipPath id="clip0_13197_138389">',
                '<rect width="32" height="32" fill="white"/>',
                '</clipPath>',
                '</defs>',
                '</svg>'
            ].join('\n');

            const markerDestinationDefault = [
                '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<circle cx="16" cy="16" r="16" fill="#5514B4"/>',
                '<circle cx="16" cy="15.9997" r="12.6667" fill="white"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M18.2186 11.2002L15.9092 7.2002L13.5998 11.2002L14.8425 11.2002V13.8669H16.9758V11.2002L18.2186 11.2002Z" fill="#5514B4"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M18.2186 11.2002L15.9092 7.2002L13.5998 11.2002L14.8425 11.2002V13.8669H16.9758V11.2002L18.2186 11.2002Z" fill="#5514B4"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M13.5999 20.7998L15.9093 24.7998L18.2187 20.7998L16.9761 20.7998L16.9761 18.1331L14.8427 18.1331L14.8427 20.7998L13.5999 20.7998Z" fill="#5514B4"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M22.1334 13.5999L18.1334 15.9093L22.1334 18.2187L22.1334 13.5999ZM24.8001 14.8427L22.1334 14.8427L22.1334 16.976L24.8001 16.976L24.8001 14.8427Z" fill="#5514B4"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M9.86658 18.2189L13.8666 15.9095L9.86658 13.6001L9.86658 14.8428L7.19991 14.8428L7.19991 16.9762L9.86658 16.9762L9.86658 18.2189Z" fill="#5514B4"/>',
                '</svg>'
            ].join('\n');
            const markerDestinationHover = [
                '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<circle cx="16" cy="16" r="16" fill="#996CD5"/>',
                '<circle cx="16" cy="15.9997" r="12.6667" fill="white"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M18.2187 11.2002L15.9093 7.2002L13.5998 11.2002H14.8425V13.8669H16.9758V11.2002H18.2187Z" fill="#996CD5"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M13.5999 20.7998L15.9093 24.7998L18.2187 20.7998L16.9761 20.7998L16.9761 18.1331L14.8427 18.1331L14.8427 20.7998L13.5999 20.7998Z" fill="#996CD5"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M22.1334 13.5999L18.1334 15.9093L22.1334 18.2187L22.1334 16.976L24.8001 16.976L24.8001 14.8427L22.1334 14.8427L22.1334 13.5999Z" fill="#996CD5"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M9.86658 18.2189L13.8666 15.9095L9.86658 13.6001L9.86658 14.8428L7.19991 14.8428L7.19991 16.9762L9.86658 16.9762L9.86658 18.2189Z" fill="#996CD5"/>',
                '</svg>'
            ].join('\n');
            const markerDestinationSecondary = [
                '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<circle cx="16" cy="16" r="16" fill="#712DC2"/>',
                '<circle cx="16" cy="15.9997" r="12.6667" fill="white"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M18.2187 11.2002L15.9093 7.2002L13.5999 11.2002H14.8425V13.8669H16.9758V11.2002H18.2187Z" fill="#712DC2"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M13.5999 20.7998L15.9093 24.7998L18.2188 20.7998L16.9761 20.7998L16.9761 18.1331L14.8428 18.1331L14.8428 20.7998L13.5999 20.7998Z" fill="#712DC2"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M22.1335 13.5999L18.1335 15.9093L22.1335 18.2187L22.1335 13.5999ZM24.8001 14.8427L22.1335 14.8427L22.1335 16.976L24.8001 16.976L24.8001 14.8427Z" fill="#712DC2"/>',
                '<path fill-rule="evenodd" clip-rule="evenodd" d="M9.86658 18.2189L13.8666 15.9095L9.86658 13.6001L9.86658 14.8428L7.19991 14.8428L7.19991 16.9762L9.86658 16.9762L9.86658 18.2189Z" fill="#712DC2"/>',
                '</svg>'
            ].join('\n');

            const renderLocation = (
                site: any[],
                defaultMarker: any,
                hoverMarker: any,
                isSource: boolean
            ) => {
                for (let i = 0; i < site.length; i++) {
                    let contentString =
                        '<div id="contentMap"><div class="content-wrp"><span>' +
                        site[i].facilityName +
                        '</span>';

                    if (site[i].badgeText) {
                        contentString +=
                            '<div class="badge-container"><span>' +
                            site[i].badgeText +
                            '</span></div>';
                    }
                    contentString +=
                        '<p>' +
                        site[i].facilityAddress?.siteAddressLine1 +
                        ', ' +
                        site[i].facilityAddress?.siteAddressLine2 +
                        '</p><p>' +
                        site[i].facilityAddress?.city +
                        ', ' +
                        '</p><p>' +
                        site[i].facilityAddress?.countyOrState +
                        '</p><p>' +
                        site[i].facilityAddress?.country +
                        ', ' +
                        site[i].facilityAddress?.postcode +
                        '</p><p>' +
                        '</p></div></div>';

                    const secondary = isSource ? markerSourceSecondary : markerDestinationSecondary;

                    const markerIcon = i === 0 ? defaultMarker : secondary;

                    const marker = new google.maps.Marker({
                        position: new google.maps.LatLng(site[i].position),
                        icon: {
                            url:
                                'data:image/svg+xml;charset=UTF-8,' +
                                encodeURIComponent(markerIcon),
                            labelOrigin: new google.maps.Point(10, 35)
                        },
                        label: site[i].label,
                        map: map
                    });

                    const infoWindow = new google.maps.InfoWindow({
                        content: contentString,
                        maxWidth: 280
                    });
                    InforObj[0] = infoWindow;

                    marker.addListener('mouseover', function () {
                        marker.setIcon(
                            'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(hoverMarker)
                        );
                        infoWindow.open(marker.get('map'), marker);
                        InforObj[0] = infoWindow;
                    });
                    marker.addListener('mouseout', function () {
                        marker.setIcon(
                            'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(markerIcon)
                        );
                        infoWindow.close(marker.get('map'), marker);
                    });
                }
            };

            renderLocation(sourceData, markerSourceDefault, markerSourceHover, true);
            renderLocation(
                destinationData,
                markerDestinationDefault,
                markerDestinationHover,
                false
            );

            const lineSymbol = {
                path: 'M 0,-1 0,1',
                strokeOpacity: 1,
                scale: 3,
                border: '2px'
            };

            const drawLine = (marker1: any, marker2: any) => {
                const line = new window.google.maps.Polyline({
                    path: [marker1, marker2],
                    map: map,
                    strokeOpacity: 0,
                    strokeWeight: '40px',
                    strokeColor: '#AAAAAA',
                    icons: [
                        {
                            icon: lineSymbol,
                            offset: '0',
                            repeat: '20px'
                        }
                    ]
                });
                return line;
            };

            for (const elementSource of sourceData) {
                for (const elementDestination of destinationData) {
                    drawLine(elementSource.position, elementDestination.position);
                }
            }
        } else if (mapType === 'port-c-my-sites') {
            map.mapTypes.set(
                'myStyle',
                new google.maps.StyledMapType(myStyle, { name: 'My Style' })
            );
            // Create markers.
            const markerDefault = [
                '<svg width="25.6" height="32" viewBox="0 0 26 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<path d="M25.0999 12.8C25.0999 16.1761 23.5733 19.2691 21.2038 22.3459C19.2106 24.934 16.6594 27.464 13.989 30.1123C13.5947 30.5033 13.1979 30.8968 12.7999 31.2935C12.4019 30.8968 12.0051 30.5033 11.6109 30.1123C8.94037 27.464 6.38923 24.934 4.39605 22.3459C2.02649 19.2691 0.499908 16.1761 0.499908 12.8C0.499908 6.0069 6.0068 0.5 12.7999 0.5C19.593 0.5 25.0999 6.0069 25.0999 12.8Z" fill="#5514B4" stroke="white" stroke-linecap="round" stroke-linejoin="round" />',
                '<path d="M12.9998 18C15.7612 18 17.9998 15.7614 17.9998 13C17.9998 10.2386 15.7612 8 12.9998 8C10.2384 8 7.99979 10.2386 7.99979 13C7.99979 15.7614 10.2384 18 12.9998 18Z" fill="white" />',
                '</svg>'
            ].join('\n');
            const markerHover = [
                '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">',
                '<g clip-path="url(#clip0_13197_138686)">',
                '<path d="M28.0999 12.8C28.0999 16.1761 26.5733 19.2691 24.2038 22.3459C22.2106 24.934 19.6594 27.464 16.989 30.1123C16.5947 30.5033 16.1979 30.8968 15.7999 31.2935C15.4019 30.8968 15.0051 30.5033 14.6108 30.1123C11.9404 27.464 9.38922 24.934 7.39604 22.3459C5.02649 19.2691 3.4999 16.1761 3.4999 12.8C3.4999 6.0069 9.0068 0.5 15.7999 0.5C22.593 0.5 28.0999 6.0069 28.0999 12.8Z" fill="#996CD5" stroke="white" stroke-linecap="round" stroke-linejoin="round" />',
                '<path d="M15.9998 18C18.7612 18 20.9998 15.7614 20.9998 13C20.9998 10.2386 18.7612 8 15.9998 8C13.2384 8 10.9998 10.2386 10.9998 13C10.9998 15.7614 13.2384 18 15.9998 18Z" fill="white" />',
                '</g>',
                '<defs>',
                '<clipPath id="clip0_13197_138686">',
                '<rect width="32" height="32" fill="white" />',
                '</clipPath>',
                '</defs>',
                '</svg>'
            ].join('\n');

            for (let i = 0; i < coordinate?.['data']?.length ?? 0; i++) {
                const address = coordinate?.['data'][i].data.address;

                const streetName = address.streetName ? `${address.streetName},` : '';
                const streetNumber = address.streetNumber ? `${address.streetNumber}, ` : '';
                const cityOrTown = address.cityOrTown ? `${address.cityOrTown},` : '';
                const countyOrState = address.countyOrState ? `${address.countyOrState},` : '';
                const country = address.country ? `${address.country}, ` : '';
                const postOrZipCode = address.postOrZipCode ? `${address.postOrZipCode}` : '';

                const contentString =
                    '<div id="contentMap"><div class="content-wrp"><span>' +
                    coordinate?.['data'][i].data.siteName +
                    '</span>' +
                    `<p>${streetNumber}${streetName}</p>` +
                    `<p>${cityOrTown}</p>` +
                    `<p>${countyOrState}</p>` +
                    `<p>${country}${postOrZipCode}</p>` +
                    '<p></p></div></div>';

                const marker = new google.maps.Marker({
                    position: coordinate?.['data'][i].position,
                    icon: {
                        url:
                            'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(markerDefault),
                        labelOrigin: new google.maps.Point(10, 35)
                    },
                    label: coordinate?.['data'][i].label,
                    map: map
                });
                const infoWindow = new google.maps.InfoWindow({
                    content: contentString,
                    maxWidth: 280
                });
                InforObj[0] = infoWindow;

                marker.addListener('mouseover', function () {
                    marker.setIcon(
                        'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(markerHover)
                    );
                    infoWindow.open(marker.get('map'), marker);
                    InforObj[0] = infoWindow;
                });
                marker.addListener('mouseout', function () {
                    marker.setIcon(
                        'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(markerDefault)
                    );
                    infoWindow.close(marker.get('map'), marker);
                });
            }
        }

        const fullscreenControlDiv = document.createElement('div');
        const fullscreenControl = createFullScreenControl(map);
        fullscreenControlDiv.appendChild(fullscreenControl);

        map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(fullscreenControlDiv);

        const zoomControlDiv = document.createElement('div');
        zoomControlDiv.style.background = '#fff';
        zoomControlDiv.style.width = '32px';
        zoomControlDiv.style.height = '65px';
        zoomControlDiv.style.borderRadius = '4px';
        zoomControlDiv.style.border = '1px solid f0f0f0';
        zoomControlDiv.style.boxShadow =
            '0px 0px 1px 0px rgba(42, 28, 74, 0.20), 0px 2px 4px 0px rgba(42, 28, 74, 0.12)';
        zoomControlDiv.style.display = 'flex';
        zoomControlDiv.style.flexDirection = 'column';
        zoomControlDiv.style.justifyContent = 'space-around';
        zoomControlDiv.style.alignItems = 'center';
        zoomControlDiv.style.margin = '8px 10px';

        const zoomInControl = createZoomInControl(map);
        const zoomOutControl = createZoomOutControl(map);

        zoomOutControl.style.cursor = map.getZoom() > 2 ? 'pointer' : 'not-allowed';

        const divider = createDivider();

        zoomControlDiv.appendChild(zoomInControl);
        zoomControlDiv.appendChild(divider);
        zoomControlDiv.appendChild(zoomOutControl);

        map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(zoomControlDiv);

        const filterControlDiv = document.createElement('div');
        const filterControl = createFilterControl(map, onClickFilter);
        filterControlDiv.appendChild(filterControl);

        map.controls[google.maps.ControlPosition.RIGHT_TOP].push(filterControlDiv);
    }

    useEffect(() => {
        initMap();
    }, [mapType, zoom, coordinate, searchPlace, sourceData, destinationData]);

    return <div id={mapId} className={`mapArea ${mapType}`}></div>;
};

export default Map;
