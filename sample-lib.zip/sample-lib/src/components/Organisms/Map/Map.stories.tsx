import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import Map from './index';


export const DefaultStory = () => (
    <Map
    mapType={"single"} 
    zoom={1} 
    coordinate={{"focus":{},"data":[]}}
    />
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Organisms/Map',
    component: Map
} as ComponentMeta<typeof Map>;

const Template: ComponentStory<typeof Map> = (args) => <Map {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    mapType:"single" ,
    zoom:1 ,
    coordinate:{"focus":{},"data":[]}
};
