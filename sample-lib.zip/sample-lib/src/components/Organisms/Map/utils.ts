declare global {
    interface Document {
      mozCancelFullScreen?: () => Promise<void>;
      msExitFullscreen?: () => Promise<void>;
      webkitExitFullscreen?: () => Promise<void>;
      mozFullScreenElement?: Element;
      msFullscreenElement?: Element;
      webkitFullscreenElement?: Element;
      onwebkitfullscreenchange?: any;
      onmsfullscreenchange?: any;
      onmozfullscreenchange?: any;
    }
  
    interface HTMLElement {
      msRequestFullScreen?: () => Promise<void>;
      mozRequestFullScreen?: () => Promise<void>;
      webkitRequestFullScreen?: () => Promise<void>;
    }
  }

  function initFullscreenControl(map) {
    const elementToSendFullscreen = map.getDiv().firstChild as HTMLElement;
      if (isFullscreen(elementToSendFullscreen)) {
        exitFullscreen();
      } else {
        requestFullscreen(elementToSendFullscreen);
      }
  }

  function isFullscreen(element: HTMLElement) {
    return (
      (document.fullscreenElement ||
        document.webkitFullscreenElement ||
        document.mozFullScreenElement ||
        document.msFullscreenElement) == element
    );
  }
  
  function requestFullscreen(element: HTMLElement) {
    if (element.requestFullscreen) {
      element.requestFullscreen();
    } else if (element.webkitRequestFullScreen) {
      element.webkitRequestFullScreen();
    } else if (element.mozRequestFullScreen) {
      element.mozRequestFullScreen();
    } else if (element.msRequestFullScreen) {
      element.msRequestFullScreen();
    }
  }
  
  function exitFullscreen() {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    } else if (document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
    }
  }

      /**
     * Creates a custom controls.
     */
     export const createFullScreenControl = (map) => {
        const controlButton = document.createElement('button');

        // Set CSS for the control.
        controlButton.style.background = 'transparent';
        controlButton.style.border = '0';
        controlButton.style.cursor = 'pointer';

        controlButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">' +
        '<g filter="url(#filter0_dd_5478_1913)"><rect x="4" y="2" width="32" height="32" rx="4" fill="white"/><rect x="4.5" y="2.5" width="31" height="31" rx="3.5" stroke="#F0F0F0"/></g>' +
        '<path d="M16.2564 25.5283C16.3402 25.5269 16.42 25.4926 16.4788 25.4328C16.5375 25.3731 16.5704 25.2926 16.5704 25.2088C16.5704 25.125 16.5375 25.0446 16.4788 24.9848C16.42 24.9251 16.3402 24.8908 16.2564 24.8893L13.4124 24.8889L18.742 19.5592C18.802 19.4993 18.8356 19.418 18.8356 19.3332C18.8356 19.2485 18.802 19.1672 18.742 19.1073C18.6821 19.0473 18.6008 19.0137 18.5161 19.0137C18.4313 19.0137 18.35 19.0473 18.2901 19.1073L12.9605 24.4369V21.5934C12.9612 21.5509 12.9535 21.5088 12.9378 21.4694C12.922 21.43 12.8986 21.3941 12.8689 21.3638C12.8391 21.3336 12.8037 21.3095 12.7645 21.2931C12.7254 21.2767 12.6834 21.2682 12.6409 21.2682C12.5985 21.2682 12.5565 21.2767 12.5174 21.2931C12.4782 21.3095 12.4428 21.3336 12.413 21.3638C12.3833 21.3941 12.3599 21.43 12.3441 21.4694C12.3284 21.5088 12.3207 21.5509 12.3214 21.5934L12.3214 25.5279L16.2564 25.5283Z" fill="#2A2A2A" stroke="#2A2A2A" stroke-width="0.5"/>' +
        '<path d="M23.7416 10.4731C23.6579 10.4746 23.578 10.5089 23.5193 10.5686C23.4605 10.6284 23.4276 10.7088 23.4276 10.7926C23.4276 10.8764 23.4605 10.9569 23.5193 11.0166C23.578 11.0764 23.6579 11.1107 23.7416 11.1122L26.5857 11.1126L21.256 16.4423C21.1961 16.5022 21.1624 16.5835 21.1624 16.6682C21.1624 16.753 21.1961 16.8343 21.256 16.8942C21.3159 16.9541 21.3972 16.9878 21.482 16.9878C21.5667 16.9878 21.648 16.9541 21.7079 16.8942L27.0376 11.5645L27.0376 14.4081C27.0368 14.4505 27.0446 14.4927 27.0603 14.5321C27.076 14.5715 27.0994 14.6074 27.1292 14.6376C27.1589 14.6679 27.1944 14.6919 27.2335 14.7084C27.2727 14.7248 27.3147 14.7332 27.3571 14.7332C27.3995 14.7332 27.4415 14.7248 27.4807 14.7084C27.5198 14.6919 27.5553 14.6679 27.585 14.6376C27.6148 14.6074 27.6382 14.5715 27.6539 14.5321C27.6696 14.4927 27.6774 14.4505 27.6766 14.4081L27.6766 10.4736L23.7416 10.4731Z" fill="#2A2A2A" stroke="#2A2A2A" stroke-width="0.5"/>' +
        '<defs><filter id="filter0_dd_5478_1913" x="0" y="0" width="40" height="40" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">' +
            '<feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset/><feGaussianBlur stdDeviation="0.5"/>' +
            '<feColorMatrix type="matrix" values="0 0 0 0 0.164706 0 0 0 0 0.109804 0 0 0 0 0.290196 0 0 0 0.2 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_5478_1913"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>' +
            '<feOffset dy="2"/><feGaussianBlur stdDeviation="2"/><feColorMatrix type="matrix" values="0 0 0 0 0.164706 0 0 0 0 0.109804 0 0 0 0 0.290196 0 0 0 0.12 0"/><feBlend mode="normal" in2="effect1_dropShadow_5478_1913" result="effect2_dropShadow_5478_1913"/><feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_5478_1913" result="shape"/>' +
          '</filter></defs></svg>'
        controlButton.type = 'button';

        // Setup the click event listeners.
        controlButton.addEventListener('click', () => {
            initFullscreenControl(map);
        });

        return controlButton;
    }

    export const createZoomInControl = (map) => {
        const zoomInButton = document.createElement('button');
        zoomInButton.style.background = 'transparent';
        zoomInButton.style.paddingTop = '4px';
        zoomInButton.style.border = '0';
        zoomInButton.style.cursor = 'pointer';

        zoomInButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">' +
        '<path d="M10.0001 4.16675V15.8334M4.16675 10.0001H15.8334" stroke="#2A2A2A" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'

        zoomInButton.type = 'button';

        zoomInButton.addEventListener('click', () => {
            map.setZoom(map.getZoom()! + 1);
        });

        return zoomInButton;
    }

    export const createZoomOutControl = (map) => {
        const zoomOutButton = document.createElement('button');
        zoomOutButton.style.background = 'transparent';
        zoomOutButton.style.paddingTop = '4px';
        zoomOutButton.style.border = '0';
        zoomOutButton.style.cursor = 'pointer';

        zoomOutButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">' +
        '<path d="M4 10H15.6667" stroke="#2A2A2A" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'

        zoomOutButton.type = 'button';

        zoomOutButton.addEventListener('click', () => {
          if(map.getZoom() > 2) {
            map.setZoom(map.getZoom()! - 1);
          } 
        });

        return zoomOutButton;
    }

    export const createFilterControl = (map, onClickFilter) => {
        const filterButton = document.createElement('button');
        filterButton.style.background = 'transparent';
        filterButton.style.border = '0';
        filterButton.style.marginTop = '10px';
        filterButton.style.cursor = 'pointer';
        filterButton.classList.add("default-filter-icon");

        filterButton.innerHTML = '<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg"><g filter="url(#filter0_dd_2016_20969)">' +
        '<path d="M4 6C4 3.79086 5.79086 2 8 2H32C34.2091 2 36 3.79086 36 6V30C36 32.2091 34.2091 34 32 34H8C5.79086 34 4 32.2091 4 30V6Z" fill="white"/>' +
        '<path d="M4.5 6C4.5 4.067 6.067 2.5 8 2.5H32C33.933 2.5 35.5 4.067 35.5 6V30C35.5 31.933 33.933 33.5 32 33.5H8C6.067 33.5 4.5 31.933 4.5 30V6Z" stroke="#F0F0F0"/>' +
        '</g><path d="M21.3554 26C21.2246 26 21.1124 25.9636 21.0002 25.8909L18.4015 24.0909C18.2333 23.9818 18.1398 23.8 18.1398 23.6V16.8364C18.1398 16.8182 18.1398 16.8 18.1211 16.8L12.1759 11.0182C12.0076 10.8545 11.9516 10.6 12.045 10.3636C12.1385 10.1455 12.3629 10 12.6059 10H27.3941C27.6371 10 27.8615 10.1455 27.955 10.3636C28.0484 10.5818 27.9924 10.8364 27.8241 11.0182L21.9724 16.8C21.9537 16.8182 21.9537 16.8182 21.9537 16.8364V25.4C21.9537 25.5636 21.8789 25.7273 21.7667 25.8364C21.6546 25.9455 21.505 26 21.3554 26ZM12.6246 10.5455C12.6246 10.5455 12.5872 10.5455 12.5685 10.5818C12.5498 10.6182 12.5685 10.6364 12.5872 10.6364L18.5137 16.4182C18.6259 16.5273 18.7007 16.6727 18.7007 16.8364V23.5818C18.7007 23.6 18.7007 23.6182 18.7194 23.6182L21.318 25.4364C21.3367 25.4364 21.3367 25.4545 21.3554 25.4545C21.3741 25.4545 21.3928 25.4545 21.3928 25.4364C21.4115 25.4182 21.4115 25.4182 21.4115 25.4V16.8364C21.4115 16.6727 21.4676 16.5273 21.5798 16.4182L27.4502 10.6364C27.4502 10.6364 27.4689 10.6182 27.4689 10.5818C27.4315 10.5455 27.4128 10.5455 27.3941 10.5455H12.6246Z" fill="#2A2A2A" stroke="#2A2A2A"/>' +
        '<defs><filter id="filter0_dd_2016_20969" x="0" y="0" width="40" height="40" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">' +
        '<feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>' +
        '<feOffset/><feGaussianBlur stdDeviation="0.5"/><feColorMatrix type="matrix" values="0 0 0 0 0.164706 0 0 0 0 0.109804 0 0 0 0 0.290196 0 0 0 0.2 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2016_20969"/>' +
        '<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset dy="2"/><feGaussianBlur stdDeviation="2"/>' +
        '<feColorMatrix type="matrix" values="0 0 0 0 0.164706 0 0 0 0 0.109804 0 0 0 0 0.290196 0 0 0 0.12 0"/><feBlend mode="normal" in2="effect1_dropShadow_2016_20969" result="effect2_dropShadow_2016_20969"/>' +
        '<feBlend mode="normal" in="SourceGraphic" in2="effect2_dropShadow_2016_20969" result="shape"/></filter></defs></svg>'

        filterButton.type = 'button';

        filterButton.addEventListener('click', () => {
           console.log("Filter the map");
           onClickFilter();
        });

        return filterButton;
    }

    export const createDivider = () => {
        const divider = document.createElement('div');
        divider.style.background = '#f0f0f0';
        divider.style.width = '24px';
        divider.style.height = '1px';

        return divider;
    }