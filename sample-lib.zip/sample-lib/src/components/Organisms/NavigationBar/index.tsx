import classNames from 'classnames';
import * as React from 'react';
import { IconName } from '../../Assets/icons/iconLib';
import Button from '../../Molecules/Button';
import Tooltip from '../../Molecules/Tooltip';

import './NavigationBar.scss';
import NavigationBarItem from './NavigationBarItem';
import useCheckMobileScreen from '../../../hooks/useCheckMobileScreen';

interface MenuItemProp {
    title: string;
    iconName?: IconName;
    iconInverted?: boolean;
    route?: string;
    isActive?: boolean;
    isDisabled?: boolean;
    onClick?: () => void;
}

export interface NavItemProp extends MenuItemProp {
    isBackRoute?: boolean;
    isFooterItems?: boolean;
    subMenu?: MenuItemProp[];
}

export interface NavItemsProp {
    header?: NavItemProp[];
    main?: NavItemProp[];
    footer?: NavItemProp[];
}

export interface NavigationBarProps {
    navigate: (route: string) => void;
    navItems?: NavItemsProp;
    toggleCallback?: (open: boolean) => void;
}

const NavigationBar: React.FC<NavigationBarProps> = ({ navigate, navItems, toggleCallback }) => {
    const [open, setopen] = React.useState(true);
    const [activeSubMenuIndex, setActiveSubMenuIndex] = React.useState(-1);
    const [showItemLabel, setShowItemLabel] = React.useState(true);
    const [openSubMenuIndex, setOpenSubMenuIndex] = React.useState(-1);
    const isTablet = useCheckMobileScreen();

    const toggleOpen = () => {
        const hideLabel = () => {
            setShowItemLabel(true);
        };
        if (!open) {
            hideLabel();
            setOpenSubMenuIndex(-1);
        } else {

            setShowItemLabel(false);
        }
        setopen(!open);
        toggleCallback && toggleCallback(!open);

    };

    const isTabletFunc = () => {
        setopen(false);
        setShowItemLabel(false);
        toggleCallback && toggleCallback(false);
    }

    React.useEffect(() => {
        isTablet && isTabletFunc();
    }, [isTablet]);

    const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0 || isTablet;
    const handleSubMenuOpen = (index: number) => {
        if (index === activeSubMenuIndex) {
            setActiveSubMenuIndex(-1);
        } else {
            setActiveSubMenuIndex(index);
        }
    };
    const getInitialActiveSubMenuIndex = () => {
        const storedRoute = localStorage.getItem('currentRoute') || window.location.pathname.split('globalfabric')[1] || '/';
        const { main } = navItems;
        if (!main) return -1;
        let activeIndex = -1;
        for (let i = 0; i < main.length; i++) {
            if (
                main[i].route === storedRoute ||
                (main[i].subMenu && main[i].subMenu.some((subItem) => subItem.route === storedRoute))
            ) {
                activeIndex = i;
                break;
            }
        }
        return activeIndex;
    }
    React.useEffect(() => {
        const initialActiveSubMenuIndex = getInitialActiveSubMenuIndex();
        initialActiveSubMenuIndex !== -1 && setActiveSubMenuIndex(initialActiveSubMenuIndex);
    }, []);
    const renderNavigationItems = (items, navigateItem, openItem, toggleOpenItem, showLabel, isTouchItem) => {
        return items.map((item, index) => (
            <NavigationBarItem
                key={item.title}
                item={item}
                navigate={navigateItem}
                open={openItem}
                toggleOpen={toggleOpen}
                showLabel={showLabel}
                isTouch={isTouchItem}
                isSubMenuOpen={index === openSubMenuIndex || index === activeSubMenuIndex}
                onSubMenuOpen={() => handleSubMenuOpen(index)}
            />
        ));
    };
    return (
        <div className='navigation-bar-wrp'>
            <div
                data-testid="navigation-bar"
                className={classNames(
                    'navigation-bar',
                    open ? 'navigation-bar-open' : 'navigation-bar-collapsed'
                )}
            >
                <div className={classNames('navigation-bar--header')}>
                    {renderNavigationItems(navItems.header, navigate, open, toggleOpen, showItemLabel, isTouch)}
                </div>

                <div className="navigation-bar-main">
                    {renderNavigationItems(navItems.main, navigate, open, toggleOpen, showItemLabel, isTouch)}
                </div>

                <footer className={classNames('navigation-bar--footer')}>
                    {navItems.footer.map((item, index) => (
                        <NavigationBarItem
                            key={item.title}
                            item={item}
                            navigate={navigate}
                            open={open}
                            toggleOpen={toggleOpen}
                            showLabel={showItemLabel}
                            isTouch={isTouch}
                            isSubMenuOpen={index === openSubMenuIndex}
                        />
                    ))}
                    <div
                        className={classNames('navigation-bar--item navigation-bar--footer__item', {
                            overflowVisible: !open
                        })}
                    >
                        <Tooltip
                            direction="right"
                            content={!isTouch && (!showItemLabel && 'Expand')}
                        >
                            <Button
                                dataTestId="collapse-section"
                                iconBefore
                                label={showItemLabel && 'Collapse'}
                                variant="link"
                                iconTitle={open ? 'side_nav_expand' : 'side_nav_collapse'}
                                onPress={toggleOpen}
                                className="item-button collapse_button"
                                enableOriginalIcon
                            />
                        </Tooltip>
                    </div>
                </footer>
            </div>
            <span className='non-desktop-overlay close-on-click-btn' onClick={toggleOpen}></span>
        </div>
    );
};

export default NavigationBar;
