import classNames from 'classnames';
import React, { useState, useEffect } from 'react';
import { NavItemProp } from '.';
import Button from '../../Molecules/Button';
import Tooltip from '../../Molecules/Tooltip';

import './NavigationBar.scss';

interface NavigationBarItemProps {
    navigate: (route: string) => void;
    toggleOpen: () => void;
    item: NavItemProp;
    open: boolean;
    showLabel: boolean;
    isTouch: boolean;
    isSubMenuOpen: boolean;
    onSubMenuOpen: () => void;
    isDisabled?: boolean;
}

const NavigationBarItem: React.FC<NavigationBarItemProps> = ({
    navigate,
    toggleOpen,
    item,
    open,
    showLabel,
    isTouch,
    isSubMenuOpen,
    onSubMenuOpen,
}) => {
    const [showSub, setShowSub] = useState(false);
    const [currentRoute, setCurrentRoute] = useState('');

    useEffect(() => {
        if (!open) {
            setShowSub(false);
        }
    }, [open]);

    useEffect(() => {
        const storedRoute = localStorage.getItem('currentRoute');
        setCurrentRoute(storedRoute !== null && storedRoute !== undefined
            ? storedRoute
            : window.location.pathname.split('globalfabric')[1]);
    }, []);

    const toggleSubMenu = () => {
        !open && toggleOpen();
        setShowSub(!showSub);
    };

    const navigateAndToggleSubMenu = (subItem) => {
        !subItem.isDisabled && navigate(subItem.route);
         !subItem.isDisabled && (subItem.route !== currentRoute) &&  toggleSubMenu();
    };

    const handleItemClick = () => {
        if (item.isDisabled) {
            return null;
        }
    
        if (item.onClick) {
            item.onClick();
        } else if (item.subMenu) {
            if (item.route) {
                navigateAndToggleSubMenu(item);
            } else {
                toggleSubMenu();
            }
        } else if (item.route) {
            navigate(item.route);
        }
    };

    const isItemActive =
        item.subMenu?.some((subItem) => currentRoute === subItem.route) ||
        currentRoute === item.route ||
        showSub;

    return (
        <div
            className={`${classNames(
                'navigation-bar--item',
                !open && 'overflowVisible',
                isSubMenuOpen && 'sub-menu-open'
            )} ${item.isDisabled && 'itm-disabled'}`}
            onClick={handleItemClick}
        >
            <Tooltip direction="right" content={!isTouch && (!showLabel || !open) && item.title }>
                <div
                    className={`${classNames('navigation-bar--item__row')} ${item.isDisabled && 'itm-disabled'} ${currentRoute === item.route && !item.isDisabled && 'isActive-row'} ${isItemActive && 'isActive-row'}`}
                >
                    <Button
                        iconBefore
                        label={showLabel && item.title}
                        variant="link"
                        iconTitle={item.iconName}
                        iconInverted={item.iconInverted || currentRoute === item.route || !item.isDisabled && isItemActive}
                        className="item-button"
                        enableOriginalIcon
                        dataTestId="chevron-down-button"
                    />

                    {item.subMenu && showLabel && open && (
                        <Button
                            variant="link"
                            iconTitle={isSubMenuOpen ? 'chevron_up' : 'chevron_down'}
                            iconSize="sm"
                            onPress={(e) => {
                                e.stopPropagation();
                                onSubMenuOpen();
                            }}
                            className="drop-icon-btn"
                            enableOriginalIcon
                        />
                    )}
                </div>
            </Tooltip>

            {open && showLabel && (
                <div className={classNames('navigation-bar--item__sub-menu')}>
                    {item.subMenu?.map((menu) => (
                        <div
                            key={menu.title}
                            className={`${classNames(
                                'navigation-bar--item__sub-menu--item',
                            )} ${menu.isDisabled && 'itm-disabled'} ${currentRoute === menu.route && 'isActive'}`}
                            onClick={(e) => {
                                !menu.isDisabled && navigate(menu.route);
                                e.stopPropagation();
                            }}
                        >
                            <Button
                                iconBefore
                                label={menu.title}
                                variant="link"
                                iconTitle={menu.iconName}
                            />
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default NavigationBarItem;
