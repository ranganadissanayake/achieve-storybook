import React, { useState } from 'react';
import { render, fireEvent, act, waitFor } from '@testing-library/react';
import NavigationBar from './';

describe('NavigationBar component', () => {
  const navigateMock = jest.fn();
  const toggleCallbackMock = jest.fn();
  jest.useFakeTimers();
  const navItemsMock = {
    header: [
      {
        title: 'Header Item 1',
        route: '/header1',
      },
    ],
    main: [
      {
        title: 'Main Item 1',
        route: '/main1',
        subMenu: [
            {
              title: 'Submenu Item 1',
              route: '/submenu1',
            },
            {
              title: 'Submenu Item 2',
              route: '/submenu2',
            },
          ],
      },
    ],
    footer: [
      {
        title: 'Footer Item 1',
        route: '/footer1',
      },
    ],
  };

  it('renders correctly when open', () => {
    const { getByTestId, getByText } = render(
      <NavigationBar navigate={navigateMock} navItems={navItemsMock} toggleCallback={toggleCallbackMock} />
    );
    expect(getByTestId('navigation-bar')).toHaveClass('navigation-bar-open');
    expect(getByText('Header Item 1')).toBeInTheDocument();
    expect(getByText('Main Item 1')).toBeInTheDocument();
    expect(getByText('Footer Item 1')).toBeInTheDocument();
  });

  it('renders correctly when closed', () => {
    const { getByTestId } = render(
      <NavigationBar navigate={navigateMock} navItems={navItemsMock} toggleCallback={toggleCallbackMock} />
    );
    fireEvent.click(getByTestId('collapse-section'));
    expect(getByTestId('navigation-bar')).toHaveClass('navigation-bar-collapsed');
  });

  it('calls navigate function when a navigation item is clicked', () => {
    const { getByText } = render(
      <NavigationBar navigate={navigateMock} navItems={navItemsMock} toggleCallback={toggleCallbackMock} />
    );
    fireEvent.click(getByText('Header Item 1'));
    expect(navigateMock).toHaveBeenCalledWith('/header1');
  });

  it('calls toggleCallback function when the collapse button is clicked', () => {
    const { getByTestId } = render(
      <NavigationBar navigate={navigateMock} navItems={navItemsMock} toggleCallback={toggleCallbackMock} />
    );
    fireEvent.click(getByTestId('collapse-section'));
    expect(toggleCallbackMock).toHaveBeenCalledWith(false);
  });

  it('toggles open and close correctly', () => {
    const { getByTestId } = render(
      <NavigationBar navigate={navigateMock} navItems={navItemsMock} toggleCallback={toggleCallbackMock} />
    );
    expect(getByTestId('navigation-bar')).toHaveClass('navigation-bar-open');
    fireEvent.click(getByTestId('collapse-section'));
    expect(getByTestId('navigation-bar')).toHaveClass('navigation-bar-collapsed');
    fireEvent.click(getByTestId('collapse-section'));
    expect(getByTestId('navigation-bar')).toHaveClass('navigation-bar-open');
  });

  it('sets state correctly when isTablet is true', () => {
    jest.spyOn(require('../../../hooks/useCheckMobileScreen'), 'default').mockReturnValue(true);
    const { getByTestId } = render(
      <NavigationBar navigate={navigateMock} navItems={navItemsMock} toggleCallback={toggleCallbackMock} />
    );
    expect(getByTestId('navigation-bar')).toHaveClass('navigation-bar-collapsed');
    expect(toggleCallbackMock).toHaveBeenCalledWith(false);
  });

  it('calculates initial active submenu index correctly', () => {
    const localStorageMock = {
      getItem: jest.fn().mockReturnValue('/main1'),
    };
    Object.defineProperty(window, 'localStorage', { value: localStorageMock });
    const { container } = render(
      <NavigationBar navigate={navigateMock} navItems={navItemsMock} toggleCallback={toggleCallbackMock} />
    );
    const component = container.firstChild as HTMLElement;
    const initialActiveSubMenuIndex = component
      .querySelector('.navigation-bar-main')
      ?.querySelector('.sub-menu-open');
    expect(initialActiveSubMenuIndex).not.toBeNull(); 
  });

  it('hideLabel changes showItemLabel state after a delay', async () => {
    const useStateMock = jest.spyOn(React, 'useState');
    let mockShowItemLabel = true;
    useStateMock.mockImplementation(() => [mockShowItemLabel, jest.fn()]);
    const { getByTestId } = render(
      <NavigationBar navigate={navigateMock} navItems={navItemsMock} toggleCallback={toggleCallbackMock} />
    );
    const component = getByTestId('navigation-bar');
    expect(mockShowItemLabel).toBe(true);
    act(() => {
      //component['hideLabel']();
    });
    await waitFor(() => {
      expect(mockShowItemLabel).toBe(true);
    }, { timeout: 550 }); 
    useStateMock.mockRestore();
  });

  it('handles submenu open and close correctly', () => {
    const { getByText } = render(
      <NavigationBar navigate={navigateMock} navItems={navItemsMock} toggleCallback={toggleCallbackMock} />
    );
    const submenuItem = getByText('Main Item 1');
    expect(submenuItem).not.toHaveClass('sub-menu-open');
    fireEvent.click(submenuItem);
   setTimeout(()=>{ expect(submenuItem.classList.contains('sub-menu-open')).toBe(true);},10);
    fireEvent.click(submenuItem);
    expect(submenuItem).not.toHaveClass('sub-menu-open');
  });



  
  afterEach(() => {
    jest.restoreAllMocks();
    jest.useRealTimers();
  });
});
