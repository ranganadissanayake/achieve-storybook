import React from 'react';
import { render, fireEvent, act } from '@testing-library/react';
import NavigationBarItem from './NavigationBarItem';
import { NavItemProp } from '.';

describe('<NavigationBarItem />', () => {
    const navigate = jest.fn();
    const toggleOpen = jest.fn();
    const onSubMenuOpen = jest.fn(); 
const localStorageMock = (() => {
    let store = {};

    return {
        getItem: (key) => store[key],
        setItem: (key, value) => {
            store[key] = value.toString();
        },
        clear: () => {
            store = {};
        },
        removeItem: (key) => {
            delete store[key];
        },
    };
})();
    const item: NavItemProp = {
        title: 'Home',
        route: '/home',
        iconName: 'home',
        isActive: true,
        subMenu: [
            {
                title: 'Submenu 1',
                route: '/submenu1'
            },
            {
                title: 'Submenu 2',
                route: '/submenu2'
            }
        ]
    };

    it('should call navigate and toggleSubMenu when submenu item is clicked', () => {
        const { getByText } = render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={item}
                open={true}
                showLabel={true}
            />
        );

        const submenuItem = getByText('Submenu 1');
        fireEvent.click(submenuItem);

        expect(navigate).toHaveBeenCalledWith('/submenu1');
    });

    it('should render NavigationBarItem with correct props', () => {
        const showLabel = true;
        const open = true;

        const { getByText } = render(
            <NavigationBarItem
                navigate={navigate}
                item={item}
                toggleOpen={toggleOpen}
                open={open}
                showLabel={showLabel}
            />
        );

        const navItemTitle = getByText(item.title);

        expect(navItemTitle).toBeInTheDocument();
    });

    it('should call toggleOpen and toggle showSub when submenu is toggled', () => {
        const onSubMenuOpen = jest.fn();

        const { getByText, getByTestId } = render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={item}
                open={false}
                showLabel={true}
                onSubMenuOpen={onSubMenuOpen}
            />
        );
        const submenuToggle = getByTestId('chevron-down-button');
        fireEvent.click(submenuToggle);
    });

    it('should call navigate and toggleSubMenu when submenu item is not disabled and route is different', () => {
        const { getByText } = render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={item}
                open={true}
                showLabel={true}
            />
        );

        const submenuItem = getByText('Submenu 1');
        fireEvent.click(submenuItem);
        expect(navigate).toHaveBeenCalledWith('/submenu1');
    });

    it('should not call toggleSubMenu when submenu item is disabled', () => {
        const { getByText } = render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={item}
                open={true}
                showLabel={true}
            />
        );

        const submenuItem = getByText('Submenu 2');
        fireEvent.click(submenuItem);
        expect(navigate).toHaveBeenCalledWith('/submenu2');
        setTimeout(() => {
            expect(toggleOpen).not.toHaveBeenCalled();
        }, 500);
    });

    it('should call toggleOpen when route is different', () => {
        const toggleOpen = jest.fn();
        const { rerender } = render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={item}
                open={true}
                showLabel={true}
            />
        );
        rerender(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={{
                    ...item,
                    subMenu: [
                        {
                            title: 'Submenu 1',
                            route: '/different-route',
                            isDisabled: false,
                        },
                    ],
                }}
                open={true}
                showLabel={true}
            />
        );
        setTimeout(() => {
            expect(toggleOpen).toHaveBeenCalled();
        }, 500);
    });

    it('should set currentRoute from localStorage or window.location.pathname', () => {
        const setCurrentRoute = jest.fn();
        Object.defineProperty(window, 'localStorage', { value: localStorageMock });
        localStorageMock.setItem('currentRoute', 'stored-route');

        render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={item}
                open={false}
                showLabel={true}
            />
        );
       
        setTimeout(() => {
            expect(setCurrentRoute).toHaveBeenCalledWith('stored-route');
        }, 500);
    });

    it('should call onSubMenuOpen when the submenu button is pressed', () => {
        const onSubMenuOpen = jest.fn();
        const { getByTestId } = render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                onSubMenuOpen={onSubMenuOpen} 
                item={item}
                open={false}
                showLabel={true}
            />
        );

        const submenuToggleButton = getByTestId('chevron-down-button'); 

        fireEvent.click(submenuToggleButton); 
        setTimeout(() => {
            expect(onSubMenuOpen).toHaveBeenCalled();
        }, 10);
        
    });

    it('should handle item click based on conditions', () => {
        const navigate = jest.fn();
    const toggleSubMenu = jest.fn();
    const toggleOpen = jest.fn();
    const navigateAndToggleSubMenu = jest.fn(); 
        const { container } = render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={{ ...item, isDisabled: true }}
                open={false}
                showLabel={true}
            />
        );

        const navItem:any = container.firstChild;

        fireEvent.click(navItem);
        setTimeout(() => {
        act(() => {
            expect(navigate).not.toHaveBeenCalled();
            expect(toggleOpen).not.toHaveBeenCalled();
            expect(navigateAndToggleSubMenu).not.toHaveBeenCalled();
        });
    },10);
        const onClickMock = jest.fn();
        render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={{ ...item, onClick: jest.fn() }}
                open={false}
                showLabel={true}
            />
        );

        fireEvent.click(navItem);
        setTimeout(() => {
        act(() => {
            expect(onClickMock).toHaveBeenCalled();
        });
    },10);
        render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={item}
                open={false}
                showLabel={true}
            />
        );

        fireEvent.click(navItem);

        setTimeout(() => {
            act(() => {
            expect(navigateAndToggleSubMenu).toHaveBeenCalled();
        });
    }, 10);
        render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={{ ...item, route: undefined }}
                open={false}
                showLabel={true}
            />
        );

        fireEvent.click(navItem);

        setTimeout(() => {
            act(async () => {
            expect(toggleSubMenu).toHaveBeenCalled();
        });
    }, 10);
        render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                item={{ ...item, subMenu: undefined }}
                open={false}
                showLabel={true}
            />
        );

        fireEvent.click(navItem);

        setTimeout(() => {
            act(async () => {
            expect(navigate).toHaveBeenCalledWith('/home');
        });
    }, 10);
    });
    it('should apply "sub-menu-open" class when isSubMenuOpen is true', () => {
        const { container } = render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                onSubMenuOpen={onSubMenuOpen}
                item={item}
                open={false}
                showLabel={true}
                isSubMenuOpen={true}
            />
        );

        const navItem = container.firstChild; 

        expect(navItem).toHaveClass('sub-menu-open');
    });

    it('should render with "chevron_up" iconTitle when isSubMenuOpen is true', () => {
        const { container } = render(
            <NavigationBarItem
                navigate={navigate}
                toggleOpen={toggleOpen}
                onSubMenuOpen={onSubMenuOpen}
                item={item}
                open={false}
                showLabel={true}
                isSubMenuOpen={true}
            />
        );

        const icon = container.querySelector('.item-button i'); 

        setTimeout(() => {expect(icon).toHaveTextContent('chevron_up')}, 10);
    });
});
