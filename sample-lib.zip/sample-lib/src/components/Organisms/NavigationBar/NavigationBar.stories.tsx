import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import NavigationBar, { NavItemsProp } from './index';

const navItems: NavItemsProp = {
    header: [],
    main: [
        { title: 'Home', iconName: 'performance_tools', route: '/dashboard' },
        {
            title: 'Accessibility',
            iconName: 'ports',
            route: '/Accessibility',
            subMenu: [
                { title: 'Ally', route: '/ally' },
                { title: 'Control Elements', route: '/Control Elements' },
                { title: 'Aria', route: '/'}
            ]
        },
        { title: 'About', iconName: 'api_keys', route: '/alert', isDisabled:true },
        {
            title: "Performance Tools",
            iconName: "performance_tools",
            route: "/",
            subMenu: [
                { route: "/a", title: "IP VPN Routes", isDisabled:true },
                { route: "/b", title: "Looking Glass" },
                { route: "/c", title: "Net Flow" },
                { route: "/", title: "PoP to Pop" },
                { route: "/e", title: "PoP to Cloud", isActive: true  },
                { route: "/f", title: "PoP to Site" },
            ],
            isDisabled:true
        },
        { title: 'Help & Support', iconName: 'help_and_support', onClick: () => window.open('https://bt.com', '_blank') }
    ],
    footer: [{ title: 'Router', iconName: 'billing', route: '/router', isActive: true }]
};

export const DefaultStory = () => <NavigationBar navigate={alert} navItems={navItems} />;

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Organisms/NavigationBar',
    component: NavigationBar
} as ComponentMeta<typeof NavigationBar>;

const Template: ComponentStory<typeof NavigationBar> = (args) => <NavigationBar {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    navigate: alert,
    navItems,
    toggleCallback: (open: boolean) => {
        console.log('open', open);
    }
};
