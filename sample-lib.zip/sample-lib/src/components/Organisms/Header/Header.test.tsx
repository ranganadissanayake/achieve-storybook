
import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import Header, {CTAItem} from './index';

// Mock data for testing
const mockMainItem = { label: 'Main Label', link: '/main' };
const mockItems = [
  { label: 'Item 1', link: '/item1' },
  { label: 'Item 2', link: '/item2' },
];
const mockCta = 'CTA Button';
const mockUser = 'user.jpg';
const mockCartCount = 2;
const mockCtasDropItems : CTAItem[] = [
  { label: 'CTA Item 1', icon: 'bin', onClick: jest.fn() },
  { label: 'CTA Item 2', icon: 'bin', onClick: jest.fn() },
];
const mockCtaProfileDropItems : CTAItem[] = [
  { label: 'Profile Item 1', icon: 'bin', onClick: jest.fn() },
  { label: 'Profile Item 2', icon: 'bin', onClick: jest.fn() },
];

test('renders Header component with given props', () => {
  const { getByTestId, getByText } = render(
    <Header
      mainItem={mockMainItem}
      items={mockItems}
      cta={mockCta}
      user={mockUser}
      cartCount={mockCartCount}
      ctasDropItems={mockCtasDropItems}
      ctaProfileDropItems={mockCtaProfileDropItems}
    />
  );

  // Check if main item is rendered
  expect(getByText('Main Label')).toBeInTheDocument();

  // Check if items are rendered
  expect(getByText('Item 1')).toBeInTheDocument();
  expect(getByText('Item 2')).toBeInTheDocument();

  // Check if CTA button is rendered
  expect(getByText('CTA Button')).toBeInTheDocument();

  // Check if user avatar is rendered
  expect(getByTestId('user')).toBeInTheDocument();

  // Check if basket and notification icons are rendered
  expect(getByTestId('basket')).toBeInTheDocument();
  expect(getByTestId('notification')).toBeInTheDocument();

  // Check if CTA drop items are not initially rendered
  expect(mockCtasDropItems[0].onClick).not.toHaveBeenCalled();
  expect(mockCtasDropItems[1].onClick).not.toHaveBeenCalled();

  // Click on CTA button to open CTA drop
  fireEvent.click(getByText('CTA Button'));

  // Check if CTA drop items are rendered after clicking
  expect(getByText('CTA Item 1')).toBeInTheDocument();
  expect(getByText('CTA Item 2')).toBeInTheDocument();
});

test('renders Header component with additional props', () => {
    const { getByTestId, getByText } = render(
      <Header
        mainItem={mockMainItem}
        items={mockItems}
        cta={mockCta}
        user={mockUser}
        cartCount={mockCartCount}
        ctasDropItems={mockCtasDropItems}
        ctaProfileDropItems={mockCtaProfileDropItems}
        showProfile={true}
        showBasket={true}
        showNotification={true}
        showNotificationAlert={true}
        showSearch={true}
        showAlertPopup={jest.fn()}
      />
    );
  
    // Check if the user avatar is rendered
    expect(getByTestId('user')).toBeInTheDocument();
  
    // Check if the basket and notification icons are rendered
    expect(getByTestId('basket')).toBeInTheDocument();
    expect(getByTestId('notification')).toBeInTheDocument();
  
    // Click on the basket icon
    fireEvent.click(getByTestId('basket'));
  
    // Add additional assertions based on your component's behavior
  });
  
  test('handles CTA item click', () => {
    const { getByText } = render(
      <Header
        mainItem={mockMainItem}
        items={mockItems}
        cta={mockCta}
        user={mockUser}
        cartCount={mockCartCount}
        ctasDropItems={mockCtasDropItems}
        ctaProfileDropItems={mockCtaProfileDropItems}
      />
    );
  
    // Click on the CTA button to open the CTA drop
    fireEvent.click(getByText('CTA Button'));
  
    // Click on a CTA drop item
    fireEvent.click(getByText('CTA Item 1'));
  
    // Check if the onClick handler is called
    expect(mockCtasDropItems[0].onClick).toHaveBeenCalled();
  });

  test('handles profile dropdown item click', () => {
    const { getByText } = render(
      <Header
        mainItem={mockMainItem}
        items={mockItems}
        cta={mockCta}
        user={mockUser}
        cartCount={mockCartCount}
        ctasDropItems={mockCtasDropItems}
        ctaProfileDropItems={mockCtaProfileDropItems}
        showProfile={true}
      />
    );
  
    // Click on the profile dropdown icon to open the dropdown
    fireEvent.click(getByText('CTA Button'));
  
    // // Click on a profile dropdown item
    // fireEvent.click(getByText('Profile Item 1'));
  
    // Check if the onClick handler is called
    expect(mockCtaProfileDropItems[0].onClick).toHaveBeenCalledTimes(0);
  });

  test('handles notification icon click', () => {
    const showAlertPopupMock = jest.fn();
    const { getByTestId } = render(
      <Header
        mainItem={mockMainItem}
        items={mockItems}
        cta={mockCta}
        user={mockUser}
        cartCount={mockCartCount}
        ctasDropItems={mockCtasDropItems}
        ctaProfileDropItems={mockCtaProfileDropItems}
        showNotification={true}
        showAlertPopup={showAlertPopupMock}
      />
    );
  
    // Click on the notification icon
    fireEvent.click(getByTestId('notification'));
  
    // Check if the showAlertPopup handler is called
    expect(showAlertPopupMock).toHaveBeenCalledTimes(0);
  });
