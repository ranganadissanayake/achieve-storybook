import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import Header from './index';

import user from '../../Assets/testImages/user.png';

export const DefaultStory = () => (
    <Header
        mainItem={{ label: 'Cloud Fabric' }}
        items={[
            { label: 'Dashboard', link: '' },
            { label: 'Locations', link: '' },
            { label: 'Marketplace', link: '' },
            { label: 'Knowledge Hub', link: '' }
        ]}
        cta="Create"
        user={user}
    />
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Organisms/Header',
    component: Header
} as ComponentMeta<typeof Header>;

const Template: ComponentStory<typeof Header> = (args) => <Header {...args} />;

export const Playground = Template.bind({});

Playground.args = {
    mainItem: { label: 'Global Fabric' },
    items: [
        { label: 'Marketplace', link: '' },
        { label: 'API Hub', link: '' },
        { label: 'Help', link: 'https://bt.com', target: '_blank' }
    ],
    cta: 'Create',
    ctasDropItems: [
        {
            label: 'Create a new port',
            icon: 'create_ports',
            onClick: () => {
                alert('popover pressed');
            }
        },
        {
            label: 'Add a network service',
            icon: 'create_network',
            onClick: () => {
                alert('popover pressed');
            }
        },
        {
            label: "Create new location",
            icon: "new_location",
            onClick: () => {
                alert('popover pressed');
            }
        }
    ],
    ctaProfileDropItems: [
        {
            label: 'Profile',
            icon: 'profile',
            onClick: () => {
                alert('popover pressed');
            }
        },
        {
            label: 'Manage User',
            icon: 'profile_user',
            onClick: () => {
                alert('popover pressed');
            }
        },
        {
            label: 'Switch Company',
            icon: 'profile_switch',
            onClick: () => {
                alert('popover pressed');
            }
        },
        {
            label: 'Notification Preferences',
            icon: 'profile_notifications',
            onClick: () => {
                alert('popover pressed');
            }
        },
        {
            label: 'Log Out',
            icon: 'profile_logout',
            onClick: () => {
                alert('popover pressed');
            }
        }
    ],
    cartCount: 12,
    user
};
