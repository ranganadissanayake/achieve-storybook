import React from 'react';
import classNames from 'classnames';
import Avatar from '../../Atoms/Avatar';
import BTLogo from '../../Atoms/BTLogo';
import Divider from '../../Atoms/Divider';
import Icon from '../../Atoms/Icon';
import Button from '../../Molecules/Button';
import Input from '../../Molecules/Input';
import { IconName } from '../../Assets/icons/iconLib';
import { useOnClickOutside } from '../../../hooks';
import Tooltip from '../../Molecules/Tooltip';
import './Header.scss';

type targetType = '_self' | '_blank' | '_parent' | '_top';

interface NavItem {
    label: string;
    link?: string;
    target?: targetType;
    subMenu?: {
        label: string;
        link: string;
        target?: targetType;
    }[];
}

export interface CTAItem {
    label: string;
    icon: IconName;
    onClick?: () => void;
}

/**
 * The properties required for the Header Component
 * @author Joel Chi <joel.abongwa@distributed.com>
 */
export interface HeaderProps {
    /**
     * Defines a main menu item in the Header
     */
    mainItem?: NavItem;
    /**
     * Defines a main items in the Header
     */
    items?: NavItem[];
    /**
     * Defines a cta for the header and its value
     */
    cta?: string;
    /**
     * Displays a user profile avatar
     */
    showProfile?: boolean;
    /**
     * Specifies the image to show in the profile avatar
     */
    user?: string;
    /**
     * Displays a basket icon
     */
    showBasket?: boolean;
    /**
     * Displays a notifications icon
     */
    showNotification?: boolean;
    /**
     * Displays a notifications with alert icon
     */
    showNotificationAlert?: boolean;
    /**
     * Displays a search bar
     */
    showSearch?: boolean;
    /**
     * Displays cart count
     */
    cartCount?: number;
    /**
     * cart navigation
     */
    cartUrl?: () => void;
    /**
     * show alert popup
     */
    showAlertPopup?: () => void;
    /**
     * cta drop items
     */
    ctasDropItems?: CTAItem[];
    /**
     * cta profiledrop items
     */
    ctaProfileDropItems?: CTAItem[];
}

/**
 * Renders the Header component
 * @param {React.PropsWithChildren<HeaderProps>} props HeaderProps properties
 * @returns
 */
const Header: React.FC<HeaderProps> = ({
    mainItem,
    items = [],
    cta = '',
    user = '',
    showProfile = true,
    showBasket = true,
    showNotification = true,
    showNotificationAlert = false,
    showSearch = false,
    cartCount,
    cartUrl,
    ctasDropItems,
    ctaProfileDropItems,
    showAlertPopup
}) => {
    const [showCTAPopover, setShowCTAPopover] = React.useState(false);
    const [showCTAProfilePopover, setShowCTAProfilePopover] = React.useState(false);
    const popoverRef = React.useRef<HTMLDivElement>(null);
    const popoverProfileRef = React.useRef<HTMLDivElement>(null);

    const handleClickOutside = () => {
        setShowCTAPopover(false);
        setShowCTAProfilePopover(false);
    };

    useOnClickOutside(popoverRef, handleClickOutside);
    useOnClickOutside(popoverProfileRef, handleClickOutside);

    return (
        <header className="header" data-testid="header">
            <nav className="main_nav">
                <ul className="nav-left">
                    <li>
                        <a href={mainItem?.link}>
                            <BTLogo color="inverse" label={mainItem?.label} />
                        </a>
                    </li>

                    {mainItem && (
                        <li>
                            <Divider orientation="vertical" className="divider divider_right" />
                        </li>
                    )}
                    {items.length > 0 &&
                        items.map(({ label, link, target, subMenu }) => (
                            <li key={label} className={classNames({ sub_menu: subMenu })}>
                                <a href={link} target={target}>
                                    {label}
                                </a>
                                {subMenu && (
                                    <Icon
                                        title="chevron_down_2px"
                                        size="sm"
                                        className="menu_icon down_icon"
                                    />
                                )}
                            </li>
                        ))}
                    {cta !== '' && (
                        <li className="cta-section">
                            <Button
                                label={cta}
                                variant="white"
                                size="medium"
                                className="cta_button"
                                onPress={() => {
                                    setShowCTAPopover(!showCTAPopover);
                                }}
                            />
                            {ctasDropItems?.length > 0 && showCTAPopover && (
                                <div
                                    ref={popoverRef}
                                    className="cta-popover"
                                >
                                    {ctasDropItems.map((item, index) => (
                                        <div
                                            key={`${item.label}-${index}`}
                                            className={classNames('cta-popover--item')}
                                        >
                                            <Button
                                                iconBefore
                                                label={item.label}
                                                variant="link"
                                                iconTitle={item.icon}
                                                isFontHeadline={false}
                                                onPress={() => {
                                                    item.onClick && item.onClick();
                                                    setShowCTAPopover(false);
                                                }}
                                            />
                                        </div>
                                    ))}
                                </div>
                            )}
                        </li>
                    )}
                </ul>
                <ul className="nav-right">
                    {showSearch && (
                        <li data-testid="search">
                            <Input iconName="search" name="search" />
                        </li>
                    )}
                    {showBasket && (
                        <li data-testid="basket">
                            <Tooltip content="Baskets" direction="bottom">
                                <a onClick={cartUrl} className="counter">
                                    <Icon
                                        title="basket_new"
                                        size="lg"
                                        className="menu_icon"
                                        showOriginal
                                    />
                                    {cartCount > 0 && (
                                        <span className="cart-count">{cartCount}</span>
                                    )}
                                </a>
                            </Tooltip>
                        </li>
                    )}
                    {showNotification && (
                        <li data-testid="notification">
                            <Tooltip content="Notifications" direction="bottom">
                                <a onClick={showAlertPopup} className="counter">
                                    <Icon title="notification" size="lg" className="menu_icon" />
                                    {showNotificationAlert && (
                                        <span className="cart-count notification-dot"></span>
                                    )}
                                </a>
                            </Tooltip>
                        </li>
                    )}
                    <Divider orientation="vertical" className="divider divider_left" />
                    {showProfile && (
                        <li data-testid="user" className="avatar-section cta-section cta-profile">
                            <Avatar
                                size="sm"
                                image={user}
                                onClick={() => {
                                    setShowCTAProfilePopover(!showCTAProfilePopover);
                                }}
                            />
                            <Icon
                                title="chevron_down_2px"
                                size="sm"
                                className="menu_icon down_icon"
                                onClick={() => {
                                    setShowCTAProfilePopover(!showCTAProfilePopover);
                                }}
                            />
                            {ctaProfileDropItems?.length > 0 && showCTAProfilePopover && (
                                <div
                                    ref={popoverProfileRef}
                                    className="cta-popover cta-popover-right"
                                >
                                    {ctaProfileDropItems.map((item, index) => (
                                        <div
                                            key={`${item.label}-${index}`}
                                            className={classNames('cta-popover--item')}
                                        >
                                            <Button
                                                iconBefore
                                                label={item.label}
                                                variant="link"
                                                iconTitle={item.icon}
                                                isFontHeadline={false}
                                                onPress={() => {
                                                    item.onClick && item.onClick();
                                                    setShowCTAProfilePopover(false);
                                                }}
                                            />
                                        </div>
                                    ))}
                                </div>
                            )}
                        </li>
                    )}
                </ul>
            </nav>
        </header>
    );
};

export default Header;
