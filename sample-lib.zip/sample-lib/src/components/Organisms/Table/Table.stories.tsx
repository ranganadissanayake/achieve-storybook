import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import Table from './index';
import Icon from '../../Atoms/Icon';
import Badge from '../../Atoms/Badge';
import logo1 from '../../Assets/testImages/client-logo-1.png';
import logo2 from '../../Assets/testImages/client-logo-2.png';
import logo3 from '../../Assets/testImages/client-logo-3.png';
import logo4 from '../../Assets/testImages/client-logo-4.png';
import logo5 from '../../Assets/testImages/client-logo-5.png';
import DropdownInputMultiSelect from '../../Molecules/DropdownInputMultiSelect';
import DropDownGroup from '../../Molecules/DropdownGroup';

//sample data for views
const tableData = [
    {
        portName: 'Equinix DC2, Ashburn',
        logoURL: logo1,
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '7 Feb 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Standard',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix DC10, Ashburn',
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '7 Feb 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Standard',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix DC10, Ashburn',
        logoURL: logo2,
        country: 'India',
        monthlyPrice: '£600',
        oneOffPayment: '£900',
        lastAdded: '6 Feb 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Standard',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix AT1, Atlanta',
        country: 'India',
        monthlyPrice: '£600',
        oneOffPayment: '£900',
        lastAdded: '6 Feb 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Standard',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix AT1, Atlanta',
        logoURL: logo3,
        country: 'Sri Lanka',
        monthlyPrice: '£700',
        oneOffPayment: '£200',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Standard',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Digital Realty ATL2, Atlanta',
        country: 'Sri Lanka',
        monthlyPrice: '£700',
        oneOffPayment: '£200',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Standard',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Digital Realty ATL2, Atlanta',
        logoURL: logo4,
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Markley One Summer Street, Boston',
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Markley One Summer Street, Boston',
        logoURL: logo5,
        country: 'India',
        monthlyPrice: '£600',
        oneOffPayment: '£900',
        lastAdded: '20 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite CH1, Chicago',
        country: 'India',
        monthlyPrice: '£600',
        oneOffPayment: '£900',
        lastAdded: '20 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite CH1, Chicago',
        logoURL: logo1,
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '10 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite CH1, Chicago',
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '10 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite CH1, Chicago',
        logoURL: logo2,
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '10 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix DA6, Dallas',
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '10 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix DA6, Dallas',
        logoURL: logo3,
        country: 'India',
        monthlyPrice: '£600',
        oneOffPayment: '£900',
        lastAdded: '10 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Digital Realty DAL1, Dallas',
        country: 'India',
        monthlyPrice: '£600',
        oneOffPayment: '£900',
        lastAdded: '10 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Digital Realty DAL1, Dallas',
        logoURL: logo4,
        country: 'Sri Lanka',
        monthlyPrice: '£700',
        oneOffPayment: '£200',
        lastAdded: '8 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite DE1, Denver',
        country: 'Sri Lanka',
        monthlyPrice: '£700',
        oneOffPayment: '£200',
        lastAdded: '8 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite DE1, Denver',
        logoURL: logo5,
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '7 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite DE2, Denver',
        country: 'United Kingdom',
        monthlyPrice: '£500',
        oneOffPayment: '£500',
        lastAdded: '7 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite DE2, Denver',
        logoURL: logo1,
        country: 'India',
        monthlyPrice: '£600',
        oneOffPayment: '£900',
        lastAdded: '7 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix LA1, Los Angeles',
        country: 'India',
        monthlyPrice: '£600',
        oneOffPayment: '£900',
        lastAdded: '7 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Diverse',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix LA1, Los Angeles',
        logoURL: logo2,
        country: 'Sri Lanka',
        monthlyPrice: '£700',
        oneOffPayment: '£200',
        lastAdded: '6 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        resilience: 'Standard',
        portSpeed: '100 GPS',
        primaryPortSpeed: '1Gbps',
        secondaryPortSpeed: '10Gbps',
        secoundPortName: 'Equinix DC2, Ashburn'
    }
];

//sample column data with custom columns
const tableColumns = [
    {
        // Make an expander cell
        Header: () => null,
        id: 'expander',
        Cell: ({ row }) => (
            <span {...row.getToggleRowExpandedProps()}>
                {row.isExpanded ? (
                    <Icon title="collapse_row" color="#5514b4" size="sm" />
                ) : (
                    <Icon title="expand_row" color="#5514b4" size="sm" />
                )}
            </span>
        ),
        sticky: 'left',
        width: 20
    },
    {
        // Make custom cell that can render components inside
        Header: 'Port Name',
        accessor: 'portName',
        id: 'portName',
        Cell: ({ row, data }) => (
            <div className="logo_wrapper">
                <div className="logo">
                    <img alt="logo" src={data[row.id].logoURL} />
                </div>
                <div className="text">{data[row.id].portName}</div>
            </div>
        ),
        sticky: 'left',
        minWidth: 200
    },
    {
        Header: 'Country',
        accessor: 'country',
        minWidth: 200
    },
    {
        Header: 'Monthly Price',
        accessor: 'monthlyPrice',
        minWidth: 200
    },
    {
        Header: 'One-off payment',
        accessor: 'oneOffPayment',
        minWidth: 200
    },
    {
        Header: 'Last Added',
        accessor: 'lastAdded',
        minWidth: 200
    },
    {
        // Make custom cell that can render components inside
        Header: 'Type',
        id: 'type',
        accessor: 'type',
        Cell: ({ row, data }) => (
            <span>
                <Badge text={data[row.id].type} />
            </span>
        )
    },
    {
        Header: 'Location',
        accessor: 'location',
        minWidth: 200
    },
    {
        Header: 'Resilience',
        accessor: 'resilience',
        minWidth: 200
    },
    {
        Header: 'Port Speed',
        accessor: 'portSpeed',
        minWidth: 200
    },
    {
        Header: 'Primary Port Speed',
        accessor: 'primaryPort',
        minWidth: 200
    },
    {
        Header: 'Secondary Port Speed',
        accessor: 'secondaryPort',
        minWidth: 200
    }
];

//sample basic column data
const tableColumnsDefaults = [
    {
        Header: 'Port Name',
        accessor: 'portName',
        minWidth: 200,
        sticky: 'left'
    },
    {
        Header: 'Country',
        accessor: 'country',
        minWidth: 200
    },
    {
        Header: 'Monthly Price',
        accessor: 'monthlyPrice',
        minWidth: 200
    },
    {
        Header: 'One-off payment',
        accessor: 'oneOffPayment',
        minWidth: 200
    },
    {
        Header: 'Last Added',
        accessor: 'lastAdded',
        minWidth: 200
    },
    {
        Header: 'Type',
        accessor: 'type',
        minWidth: 200
    },
    {
        Header: 'Location',
        accessor: 'location',
        minWidth: 200
    },
    {
        Header: 'Term',
        accessor: 'term',
        minWidth: 200
    },
    {
        Header: 'portSpeed',
        accessor: 'portSpeed',
        minWidth: 200
    }
];

//passing row id for deletion . deletion need to happen from application side
const deleteItem = (id: string) => {
    alert('Deleting item with Id ' + id);
};

const editItem = (id: string) => {
    alert('Editing item with Id ' + id);
};

const getSelectedValues = (values: string[]) => {
    console.log(values);
};

const onSelectMulitiRows = (values: []) => {
    console.log(values);
};

const FilterOptions = () => {
    return (
        <>
            <DropdownInputMultiSelect
                type="text"
                name="Country"
                placeholder="Country"
                showFlag={false}
                onlySelectedValue={false}
                options={[
                    { id: 'Canada', value: 'Canada' },
                    { id: 'UK', value: 'United Kingdom' },
                    { id: 'Belgium', value: 'Belgium' },
                    { id: 'USA', value: 'United States' },
                    { id: 'HongKong', value: 'HongKong' },
                    { id: 'Australia', value: 'Australia' },
                    { id: 'Mexico', value: 'Mexico' }
                ]}
                defaultValue="Country"
                getSelectedValues={getSelectedValues}
                size="sm"
                labelSize="xs"
            />
            <DropDownGroup
                rangeDefault={{ min: 100, max: 1400 }}
                range={{ min: 100, max: 1400 }}
                label="Speed"
                type="range"
                selectSideEffects={(value) => {
                    console.log('Range ?>>>.  ', value);
                }}
            />
            <DropDownGroup
                options={[
                    { label: 'Standard', value: 'standard', name: 'resilience' },
                    { label: 'Diverse', value: 'diverse', name: 'resilience' }
                ]}
                label="Resilience"
                type="radio"
                selectSideEffects={(value) => {
                    console.log('Radio?>>>.  ', value);
                }}
            />
            <DropDownGroup
                options={[
                    { label: 'Standard', value: 'standard' },
                    { label: 'Diverse', value: 'diverse' }
                ]}
                label="Port Type"
                type="checkbox"
                selectSideEffects={(value) => {
                    console.log('checkbox?>>>.  ', value);
                }}
            />
        </>
    );
};

export const DefaultStory = () => (
    <Table
        tableData={tableData}
        tableColumn={tableColumnsDefaults}
        enablePagination={true}
        enableSorting={true}
        visibleColumnLimit={5}
        selectMulitiRows={true}
        onSelectMulitiRows={onSelectMulitiRows}
    />
);

DefaultStory.storyName = 'Default';

export default {
    title: 'ReactComponentLibrary/Organisms/Table',
    component: Table
} as ComponentMeta<typeof Table>;

const Template: ComponentStory<typeof Table> = (args) => (
    <div style={{ maxWidth: '700px', overflow: 'scroll' }}>
        <Table {...args} />
    </div>
);

export const Playground = Template.bind({});

let showBar = false;

Playground.args = {
    tableData: tableData,
    tableColumn: tableColumns,
    enablePagination: true,
    enableFilters: true,
    enableSorting: true,
    visibleColumnLimit: 6,
    deleteItem: deleteItem,
    editItem: editItem,
    maxColumnCount: 12,
    showAdvanceFilter: true,
    searchPlaceholder: 'Search by internet name',
    pageSizes: [10, 25, 50, 100],
    FilterBar: <FilterOptions />,
    showFilterBar: showBar,
    defaultSortColumn:"lastAdded",
    selectMulitiRows : true,
    onSelectMulitiRows : onSelectMulitiRows,
    preExpandedIndex: 0,
};
