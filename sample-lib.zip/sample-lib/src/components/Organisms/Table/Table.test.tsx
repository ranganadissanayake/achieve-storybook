import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Table from './index';
import Icon from '../../Atoms/Icon';
import "regenerator-runtime";
//setup sample data for testing
const tableData = [
    {
        portName: 'Equinix DC2, Ashburn',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-1.png',
        country: 'United Kingdom',
        monthlyPrice: '500',
        oneOffPayment: '500',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix DC10, Ashburn',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-2.png',
        country: 'India',
        monthlyPrice: '600',
        oneOffPayment: '900',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix AT1, Atlanta',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-3.png',
        country: 'Sri Lanka',
        monthlyPrice: '700',
        oneOffPayment: '200',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Digital Realty ATL2, Atlanta',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-4.png',
        country: 'United Kingdom',
        monthlyPrice: '500',
        oneOffPayment: '500',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Markley One Summer Street, Boston',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-5.png',
        country: 'India',
        monthlyPrice: '600',
        oneOffPayment: '900',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix CH2, Chicago',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-1.png',
        country: 'Sri Lanka',
        monthlyPrice: '700',
        oneOffPayment: '200',
        lastAdded: '22 Jan 2022',
        type: 'IPVPN'
    },
    {
        portName: 'CoreSite CH1, Chicago',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-2.png',
        country: 'United Kingdom',
        monthlyPrice: '500',
        oneOffPayment: '500',
        lastAdded: '22 Jan 2022',
        type: 'IPVPN',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix DA6, Dallas',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-3.png',
        country: 'India',
        monthlyPrice: '600',
        oneOffPayment: '900',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Digital Realty DAL1, Dallas',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-4.png',
        country: 'Sri Lanka',
        monthlyPrice: '700',
        oneOffPayment: '200',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite DE1, Denver',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-5.png',
        country: 'United Kingdom',
        monthlyPrice: '500',
        oneOffPayment: '500',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'CoreSite DE2, Denver',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-1.png',
        country: 'India',
        monthlyPrice: '600',
        oneOffPayment: '900',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    },
    {
        portName: 'Equinix LA1, Los Angeles',
        logoURL: 'static/media/src/components/Assets/testImages/client-logo-2.png',
        country: 'Sri Lanka',
        monthlyPrice: '700',
        oneOffPayment: '200',
        lastAdded: '22 Jan 2022',
        type: 'Port Only',
        location: 'Google GP S3',
        term: '12 months',
        portSpeed: '100 GPS'
    }
];

//setup columns data for testing
const tableColumns = [
    {
        Header: () => null,
        id: 'expander',
        Cell: ({ row }) => (
            <span {...row.getToggleRowExpandedProps()}>
                {row.isExpanded ? (
                    <Icon title="collapse_row" size="sm" />
                ) : (
                    <Icon title="expand_row" size="sm" />
                )}
            </span>
        ),
        width: 20
    },
    {
        Header: 'Port Name',
        accessor: 'portName'
    },
    {
        Header: 'Country',
        accessor: 'country'
    },
    {
        Header: 'Monthly Price',
        accessor: 'monthlyPrice'
    },
    {
        Header: 'One-off payment',
        accessor: 'oneOffPayment'
    },
    {
        Header: 'Last Added',
        accessor: 'lastAdded'
    },
    {
        Header: 'Type',
        accessor: 'type'
    },
    {
        Header: 'Location',
        accessor: 'location'
    },
    {
        Header: 'Term',
        accessor: 'term'
    },
    {
        Header: 'portSpeed',
        accessor: 'portSpeed'
    }
];

describe('ReactTable ', () => {
    const componentWrap = (
        <Table
            tableData={tableData}
            tableColumn={tableColumns}
            enablePagination={true}
            enableSorting={true}
            visibleColumnLimit={4}
            deleteItem={jest.fn()}
            editItem={jest.fn()}
            showAdvanceFilter={true}
            searchPlaceholder={'Search by internet name'}
            pageSizes={[10, 25, 50, 100]}
        />
    );

    test('should renders the ReactTable component', () => {
        render(componentWrap);
        expect(screen.getByTestId('reactTable')).toBeInTheDocument();
    });

    test('should renders the ReactTable component with false props', () => {
        const componentWrapNegetive = <Table tableData={tableData} tableColumn={tableColumns} />;
        render(componentWrapNegetive);
        expect(screen.getByTestId('reactTable')).toBeInTheDocument();
    });

    test('should trigger the deleteRow callback funtion', () => {
        render(componentWrap);
        const deleteRow = jest.fn();
        const button = screen.getAllByTestId('delete-action');
        fireEvent.click(button[0]);
        expect(deleteRow).toHaveBeenCalled;
    });

    test('should work next and back paginations', () => {
        render(componentWrap);
        const nextPage = jest.fn();
        const previousPage = jest.fn();
        const nextAction = screen.getByTestId('next-page');
        fireEvent.click(nextAction);
        expect(nextPage).toHaveBeenCalled;
        const backAction = screen.getByTestId('previous-page');
        fireEvent.click(backAction);
        expect(previousPage).toHaveBeenCalled;
    });

    test('Shold work sorting', () => {
        render(componentWrap);
        const sorting = screen.getByText('Port Name');
        fireEvent.click(sorting);
        fireEvent.click(sorting);
        expect(screen.getByTestId('reactTable')).toHaveClass('nayan_table');
    });

    test('Should expand the rows onclick the action', () => {
        render(componentWrap);
        const expand = screen.getAllByTitle('Toggle Row Expanded');
        fireEvent.click(expand[0]);
        expect(screen.getByTestId('tableChild')).toHaveClass('table_child');
        fireEvent.click(expand[0]);
        expect(screen.getByTestId('reactTable')).toHaveClass('nayan_table');
    });

    test('Check no data message', () => {
        const componentWrapNegetive = <Table tableData={tableData} tableColumn={tableColumns} />;
        render(componentWrapNegetive);
        const expand = screen.getAllByTitle('Toggle Row Expanded');
        fireEvent.click(expand[0]);
        const noData = screen.getAllByTestId('noData');
        expect(noData.length === 3);
    });
    test('filters table data correctly', () => {
        const tableData = [
          { id: 1, name: 'John Doe', age: 30 },
          { id: 2, name: 'Jane Smith', age: 25 },
          { id: 3, name: 'Mark Johnson', age: 35 },
        ];
        const tableColumn = [
          { Header: 'ID', accessor: 'id' },
          { Header: 'Name', accessor: 'name' },
          { Header: 'Age', accessor: 'age' },
        ];
      
        render(<Table tableData={tableData} tableColumn={tableColumn} enableFilters={true} />);
      
       
        const searchInput = screen.getByTestId('input');
        fireEvent.change(searchInput, { target: { value: 'John' } });
      
        expect(screen.getByText('1')).toBeInTheDocument();
        expect(screen.getByText('John Doe')).toBeInTheDocument();
        expect(screen.getByText('30')).toBeInTheDocument();
      
       
      });

    test('should select and deselect multiple rows', () => {
        const onSelectMulitiRows = jest.fn();
        render(
            <Table
                tableData={tableData}
                tableColumn={tableColumns}
                enablePagination={true}
                enableSorting={true}
                visibleColumnLimit={4}
                selectMulitiRows={true}
                onSelectMulitiRows={onSelectMulitiRows}
            />
        );
    });

    test('should select and deselect multiple rows', () => {
        const onSelectMulitiRows = jest.fn();
        render(
            <Table
                tableData={tableData}
                tableColumn={tableColumns}
                enablePagination={true}
                enableSorting={true}
                visibleColumnLimit={4}
                selectMulitiRows={true}
                onSelectMulitiRows={onSelectMulitiRows}
            />
        );
    });

    test('should set filter badge for 1', () => {
        render(
            <Table
                tableData={tableData}
                tableColumn={tableColumns}
                filteredOptionsList={["Test"]}
                filteredOptions={1}
            />
        );
    });

    test('should set filter badge for >1', () => {
        render(
            <Table
                tableData={tableData}
                tableColumn={tableColumns}
                filteredOptionsList={["Test","Test2"]}
                filteredOptions={2}
            />
        );
    });

    test('should set filter badge for 0', () => {
        render(
            <Table
                tableData={tableData}
                tableColumn={tableColumns}
                filteredOptionsList={[]}
                filteredOptions={0}
            />
        );
    });

    test('should set filter badge for filteredOptionsList undefined', () => {
        render(
            <Table
                tableData={tableData}
                tableColumn={tableColumns}
                filteredOptions={2}
            />
        );
    });
});
