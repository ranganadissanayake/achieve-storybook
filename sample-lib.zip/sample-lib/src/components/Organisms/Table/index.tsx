import React, {   useState } from 'react';
import {
    useTable,
    useSortBy,
    useExpanded,
    usePagination,
    useFilters,
    useGlobalFilter,
    useAsyncDebounce,
    useRowSelect
} from 'react-table';
import './Table.scss';
import Button from '../../Molecules/Button';
import Input from '../../Molecules/Input';
import Icon from '../../Atoms/Icon';
import { ContainerRow, Column } from '../../Atoms/Grid';
import noDataIcon from '../../Assets/icons/img/no-data.png';
import { useSticky } from 'react-table-sticky';

export interface TableProps {
    tableData: any[];
    tableColumn: any[];
    enablePagination?: boolean;
    enableFilters?: boolean;
    enableSorting?: boolean;
    visibleColumnLimit?: number;
    maxColumnCount?: number;
    mirrorParentRow?: boolean;
    deleteItem?: (id: string) => void;
    editItem?: (id: string) => void;
    showAdvanceFilter?: boolean;
    searchPlaceholder?: string;
    pageSizes?: number[];
    FilterBar?: React.ReactElement;
    filteredOptions?: number;
    showFilterBar?: boolean;
    buttonIconBefore?: boolean;
    setShowFilterBar?: (showFilterBar: boolean) => void;
    clearFilters?: () => void;
    defaultSortColumn?: string;
    defaultSortDesc?: boolean;
    selectMulitiRows?: boolean;
    onSelectMulitiRows?: (values: []) => void;
    filteredOptionsList?:string[];
    preExpandedIndex?: number;
}

interface IMultiselectCheckboxProps {
    indeterminate?: boolean;
    name: string;
}

const Table: React.FC<TableProps> = ({
    tableData,
    tableColumn,
    enablePagination,
    enableFilters,
    enableSorting,
    visibleColumnLimit,
    maxColumnCount,
    mirrorParentRow,
    deleteItem,
    editItem,
    showAdvanceFilter,
    searchPlaceholder,
    pageSizes,
    FilterBar,
    filteredOptions,
    showFilterBar,
    setShowFilterBar,
    buttonIconBefore,
    defaultSortColumn,
    defaultSortDesc,
    selectMulitiRows,
    onSelectMulitiRows,
    filteredOptionsList,
    preExpandedIndex
}) => {
    
    const [filterBadgeVal, setfilterBadgeVal] = useState("");
    // set default colums sizes
    const defaultColumn = React.useMemo(
        () => ({
            minWidth: 20,
            maxWidth: 400
        }),
        []
    );
    
    // set filter badge
    React.useEffect(() => {
        if(filteredOptions===1){
            setfilterBadgeVal(filteredOptionsList?.[0] || filteredOptions.toString());
        }
        else if(filteredOptions>1){
            setfilterBadgeVal(`${filteredOptionsList?.[0]} +${filteredOptions-1}`)
        }
        else{
            setfilterBadgeVal("");
        }
        if(!filteredOptionsList && filteredOptions>0) {
            setfilterBadgeVal(filteredOptions.toString());
        }
    }, [filteredOptions,filteredOptionsList])
        
    // delete action and item
    const deleteAction = (id: string) => {
        return (
            <span className="delete">
                <a data-testid="delete-action" onClick={() => deleteItem(id)}>
                    <Icon title="bin" size="md" />
                </a>
            </span>
        );
    };

    // edit action and item
    const editAction = (id: string) => {
        return <div onClick={() => editItem(id)}>Edit</div>;
    };

    // use memo for data and columns
    const data = tableData ? tableData : [];
    const columns = React.useMemo(
        () => (visibleColumnLimit ? tableColumn.slice(0, visibleColumnLimit + 1) : tableColumn),
        []
    );

    const MultiselectCheckbox = React.forwardRef<HTMLInputElement, IMultiselectCheckboxProps>(
        ({ indeterminate, ...rest }, ref) => {
          const defaultRef = React.useRef()
          const resolvedRef = ref || defaultRef
      
          React.useEffect(() => {
            if (resolvedRef != null && typeof resolvedRef !== 'function') {
                resolvedRef.current.indeterminate = indeterminate
              }
           
          }, [resolvedRef, indeterminate])
      
          return (
            <>
              <input className="row-select" type="checkbox" ref={resolvedRef} {...rest} />
            </>
          )
        }
      )

      const preExtended = {};
      preExtended[preExpandedIndex] = true;

    //use table
    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        state,
        prepareRow,
        page,
        canPreviousPage,
        canNextPage,
        pageCount,
        nextPage,
        previousPage,
        state: { pageIndex, pageSize },
        visibleColumns,
        setGlobalFilter,
        setPageSize,
        selectedFlatRows
    } = useTable(
        {
            data,
            columns,
            defaultColumn,
            initialState: defaultSortColumn?{
                sortBy: columns.map((tableCol) => {
                    return {
                        desc: defaultSortDesc,
                        id: tableCol.accessor ? defaultSortColumn : ''
                    };
                }),
                expanded: preExtended,
            }:{}
        },
        useFilters,
        useGlobalFilter,
        useSortBy,
        useExpanded,
        usePagination,
        useSticky,
        useRowSelect,
        (hooks) => {
            if (selectMulitiRows) {
                hooks.visibleColumns.push((selectedColumns) => [
                    {
                        width: 20,
                        id: 'selection',
                        Header: ({ getToggleAllRowsSelectedProps }) => (
                            <div>
                                <MultiselectCheckbox {...getToggleAllRowsSelectedProps()} />
                            </div>
                        ),

                        Cell: ({ row }) => (
                            <div>
                                <MultiselectCheckbox {...row.getToggleRowSelectedProps()} />
                            </div>
                        )
                    },
                    ...selectedColumns
                ]);
            } else {
                hooks.visibleColumns.push((selectedColumns) => [...selectedColumns]);
            }
        }
    );
    const pageLength = () => {
        if (page?.length < 1) {
            return 'disable-text';
        } else {
            return '';
        }
    };
    const getPageLength = React.useMemo(() => pageLength(), [page]);

    const getVariant = React.useMemo(() => {
        if (showFilterBar || filteredOptions) {
            return 'solid';
        }
        else {
            return 'outline';
        }
    }, [showFilterBar, filteredOptions]);

    const rowCount = React.useMemo(() => {
        if (pageCount === pageIndex + 1) {
            return tableData.length
        }
        else {
            return pageSize + pageSize * pageIndex;
        }
    }, [pageCount]);

    //set selected rows to pass parent component
    
    React.useEffect(() => {
        if (onSelectMulitiRows) {
            onSelectMulitiRows(selectedFlatRows.map((row) => row.original));
        }
    }, [selectedFlatRows]);

    // expanded row data
    const expandedData = (selectedTableData, dataLength) => {
        let array = Object.keys(selectedTableData).map(function (key) {
            return selectedTableData[key];
        });
        return (
            <>
                {dataLength === 'more' ? (
                    <tr>
                        {array.slice(visibleColumnLimit + 1, maxColumnCount).map((cellData) => (
                            <td>{cellData}</td>
                        ))}
                    </tr>
                ) : (
                    <tr>
                        {array.slice(visibleColumnLimit + 1, maxColumnCount - 2).map((cellData) => (
                            <td>{cellData}</td>
                        ))}
                    </tr>
                )}
            </>
        );
    };

    //render sub component
    const renderRowSubComponent = React.useCallback(
        ({ tableData: tableItems, row }) => (
            <>
                {Object.keys(tableItems[row.id]).length > 10 ? (
                    <table className="table_child" data-testid="tableChild">
                        <tbody>
                            <tr>
                                {tableColumn
                                    .slice(visibleColumnLimit + 1, maxColumnCount)
                                    .map((columnData) => (
                                        <th className="child_th">{columnData.Header}</th>
                                    ))}
                            </tr>
                            {expandedData(tableItems[row.id], 'more')}
                        </tbody>
                    </table>
                ) : (
                    <table className="table_child" data-testid="tableChild">
                        <tbody>
                            <tr>
                                {tableColumn
                                    .slice(visibleColumnLimit + 1, maxColumnCount - 2)
                                    .map((columnData) => (
                                        <th className="child_th">{columnData.Header}</th>
                                    ))}
                            </tr>
                            {expandedData(tableItems[row.id], 'less')}
                        </tbody>
                    </table>
                )}

                {editItem ? <div className="edit">{editAction(row.id)}</div> : ''}
            </>
        ),
        []
    );

    // Define a default UI for filtering
    const GlobalFilter = ({ globalFilter, setGlobalFilter: setGloFilter }) => {
        const [value, setValue] = useState(globalFilter);
        const onChange = useAsyncDebounce((inputValue: any) => {
            setGloFilter(inputValue || undefined);
        }, 1000);

        const onChangeSearch = (inputText) => {
            setValue(inputText);
            onChange(inputText);
        };
       
        return (
            <>
                <ContainerRow className="filter-row">
                    <Column sm={16} md={16} lg={16} className="filter-section">
                        <Input
                            value={value || ''}
                            onChange={onChangeSearch}
                            name="searchInput"
                            iconName="search"
                            placeholder={searchPlaceholder}
                            className="filter-input"
                            size="sm"
                            iconSize="sm"
                        />
                        {showAdvanceFilter ? (
                            <>
                                <Button
                                    label="Filter"
                                    className="filter-button"
                                    iconTitle="filter"
                                    variant={getVariant}
                                    onPress={() => {
                                        setShowFilterBar && setShowFilterBar(!showFilterBar);
                                    }}
                                    primaryBadgeText={filterBadgeVal}
                                    primaryBadgeVariant="default-light"
                                    iconBefore={buttonIconBefore}
                                    isFontHeadline={false}
                                />
                            </>
                        ) : (
                            ''
                        )}
                    </Column>
                </ContainerRow>
                {showFilterBar && <ContainerRow className="filter-row">{FilterBar}</ContainerRow>}
            </>
        );
    };

  

    return (
        <div className="nayan_table" data-testid="reactTable">
            {enableFilters ? (
                <GlobalFilter globalFilter={state.globalFilter} setGlobalFilter={setGlobalFilter} />
            ) : null}

            <table
                {...getTableProps()}
                className={`${selectMulitiRows ? 'table_parent multiselect' : 'table_parent'}`}
            >
                <thead>
                    {headerGroups.map((headerGroup) => (
                        <tr key={headerGroup.id} {...headerGroup.getHeaderGroupProps()}>
                            {headerGroup.headers.map((column) => (
                                <th
                                    key={column.id}
                                    {...column.getHeaderProps(
                                        enableSorting ? column.getSortByToggleProps() : undefined,
                                        {
                                            style: {
                                                minWidth: column.minWidth,
                                                width: column.width
                                            }
                                        }
                                    )}
                                >
                                    {column.render('Header')}
                                    <span className="sort_icon">
                                        {column.isSorted ? (
                                            column.isSortedDesc ? (
                                                <Icon title="chevron_up_2px" size="sm" />
                                            ) : (
                                                <Icon title="chevron_down_2px" size="sm" />
                                            )
                                        ) : (
                                            ''
                                        )}
                                    </span>
                                </th>
                            ))}
                            {deleteItem ? <th>{''}</th> : null}
                        </tr>
                    ))}
                </thead>
                <tbody {...getTableBodyProps()}>
                    {page.map((row) => {
                        prepareRow(row);
                        return (
                            <>
                                <tr key={row.id} {...row.getRowProps()}>
                                    {row.cells.map((cell) => {
                                        return (
                                            <td
                                                key={cell.id}
                                                {...cell.getCellProps({
                                                    style: {
                                                        minWidth: cell.column.minWidth,
                                                        width: cell.column.width
                                                    }
                                                })}
                                            >
                                                {cell.render('Cell')}
                                            </td>
                                        );
                                    })}

                                    {deleteItem ? <td>{deleteAction(row.id)}</td> : null}
                                </tr>
                                {row.isExpanded && !mirrorParentRow ? (
                                    <tr>
                                        <td colSpan={visibleColumns.length}>
                                            {visibleColumnLimit &&
                                                renderRowSubComponent({ tableData, row })}
                                            {!visibleColumnLimit && (
                                                <span data-testid="noData">'No Data'</span>
                                            )}
                                        </td>
                                    </tr>
                                ) : null}
                            </>
                        );
                    })}
                </tbody>
            </table>
            {page?.length < 1 ? (
                <div className="nodata-message">
                    <div className="message-icon">
                        <img src={noDataIcon} />
                    </div>
                    <div className="message-text">No results found</div>
                </div>
            ) : (
                ''
            )}
            {enablePagination ? (
                <div className="pagination">
                    {pageSizes ? (
                        <>
                            <span className={`show-text ${getPageLength}`}>
                                Show{' '}
                            </span>
                            <span className="page-select">
                                <select
                                    value={pageSize}
                                    onChange={(e) => {
                                        setPageSize(Number(e.target.value));
                                    }}
                                    disabled={page?.length < 1}
                                >
                                    {pageSizes
                                        ? pageSizes?.map((selectedPageSize) => (
                                              <option key={selectedPageSize} value={selectedPageSize}>
                                                  {selectedPageSize}
                                              </option>
                                          ))
                                        : ''}
                                </select>
                            </span>
                            <span
                                className={`entries-text ${getPageLength}`}
                            >
                                {' '}
                                entries
                            </span>
                        </>
                    ) : (
                        ''
                    )}
                    <span className={`page_count ${getPageLength}`}>
                        <span className='first-entry'>{pageSize * pageIndex + 1}</span> to{' '}
                        <span className='last-entry'> 
                            {rowCount}
                        </span>{' '}
                        of <span className='total-entries'>{tableData.length}</span> entries{' '}
                    </span>
                    <span className="actions">
                        <Button
                            dataTestId="previous-page"
                            label={'Previous'}
                            onPress={() => previousPage()}
                            disabled={!canPreviousPage}
                            variant="outline"
                            size="small"
                            className="cta_button_next"
                            iconTitle="pagination_left"
                            iconBefore={true}
                            iconSize="lg"
                        />
                        <Button
                            dataTestId="next-page"
                            label={'Next'}
                            onPress={() => nextPage()}
                            disabled={!canNextPage}
                            variant="outline"
                            size="small"
                            className="cta_button_previous"
                            iconTitle="pagination_right"
                            iconBefore={false}
                            iconSize="lg"
                        />
                    </span>
                </div>
            ) : null}
        </div>
    );
};

export default Table;
