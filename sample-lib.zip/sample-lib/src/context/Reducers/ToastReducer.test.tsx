import { toastReducer } from './ToastReducer';

describe('toastReducer', () => {
    const initialState = {
        toasts: [
            { id: 1, message: 'Toast 1', type: 'success' },
            { id: 2, message: 'Toast 2', type: 'error' }
        ]
    };

    it('should add a new toast', () => {
        const newToast = { id: 3, message: 'New Toast', type: 'info' };
        const newState = toastReducer(initialState, { type: 'ADD_TOAST', payload: newToast });

        expect(newState.toasts).toHaveLength(3);
        expect(newState.toasts).toContainEqual(newToast);
    });

    it('should delete a toast', () => {
        const toastIdToDelete = 2;
        const newState = toastReducer(initialState, {
            type: 'DELETE_TOAST',
            payload: toastIdToDelete
        });

        expect(newState.toasts).toHaveLength(2);
        expect(
            newState.toasts.some((toast) => toast.id === toastIdToDelete && toast.type === 'empty')
        ).toBe(true);
    });

    it('should clear all toasts', () => {
        const newState = toastReducer(initialState, { type: 'CLEAR_TOASTS' });

        expect(newState.toasts).toHaveLength(0);
    });

    it('should throw an error for an unhandled action type', () => {
        const invalidAction = { type: 'INVALID_ACTION' };

        expect(() => toastReducer(initialState, invalidAction)).toThrowError(
            'Unhandled action type: INVALID_ACTION'
        );
    });
});
