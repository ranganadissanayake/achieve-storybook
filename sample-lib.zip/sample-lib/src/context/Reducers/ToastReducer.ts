export const toastReducer = (state, action) => {
    switch (action.type) {
        case 'ADD_TOAST':
            return {
                ...state,
                toasts: [...state.toasts, action.payload]
            };
        case 'DELETE_TOAST':
            const updatedToasts = state.toasts.map((toast) => {
                if (toast.id === action.payload) {
                    return { ...toast, type: 'empty' };
                }
                return toast;
            });
            return {
                ...state,
                toasts: updatedToasts
            };
        case 'CLEAR_TOASTS':
            return {
                ...state,
                toasts: []
            };
        default:
            throw new Error(`Unhandled action type: ${action.type}`);
    }
};
