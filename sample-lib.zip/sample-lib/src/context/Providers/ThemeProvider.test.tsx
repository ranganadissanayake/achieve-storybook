import React from 'react';
import { render} from '@testing-library/react';
import ThemeProvider, { ThemeType } from './themeProvider';

describe('ThemeProvider', () => {
    const mockChildren = <div>Mock children</div>;

    test('renders children with default theme from context', () => {
        const { getByText } = render(<ThemeProvider>{mockChildren}</ThemeProvider>);

        const children = getByText('Mock children');
        expect(children).toBeInTheDocument();
    });

    test('applies custom theme when provided', () => {
        const customTheme: ThemeType[] = [
            {
                light: {
                    primary: 'red',
                    text: 'black'
                }
            }
        ];

        render(<ThemeProvider theme={customTheme}>{mockChildren}</ThemeProvider>);
    });
});
