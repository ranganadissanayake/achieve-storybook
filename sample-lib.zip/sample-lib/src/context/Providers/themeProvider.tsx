import React from 'react';
import ThemeContext, { initialThemeState } from '../Contexts/themeContext';

import '../../theme/index.scss';
import { ToastContextProvider } from '../Contexts/ToastContext';

export type Style = {
    primary?: string;
    text?: string;
    'primary-gradient'?: string;
    highlight?: string;
    active?: string;
};

export type ThemeType = {
    light?: Style;
    dark?: Style;
};

export type ProviderProps = React.PropsWithChildren & {
    mode?: string;
    theme?: ThemeType[];
};

const applyTheme = (theme: ThemeType[]) => {
    Object.keys(theme).forEach((themeKey) => {
        Object.keys(theme[themeKey]).forEach((key) => {
            let value = theme[themeKey][key];
            document.documentElement.style.setProperty(`--${themeKey}-${key}`, value);
        });
    });
};

const ThemeProvider = ({ mode, theme, children }: ProviderProps) => {
    const [selectedTheme, setTheme] = React.useState(mode || initialThemeState.theme);

    React.useEffect(() => {
        if (theme && Object.keys(theme).length !== 0) {
            applyTheme(theme);
        }
    }, []);

    React.useEffect(() => {
        if (mode !== selectedTheme) {
            setTheme(mode);
        }
    }, [mode]);

    return (
        <ThemeContext.Provider value={{ theme: selectedTheme, setTheme }}>
            <div className={`theme--${selectedTheme}`}>
                <ToastContextProvider>{children}</ToastContextProvider>
            </div>
        </ThemeContext.Provider>
    );
};

export default ThemeProvider;
