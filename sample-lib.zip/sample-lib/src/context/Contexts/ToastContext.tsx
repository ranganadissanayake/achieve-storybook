import React, { createContext, useEffect, useReducer } from 'react';
import { toastReducer } from '../Reducers/ToastReducer';
import { RandomId } from '../../utils';
import { Toast } from '../../components';
import { ToastItem } from '../../components/Molecules/Toast';
import { IconName } from '../../components/Assets/icons/iconLib';

export interface ToastViewOptions {
    /**
     * Set className extention
     */
    className?: string;
    /**
     * Set the position of the Toast
     */
    position?: 'top' | 'bottom';
    /**
     * Auto disappear time
     */
    timeout?: number;
    /**
     * Add a delete sideeffect function to be called on delete
     */
    deleteSideEffect?: () => void;
}
export interface AddToastItem {
    /**
     * Set the title of the Toast
     */
    title?: string;
    /**
     * Set the type of the Toast
     */
    type: 'success' | 'warning' | 'critical' | 'info' | 'empty';
    /**
     * Set the description of the Toast
     */
    description?: string | React.ReactNode;
    /**
     * Set the sussces Toast action title
     */
    actionTitle?: string;
    /**
     * Set the sussces Toast action
     */
    action?: () => void;
    /**
     * Set the action icon
     */
    actionIconTitle?: IconName;
}

type ToastState = {
    /**
     * Toast lists
     */
    toasts?: ToastItem[];
    /**
     * Set a toast action
     */
    addToast: (toast: AddToastItem, options?: ToastViewOptions) => void;
    /**
     * Remove a toast action
     */
    removeToast: (id: string | number) => void;
};

const initialState: ToastState = {
    toasts: [],
    addToast: function (toast: AddToastItem, options?: ToastViewOptions): void {},
    removeToast: function (id: string | number): void {}
};

export const ToastContext = createContext(initialState);

export const ToastContextProvider = ({ children }) => {
    const [state, dispatch] = useReducer(toastReducer, initialState);
    const [options, setOptions] = React.useState<ToastViewOptions>();

    const addToast = (
        { type, title, description, actionTitle, action, actionIconTitle }: AddToastItem,
        toastOptions?: ToastViewOptions
    ) => {
        const id = RandomId();

        if (toastOptions) {
            setOptions(toastOptions);
        }

        dispatch({
            type: 'ADD_TOAST',
            payload: { id, title, description, type, actionTitle, action, actionIconTitle }
        });
    };

    const clearAll = () => {
        dispatch({ type: 'CLEAR_TOASTS' });
    };

    const removeToast = (id: string | number) => {
        dispatch({ type: 'DELETE_TOAST', payload: id });
    };

    useEffect(() => {
        if (state.toasts.length > 0) {
            const interval = setInterval(() => {
                if (state.toasts.every((toast) => toast.type === 'empty')) {
                    clearAll();
                }
            }, 60000);

            return () => {
                clearInterval(interval);
            };
        }
    }, [state.toasts]);

    const value = { addToast, removeToast };

    return (
        <ToastContext.Provider value={value}>
            <Toast {...options} toastList={state.toasts} />
            {children}
        </ToastContext.Provider>
    );
};
