import React, { useContext } from 'react';
import { render, act } from '@testing-library/react';
import ThemeContext, { initialThemeState } from './themeContext';

const MockComponent = () => {
    const { theme, setTheme } = useContext(ThemeContext);

    return (
        <div>
            <span data-testid="theme">{theme}</span>
            <button data-testid="button" onClick={() => setTheme && setTheme('light')}>
                Change Theme
            </button>
        </div>
    );
};

describe('ThemeContext', () => {
    it('should render with initial theme state', () => {
        const { getByTestId } = render(
            <ThemeContext.Provider value={initialThemeState}>
                <MockComponent />
            </ThemeContext.Provider>
        );

        const themeElement = getByTestId('theme');
        expect(themeElement.textContent).toBe('dark');
    });

    it('should update theme when button is clicked', () => {
        const { getByTestId } = render(
            <ThemeContext.Provider value={initialThemeState}>
                <MockComponent />
            </ThemeContext.Provider>
        );

        const themeElement = getByTestId('theme');
        const buttonElement = getByTestId('button');

        act(() => {
            buttonElement.click();
        });

        expect(themeElement.textContent).toBe('dark');
    });
});
