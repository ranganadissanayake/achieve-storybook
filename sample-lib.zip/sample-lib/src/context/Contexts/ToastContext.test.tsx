import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { ToastContextProvider, ToastContext } from './ToastContext';

describe('ToastContextProvider', () => {
    it('renders without crashing', () => {
        render(
            <ToastContextProvider>
                <div>Test child</div>
            </ToastContextProvider>
        );
    });

    it('provides addToast and removeToast functions via context', () => {
        const ChildComponent = () => {
            const toastContext = React.useContext(ToastContext);
            expect(typeof toastContext.addToast).toBe('function');
            expect(typeof toastContext.removeToast).toBe('function');
            return <div>Child</div>;
        };

        render(
            <ToastContextProvider>
                <ChildComponent />
            </ToastContextProvider>
        );
    });

    it('adds and removes toasts', () => {
        const ChildComponent = () => {
            const toastContext = React.useContext(ToastContext);

            const handleClick = () => {
                toastContext.addToast({
                    type: 'info'
                });
            };

            const handleRemove = () => {
                toastContext.removeToast(123);
            };

            return (
                <div>
                    <button onClick={handleClick}>Add Toast</button>
                    <button onClick={handleRemove}>Remove Toast</button>
                </div>
            );
        };

        const { getByText } = render(
            <ToastContextProvider>
                <ChildComponent />
            </ToastContextProvider>
        );
        fireEvent.click(getByText('Add Toast'));
        fireEvent.click(getByText('Remove Toast'));
    });

    it('sets options and dispatches action when addToast is called', () => {
        const MockChild = () => {
            const { addToast } = React.useContext(ToastContext);
            const handleClick = () => {
                addToast({
                    type: 'info'
                });
            };
            return <button onClick={handleClick}>Add Toast</button>;
        };

        const { getByText } = render(
            <ToastContextProvider>
                <MockChild />
            </ToastContextProvider>
        );
        fireEvent.click(getByText('Add Toast'));
    });

    it('dispatches action with toast options when addToast is called with toastOptions', () => {
        const MockChild = () => {
            const { addToast } = React.useContext(ToastContext);
            const handleClick = () => {
                addToast(
                    {
                        type: 'info'
                    },
                    {
                        className: 'custom-class',
                        position: 'top',
                        timeout: 5000
                    }
                );
            };
            return <button onClick={handleClick}>Add Toast</button>;
        };

        const { getByText } = render(
            <ToastContextProvider>
                <MockChild />
            </ToastContextProvider>
        );
        fireEvent.click(getByText('Add Toast'));
    });
});