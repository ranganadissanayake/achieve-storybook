import React from 'react';

type ThemeState = {
    theme: string;
    setTheme?: React.Dispatch<React.SetStateAction<string>>;
};

export const initialThemeState: ThemeState = {
    theme: 'dark'
};

const ThemeContext = React.createContext(initialThemeState);
export default ThemeContext;
