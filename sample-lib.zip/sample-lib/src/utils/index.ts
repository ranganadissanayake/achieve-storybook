export const RandomId = () => new Date().getTime().toString() + Math.floor(Math.random() * 1000000);
