import { useContext } from 'react';
import { ToastContext } from '../context/Contexts/ToastContext';

const useToast = () => useContext(ToastContext);

export default useToast;
