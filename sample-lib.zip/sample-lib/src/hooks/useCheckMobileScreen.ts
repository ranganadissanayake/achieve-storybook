import React, { useEffect, useState } from 'react';

const useCheckMobileScreen = () => {
    const [width, setWidth] = useState(window.innerWidth);
    const handleWindowSizeChange = () => {
        setWidth(window.innerWidth);
    };

    useEffect(() => {
        window.addEventListener('onload', handleWindowSizeChange);
        return () => {
            window.removeEventListener('onload', handleWindowSizeChange);
        };
    }, []);

    useEffect(() => {
        window.addEventListener('resize', handleWindowSizeChange);
        return () => {
            window.removeEventListener('resize', handleWindowSizeChange);
        };
    }, []);

    return width <= 912;
};

export default useCheckMobileScreen;
