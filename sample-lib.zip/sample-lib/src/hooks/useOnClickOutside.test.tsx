import { renderHook, act } from '@testing-library/react';
import useOnClickOutside from './useOnClickOutside';

// Mock RefObject
const mockRef = {
    current: document.createElement('div')
};

describe('useOnClickOutside', () => {
    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should call the handler function when clicking outside of the ref element', () => {
        const handler = jest.fn();
        const { unmount } = renderHook(() => useOnClickOutside(mockRef, handler));

        act(() => {
            document.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        });
        expect(handler).toHaveBeenCalled();
        unmount();
    });

    it('should not call the handler function when clicking inside of the ref element', () => {
        const handler = jest.fn();
        const { unmount } = renderHook(() => useOnClickOutside(mockRef, handler));

        act(() => {
            mockRef.current.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        });
        expect(handler).not.toHaveBeenCalled();
        unmount();
    });

    it('should call the handler function when touching outside of the ref element', () => {
        const handler = jest.fn();
        const { unmount } = renderHook(() => useOnClickOutside(mockRef, handler));

        act(() => {
            document.dispatchEvent(new TouchEvent('touchstart', { bubbles: true }));
        });
        expect(handler).toHaveBeenCalled();
        unmount();
    });

    it('should not call the handler function when touching inside of the ref element', () => {
        const handler = jest.fn();
        const { unmount } = renderHook(() => useOnClickOutside(mockRef, handler));

        act(() => {
            mockRef.current.dispatchEvent(new TouchEvent('touchstart', { bubbles: true }));
        });
        expect(handler).not.toHaveBeenCalled();
        unmount();
    });
});
